-- NIGHT SHIFT 4.5: anticipatory creature poses, sound search and fair pursuit.
-- Movement stays on computed paths and verified support. No teleport fallback.
local Threat = {}
Threat.__index = Threat

local function flat(v)
    return Vector3.new(v.X, 0, v.Z)
end

local NOISE_WEIGHT = {walk = .55, run = 1, sprint = 1, door = .9, repair = 1.15,
    generator = 1.2, switch = .6, pickup = .65, item_drop = .85, customer_error = 1.2,
    machinery = 1.1, alarm = 1.25, glass = 1.25, radio = .65}
local DEFAULT_PATROL = {
    Vector3.new(-24, .8, 11), Vector3.new(1, .8, 7), Vector3.new(30, .8, 5),
    Vector3.new(31, .8, -8), Vector3.new(32, .8, -19), Vector3.new(-2, .8, -23),
    Vector3.new(2, .8, -44), Vector3.new(7, -10, -84), Vector3.new(13, -10, -96),
    Vector3.new(-21, -10, -93), Vector3.new(32, -10, -94), Vector3.new(53, .4, 0),
}
local function validPosition(position)
    return typeof(position) == "Vector3" and position.X == position.X and position.Y == position.Y
        and position.Z == position.Z and math.abs(position.X) < 100000 and math.abs(position.Y) < 100000
        and math.abs(position.Z) < 100000
end

-- A brief glimpse creates suspicion, rather than an immediate full-speed attack.
function Threat.RecognitionSeconds(distance, variantName, night, lit)
    local seconds = 1.5 - math.min(8, math.max(0, (night or 1) - 1)) * .045
    if variantName == "THE_WATCHER" or variantName == "THE WATCHER" then seconds *= .85 end
    if variantName == "THE_RUNNER" or variantName == "THE RUNNER" then seconds *= 1.1 end
    if variantName == "THE CRAWLER" then seconds *= 1.25 end -- poor sight; powerful hearing
    if variantName == "THE IMITATOR" then seconds *= 1.38 end -- extended warning to learn its tell
    if distance < 9 then seconds *= .62 end
    if lit then seconds *= .83 end
    return math.clamp(seconds, .55, 1.8)
end

-- Kept pure so visibility decisions can be checked without a renderer.
function Threat.InVisionCone(origin, forward, target, range, cosine)
    local delta = target - origin
    if delta.Magnitude > range then return false end
    if delta.Magnitude <= 7 then return true end
    local direction, facing = flat(delta), flat(forward)
    if direction.Magnitude < 0.01 or facing.Magnitude < 0.01 then return true end
    return direction.Unit:Dot(facing.Unit) >= (cosine or 0.42)
end

function Threat.MemoryDecision(state, lastSeenAt, searchUntil, now, hasVisible, hasNoise)
    if hasVisible then return "CHASE" end
    if state == "CHASE" then return "SEARCH" end
    if hasNoise then return "INVESTIGATE" end
    if (state == "SEARCH" or state == "INVESTIGATE") and now < (searchUntil or lastSeenAt + 12) then return state end
    return "PATROL"
end

function Threat.new(ctx)
    return setmetatable({ctx = ctx, token = 0, noises = {}, suspicions = {}, cueTimes = {},
        unreachableUntil = {}, recentPatrol = {}, state = "IDLE", lastSeenAt = -100, nextStepSound = 0}, Threat)
end

function Threat:_cue(player, state, message, intensity)
    if not player or player.Parent ~= self.ctx.Players or type(self.ctx.cue) ~= "function" then return end
    local now = self.ctx.clock()
    local last = self.cueTimes[player]
    if last and last.state == state and now - last.at < .6 then return end
    self.cueTimes[player] = {state = state, at = now}
    pcall(self.ctx.cue, player, {state = state, text = message, intensity = math.clamp(intensity or 0, 0, 1),
        duration = state == "IDLE" and .2 or 1.8, position = self.root and self.root.Position})
end

function Threat:_sound(kind, caption, player)
    if self.root and type(self.ctx.sound) == "function" then
        self.ctx.sound(kind, self.root.Position, caption, player)
    end
end

function Threat:_lit(player)
    local character = player and player.Character
    local tool = character and character:FindFirstChild("NightShiftFlashlight")
    local handle = tool and tool:FindFirstChild("Handle")
    local beam = handle and handle:FindFirstChild("FlashlightBeam")
    return beam ~= nil and beam.Enabled == true
end

function Threat:_patrolPoints()
    local points = {}
    for _, point in ipairs(DEFAULT_PATROL) do table.insert(points, point) end
    if type(self.ctx.getPatrolPoints) == "function" then
        local ok, extra = pcall(self.ctx.getPatrolPoints)
        if ok and type(extra) == "table" then
            for index, point in ipairs(extra) do
                if index > 120 then break end
                if validPosition(point) then table.insert(points, point) end
            end
        end
    end
    return points
end

function Threat:_rayClear(origin, destination, targetCharacter)
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    local excluded = {}
    if self.model then table.insert(excluded, self.model) end
    if targetCharacter then table.insert(excluded, targetCharacter) end
    params.FilterDescendantsInstances = excluded
    params.RespectCanCollide = true
    params.IgnoreWater = true
    return self.ctx.Workspace:Raycast(origin, destination - origin, params) == nil
end

function Threat:_eligible(player)
    if not self.ctx.isTargetable(player) then return nil end
    local character = player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    local human = character and character:FindFirstChildOfClass("Humanoid")
    if not root or not human or human.Health <= 0 then return nil end
    return root
end

function Threat:_canSee(player)
    local target = self:_eligible(player)
    if not target or player:GetAttribute("NightShiftHidden") then return false end
    local range = self.variant.name == "THE WATCHER" and 56 or
        (self.variant.name == "THE CRAWLER" and 29 or self.variant.name == "THE IMITATOR" and 38 or 43)
    if self:_lit(player) then range += self.variant.name == "THE WATCHER" and 25 or 8 end
    local eye = self.root.Position + Vector3.new(0, 0.8, 0)
    local head = player.Character:FindFirstChild("Head") or target
    if not Threat.InVisionCone(eye, self.root.CFrame.LookVector, head.Position, range, 0.42) then return false end
    return self:_rayClear(eye, head.Position, player.Character)
end

function Threat:ChooseSpawn(points)
    local safe = {}
    for _, position in ipairs(points) do
        local acceptable = validPosition(position)
        if not acceptable then continue end
        for _, player in ipairs(self.ctx.Players:GetPlayers()) do
            local character = player.Character
            local root = character and character:FindFirstChild("HumanoidRootPart")
            local head = character and (character:FindFirstChild("Head") or root)
            if root and head then
                if (root.Position - position).Magnitude < 26 then acceptable = false; break end
                if Threat.InVisionCone(head.Position, head.CFrame.LookVector, position, 85, 0.1)
                    and self:_rayClear(head.Position, position, character) then acceptable = false; break end
                if player:GetAttribute("NightShiftCCTV") then
                    local folder = self.ctx.getWorld():FindFirstChild("CameraPoints")
                    local index = tonumber(player:GetAttribute("NightShiftCameraIndex")) or 1
                    local point = folder and folder:FindFirstChild(string.format("Cam%02d", index))
                    if point and Threat.InVisionCone(point.Position, point.CFrame.LookVector, position, 90, 0.25)
                        and self:_rayClear(point.Position, position) then acceptable = false; break end
                end
            end
        end
        if acceptable then table.insert(safe, position) end
    end
    if #safe == 0 then return nil end
    return safe[self.ctx.random:NextInteger(1, #safe)]
end

function Threat:Noise(position, kind, radius, player)
    if not validPosition(position) or not self.model then return end
    local amount = tonumber(radius) or 18
    if amount ~= amount or amount == math.huge or amount == -math.huge then return end
    local now = self.ctx.clock()
    -- Coalesce rapid repeats from the same actor; noisy work stays audible without
    -- allowing an unbounded queue or updating a sound to an unseen future position.
    local last = self.noises[#self.noises]
    if player and last and last.player == player and last.kind == kind and now - last.at < .18 then return end
    table.insert(self.noises, {position = position, kind = kind, radius = math.clamp(amount, 4, 65), player = player, at = now})
    while #self.noises > 24 do table.remove(self.noises, 1) end
end

function Threat:OnHide(player, locker)
    if not self.root or not self.model or self.target ~= player then return end
    -- The player has ALREADY gained NightShiftHidden when this callback fires.
    -- _canSee would always reject them; use remembered LOS to the cabinet instead.
    if self.ctx.clock()-self.lastSeenAt>1.1 then return end
    local eye=self.root.Position+Vector3.new(0,.8,0)
    if not Threat.InVisionCone(eye,self.root.CFrame.LookVector,locker.Position,32,.05) then return end
    local params=RaycastParams.new()
    params.FilterType=Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances={self.model,player.Character}
    params.RespectCanCollide=true
    local obstruction=self.ctx.Workspace:Raycast(eye,locker.Position-eye,params)
    -- Lockers live directly under the world in the base map.  Checking
    -- IsDescendantOf(locker.Parent) would incorrectly treat ALL world walls as
    -- the locker, letting the creature see a hide action through solid walls.
    if obstruction and obstruction.Instance~=locker then return end
    self.lockerMemory = {player = player, locker = locker, noticedAt = self.ctx.clock()}
    self.target = nil
    self:_setState("CHECK_LOCKER", locker:GetAttribute("HideExit") or locker.Position)
    self:_cue(player, "CHECK_LOCKER", "Вход в укрытие замечен. Смените позицию.", .9)
    self.ctx.notify(player, "Он заметил, в какой шкаф ты вошёл. Есть несколько секунд, чтобы сменить укрытие.")
end

function Threat:_setState(state, goal)
    if self.state ~= state then
        self.state = state
        self.path = nil
        self.lastPathAt = -100
        if self.model then self.model:SetAttribute("Behavior", state) end
    end
    if goal then self.goal = goal end
end

function Threat:_beginSearch(position, now, seconds)
    self.target, self.suspicionTarget = nil, nil
    self.recoveryGoal, self.stuckCount = nil, 0
    self.searchAnchor = position
    self.searchUntil = now + (seconds or 12)
    self.searchVisits, self.searchPauseAt = {}, nil
    self:_setState("SEARCH", position)
end

function Threat:_sense(now)
    if not self.root or not self.root.Parent then return end
    local dt = math.clamp(now - (self.lastSenseAt or now - .1), 0, .25)
    self.lastSenseAt = now
    local closest, closestRoot, best = nil, nil, math.huge
    for _, player in ipairs(self.ctx.Players:GetPlayers()) do
        local target = self:_eligible(player)
        local visible = target and now >= (self.unreachableUntil[player] or -100) and self:_canSee(player)
        local meter = self.suspicions[player]
        if meter and meter.character ~= player.Character then self.suspicions[player] = nil; meter = nil end
        if visible then
            local distance = (target.Position - self.root.Position).Magnitude
            if not meter then meter = {value = 0, character = player.Character}; self.suspicions[player] = meter end
            meter.value = math.min(1, meter.value + dt / Threat.RecognitionSeconds(distance, self.variant.name, self.ctx.getRound().number, self:_lit(player)))
            meter.seenAt = now
            local score = distance - ((player == self.target or player == self.suspicionTarget) and 8 or 0)
            if score < best then closest, closestRoot, best = player, target, score end
        elseif meter then
            meter.value = math.max(0, meter.value - dt * .8)
            if meter.value <= 0 or not target then self.suspicions[player] = nil; self:_cue(player, "IDLE", "", 0) end
        end
    end
    for player in pairs(self.suspicions) do
        if player.Parent ~= self.ctx.Players then self.suspicions[player], self.cueTimes[player], self.unreachableUntil[player] = nil, nil, nil end
    end
    for player in pairs(self.cueTimes) do if player.Parent ~= self.ctx.Players then self.cueTimes[player] = nil end end
    for player in pairs(self.unreachableUntil) do if player.Parent ~= self.ctx.Players or now >= self.unreachableUntil[player] then self.unreachableUntil[player] = nil end end
    if closest then
        local meter = self.suspicions[closest]
        self.lastSeenAt, self.lastKnown = now, closestRoot.Position
        self.lockerMemory = nil
        if meter.value < 1 and self.target ~= closest then
            if self.state ~= "SUSPICIOUS" or self.suspicionTarget ~= closest then
                self:_sound("monster_notice", "Существо насторожилось")
            end
            self.suspicionTarget, self.target = closest, nil
            self:_setState("SUSPICIOUS", self.lastKnown)
            self:_cue(closest, "SUSPICIOUS", "Вас замечают. Разорвите линию обзора.", meter.value)
            return
        end
        local newTarget = self.target ~= closest or self.state ~= "CHASE"
        self.target, self.suspicionTarget = closest, nil
        self:_setState("CHASE", self.lastKnown)
        if newTarget then
            self.recoveryGoal, self.stuckCount = nil, 0
            self.path, self.pathIndex, self.lastPathAt = nil, 1, -100
            self.chaseStarted = now
            self.attackReadyAt = now + .65
            self:_sound(self.variant.name=="THE CRAWLER" and "crawler_scrape" or
                self.variant.name=="THE IMITATOR" and "mimic_voice" or "threat",
                "Существо преследует сотрудника")
        end
        if now < (self.staggerUntil or 0) then
            self:_cue(closest, "STAGGER", "Луч задержал Смотрителя. Используйте паузу.", .45)
        elseif self.variant.name == "THE CRAWLER" then
            self:_cue(closest,"CHASE","Ползун слышит шаги и работу инструментов. Двигайтесь тише.",1)
        elseif self.variant.name == "THE IMITATOR" then
            self:_cue(closest,"CHASE","Поддельный сотрудник приближается. Свет может его остановить.",1)
        elseif self.variant.name == "THE RUNNER" and (now - (self.chaseStarted or now)) % 10 >= 7 then
            self:_cue(closest, "RECOVER", "Бегун замедлился. Меняйте маршрут.", .6)
        else self:_cue(closest, "CHASE", "Погоня. Скрывайтесь за углами; не бегите прямо.", 1) end
        -- Watcher counterplay has line of sight, distance and facing requirements.
        -- A flashlight also makes its owner visible from farther away.
        if (self.variant.name=="THE WATCHER" or self.variant.name=="THE IMITATOR") and self:_lit(closest)
            and now >= (self.nextStaggerAt or 0)
            and now - (self.chaseStarted or now) >= .7 then
            local head = closest.Character:FindFirstChild("Head") or closestRoot
            if Threat.InVisionCone(head.Position, head.CFrame.LookVector, self.root.Position, 22, .82)
                and (head.Position - self.root.Position).Magnitude > 7 then
                self.staggerUntil=now+(self.variant.name=="THE IMITATOR" and 1.15 or 1.6)
                self.nextStaggerAt=now+(self.variant.name=="THE IMITATOR" and 11 or 14)
                self:_sound(self.variant.name=="THE IMITATOR" and "mimic_voice" or "monster_breath","Существо отступает от света")
                self:_cue(closest,"STAGGER","Свет ненадолго задержал существо.",.45)
            end
        end
        return
    end
    if self.suspicionTarget then
        local previous = self.suspicionTarget
        self.suspicionTarget = nil
        self:_beginSearch(self.lastKnown, now, 7)
        self:_cue(previous, "SEARCH", "Обзор потерян. Существо проверяет последнее место.", .35)
        self:_sound("monster_search", "Существо прислушивается")
    end
    if self.lockerMemory then
        local memory = self.lockerMemory
        if memory.locker.Parent and self.ctx.getHiddenLocker(memory.player) == memory.locker and now - memory.noticedAt < 17 then
            self:_setState("CHECK_LOCKER", memory.locker:GetAttribute("HideExit") or memory.locker.Position)
            return
        end
        self.lastKnown = self.goal
        self.lockerMemory = nil
        self:_beginSearch(self.lastKnown, now, 9)
    end
    if self.state == "CHASE" then
        local previous = self.target
        self:_beginSearch(self.lastKnown, now, 12)
        self:_cue(previous, "SEARCH", "Обзор потерян. Не выдавайте себя шумом.", .4)
        self:_sound("monster_search", "Существо ищет след")
    end
    local heard, bestNoise
    for index = #self.noises, 1, -1 do
        local noise = self.noises[index]
        if now - noise.at > 2.5 then
            table.remove(self.noises, index)
        else
            local distance = (noise.position - self.root.Position).Magnitude
            local hearing=self.variant.name=="THE CRAWLER" and 1.95 or
                self.variant.name=="THE RUNNER" and 1.6 or self.variant.name=="THE IMITATOR" and .8 or 1
            local radius=noise.radius*(NOISE_WEIGHT[noise.kind] or 1)*hearing
            if not self:_rayClear(self.root.Position, noise.position, noise.player and noise.player.Character) then radius *= .62 end
            local strength = radius - distance
            if strength > 0 and (not bestNoise or strength > bestNoise) then heard, bestNoise = noise, strength end
        end
    end
    if heard and heard.at > (self.lastHeardAt or -100) then
        self.lastHeardAt = heard.at
        self.searchUntil, self.searchAnchor, self.searchPauseAt = now + 10, heard.position, nil
        self.searchVisits = {}
        self:_setState("INVESTIGATE", heard.position)
        if now >= (self.nextListenSound or 0) then
            self.nextListenSound = now + 5
            self:_sound("monster_search", "Существо услышало шум")
        end
    elseif (self.state == "SEARCH" or self.state == "INVESTIGATE") and now >= (self.searchUntil or now) then
        self:_setState("PATROL")
        self.goal, self.searchAnchor, self.searchPauseAt = nil, nil, nil
        self:_sound("monster_retreat", "Шаги удаляются")
    end
end

function Threat:_patrolGoal()
    local points, candidates, fresh, nearby = self:_patrolPoints(), {}, {}, {}
    for _, point in ipairs(points) do
        local distance = (point - self.root.Position).Magnitude
        -- Stay on the same walkable floor when selecting patrol goals.
        if distance > 8 and distance < 75 and math.abs((point.Y+4.1)-self.root.Position.Y)<5.5 then
            table.insert(candidates, point)
            local used = false
            for _, old in ipairs(self.recentPatrol) do if (old - point).Magnitude < 4 then used = true; break end end
            if not used then
                table.insert(fresh, point)
                if distance < 45 then table.insert(nearby, point) end
            end
        end
    end
    self.patrolSelections = (self.patrolSelections or 0) + 1
    if #nearby > 0 and self.patrolSelections % 5 ~= 0 then candidates = nearby
    elseif #fresh > 0 then candidates = fresh elseif #candidates == 0 then candidates = points end
    local selected = candidates[self.ctx.random:NextInteger(1, #candidates)]
    table.insert(self.recentPatrol, selected)
    while #self.recentPatrol > 4 do table.remove(self.recentPatrol, 1) end
    return selected
end

function Threat:_nextSearchPoint(now)
    if not self.searchAnchor or now >= (self.searchUntil or 0) then return end
    if not self.searchPauseAt then self.searchPauseAt = now; return end
    if now - self.searchPauseAt < 1.2 then return end
    self.searchVisits = self.searchVisits or {}
    if #self.searchVisits >= 3 then return end
    local candidates = {}
    for _, point in ipairs(self:_patrolPoints()) do
        local near = (flat(point - self.searchAnchor)).Magnitude
        if near > 3 and near < 28 and math.abs(point.Y - self.searchAnchor.Y) < 5 then
            local used = false
            for _, old in ipairs(self.searchVisits) do if (old - point).Magnitude < 3 then used = true; break end end
            if not used then table.insert(candidates, point) end
        end
    end
    if #candidates > 0 then
        local chosen = candidates[self.ctx.random:NextInteger(1, #candidates)]
        table.insert(self.searchVisits, chosen)
        self.goal, self.path, self.lastPathAt, self.searchPauseAt = chosen, nil, -100, nil
    end
end

function Threat:_recoveryGoal()
    if not self.root or not self.root.Parent then return nil end
    local origin = self.root.Position
    local forward = flat((self.goal or (origin + self.root.CFrame.LookVector * 6)) - origin)
    if forward.Magnitude < .05 then forward = flat(self.root.CFrame.LookVector) end
    if forward.Magnitude < .05 then forward = Vector3.new(0, 0, -1) end
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    local excluded = {self.model}
    for _, player in ipairs(self.ctx.Players:GetPlayers()) do
        if player.Character then table.insert(excluded, player.Character) end
    end
    params.FilterDescendantsInstances = excluded
    params.RespectCanCollide = true
    params.IgnoreWater = true
    for _, radius in ipairs({4.5, 6.5, 8.5}) do
        for _, degrees in ipairs({-65, -40, 40, 65, 115, -115, 180, 0}) do
            local direction = CFrame.Angles(0, math.rad(degrees), 0):VectorToWorldSpace(forward.Unit)
            local candidate = origin + direction * radius
            local floor = self.ctx.Workspace:Raycast(candidate + Vector3.new(0, 2.5, 0), Vector3.new(0, -9, 0), params)
            if floor and floor.Normal.Y > .55 and math.abs((floor.Position.Y + 4.1) - origin.Y) < 1.55 then
                local grounded = Vector3.new(candidate.X, floor.Position.Y + 4.1, candidate.Z)
                local sweep = self.ctx.Workspace:Blockcast(CFrame.new(origin + Vector3.new(0, .15, 0)),
                    Vector3.new(2.0, 5.2, 1.9), grounded - origin, params)
                if not sweep then return grounded end
            end
        end
    end
    return nil
end

function Threat:_computePath(goal, token)
    if self.pathBusy or not validPosition(goal) or not self.root then return end
    self.pathBusy, self.pathToken = true, token
    local job = {paths = {}}
    local ok = pcall(self._buildPath, self, goal, token, job)
    for _, path in ipairs(job.paths) do pcall(function() path:Destroy() end) end
    if self.pathToken == token then self.pathBusy = false end
    if not ok and self.token == token then
        self.path = nil
        self.pathFailures = (self.pathFailures or 0) + 1
        self.lastPathAt = self.ctx.clock()
    end
end

function Threat:_buildPath(goal, token, job)
    local now = self.ctx.clock()
    if self.doorBashAt and self.doorTarget and self.doorTarget.Parent and self.doorTarget:GetAttribute("IsOpen") ~= true then return end
    if now - (self.lastPathAt or -100) < 1.15 then return end
    self.lastPathAt = now
    local origin = self.root.Position - Vector3.new(0, 3.6, 0)
    local path = self.ctx.PathfindingService:CreatePath({AgentRadius = 1.35, AgentHeight = 6.6, AgentCanJump = false, WaypointSpacing = 2.0})
    table.insert(job.paths, path)
    local ok = pcall(function() path:ComputeAsync(origin, goal) end)
    if self.token ~= token or not self.root or not self.root.Parent then path:Destroy(); return end
    if ok and path.Status == Enum.PathStatus.Success then
        self.path = path:GetWaypoints()
        self.pathIndex = math.min(2, #self.path)
        self.doorTarget, self.doorBashAt = nil, nil
        self.pathFailures = 0
    else
        self.path = nil
        local candidates = {}
        for panel in pairs(self.ctx.getDoors()) do
            if panel.Parent and panel:GetAttribute("IsOpen") ~= true then
                local normal = panel.Size.X < panel.Size.Z and panel.CFrame.RightVector or panel.CFrame.LookVector
                local side = (self.root.Position - panel.Position):Dot(normal) >= 0 and 1 or -1
                local approach = panel.Position + normal * (side * 4)
                approach = Vector3.new(approach.X, origin.Y, approach.Z)
                table.insert(candidates, {panel = panel, approach = approach, score = (approach - origin).Magnitude + (panel.Position - goal).Magnitude})
            end
        end
        table.sort(candidates, function(a, b) return a.score < b.score end)
        for i = 1, math.min(3, #candidates) do
            local candidate = candidates[i]
            local approachPath = self.ctx.PathfindingService:CreatePath({AgentRadius = 1.35, AgentHeight = 6.6, AgentCanJump = false, WaypointSpacing = 2.0})
            table.insert(job.paths, approachPath)
            local approachOK = pcall(function() approachPath:ComputeAsync(origin, candidate.approach) end)
            if self.token ~= token or not self.root or not self.root.Parent then approachPath:Destroy(); path:Destroy(); return end
            if approachOK and approachPath.Status == Enum.PathStatus.Success then
                self.path = approachPath:GetWaypoints()
                self.pathIndex = math.min(2, #self.path)
                if self.doorTarget ~= candidate.panel then self.doorBashAt = nil end
                self.doorTarget = candidate.panel
                approachPath:Destroy()
                break
            end
            approachPath:Destroy()
        end
    end
    path:Destroy()
    if not self.path then
        self.pathFailures = (self.pathFailures or 0) + 1
        if self.state == "PATROL" then self.goal = nil end
        if self.pathFailures >= 3 and self.target then
            self.unreachableUntil[self.target] = now + 5
            self:_cue(self.target, "SEARCH", "Существо ищет обходной путь.", .4)
            self:_beginSearch(self.lastKnown, now, 7)
        end
    end
end

function Threat:_speed(now)
    local speed = self.variant.speed + math.min(2.2, math.max(0, self.ctx.getRound().number - 1) * .24)
    if self.state == "SUSPICIOUS" then speed *= .27
    elseif self.state ~= "CHASE" then speed *= .67 end
    if self.variant.name == "THE SHADE" and self.ctx.isBlackout() then speed += 1.8 end
    if self.variant.name == "THE CRAWLER" then
        if self.root.Position.Y < -2 then speed += 2.0 else speed -= 1.4 end
    end
    if now < (self.staggerUntil or 0) or now < (self.catchQuietUntil or 0) then return 0 end
    if self.variant.name == "THE RUNNER" and self.state == "CHASE" then
        local cycle = (now - (self.chaseStarted or now)) % 10
        if cycle >= 7 then
            speed *= .62
            if not self.runnerRecovering then
                self.runnerRecovering = true
                self:_sound("monster_breath", "Бегун замедляется и переводит дыхание")
                self:_cue(self.target, "RECOVER", "Бегун замедлился. Меняйте маршрут.", .6)
            end
        else self.runnerRecovering = false end
    end
    return speed
end

function Threat:_move(dt, now)
    local speed = self:_speed(now)
    if speed <= 0 then return end
    if self.doorTarget and self.doorTarget.Parent and self.doorTarget:GetAttribute("IsOpen") ~= true
        and (flat(self.doorTarget.Position - self.root.Position)).Magnitude < 6 then
        local panel = self.doorTarget
        if self:_rayClear(self.root.Position, panel.Position - (panel.Position - self.root.Position).Unit * 0.7) then
            if not self.doorBashAt then self.doorBashAt = now end
            if now >= (self.nextDoorSound or 0) then
                self.nextDoorSound = now + 0.8
                self.ctx.sound("doorHit", panel.Position, "Удары в дверь")
            end
            if now - self.doorBashAt > 2.5 then
                local controller = self.ctx.getDoors()[panel]
                if controller then controller:SetOpen(true) end
                self.doorTarget, self.doorBashAt, self.path = nil, nil, nil
                self.lastPathAt = -100
            end
            return
        end
    end
    local destination
    if self.path and self.path[self.pathIndex] then
        destination = self.path[self.pathIndex].Position + Vector3.new(0, 4.1, 0)
        if (flat(destination - self.root.Position)).Magnitude < 1.05 and math.abs(destination.Y - self.root.Position.Y) < 2 then
            self.pathIndex += 1
            destination = self.path[self.pathIndex] and self.path[self.pathIndex].Position + Vector3.new(0, 4.1, 0) or nil
        end
    end
    if not destination then
        if self.goal and flat(self.goal - self.root.Position).Magnitude < 4 then
            if self.recoveryGoal then
                self.goal, self.recoveryGoal = self.recoveryGoal, nil
                self.path, self.pathIndex, self.lastPathAt = nil, 1, -100
            elseif self.state == "PATROL" then self.goal = nil end
            if self.state == "SEARCH" or self.state == "INVESTIGATE" then
                self.root.CFrame = self.root.CFrame * CFrame.Angles(0, dt * 0.55, 0)
                self:_nextSearchPoint(now)
            end
        end
        return
    end
    local direction = destination - self.root.Position
    if direction.Magnitude < 0.05 then return end
    local movement = direction.Unit * math.min(direction.Magnitude, speed * dt)
    local nextPosition = self.root.Position + movement
    local exclude = {self.model}
    for _, player in ipairs(self.ctx.Players:GetPlayers()) do if player.Character then table.insert(exclude, player.Character) end end
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = exclude
    params.RespectCanCollide = true
    params.IgnoreWater = true
    local floor = self.ctx.Workspace:Raycast(nextPosition + Vector3.new(0, 1.5, 0), Vector3.new(0, -7.2, 0), params)
    if not floor or floor.Normal.Y < 0.5 then self.path = nil; return end
    local y = floor.Position.Y + 4.1
    if math.abs(y - self.root.Position.Y) > 1.35 then self.path = nil; return end
    nextPosition = Vector3.new(nextPosition.X, y, nextPosition.Z)
    movement = nextPosition - self.root.Position
    local blocked = movement.Magnitude > 0.001 and self.ctx.Workspace:Blockcast(CFrame.new(self.root.Position + Vector3.new(0, 0.2, 0)), Vector3.new(2.0, 5.2, 1.9), movement, params)
    if blocked then
        self.path = nil
        if self.ctx.getDoors()[blocked.Instance] then self.doorTarget = blocked.Instance end
        self.blockedSince = self.blockedSince or now
        if now - self.blockedSince > 2.4 then
            self.lastPathAt = math.min(self.lastPathAt or now, now - 1.2)
            if self.target then
                self.unreachableUntil[self.target] = now + 3
                self:_beginSearch(self.lastKnown, now, 6)
            end
        end
        return
    end
    self.blockedSince = nil
    local horizontal = flat(direction)
    if horizontal.Magnitude > 0.01 then self.root.CFrame = CFrame.lookAt(nextPosition, nextPosition + horizontal.Unit) end
    if now > self.nextStepSound then
        self.nextStepSound=now+(self.variant.name=="THE CRAWLER" and (self.state=="CHASE" and .33 or .52)
            or self.state=="CHASE" and .43 or .7)
        local stepKind=self.variant.name=="THE CRAWLER" and "crawler_scrape" or
            self.variant.name=="THE IMITATOR" and "mimic_step" or "step"
        self.ctx.sound(stepKind,nextPosition-Vector3.new(0,4,0),"Шаги существа")
    end
end

function Threat:_inspectLocker(now)
    local memory = self.lockerMemory
    if not memory or not memory.locker.Parent then return end
    local approach = memory.locker:GetAttribute("HideExit") or memory.locker.Position
    if flat(approach - self.root.Position).Magnitude > 4.5 then return end
    if not memory.inspectAt then
        memory.inspectAt = now
        self.ctx.sound("doorHit", memory.locker.Position, "Кто-то проверяет дверцу шкафа")
        self.ctx.notify(memory.player, "Дверцу проверяют. Можно успеть выйти и убежать!")
    elseif now - memory.inspectAt >= 3.5 then
        if self:_eligible(memory.player) and self.ctx.getHiddenLocker(memory.player) == memory.locker then
            self.ctx.forceExit(memory.player)
            local caught = self.ctx.onCaught(memory.player)
            if caught ~= false then self:_sound("monster_attack", "Существо распахивает шкаф") end
            self.catchQuietUntil = now + 2.4
        end
        self.lockerMemory = nil
        self:_beginSearch(approach, now, 7)
    end
end

function Threat:Start(model, root, variant, rigParts, duration)
    self:Stop()
    self.model, self.root, self.variant = model, root, variant
    self.state = "PATROL"
    self.goal, self.target, self.lastKnown, self.path, self.lockerMemory = nil, nil, nil, nil, nil
    self.lastSeenAt, self.lastPathAt = -100, -100
    self.noises, self.suspicions, self.cueTimes, self.unreachableUntil, self.recentPatrol = {}, {}, {}, {}, {}
    self.pathBusy, self.pathFailures, self.lastSenseAt, self.suspicionTarget = false, 0, nil, nil
    self.doorTarget, self.doorBashAt, self.blockedSince = nil, nil, nil
    self.recoveryGoal, self.stuckCount = nil, 0
    local started = self.ctx.clock()
    self.progressPosition, self.progressCheckAt = root.Position, started
    self.searchAnchor, self.searchUntil, self.lastHeardAt = nil, nil, -100
    self.nextStaggerAt, self.staggerUntil, self.catchQuietUntil = 0, 0, 0
    self.runnerRecovering, self.chaseStarted, self.patrolSelections = false, nil, 0
    self.nextStepSound, self.nextListenSound = 0, 0
    local token = self.token
    self.attackReadyAt, self.spawnSafeUntil = started + 1.25, started + 1.25
    model:SetAttribute("Behavior", "PATROL")
    task.spawn(function()
        local previous = started
        while self.token == token and model.Parent and root.Parent and self.ctx.getRound().phase == "SHIFT" and self.ctx.clock() - started < duration do
            local now = self.ctx.clock()
            local dt = math.clamp(now - previous, 0, 0.15)
            previous = now
            self:_sense(now)
            if self.target and now >= math.max(self.attackReadyAt or 0, self.spawnSafeUntil or 0, self.staggerUntil or 0, self.catchQuietUntil or 0)
                and self:_canSee(self.target) then
                local target = self:_eligible(self.target)
                if target and (target.Position - root.Position).Magnitude < 4.5 then
                    local caught = self.ctx.onCaught(self.target)
                    if caught ~= false then self:_sound("monster_attack", "Резкий рывок и удар") end
                    self.catchQuietUntil = now + 2.4
                    self:_beginSearch(self.lastKnown, now, 6)
                end
            end
            if not self.goal then self.goal = self:_patrolGoal() end
            self:_computePath(self.goal, token)
            if self.token ~= token or not root.Parent then break end
            previous = self.ctx.clock() -- Pathfinding yields must not become a movement jump.
            self:_inspectLocker(now)
            local before = root.Position
            self:_move(dt, now)
            if now - (self.progressCheckAt or now) >= 1.15 then
                local progress = flat(root.Position - (self.progressPosition or root.Position)).Magnitude
                local goalDistance = self.goal and flat(self.goal - root.Position).Magnitude or 0
                local doorBashing = self.doorTarget and self.doorTarget.Parent and self.doorTarget:GetAttribute("IsOpen") ~= true
                    and flat(self.doorTarget.Position - root.Position).Magnitude < 6
                local intentionallyPaused = now < (self.staggerUntil or 0) or now < (self.catchQuietUntil or 0)
                    or self.state == "CHECK_LOCKER" or doorBashing
                if goalDistance > 5 and progress < .42 and not intentionallyPaused then
                    self.stuckCount = (self.stuckCount or 0) + 1
                    self.path, self.pathIndex = nil, 1
                    self.lastPathAt = now - 1.2
                    if self.stuckCount >= 2 then
                        local escape = self:_recoveryGoal()
                        if escape then
                            if not self.recoveryGoal then self.recoveryGoal = self.goal end
                            self.goal = escape
                            self.lastPathAt = -100
                        elseif self.target then
                            self.unreachableUntil[self.target] = now + 3
                            self:_beginSearch(self.lastKnown, now, 5)
                        else
                            self.goal = self:_patrolGoal()
                        end
                    end
                    if self.stuckCount >= 4 then
                        if self.target then self.unreachableUntil[self.target] = now + 4 end
                        self.target = nil
                        self.recoveryGoal = nil
                        self:_beginSearch(self.lastKnown or root.Position, now, 5)
                        self.stuckCount = 0
                    end
                else
                    self.stuckCount = 0
                end
                self.progressPosition, self.progressCheckAt = root.Position, now
            end
            local elapsed = now - started
            local moved = (root.Position - before).Magnitude > .02
            local cycle=self.variant.name=="THE CRAWLER" and (self.state=="CHASE" and 12 or 7)
                or self.variant.name=="THE IMITATOR" and (self.state=="CHASE" and 6 or 3)
                or (self.state=="CHASE" and 9 or 5)
            local gait=moved and math.sin(elapsed*cycle) or 0
            local gaitL, gaitR = gait, -gait
            local wary = self.state == "SUSPICIOUS" or self.state == "SEARCH" or self.state == "INVESTIGATE"
            local chasing = self.state == "CHASE"
            local breathing=math.sin(elapsed*(chasing and 4.8 or 1.65))
            local leaning=chasing and -.19 or wary and -.095 or .025
            local listen = wary and math.sin(elapsed*1.25)*.2 or 0
            local bob = moved and math.abs(math.sin(elapsed*cycle*2))*.055 or math.sin(elapsed*1.7)*.025
            local sway = math.sin(elapsed*(chasing and 5.5 or 1.15))*(chasing and .11 or .055)
            local headTurn = listen
            if self.target then
                local targetRoot = self:_eligible(self.target)
                if targetRoot then
                    local direction = flat(targetRoot.Position - root.Position)
                    if direction.Magnitude > .1 then
                        headTurn = math.clamp(math.atan2(root.CFrame.LookVector:Cross(direction.Unit).Y,
                            root.CFrame.LookVector:Dot(direction.Unit)), -.52, .52)
                    end
                end
            end
            for _, rig in ipairs(rigParts) do
                if rig.part and rig.part.Parent then
                    local pose = CFrame.new(0, bob + breathing*.025, 0)
                    local kind = rig.kind
                    if kind == "torso" then
                        pose = CFrame.new(0,bob+breathing*.035,0) * CFrame.Angles(leaning+breathing*.035,0,sway)
                    elseif kind == "shoulders" then
                        pose = CFrame.new(0,breathing*.018,0) * CFrame.Angles(leaning*.55,sway*.2,-sway*.28)
                    elseif kind == "neck" then pose = CFrame.Angles(leaning*.4,headTurn*.35,sway*.15)
                    elseif kind == "shoulderL" then pose = CFrame.Angles(gaitL*.12,0,-.08+sway*.45)
                    elseif kind == "shoulderR" then pose = CFrame.Angles(gaitR*.12,0,.08+sway*.45)
                    elseif kind == "armL" then pose = CFrame.Angles(gaitL*.58+(chasing and -.34 or wary and -.18 or 0),0,.12+sway*.4)
                    elseif kind == "armR" then pose = CFrame.Angles(gaitR*.58+(chasing and -.34 or wary and -.18 or 0),0,-.12+sway*.4)
                    elseif kind == "forearmL" then pose = CFrame.Angles(-.28+gaitL*.38+(chasing and -.2 or 0),0,.1)
                    elseif kind == "forearmR" then pose = CFrame.Angles(-.28+gaitR*.38+(chasing and -.2 or 0),0,-.1)
                    elseif kind == "handL" then pose = CFrame.Angles(.12+math.abs(gaitL)*.22,0,.12)
                    elseif kind == "handR" then pose = CFrame.Angles(.12+math.abs(gaitR)*.22,0,-.12)
                    elseif kind == "claw" then pose = CFrame.Angles(.08+math.abs(gait)*.14,0,math.sin(elapsed*5.5)*.06)
                    elseif kind == "legL" then pose = CFrame.Angles(-gaitL*.48,0,0)
                    elseif kind == "legR" then pose = CFrame.Angles(-gaitR*.48,0,0)
                    elseif kind == "shinL" then pose = CFrame.Angles(math.max(0,gaitL)*.52,0,0)
                    elseif kind == "shinR" then pose = CFrame.Angles(math.max(0,gaitR)*.52,0,0)
                    elseif kind == "footL" then pose = CFrame.Angles(-math.max(0,gaitL)*.26,0,0)
                    elseif kind == "footR" then pose = CFrame.Angles(-math.max(0,gaitR)*.26,0,0)
                    elseif kind == "head" then
                        if self.variant.name=="THE IMITATOR" then
                            local twitch = math.sin(elapsed*2.35)*.12 + (math.sin(elapsed*.61)>.94 and .3 or 0)
                            pose=CFrame.Angles(-.18+math.sin(elapsed*1.3)*.05,headTurn+math.sin(elapsed*.73)*.3,.22*math.sin(elapsed*.55)+twitch)
                        elseif self.variant.name=="THE CRAWLER" then pose=CFrame.Angles(.3+math.sin(elapsed*2.2)*.14,headTurn*.7+math.sin(elapsed*1.4)*.2,.08*math.sin(elapsed*2.8))
                        else pose = CFrame.Angles(leaning+breathing*.035,headTurn,chasing and math.sin(elapsed*2.3)*.08 or listen*.5) end
                    elseif kind == "jaw" then pose = CFrame.Angles(chasing and .28+math.sin(elapsed*5.1)*.09 or wary and .1 or .025,0,0)
                    elseif kind == "badge" and self.variant.name=="THE IMITATOR" then pose=CFrame.Angles(0,0,math.sin(elapsed*1.4)*.07)
                    elseif kind == "coat" then pose = CFrame.Angles(leaning+gait*.09,math.sin(elapsed*1.8)*.05,breathing*.025+sway*.3)
                    elseif kind == "antenna" then pose = CFrame.Angles(.04,math.sin(elapsed*2.3)*.2,math.sin(elapsed*1.7)*.09)
                    elseif kind == "spine" then pose = CFrame.Angles(.08+breathing*.08,math.sin(elapsed*2.1)*.08,math.sin(elapsed*2.7)*.07)
                    elseif kind == "rib" then pose = CFrame.new(0,breathing*.025,0) * CFrame.Angles(breathing*.025,0,0)
                    elseif kind == "core" then rig.part.Transparency = .08 + (1 + math.sin(elapsed * (chasing and 6.2 or 2.4))) * .1
                    elseif kind == "face" and rig.part.Name == "Eye" then
                        local blink = elapsed % 5.7 > 5.58 and elapsed % 5.7 < 5.68
                        rig.part.Transparency = blink and .82 or 0
                    end
                    if self.state == "CHECK_LOCKER" and (kind == "armL" or kind == "forearmL") then pose = CFrame.Angles(-.95,0,-.14) end
                    if self.state == "SUSPICIOUS" and (kind == "head" or kind == "antenna") then pose = CFrame.Angles(-.2,math.sin(elapsed*1.1)*.36,0) end
                    if self.variant.name == "THE CRAWLER" and (kind == "armL" or kind == "armR" or kind == "forearmL" or kind == "forearmR") then
                        pose = pose * CFrame.Angles(.16+math.abs(gait)*.12,0,0)
                    end
                    rig.part.CFrame = root.CFrame * rig.localCFrame * pose
                end
            end
            task.wait(0.055)
        end
        if self.token == token then self.ctx.onExpired(model) end
    end)
end

function Threat:Stop()
    for player in pairs(self.cueTimes) do self:_cue(player, "IDLE", "", 0) end
    self.token += 1
    self.model, self.root, self.target, self.path, self.lockerMemory = nil, nil, nil, nil, nil
    self.state = "IDLE"
    self.suspicionTarget, self.goal, self.doorTarget, self.doorBashAt = nil, nil, nil, nil
    self.noises, self.suspicions, self.cueTimes, self.unreachableUntil = {}, {}, {}, {}
    self.pathBusy, self.pathToken = false, nil
end

return Threat
