-- NIGHT SHIFT 4.5: complete B1 service wing, wall guidance and inspectable equipment.
-- Build AFTER the original map and BEFORE Campaign.Build. All new walking surfaces
-- are at Y=-10.5; patrol points are FEET positions, spawn points are ROOT positions.
local Locations = {}
local Methods = {}
Methods.__index = Methods

local V = Vector3.new
local C = Color3.fromRGB
local PALETTE = {
    wall=C(49,57,62), floor=C(51,58,61), ceiling=C(32,39,44), trim=C(101,114,119),
    dark=C(28,36,40), ivory=C(222,224,210), amber=C(196,156,81), teal=C(78,130,128),
    blue=C(86,126,151), red=C(144,68,55), green=C(84,121,96), paper=C(201,195,170),
}
local FLOOR, TOP, HEIGHT = -10.5, -0.8, 9.7
local ROOM_LABELS = {retail="Торговый зал",stock="Товарный склад",generator="Генераторная",security="Комната охраны",
    loading="Погрузочная",basement="Подвал B1",cold="Холодный склад",boiler="Котельная",yard="Технический двор",
    workshop="Мастерская",pump="Насосная",archive="Архив",comms="Серверная",staff="Комната персонала",dispatch="Склад возвратов"}
local ROOM_DEFS = {
    {id="workshop", label="МАСТЕРСКАЯ", number="B1-01", minX=-26, maxX=2, minZ=-131, maxZ=-109, doorZ=-120, accent=PALETTE.amber},
    {id="pump", label="НАСОСНАЯ", number="B1-02", minX=12, maxX=40, minZ=-131, maxZ=-109, doorZ=-120, accent=PALETTE.teal},
    {id="archive", label="АРХИВ", number="B1-03", minX=-26, maxX=2, minZ=-153, maxZ=-131, doorZ=-142, accent=PALETTE.paper},
    {id="comms", label="СЕРВЕРНАЯ", number="B1-04", minX=12, maxX=40, minZ=-153, maxZ=-131, doorZ=-142, accent=PALETTE.blue},
    {id="staff", label="КОМНАТА ПЕРСОНАЛА", number="B1-05", minX=-26, maxX=2, minZ=-175, maxZ=-153, doorZ=-164, accent=PALETTE.green},
    {id="dispatch", label="СКЛАД ВОЗВРАТОВ", number="B1-06", minX=12, maxX=40, minZ=-175, maxZ=-153, doorZ=-164, accent=PALETTE.red},
}

function Methods:_model(name, room)
    local model=Instance.new("Model")
    model.Name=name;model.Parent=self.folder
    if room then model:SetAttribute("RoomId",room) end
    return model
end

function Methods:_part(name,size,position,color,material,parent,collide,transparency)
    local part
    if self.ctx.makePart then
        part=self.ctx.makePart(name,size,position,color or PALETTE.wall,material or Enum.Material.Metal,parent or self.folder,transparency)
    else
        part=Instance.new("Part");part.Name=name;part.Size=size;part.Position=position
        part.Color=color or PALETTE.wall;part.Material=material or Enum.Material.Metal
        part.Anchored=true;part.TopSurface=Enum.SurfaceType.Smooth;part.BottomSurface=Enum.SurfaceType.Smooth
        part.Parent=parent or self.folder
        if transparency then part.Transparency=transparency end
    end
    part.CanTouch=false;part.CanCollide=collide==true;part.CanQuery=collide==true
    return part
end

function Methods:_sign(name,position,width,height,message,facing,color,parent)
    local part=self:_part(name,V(width,height,.12),position,color or PALETTE.dark,Enum.Material.Metal,parent)
    part.CFrame=CFrame.lookAt(position,position+facing)
    part:SetAttribute("ReadFrom",position+facing*4)
    if self.ctx.addTextSign then self.ctx.addTextSign(part,message,Enum.NormalId.Front,PALETTE.ivory)
    else
        local gui=Instance.new("SurfaceGui");gui.Name="ReadableSign_Front";gui.Face=Enum.NormalId.Front
        gui.SizingMode=Enum.SurfaceGuiSizingMode.PixelsPerStud;gui.PixelsPerStud=45;gui.LightInfluence=0
        gui.AlwaysOnTop=false;gui.MaxDistance=95;gui.Parent=part
        local label=Instance.new("TextLabel");label.Size=UDim2.fromScale(.92,.88);label.Position=UDim2.fromScale(.04,.06)
        label.BackgroundTransparency=1;label.Text=message;label.Font=Enum.Font.GothamBold
        label.TextScaled=true;label.TextWrapped=true;label.TextColor3=PALETTE.ivory;label.Parent=gui
    end
    table.insert(self.signs,part)
    return part
end

function Methods:_fixture(name,position,tint,parent,emergency)
    self:_part(name.."Housing",V(3.8,.22,1.0),position,PALETTE.trim,Enum.Material.Metal,parent)
    local lens=self:_part(name.."Lens",V(3.4,.08,.72),position-V(0,.15,0),tint,Enum.Material.Neon,parent)
    local light=Instance.new("PointLight")
    light.Name=emergency and "BatteryEmergencyLight" or "NS40RoomLight"
    light.Color=tint;light.Brightness=emergency and .5 or .95;light.Range=emergency and 10 or 20
    light.Shadows=false;light.Parent=lens
    if not emergency and self.ctx.registerLight then self.ctx.registerLight(light) end
    table.insert(self.lights,light)
    return light
end

function Methods:_ambient(name,kind,position,powered,parent)
    local part=self:_part(name,V(.16,.16,.16),position,PALETTE.dark,Enum.Material.SmoothPlastic,parent,false,1)
    part:SetAttribute("NS40Ambient",kind);part:SetAttribute("Powered",powered==true)
    table.insert(self.ambientSources,{part=part,kind=kind,powered=powered==true})
    return part
end

function Methods:_station(id,title,room,position,facing,floorY,parent)
    local part=self:_sign("NS40Station_"..id,position,2.8,1.65,title,facing,PALETTE.dark,parent)
    part.CanQuery=true
    part:SetAttribute("StationId",id);part:SetAttribute("RoomId",room);part:SetAttribute("RoomLabel",ROOM_LABELS[room] or room)
    local approach=V(position.X,floorY+3,position.Z)+facing*3.5
    part:SetAttribute("Approach",approach)
    self.stations[id]={part=part,position=position,approach=approach,facing=facing,room=room,roomLabel=ROOM_LABELS[room] or room,title=title,floorY=floorY}
    return part
end

function Methods:_cabinet(name,position,width,height,depth,facing,parent,accent)
    local model=Instance.new("Model");model.Name=name.."Assembly";model.Parent=parent or self.folder
    local frame=CFrame.lookAt(position,position+facing)
    local body=self:_part(name.."Body",V(width,height,depth),position,accent or PALETTE.wall,Enum.Material.Metal,model,true)
    body.CFrame=frame
    local door=self:_part(name.."Front",V(width-.16,height-.16,.08),position,PALETTE.trim,Enum.Material.Metal,model)
    door.CFrame=frame*CFrame.new(0,0,-depth*.5-.04)
    local handle=self:_part(name.."Handle",V(.12,.8,.12),position,PALETTE.ivory,Enum.Material.Metal,model)
    handle.CFrame=frame*CFrame.new(width*.31,0,-depth*.5-.14)
    model:SetAttribute("Front",facing)
    return model
end

function Methods:_bench(name,center,width,depth,parent)
    self:_part(name.."Top",V(width,.22,depth),center,PALETTE.paper,Enum.Material.Wood,parent,true)
    for _,x in ipairs({-width*.43,width*.43}) do
        self:_part(name.."Leg",V(.24,2.8,depth-.3),center+V(x,-1.5,0),PALETTE.trim,Enum.Material.Metal,parent,true)
    end
    self:_part(name.."LowerShelf",V(width-.6,.14,depth-.4),center-V(0,2.1,0),PALETTE.wall,Enum.Material.Metal,parent,true)
end

function Methods:_locker(id,position,facing,parent)
    local assembly=Instance.new("Model");assembly.Name="NS40HideLocker_"..id.."Assembly";assembly.Parent=parent
    parent=assembly
    local frame=CFrame.lookAt(position,position+facing)
    local locker=self:_part("NS40HideLocker_"..id,V(3.6,7.2,2.4),position,PALETTE.wall,Enum.Material.Metal,parent,true)
    locker.CFrame=frame
    local exit=V(position.X,FLOOR+3,position.Z)+facing*4.0
    locker:SetAttribute("HidePosition",V(position.X,FLOOR+3,position.Z))
    locker:SetAttribute("HideExit",exit);locker:SetAttribute("LockerId","NS40_"..id)
    local front=self:_sign("NS40LockerLabel_"..id,position+facing*1.34+V(0,1.7,0),2.8,.65,"УКРЫТИЕ",facing,PALETTE.green,parent)
    local door=self:_part("NS40LockerDoor",V(3.3,6.85,.12),position,PALETTE.trim,Enum.Material.Metal,parent)
    door.CFrame=frame*CFrame.new(0,0,-1.25)
    local handle=self:_part("NS40LockerHandle",V(.14,.8,.16),position,PALETTE.ivory,Enum.Material.Metal,parent)
    handle.CFrame=frame*CFrame.new(1,-.3,-1.38)
    local anchor=self:_part("NS40LockerPrompt_"..id,V(.18,.18,.18),position+facing*1.5-V(0,.5,0),PALETTE.dark,Enum.Material.SmoothPlastic,parent,false,1)
    if self.ctx.addPrompt and self.ctx.toggleHide then
        self.ctx.addPrompt(anchor,"Спрятаться / выйти","Укрытие B1",.35,function(player)self.ctx.toggleHide(player,locker)end,
            {allowHidden=true,lineOfSight=false,enforceLineOfSight=true,distance=5.5})
    end
    table.insert(self.hideLockers,locker)
    return front
end

function Methods:_shell(def)
    local room=self:_model("NS40Room_"..def.id,def.id)
    local cx,cz=(def.minX+def.maxX)*.5,(def.minZ+def.maxZ)*.5
    local width,depth=def.maxX-def.minX,def.maxZ-def.minZ
    local middle=(FLOOR+TOP)*.5
    self:_part(def.id.."Floor",V(width+.6,.6,depth+.6),V(cx,FLOOR-.3,cz),PALETTE.floor,Enum.Material.Concrete,room,true)
    self:_part(def.id.."Ceiling",V(width+.6,.7,depth+.6),V(cx,TOP+.35,cz),PALETTE.ceiling,Enum.Material.Concrete,room,true)
    local outerX=def.maxX<7 and def.minX or def.maxX
    local doorX=def.maxX<7 and def.maxX or def.minX
    self:_part(def.id.."OuterWall",V(.6,HEIGHT,depth+.6),V(outerX,middle,cz),PALETTE.wall,Enum.Material.Concrete,room,true)
    for _,z in ipairs({def.minZ,def.maxZ}) do
        local serviceLink=def.minX<0 and (z==-131 or z==-153)
        if serviceLink then
            -- A second route links the three west rooms, giving a chase an escape
            -- loop without adding teleportation, vents or narrow crawl passages.
            for _,span in ipairs({{def.minX,-25.5},{-18.5,def.maxX}}) do
                local length=span[2]-span[1];local mid=(span[1]+span[2])*.5
                self:_part(def.id.."LinkWall",V(length,HEIGHT,.6),V(mid,middle,z),PALETTE.wall,Enum.Material.Concrete,room,true)
                self:_part(def.id.."LinkSkirting",V(length,.5,.08),V(mid,FLOOR+.25,z+(z==def.minZ and .34 or -.34)),PALETTE.trim,Enum.Material.Metal,room)
            end
            self:_part(def.id.."LinkHeader",V(7,1.6,.6),V(-22,TOP-.8,z),PALETTE.wall,Enum.Material.Concrete,room,true)
            for _,x in ipairs({-25.5,-18.5}) do self:_part(def.id.."LinkFrame",V(.12,8.1,.8),V(x,FLOOR+4.05,z),PALETTE.trim,Enum.Material.Metal,room) end
            local direction=z==def.minZ and V(0,0,1) or V(0,0,-1)
            self:_sign(def.id.."LinkSign",V(-22,FLOOR+8.85,z+direction.Z*.42),6.7,.9,"СЛУЖЕБНЫЙ ПРОХОД",direction,PALETTE.green,room)
            table.insert(self.portals,{id=def.id.."_link_"..tostring(math.abs(z)),room=def.id,axis="z",plane=z,
                min=V(-25.5,FLOOR,z-.6),max=V(-18.5,FLOOR+8.1,z+.6)})
        else
            self:_part(def.id.."EndWall",V(width+.6,HEIGHT,.6),V(cx,middle,z),PALETTE.wall,Enum.Material.Concrete,room,true)
            self:_part(def.id.."SkirtingEnd",V(width-.6,.5,.08),V(cx,FLOOR+.25,z+(z==def.minZ and .34 or -.34)),PALETTE.trim,Enum.Material.Metal,room)
            self:_part(def.id.."WallBand",V(width-.6,.16,.05),V(cx,FLOOR+2.3,z+(z==def.minZ and .35 or -.35)),def.accent,Enum.Material.Metal,room)
        end
    end
    local openMin,openMax=def.doorZ-3.8,def.doorZ+3.8
    for _,segment in ipairs({{def.minZ,openMin},{openMax,def.maxZ}}) do
        local length=segment[2]-segment[1]
        self:_part(def.id.."CorridorWall",V(.6,HEIGHT,length),V(doorX,middle,(segment[1]+segment[2])*.5),PALETTE.wall,Enum.Material.Concrete,room,true)
        self:_part(def.id.."CorridorSkirting",V(.08,.5,length),V(doorX+(doorX<7 and -.34 or .34),FLOOR+.25,(segment[1]+segment[2])*.5),PALETTE.trim,Enum.Material.Metal,room)
    end
    local openingHeight=8.1
    self:_part(def.id.."DoorHeader",V(.6,HEIGHT-openingHeight,7.6),V(doorX,FLOOR+openingHeight+(HEIGHT-openingHeight)*.5,def.doorZ),PALETTE.wall,Enum.Material.Concrete,room,true)
    for _,z in ipairs({openMin,openMax}) do
        self:_part(def.id.."DoorFrame",V(.8,8.1,.12),V(doorX,FLOOR+4.05,z),PALETTE.trim,Enum.Material.Metal,room)
    end
    self:_part(def.id.."DoorLintel",V(.8,.12,7.7),V(doorX,FLOOR+8.12,def.doorZ),PALETTE.trim,Enum.Material.Metal,room)
    self:_part(def.id.."Threshold",V(1,.04,7.4),V(doorX,FLOOR+.02,def.doorZ),def.accent,Enum.Material.DiamondPlate,room)
    local facing=doorX<7 and V(1,0,0) or V(-1,0,0)
    self:_sign(def.id.."RoomSign",V(doorX+(doorX<7 and .42 or -.42),FLOOR+8.85,def.doorZ),7.0,.95,def.number.."  /  "..def.label,facing,def.accent,room)
    self:_sign(def.id.."ExitSign",V(doorX+(doorX<7 and -.42 or .42),FLOOR+8.85,def.doorZ),6.3,.85,"КОРИДОР  /  ВЫХОД",-facing,PALETTE.green,room)
    self:_part(def.id.."OuterSkirting",V(.08,.5,depth-.6),V(outerX+(outerX<7 and .34 or -.34),FLOOR+.25,cz),PALETTE.trim,Enum.Material.Metal,room)
    self:_part(def.id.."CableTray",V(width-1.2,.15,.35),V(cx,TOP-.55,def.minZ+1.2),PALETTE.trim,Enum.Material.Metal,room)
    self:_fixture(def.id.."MainLight",V(cx,TOP-.38,cz),def.id=="staff" and C(219,198,159) or C(183,205,208),room)
    self:_fixture(def.id.."EmergencyLight",V(doorX+(doorX<7 and -2 or 2),TOP-.45,def.doorZ),C(193,161,96),room,true)
    local portal={id=def.id.."_door",room=def.id,axis="x",plane=doorX,min=V(doorX-.6,FLOOR,openMin),max=V(doorX+.6,FLOOR+openingHeight,openMax)}
    local ordinal=def.doorZ==-120 and "первая" or def.doorZ==-142 and "вторая" or "третья"
    local hint="Погрузочная → лестница B1 → щитовая → служебное крыло, "..ordinal.." дверь "..(doorX<7 and "слева." or "справа.")
    local metadata={id=def.id,label=def.label,number=def.number,center=V(cx,FLOOR+3,cz),floorY=FLOOR,hint=hint,
        bounds={min=V(def.minX-.3,FLOOR-.6,def.minZ-.3),max=V(def.maxX+.3,TOP+.7,def.maxZ+.3)},
        interior={min=V(def.minX+.3,FLOOR,def.minZ+.3),max=V(def.maxX-.3,TOP,def.maxZ-.3)},door=portal,new=true}
    table.insert(self.rooms,metadata);table.insert(self.newRooms,metadata);table.insert(self.portals,portal)
    table.insert(self.patrolPoints,V(cx,FLOOR,cz));self.roomModels[def.id]=room
    self:_ambient("NS40Vent_"..def.id,def.id=="pump" and "pump" or def.id=="comms" and "server" or "vent",V(outerX+(outerX<7 and 1 or -1),TOP-1.0,cz),true,room)
    return room
end

function Methods:_connectBasement()
    local old=self.world:FindFirstChild("BasementWallBack",true)
    assert(old and old:IsA("BasePart"),"Build original B1 before NightShift_Locations")
    -- Keep the original identity for legacy shell inventories, but split its volume
    -- into two piers and a real lintel. Only this documented portal is removed.
    old.Size=V(12.95,10.4,.9);old.Position=V(-4.475,-5.5,-107)
    self:_part("NS40BasementPortalRight",V(12.95,10.4,.9),V(18.475,-5.5,-107),PALETTE.wall,Enum.Material.Concrete,self.folder,true)
    self:_part("NS40BasementPortalHeader",V(10,2,.9),V(7,-1.3,-107),PALETTE.wall,Enum.Material.Concrete,self.folder,true)
    self:_part("NS40BasementPortalThreshold",V(10,.6,2),V(7,FLOOR-.3,-107),PALETTE.floor,Enum.Material.Concrete,self.folder,true)
    self:_sign("NS40WingEntry",V(7,-1.35,-106.45),8.8,.95,"B1  /  СЛУЖЕБНОЕ КРЫЛО",V(0,0,1),PALETTE.amber,self.folder)
    self:_sign("NS40WingReturn",V(7,-1.35,-107.55),8.8,.95,"ЩИТОВАЯ  /  ВЫХОД НАВЕРХ",V(0,0,-1),PALETTE.green,self.folder)
    table.insert(self.portals,{id="existing_b1_to_wing",room="basement",axis="z",plane=-107,min=V(2.3,-10.5,-107.5),max=V(11.7,-2.3,-106.5)})

    local hall=self:_model("NS40ServiceCorridor","service_corridor")
    self:_part("NS40CorridorFloor",V(10.6,.6,69),V(7,FLOOR-.3,-141),PALETTE.floor,Enum.Material.Concrete,hall,true)
    self:_part("NS40CorridorCeiling",V(10.6,.7,69),V(7,TOP+.35,-141),PALETTE.ceiling,Enum.Material.Concrete,hall,true)
    for _,x in ipairs({2,12}) do
        self:_part("NS40VestibuleSideWall",V(.6,HEIGHT,2.6),V(x,(TOP+FLOOR)*.5,-107.7),PALETTE.wall,Enum.Material.Concrete,hall,true)
        self:_part("NS40CorridorCable",V(.18,.18,67),V(x+(x<7 and .6 or -.6),TOP-.5,-141),PALETTE.trim,Enum.Material.Metal,hall)
        self:_part("NS40CorridorGuideLine",V(.1,.025,66),V(x+(x<7 and 1.1 or -1.1),FLOOR+.018,-141),PALETTE.amber,Enum.Material.Metal,hall)
    end
    self:_part("NS40CorridorRearWall",V(10.6,HEIGHT,.6),V(7,(TOP+FLOOR)*.5,-175),PALETTE.wall,Enum.Material.Concrete,hall,true)
    self:_sign("NS40CorridorEndMap",V(7,-6,-174.62),6.5,2.2,"СЛУЖЕБНОЕ КРЫЛО B1\nМАГАЗИН И ВЫХОД — НАЗАД",V(0,0,1),PALETTE.green,hall)
    for index,z in ipairs({-112,-131,-153,-170}) do
        self:_fixture("NS40CorridorLight"..index,V(7,TOP-.4,z),C(201,204,183),hall)
        table.insert(self.patrolPoints,V(7,FLOOR,z))
    end
    -- Low, battery-fed wayfinding: the basement is navigable when the main lights go out.
    -- These emergency lights deliberately are not registered with grid-controlled lights.
    for _,z in ipairs({-119,-141,-163}) do
        self:_fixture("NS42EmergencyGuide"..tostring(-z),V(7,TOP-.44,z),C(177,76,61),hall,true)
    end
    for _,z in ipairs({-120,-142,-164}) do table.insert(self.patrolPoints,V(7,FLOOR,z)) end
    for _,z in ipairs({-131,-153}) do table.insert(self.patrolPoints,V(-21.5,FLOOR,z)) end
    table.insert(self.rooms,{id="service_corridor",label="СЛУЖЕБНЫЙ КОРИДОР B1",center=V(7,FLOOR+3,-142),floorY=FLOOR,
        hint="Погрузочная → лестница B1 → пройди щитовую прямо.",
        bounds={min=V(1.7,FLOOR-.6,-175.3),max=V(12.3,TOP+.7,-106.5)},new=true})
    self.bounds={min=V(-26.3,FLOOR-.6,-175.3),max=V(40.3,TOP+.7,-106.5)}
end

function Methods:_furnishNewRooms()
    local workshop=self.roomModels.workshop
    self:_bench("WorkshopBench",V(-10,FLOOR+3.05,-128),14,3,workshop)
    self:_part("WorkshopToolBoard",V(12,3.6,.12),V(-10,-5.5,-130.56),PALETTE.wall,Enum.Material.Metal,workshop)
    self:_sign("WorkshopToolTitle",V(-10,-4.12,-130.46),10,.55,"ИНСТРУМЕНТЫ / УЧЁТ",V(0,0,1),PALETTE.dark,workshop)
    for index=1,5 do
        self:_part("WorkshopToolHandle",V(.22,1.15,.15),V(-17.5+index*2,-5.4,-130.42),index%2==0 and PALETTE.amber or PALETTE.red,Enum.Material.Metal,workshop)
        self:_part("WorkshopToolHead",V(.7,.28,.18),V(-17.5+index*2,-4.8,-130.4),PALETTE.trim,Enum.Material.Metal,workshop)
    end
    self:_cabinet("WorkshopPartsCabinet",V(-24.5,-7.2,-115.4),5.5,6.4,2.0,V(1,0,0),workshop,PALETTE.amber)
    self:_station("workshop_bench","РЕМОНТНЫЙ СТЕНД","workshop",V(-12,-6.6,-126.3),V(0,0,1),FLOOR,workshop)
    self:_station("workshop_parts","КОМПЛЕКТУЮЩИЕ","workshop",V(-23.35,-6.3,-115.4),V(1,0,0),FLOOR,workshop)
    self:_sign("WorkshopSafety",V(-.8,-5.4,-130.58),2.0,2.1,"ОТКЛЮЧИ\nПИТАНИЕ\nПЕРЕД РЕМОНТОМ",V(0,0,1),PALETTE.red,workshop)

    local pump=self.roomModels.pump
    for _,x in ipairs({18,34}) do
        local tank=self:_part("NS40PumpTank",V(6.2,3.2,3.2),V(x,-7.3,-127.4),PALETTE.teal,Enum.Material.Metal,pump,true)
        tank.Shape=Enum.PartType.Cylinder;tank.CFrame=CFrame.new(tank.Position)*CFrame.Angles(0,0,math.rad(90))
        self:_part("PumpTankBase",V(3.5,.4,3.5),V(x,FLOOR+.2,-127.4),PALETTE.dark,Enum.Material.Metal,pump,true)
        self:_part("PumpTankPipe",V(.25,.25,4),V(x,-3.4,-125.8),PALETTE.trim,Enum.Material.Metal,pump)
    end
    self:_cabinet("PumpControlCabinet",V(26,-7.4,-129.4),4.8,5.8,1.5,V(0,0,1),pump)
    self:_station("pump_console","КОНТРОЛЬ ДАВЛЕНИЯ","pump",V(26,-6.6,-128.56),V(0,0,1),FLOOR,pump)
    for index,x in ipairs({17,26,35}) do
        self:_part("PumpValvePipe",V(.28,6.6,.28),V(x,-6.3,-109.7),PALETTE.trim,Enum.Material.Metal,pump)
        local valve=self:_part("PumpValveWheel",V(.2,1.35,1.35),V(x,-7.4,-110.15),index==1 and PALETTE.red or index==2 and PALETTE.blue or PALETTE.amber,Enum.Material.Metal,pump)
        valve.Shape=Enum.PartType.Cylinder;valve.CFrame=CFrame.new(valve.Position)*CFrame.Angles(0,math.rad(90),0)
        self:_station("pump_valve_"..string.char(96+index),"КОНТУР "..string.char(64+index),"pump",V(x,-5.4,-110.32),V(0,0,-1),FLOOR,pump)
    end
    self:_part("PumpFloorDrain",V(8,.025,1.1),V(26,FLOOR+.02,-122),PALETTE.dark,Enum.Material.DiamondPlate,pump)
    self:_ambient("NS40PumpDrip","drip",V(35,-8.5,-125),false,pump)

    local archive=self.roomModels.archive
    for index,z in ipairs({-138,-146}) do
        self:_cabinet("ArchiveFileCabinet"..index,V(-24.4,-7.2,z),5.0,6.4,2.2,V(1,0,0),archive,PALETTE.paper)
    end
    self:_bench("ArchiveDesk",V(-12,FLOOR+2.8,-134.4),10,2.5,archive)
    for index=1,5 do
        self:_part("ArchiveFolder",V(.8,.12,1.1),V(-16+index*1.4,FLOOR+3.0,-134.5),index%2==0 and PALETTE.blue or PALETTE.paper,Enum.Material.SmoothPlastic,archive)
    end
    self:_sign("ArchiveRecordsBoard",V(-10,-5.6,-152.55),15,2.8,"АРХИВ / ЗАКРЫТЫЕ СМЕНЫ\nДОКУМЕНТЫ ВЫДАЮТСЯ ПО ЖУРНАЛУ",V(0,0,1),PALETTE.dark,archive)
    self:_station("archive_catalog","КАТАЛОГ СМЕН","archive",V(-12,-6.6,-135.8),V(0,0,-1),FLOOR,archive)
    self:_station("archive_records","АРХИВНЫЕ ЗАПИСИ","archive",V(-23.2,-6.3,-146),V(1,0,0),FLOOR,archive)
    self:_locker("archive",V(-3,-6.9,-150.7),V(0,0,1),archive)

    local comms=self.roomModels.comms
    for index,x in ipairs({18,26,34}) do
        self:_cabinet("ServerRack"..index,V(x,-6.85,-150.3),4.4,7.2,3.0,V(0,0,1),comms,PALETTE.dark)
        for row=0,3 do
            self:_part("ServerRackModule",V(3.9,.6,.1),V(x,-9.2+row*1.55,-148.7),PALETTE.wall,Enum.Material.Metal,comms)
            self:_part("ServerRackLED",V(.12,.12,.06),V(x+1.5,-9.2+row*1.55,-148.6),row%2==0 and PALETTE.teal or PALETTE.amber,Enum.Material.Neon,comms)
        end
    end
    self:_bench("CommsConsoleDesk",V(26,FLOOR+2.9,-134.2),13,2.5,comms)
    self:_station("comms_console","СЕТЕВОЙ ТЕРМИНАЛ","comms",V(26,-6.6,-135.6),V(0,0,-1),FLOOR,comms)
    self:_station("comms_rack","УЗЕЛ СВЯЗИ / R2","comms",V(26,-6.0,-148.56),V(0,0,1),FLOOR,comms)
    self:_sign("CommsTopology",V(39.56,-5.6,-140),6.2,3.4,"СВЯЗЬ  /  CCTV\nКОНТУРЫ A — B — C",V(-1,0,0),PALETTE.blue,comms)

    local staff=self.roomModels.staff
    self:_bench("StaffDiningTable",V(-16,FLOOR+2.7,-169.6),12,3.2,staff)
    self:_part("StaffBenchSeat",V(12,.38,1.3),V(-16,FLOOR+1.55,-172.2),PALETTE.green,Enum.Material.Wood,staff,true)
    for _,x in ipairs({-21,-11}) do self:_part("StaffBenchLeg",V(.3,1.4,1.1),V(x,FLOOR+.7,-172.2),PALETTE.trim,Enum.Material.Metal,staff,true) end
    for _,x in ipairs({-14,-9}) do self:_cabinet("StaffPersonalLocker",V(x,-6.9,-154.6),3.6,7.2,2.0,V(0,0,-1),staff,PALETTE.green) end
    self:_station("staff_locker","ЛИЧНЫЙ ШКАФ / 07","staff",V(-14,-6.0,-155.76),V(0,0,-1),FLOOR,staff)
    self:_cabinet("StaffFirstAid",V(-25.35,-6.2,-163),3.0,3.4,.65,V(1,0,0),staff,PALETTE.ivory)
    self:_station("staff_firstaid","АПТЕЧКА / УЧЁТ","staff",V(-24.94,-6.0,-163),V(1,0,0),FLOOR,staff)
    self:_sign("StaffNoticeboard",V(-12,-5.8,-174.55),14,2.3,"ПЕРЕРЫВ  /  СЛУЖЕБНАЯ КОМНАТА\nНЕ ОСТАВЛЯЙ НАПАРНИКА ВНИЗУ",V(0,0,1),PALETTE.green,staff)
    self:_locker("staff",V(-2,-6.9,-172.3),V(0,0,1),staff)
    self:_ambient("NS40StaffRoomTone","vent",V(-23,-2.5,-169),true,staff)

    local dispatch=self.roomModels.dispatch
    for index,x in ipairs({18,34}) do
        self:_part("ReturnsPallet",V(7,.3,4.5),V(x,FLOOR+.15,-171.8),PALETTE.paper,Enum.Material.WoodPlanks,dispatch,true)
        for level=0,1 do
            for offset=-1,1,2 do
                local box=self:_part("ReturnsCrate",V(2.5,1.8,2.2),V(x+offset*1.6,FLOOR+1.2+level*1.8,-171.8),index==1 and PALETTE.red or PALETTE.blue,Enum.Material.WoodPlanks,dispatch,true)
                self:_sign("ReturnsBoxLabel",box.Position+V(0,.05,1.17),1.75,.6,index==1 and "ВОЗВРАТ" or "ПРОВЕРИТЬ",V(0,0,1),PALETTE.dark,dispatch)
            end
        end
    end
    self:_sign("DispatchManifest",V(26,-5.2,-153.56),14,3.4,"ВОЗВРАТЫ  /  КАРАНТИН ТОВАРА\nПРОВЕРЬ ПЛОМБУ И НОМЕР НАКЛАДНОЙ",V(0,0,-1),PALETTE.red,dispatch)
    self:_station("dispatch_board","НАКЛАДНЫЕ ВОЗВРАТОВ","dispatch",V(26,-7.2,-153.62),V(0,0,-1),FLOOR,dispatch)
    self:_bench("ReturnsScannerTable",V(26,FLOOR+2.9,-172.2),5.5,2.4,dispatch)
    self:_station("dispatch_scanner","ПРОВЕРКА ПЛОМБ","dispatch",V(26,-6.5,-170.86),V(0,0,1),FLOOR,dispatch)
    self.spawnPoints={V(-12,FLOOR+4.1,-120),V(26,FLOOR+4.1,-142),V(-12,FLOOR+4.1,-164),V(26,FLOOR+4.1,-164)}
end

function Methods:_finishExistingRooms()
    local normal=.3
    local existing=self:_model("NS40ExistingRoomFinish")
    -- Wall-mounted mission equipment keeps the old routes and furniture clear.
    local stations={
        {"security_terminal","ЖУРНАЛ ОХРАНЫ","security",V(23.15,4,14.7),V(1,0,0),normal},
        {"loading_manifest","ПРИЁМКА ПОСТАВОК","loading",V(-28.36,4,-40),V(1,0,0),normal},
        {"stock_supplies","ЗАПАСЫ / КОМПЛЕКТЫ","stock",V(21.76,4,-12.8),V(1,0,0),normal},
        {"retail_check","ОБХОД ТОРГОВОГО ЗАЛА","retail",V(-40.62,4,-1),V(1,0,0),normal},
        {"retail_register","СВЕРКА КАССЫ","retail",V(-16,4,30.9),V(0,0,-1),normal},
        {"generator_panel","ЖУРНАЛ ЭЛЕКТРОПИТАНИЯ","generator",V(22.15,5.8,-23),V(1,0,0),normal},
        {"cold_sensor","ДАТЧИК ХОЛОДНОГО СКЛАДА","cold",V(-31.94,-6.0,-91.5),V(1,0,0),FLOOR},
        {"boiler_gauge","КОНТРОЛЬ КОТЕЛЬНОЙ","boiler",V(41.94,-6.1,-98),V(-1,0,0),FLOOR},
        {"basement_breaker","СХЕМА РЕЗЕРВНОГО ПИТАНИЯ","basement",V(-7.8,-6.1,-106.42),V(0,0,1),FLOOR},
        {"yard_meter","УЧЁТ ВНЕШНЕГО КОНТУРА","yard",V(81.4,4,-6),V(-1,0,0),-.115},
    }
    for _,s in ipairs(stations) do self:_station(s[1],s[2],s[3],s[4],s[5],s[6],existing) end
    -- Clear visual identity and practical safety equipment for every old interior.
    self:_sign("RetailShiftBoard",V(-40.6,8,20.5),7,3.2,"NIGHTMART\nНОЧНАЯ СМЕНА / ОБХОД ПО ЧЕК-ЛИСТУ",V(1,0,0),PALETTE.green,existing)
    self:_part("RetailPASpeaker",V(.35,1.1,1.7),V(-40.6,13,20.5),PALETTE.dark,Enum.Material.Metal,existing)
    self:_sign("RetailRegisterRules",V(-16,6.3,30.88),6.2,1.3,"СВЕРЬ ЧЕКИ ПЕРЕД ЗАКРЫТИЕМ",V(0,0,-1),PALETTE.amber,existing)
    self:_sign("StockInventoryBoard",V(21.78,8.5,-9.8),6.2,2.0,"ПРИЁМКА / ЗАПАСЫ\nПРОХОД К ГЕНЕРАТОРУ НЕ ЗАГРОМОЖДАТЬ",V(1,0,0),PALETTE.amber,existing)
    self:_part("StockWallConduit",V(.1,.1,9),V(21.74,10.8,-9.8),PALETTE.trim,Enum.Material.Metal,existing)
    self:_part("GeneratorCableDownpipe",V(.18,5,.18),V(22.18,8,-26.5),PALETTE.trim,Enum.Material.Metal,existing)
    self:_sign("GeneratorInspectionDate",V(22.16,8.8,-23),6.5,1.25,"РЕГЛАМЕНТ / ПРОВЕРКА КАЖДУЮ СМЕНУ",V(1,0,0),PALETTE.amber,existing)
    self:_sign("SecurityRouteMap",V(23.16,7.2,23.3),6.5,2.0,"ПОГРУЗОЧНАЯ → ЛЕСТНИЦА B1\nЩИТОВАЯ → СЛУЖЕБНОЕ КРЫЛО",V(1,0,0),PALETTE.teal,existing)
    self:_part("SecurityWallRadioSpeaker",V(.28,.9,1.2),V(23.15,8.7,15),PALETTE.dark,Enum.Material.Metal,existing)
    self:_sign("LoadingManifestBoard",V(-28.36,7,-40),6.8,2.2,"ПОСТАВКИ / РАЗГРУЗКА\nВОЗВРАТЫ — УРОВЕНЬ B1",V(1,0,0),PALETTE.amber,existing)
    self:_part("LoadingBaySafetyMapFrame",V(.1,3.0,5.4),V(28.42,6.2,-37),PALETTE.trim,Enum.Material.Metal,existing)
    self:_sign("LoadingBaySafetyMap",V(28.32,6.2,-37),5.1,2.6,"B1 — ВПЕРЁД\nВЫХОД — ЧЕРЕЗ МАГАЗИН",V(-1,0,0),PALETTE.green,existing)
    self:_part("LoadingRouteFloorStripe",V(.12,.02,15),V(1.1,.32,-44),PALETTE.amber,Enum.Material.Metal,existing)
    self:_ambient("NS40DockVent","vent",V(-26,9,-48),true,existing)

    -- The old basement receives continuous skirting wherever there is a solid wall;
    -- no trim is placed across existing cold/boiler doors or the new rear portal.
    for _,d in ipairs({
        {-10.0,-100.5,12.2},{-10.0,-83.5,8.2},{24.0,-102,9.2},{24.0,-84.5,10.2},
        {-31.96,-92,22.8},{41.96,-92,22.8},
    }) do self:_part("B1FinishedWallSkirting",V(.08,.6,d[3]),V(d[1],FLOOR+.3,d[2]),PALETTE.trim,Enum.Material.Metal,existing) end
    for _,d in ipairs({{-21.5,-103.52,20.8},{-21.5,-80.48,20.8},{33.5,-103.52,16.8},{33.5,-80.48,16.8}}) do
        self:_part("B1FinishedEndSkirting",V(d[3],.6,.08),V(d[1],FLOOR+.3,d[2]),PALETTE.trim,Enum.Material.Metal,existing)
    end
    self:_sign("BasementRouteDirectory",V(-10.0,-5.1,-97),4.8,2.6,"ХОЛОДНЫЙ СКЛАД\nКОТЕЛЬНАЯ\nДАЛЕЕ — КРЫЛО B1",V(1,0,0),PALETTE.teal,existing)
    self:_part("BasementServiceGrate",V(8,.04,1.1),V(7,FLOOR+.02,-97.3),PALETTE.dark,Enum.Material.DiamondPlate,existing)
    self:_part("BasementCableCross",V(27,.22,.45),V(6,-1.65,-105.7),PALETTE.trim,Enum.Material.Metal,existing)
    self:_ambient("NS40BasementDrip","drip",V(-7,-5.5,-96),false,existing)
    self:_sign("ColdStorageSafety",V(-31.93,-3.0,-91.5),6,1.25,"ХОЛОДОВАЯ ЦЕПЬ / ДАТЧИК T-04",V(1,0,0),PALETTE.blue,existing)
    self:_part("ColdSensorConduit",V(.12,3.5,.12),V(-31.9,-3.5,-94),PALETTE.trim,Enum.Material.Metal,existing)
    self:_sign("ColdStorageRackIndex",V(-24.5,-2.1,-103.45),9,.9,"B1 / C1 — C6 / УЧЁТ ТЕМПЕРАТУРЫ",V(0,0,1),PALETTE.blue,existing)
    self:_ambient("NS40ColdVent","vent",V(-30,-2,-100),true,existing)
    self:_sign("BoilerPressureLimits",V(41.93,-3,-98),6,1.4,"ДАВЛЕНИЕ / СЛЕДУЙ РЕГЛАМЕНТУ",V(-1,0,0),PALETTE.amber,existing)
    self:_part("BoilerInstrumentConduit",V(.12,5,.12),V(41.9,-4,-100.8),PALETTE.trim,Enum.Material.Metal,existing)
    self:_sign("BoilerPipeFlow",V(33.5,-3,-103.45),10,1.1,"ПОДАЧА → / ОБРАТНЫЙ КОНТУР ←",V(0,0,1),PALETTE.red,existing)
    self:_sign("YardMeterWarning",V(81.38,7,-6),6.2,1.3,"ВНЕШНЕЕ ПИТАНИЕ / 240 V",V(-1,0,0),PALETTE.amber,existing)
    self:_ambient("NS40YardTransformer","transformer",V(54,4,-12),true,existing)
    self:_sign("ParkingShiftInformation",V(-26,5.2,33.12),8,2.6,"NIGHTMART 24/7\nСЛУЖЕБНЫЙ ВХОД — ВНУТРИ МАГАЗИНА",V(0,0,1),PALETTE.green,existing)
    for _,z in ipairs({-56,-65,-75}) do
        self:_part("B1StairEmergencyArrow",V(.06,.35,.8),V(10.91,2.2+(z+54)*(.6/1.35),z),PALETTE.amber,Enum.Material.Neon,existing)
    end
    -- Mounted on the INSIDE of the stair wall, facing the people descending.
    -- The former outward-facing board was invisible from the usable stair route.
    self:_sign("StairWingDirectory",V(3.09,.5,-64),3.2,1.5,"B1 / СЛУЖЕБНЫЕ КОМНАТЫ\nНАСОСНАЯ · АРХИВ · СЕРВЕРНАЯ",V(1,0,0),PALETTE.teal,existing)
    self:_sign("BasementUpWayfinding",V(17.75,-5.6,-79.55),4.7,1.2,"ВЫХОД ↑ / МАГАЗИН",V(0,0,-1),PALETTE.green,existing)
    self:_sign("BasementInspectionGuide",V(17.75,-7.05,-79.55),4.7,1.2,
        "ОСМОТР — В ЛЮБОЕ ВРЕМЯ\nЗАДАНИЕ — ПО КОНТРАКТУ",V(0,0,-1),PALETTE.teal,existing)
    local previousRooms={
        {"retail","ТОРГОВЫЙ ЗАЛ",V(-41,.3,-31.5),V(41,20.5,31.15),V(0,3.3,4),.3,"Главный вход магазина; отделы и кассы находятся в зале."},
        {"stock","ТОВАРНЫЙ СКЛАД",V(21.6,.3,-31),V(41,12.275,-4.2),V(31,3.3,-8.5),.3,"Из торгового зала направо, дверь «Склад / генераторная»."},
        {"generator","ГЕНЕРАТОРНАЯ",V(22,.3,-30.8),V(40.6,11.725,-15),V(32,3.3,-18.5),.3,"Через товарный склад прямо, под табличку «Генераторная»."},
        {"security","КОМНАТА ОХРАНЫ",V(23,.3,11),V(40,9.8,30.5),V(32,3.3,20),.3,"В правой передней части торгового зала, под табличкой «Охрана»."},
        {"loading","ПОГРУЗОЧНАЯ",V(-28.5,.3,-62),V(28.5,11.3,-33.4),V(0,3.3,-43),.3,"Задняя дверь торгового зала: «Погрузка / подвал B1»."},
        {"basement","ТЕХНИЧЕСКИЙ УРОВЕНЬ B1",V(-10.5,FLOOR,-107),V(24.5,TOP,-79.4),V(7,FLOOR+3,-91),FLOOR,"Погрузочная → лестница у настенного указателя «Подвал B1». Станции доступны для осмотра без контракта."},
        {"cold","ХОЛОДНЫЙ СКЛАД",V(-32.5,FLOOR,-104),V(-10.5,TOP,-80),V(-22,FLOOR+3,-91),FLOOR,"Спустись в B1; проход в холодный склад слева от лестницы."},
        {"boiler","КОТЕЛЬНАЯ",V(24.5,FLOOR,-104),V(42.5,TOP,-80),V(33,FLOOR+3,-94),FLOOR,"Спустись в B1; котельная справа от главного коридора."},
        {"electrical","ЭЛЕКТРОЩИТОВАЯ B1",V(-10.5,FLOOR,-107),V(24.5,TOP,-99.5),V(7,FLOOR+3,-103),FLOOR,"В подвале пройди прямо через проём «Электрощитовая»."},
        {"yard","ТЕХНИЧЕСКИЙ ДВОР",V(42.5,-.115,-21.5),V(81.5,9.7,21.5),V(62,2.885,8),-.115,"Боковой служебный выход в правой стене торгового зала."},
        {"stairs","ЛЕСТНИЦА B1",V(3,FLOOR,-79.4),V(11,11.3,-54),V(7,-2.1,-66.15),-5.1,"Погрузочная → жёлтый указатель «Подвал B1 / спуск»."},
    }
    for _,r in ipairs(previousRooms) do
        table.insert(self.rooms,{id=r[1],label=r[2],bounds={min=r[3],max=r[4]},center=r[5],floorY=r[6],hint=r[7],new=false})
    end
end

function Locations.Build(ctx)
    assert(type(ctx)=="table" and ctx.world,"NightShift_Locations.Build needs {world=...}")
    local prior=ctx.world:FindFirstChild("Locations_4_0")
    assert(not prior,"Locations.Build must run once per newly built world")
    local self=setmetatable({ctx=ctx,world=ctx.world,stations={},rooms={},newRooms={},roomModels={},portals={},
        patrolPoints={},spawnPoints={},ambientSources={},lights={},signs={},hideLockers={}},Methods)
    self.folder=Instance.new("Folder");self.folder.Name="Locations_4_0";self.folder.Parent=ctx.world
    self:_connectBasement()
    for _,def in ipairs(ROOM_DEFS) do self:_shell(def) end
    self:_furnishNewRooms();self:_finishExistingRooms()
    ctx.world:SetAttribute("ExpansionVersion","4.0")
    ctx.world:SetAttribute("ExpansionRoomCount",#self.newRooms)
    ctx.world:SetAttribute("ExpansionMinZ",-175.3)
    return self
end

return Locations
