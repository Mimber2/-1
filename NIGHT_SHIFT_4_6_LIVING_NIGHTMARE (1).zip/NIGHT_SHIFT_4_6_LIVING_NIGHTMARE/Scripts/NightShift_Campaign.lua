-- NIGHT SHIFT 4.5: persistent, server-authoritative investigation contracts.
-- Two completed contracts per shift. Inventory and timers require a live owner.
local Campaign = {}
Campaign.__index = Campaign
local LIMIT_PER_SHIFT, STATION_RANGE = 2, 8
local CHAPTERS = {
    {title="Чужая смена", record="01 · Накладная без подписи", text="В поставке есть коробки с датой завтрашней смены. Номер машины зачёркнут тем же карандашом, которым отмечен старый подвал."},
    {title="Вода под полом", record="02 · Нижний контур", text="Насосы включались ночью без команды щитовой. Следы воды ведут к сухой стене архива: утечка началась не в трубах."},
    {title="Ложные сигналы", record="03 · Повторитель", text="Помехи копируют служебные сообщения. Не иди на голос: сверяй номер станции и журнал текущей смены."},
    {title="Архив закрытых смен", record="04 · Пропавший обход", text="Сотрудник К-17 каждый раз исчезает из списка после обхода подвала. Его маршрут заканчивается у комнаты связи."},
    {title="Нижний контур", record="05 · Вторая линия", text="Генератор питает магазин и отдельную линию, которой нет на старой схеме. Эта линия уходит под архив."},
    {title="Правила Смотрителя", record="06 · Он слушает", text="Смотритель реагирует на шум и проверяет последнее место, где видел человека. Укрытие помогает, только если вход в него не заметили."},
    {title="Смена без записи", record="07 · Подмена", text="Касса, диспетчерская и архив хранят разные номера одной машины. Кто-то заменял документы до закрытия магазина."},
    {title="До рассвета", record="08 · Протокол рассвета", text="Ты восстановил связь, сохранил журнал и закрыл нижний контур. После рассвета остаются дежурные контракты: магазин всё ещё нуждается в обходе."},
}
local function inspect(station,objective,note,sound)
    return {kind="inspect",station=station,objective=objective,note=note,sound=sound or "scan"}
end
local function pickup(station,item,objective)
    return {kind="pickup",station=station,item=item,objective=objective,sound="item_pickup"}
end
local function deliver(station,item,objective,note)
    return {kind="deliver",station=station,item=item,objective=objective,note=note,sound="item_drop"}
end
local function work(station,objective,seconds,note,sound)
    return {kind="work",station=station,objective=objective,duration=seconds,note=note,sound=sound or "repair"}
end
local function choose(station,objective,hint,options,answer)
    return {kind="choice",station=station,objective=objective,hint=hint,options=options,answer=answer,sound="terminal"}
end
local function sequence(station,objective,hint,order)
    return {kind="sequence",station=station,objective=objective,hint=hint,order=order,sound="switch",
        options={{id="A",label="Контур A"},{id="B",label="Контур B"},{id="C",label="Контур C"}}}
end
local MISSIONS = {
    {id="shift_handover",title="Принять незавершённый обход",chapter=1,
        summary="Сверь журнал охраны с залом и передай маршрут диспетчеру.",steps={
        inspect("security_terminal","Прочитай журнал предыдущей смены","В шкафчике персонала оставили неподписанный маршрутный лист.","paper"),
        pickup("staff_locker","Маршрутный лист","Забери маршрутный лист из шкафчика"),
        work("retail_check","Сверь маршрут с маркировкой в торговом зале",5,"На листе отсутствует пункт B1. Сообщи диспетчеру.","scan"),
        deliver("dispatch_board","Маршрутный лист","Передай исправленный маршрут диспетчеру","Нижний этаж добавлен в обязательный обход."),
    }},
    {id="missing_delivery",title="Поставка без подписи",chapter=1,
        summary="Найди коробку по накладной и проверь её на станции приёмки.",steps={
        inspect("loading_manifest","Прочитай номер подозрительной поставки","В накладной указан груз К-17, отдел «Связь».","paper"),
        pickup("stock_supplies","Коробка К-17","Возьми коробку К-17 на товарном складе"),
        deliver("dispatch_scanner","Коробка К-17","Доставь коробку на сканер диспетчерской"),
        work("dispatch_scanner","Дождись полного сканирования коробки",6,"Внутри детали связи, а этикетка указывает холодный склад.","scan"),
        choose("dispatch_board","Зафиксируй расхождение","Сканер нашёл детали связи; этикетка указывает холодный склад.",
            {{id="weight",label="Неверный вес"},{id="destination",label="Подменён отдел"},{id="none",label="Всё совпадает"}},"destination"),
    }},
    {id="cold_chain",title="Температура не сходится",chapter=1,
        summary="Замени контрольный датчик и проверь показание после стабилизации.",steps={
        inspect("cold_sensor","Осмотри датчик холодного склада","Контрольная температура исправного контура: +4 °C."),
        pickup("workshop_parts","Датчик температуры","Возьми запасной датчик в мастерской"),
        deliver("cold_sensor","Датчик температуры","Установи запасной датчик"),
        work("cold_sensor","Подожди стабилизации нового датчика",8,"Датчик стабилен. Выставь контрольные +4 °C.","scan"),
        choose("cold_sensor","Выставь контрольную температуру","Норма технической карты: +4 °C.",
            {{id="minus4",label="−4 °C"},{id="plus4",label="+4 °C"},{id="plus14",label="+14 °C"}},"plus4"),
    }},
    {id="pump_prime",title="Запустить осушение",chapter=2,
        summary="Подготовь насосную и открой вентили в порядке из схемы.",steps={
        inspect("pump_console","Прочитай схему запуска насосов","Порядок первичного запуска: A → C → B."),
        inspect("pump_valve_a","Открой первый вентиль A","Контур A подготовлен.","valve"),
        inspect("pump_valve_c","Открой второй вентиль C","Контур C подготовлен.","valve"),
        inspect("pump_valve_b","Открой последний вентиль B","Все три ветви подготовлены.","valve"),
        work("pump_console","Удерживай запуск до рабочего режима",9,"Насос работает. Вода отступает от технического прохода.","repair"),
    }},
    {id="water_sample",title="Найти источник воды",chapter=2,
        summary="Отнеси пробу в мастерскую и сравни её с котловым контуром.",steps={
        pickup("pump_console","Проба воды","Возьми пробу в насосной"),
        deliver("workshop_bench","Проба воды","Передай пробу на диагностический стенд"),
        work("workshop_bench","Проанализируй пробу",7,"В пробе нет теплоносителя: котловой контур не повреждён.","scan"),
        inspect("boiler_gauge","Сверь давление котла","Давление 2,0 бар, утечки из котла нет."),
        choose("archive_catalog","Запиши вывод в технический журнал","В пробе нет теплоносителя, давление котла в норме.",
            {{id="boiler",label="Течь котла"},{id="drain",label="Обратный дренаж"},{id="cold",label="Холодильный контур"}},"drain"),
    }},
    {id="drain_isolation",title="Закрыть обратный поток",chapter=2,
        summary="Изолируй дренаж, проверь питание и закрепи защитную схему.",steps={
        inspect("pump_valve_b","Перекрой обратную ветвь B","Обратная ветвь закрыта.","valve"),
        work("basement_breaker","Проверь питание аварийного насоса",6,"Защитная последовательность: C → A → B.","switch"),
        sequence("pump_console","Введи защитную последовательность","Схема щитовой: C → A → B. Ошибка сбрасывает только последовательность.",{"C","A","B"}),
        work("pump_console","Убедись, что обратный поток не возвращается",10,"Дренаж стабилен. Открыта запись о нижнем контуре.","scan"),
    }},
    {id="signal_trace",title="Поймать чужую частоту",chapter=3,
        summary="Сверь канал охраны с настройкой повторителя.",steps={
        inspect("security_terminal","Прочитай канал служебной связи","Рабочий канал линии: 17.","radio"),
        work("comms_console","Прослушай канал помех",6,"Повторитель перескочил на канал 71. Верни канал из журнала охраны.","radio"),
        choose("comms_console","Настрой рабочий канал","В журнале охраны указан канал 17.",
            {{id="7",label="Канал 7"},{id="17",label="Канал 17"},{id="71",label="Канал 71"}},"17"),
        inspect("dispatch_board","Подтверди связь с диспетчерской","Диспетчер ответил правильным номером смены.","radio"),
    }},
    {id="false_sensor",title="Проверить ложную тревогу",chapter=3,
        summary="Проверь три датчика на месте и отметь неисправный сектор.",steps={
        inspect("security_terminal","Открой запись тревоги","Тревога пришла из зала, погрузки и мастерской.","terminal"),
        work("retail_check","Проверь датчик торгового зала",4,"Зал: датчик отвечает, пломба цела.","scan"),
        work("loading_manifest","Проверь датчик погрузочной",4,"Погрузка: датчик отвечает, дверь закрывается.","scan"),
        work("workshop_bench","Проверь датчик мастерской",4,"Мастерская: ответ повторяется с задержкой, разъём повреждён.","scan"),
        choose("security_terminal","Отметь неисправный сектор","Повреждённый разъём обнаружен в мастерской.",
            {{id="retail",label="Торговый зал"},{id="loading",label="Погрузочная"},{id="workshop",label="Мастерская"}},"workshop"),
    }},
    {id="relay_repair",title="Заменить повторитель",chapter=3,
        summary="Установи резервное реле и восстанови подтверждение сигнала.",steps={
        pickup("workshop_parts","Реле связи","Возьми резервное реле в мастерской"),
        deliver("comms_rack","Реле связи","Установи реле в стойку связи"),
        work("comms_rack","Закрепи контакты и проверь линию",8,"Порядок проверки: B → A → C.","repair"),
        sequence("comms_console","Выполни контроль трёх каналов","После замены реле: B → A → C.",{"B","A","C"}),
        inspect("security_terminal","Подтверди чистый сигнал в охране","Повторитель перестал копировать старую запись.","radio"),
    }},
    {id="archive_recovery",title="Собрать разорванный журнал",chapter=4,
        summary="Найди папку и сопоставь её с карточкой сотрудника.",steps={
        inspect("archive_catalog","Найди индекс пропавшей смены","Индекс папки: К-17 / ночной обход.","paper"),
        pickup("archive_records","Папка К-17","Возьми папку К-17 с архивного стеллажа"),
        deliver("staff_locker","Папка К-17","Сверь папку с карточкой в шкафчике"),
        work("staff_locker","Восстанови последовательность записей",7,"Последний пункт обхода: комната связи.","paper"),
        choose("archive_catalog","Отметь последнюю точку маршрута","Карточка К-17 заканчивается комнатой связи.",
            {{id="pump",label="Насосная"},{id="comms",label="Комната связи"},{id="retail",label="Торговый зал"}},"comms"),
    }},
    {id="manifest_compare",title="Две копии накладной",chapter=4,
        summary="Сравни документы погрузки и диспетчерской с оригиналом.",steps={
        inspect("loading_manifest","Прочитай номер машины на погрузке","Копия погрузки: машина 204.","paper"),
        inspect("dispatch_board","Прочитай номер машины у диспетчера","Копия диспетчера: машина 240.","paper"),
        inspect("archive_records","Найди исходный номер в архиве","Архивный оригинал: машина 204.","paper"),
        choose("archive_catalog","Укажи подменённую копию","Архив и погрузка: 204. Диспетчерская: 240.",
            {{id="loading",label="Копия погрузки"},{id="dispatch",label="Копия диспетчера"},{id="archive",label="Оригинал архива"}},"dispatch"),
        work("dispatch_scanner","Сохрани обе копии в журнале",6,"Расхождение зафиксировано, оригинал защищён.","scan"),
    }},
    {id="sealed_index",title="Открыть закрытый индекс",chapter=4,
        summary="Собери служебный код из трёх источников.",steps={
        inspect("security_terminal","Найди первую букву кода","Первая буква: C.","terminal"),
        inspect("staff_locker","Найди вторую букву кода","Вторая буква: B.","paper"),
        inspect("archive_records","Найди третью букву кода","Третья буква: A.","paper"),
        sequence("archive_catalog","Открой закрытую запись","Собранный код: C → B → A.",{"C","B","A"}),
        work("archive_catalog","Сними копию закрытого индекса",6,"Индекс указывает на отдельную линию под архивом.","scan"),
    }},
    {id="boiler_flush",title="Стабилизировать котельную",chapter=5,
        summary="Проверь давление, продуй ветви и закрепи рабочий режим.",steps={
        inspect("boiler_gauge","Сними начальное давление","Давление колеблется. Продувка: B → C → A."),
        inspect("pump_valve_b","Продуй ветвь B","Ветвь B очищена.","valve"),
        inspect("pump_valve_c","Продуй ветвь C","Ветвь C очищена.","valve"),
        inspect("pump_valve_a","Продуй ветвь A","Ветвь A очищена.","valve"),
        work("boiler_gauge","Наблюдай за давлением после продувки",9,"Давление удерживается на 2,0 бар.","scan"),
    }},
    {id="reserve_line",title="Восстановить резервную линию",chapter=5,
        summary="Подготовь резервный ввод и поставь защитный блок.",steps={
        inspect("basement_breaker","Проверь маркировку резервного ввода","Для линии B1 нужен блок R-2.","switch"),
        pickup("workshop_parts","Защитный блок R-2","Возьми блок R-2 в мастерской"),
        deliver("generator_panel","Защитный блок R-2","Установи блок в генераторной"),
        sequence("basement_breaker","Переведи ввод на резерв","Порядок ввода: A → B → C.",{"A","B","C"}),
        work("comms_rack","Проверь устойчивость питания связи",8,"Резервная линия выдержала нагрузку.","scan"),
    }},
    {id="cold_calibration",title="Откалибровать холодный склад",chapter=5,
        summary="Сверь эталонный зонд, настрой датчик и оформи приёмку.",steps={
        pickup("cold_sensor","Контрольный зонд","Сними контрольный зонд холодного склада"),
        deliver("workshop_bench","Контрольный зонд","Передай зонд на калибровочный стенд"),
        work("workshop_bench","Определи поправку зонда",7,"Зонд завышает на +2 °C. Нужна поправка −2 °C.","scan"),
        choose("cold_sensor","Введи измеренную поправку","Завышение +2 °C; корректирующая поправка −2 °C.",
            {{id="minus2",label="−2 °C"},{id="zero",label="0 °C"},{id="plus2",label="+2 °C"}},"minus2"),
        inspect("loading_manifest","Оформи допуск холодных поставок","Холодные поставки снова разрешены.","paper"),
    }},
    {id="watcher_traces",title="Составить карту следов",chapter=6,
        summary="Сравни следы в зале, насосной и у связи.",steps={
        work("retail_check","Осмотри следы у торгового зала",5,"Следы направлены к погрузке.","scan"),
        work("pump_console","Осмотри следы в насосной",5,"Следы продолжаются по коридору B1.","scan"),
        work("comms_rack","Осмотри следы у стойки связи",5,"Здесь следы обрываются у служебной линии.","scan"),
        choose("security_terminal","Отметь конечный сектор следов","Последние следы обнаружены у стойки связи.",
            {{id="retail",label="Торговый зал"},{id="comms",label="Комната связи"},{id="cold",label="Холодный склад"}},"comms"),
    }},
    {id="noise_decoy",title="Проверить шумовую приманку",chapter=6,
        summary="Собери приманку, установи во дворе и проверь датчик.",steps={
        work("workshop_bench","Собери таймер шумовой приманки",7,"Таймер готов. Установи приманку у наружного счётчика.","repair"),
        pickup("workshop_parts","Шумовая приманка","Возьми собранную приманку"),
        deliver("yard_meter","Шумовая приманка","Установи приманку во дворе","Приманка включена. Сигнал может привлечь Смотрителя."),
        work("dispatch_board","Дождись телеметрии наружного датчика",9,"Датчик принял импульс. Шум можно использовать для отвлечения.","radio"),
        inspect("security_terminal","Сохрани результат испытания","Протокол приманки добавлен в правила обхода.","terminal"),
    }},
    {id="quiet_route",title="Пройти тихий маршрут",chapter=6,
        summary="Сделай контрольные остановки, не срывая замер шагами.",steps={
        inspect("staff_firstaid","Прочитай памятку тихого обхода","На точках замера не беги и не двигайся до его окончания.","paper"),
        {kind="work",station="archive_records",objective="Тихо осмотри архивный проход",duration=7,quiet=true,note="Архивный проход чист.",sound="scan"},
        {kind="work",station="pump_console",objective="Тихо осмотри насосную",duration=7,quiet=true,note="Насосная проверена.",sound="scan"},
        {kind="work",station="cold_sensor",objective="Тихо осмотри холодный склад",duration=7,quiet=true,note="Холодный склад проверен.",sound="scan"},
        inspect("security_terminal","Зарегистрируй безопасный маршрут","Тихий обход завершён. Укрывайся до того, как тебя заметили.","terminal"),
    }},
    {id="register_audit",title="Сверить кассовый след",chapter=7,
        summary="Сопоставь чек, приёмку и архивный номер поставки.",steps={
        inspect("retail_register","Прочитай номер поставки на чеке","На чеке поставка 318.","paper"),
        inspect("dispatch_scanner","Прочитай номер сканированной поставки","Сканер записал поставку 381.","scan"),
        inspect("archive_records","Сверь номер с архивным оригиналом","Архив подтверждает поставку 318.","paper"),
        choose("dispatch_board","Отметь источник неверного номера","Касса и архив: 318. Сканер: 381.",
            {{id="register",label="Кассовый чек"},{id="scanner",label="Запись сканера"},{id="archive",label="Архив"}},"scanner"),
        work("dispatch_scanner","Восстанови индекс приёмки",8,"Индекс восстановлен без удаления оригиналов.","repair"),
    }},
    {id="courier_packet",title="Сохранить доказательства",chapter=7,
        summary="Упакуй оригиналы и проведи пакет по защищённому маршруту.",steps={
        work("archive_catalog","Подготовь опись доказательств",6,"Пакет готов к опечатыванию.","paper"),
        pickup("archive_records","Опечатанный пакет","Возьми пакет оригиналов"),
        work("staff_locker","Проверь пломбу в комнате персонала",5,"Пломба цела; доставь пакет диспетчеру.","scan"),
        deliver("dispatch_board","Опечатанный пакет","Передай пакет на защищённое хранение"),
        inspect("security_terminal","Отметь передачу пакета в журнале","Оригиналы сохранены за пределами изменяемого индекса.","terminal"),
    }},
    {id="power_fingerprint",title="Найти чужую нагрузку",chapter=7,
        summary="Сравни три показания и изолируй лишний контур.",steps={
        inspect("yard_meter","Сними наружное показание мощности","Счётчик показывает нагрузку трёх контуров."),
        inspect("generator_panel","Сверь нагрузку генератора","Магазин использует контуры A и B."),
        inspect("basement_breaker","Проверь незарегистрированный контур","Контур C отсутствует в журнале обслуживания."),
        choose("basement_breaker","Изолируй незарегистрированный контур","Магазин: A и B. Незарегистрированная нагрузка: C.",
            {{id="A",label="Контур A"},{id="B",label="Контур B"},{id="C",label="Контур C"}},"C"),
        work("yard_meter","Проверь показание после изоляции",8,"Лишняя нагрузка исчезла; основные системы работают.","scan"),
    }},
    {id="dawn_call",title="Передать сигнал рассвета",chapter=8,
        summary="Верни магистральный канал и отправь подтверждение наружу.",steps={
        pickup("workshop_parts","Магистральный модуль","Возьми магистральный модуль связи"),
        deliver("comms_rack","Магистральный модуль","Установи модуль в стойку"),
        sequence("comms_console","Собери выходную линию","Протокол рассвета: B → C → A → B.",{"B","C","A","B"}),
        work("comms_console","Дождись подтверждения внешней станции",12,"Внешняя станция приняла сигнал рассвета.","radio"),
        inspect("dispatch_board","Запиши ответ внешней станции","Ответ сохранён. Магазин снова виден диспетчеру.","paper"),
    }},
    {id="last_circuit",title="Закрыть нижний контур",chapter=8,
        summary="Проверь системы B1 и зафиксируй безопасное состояние.",steps={
        work("pump_console","Проверь сухой режим насосной",7,"Насосная сухая, обратного потока нет.","scan"),
        work("boiler_gauge","Проверь устойчивое давление котла",7,"Котёл удерживает рабочее давление.","scan"),
        work("cold_sensor","Проверь температуру холодного склада",7,"Холодный склад удерживает норму.","scan"),
        sequence("basement_breaker","Зафиксируй безопасное отключение","Защитная фиксация: C → B → A → C.",{"C","B","A","C"}),
        inspect("archive_catalog","Закрой карточку нижнего контура","Все системы B1 приняты в безопасном состоянии.","paper"),
    }},
    {id="dawn_report",title="Сдать смену до рассвета",chapter=8,
        summary="Сохрани итоговый журнал и передай копию охране.",steps={
        pickup("archive_records","Итоговый журнал","Забери восстановленный журнал из архива"),
        deliver("dispatch_scanner","Итоговый журнал","Передай журнал на защищённое копирование"),
        work("dispatch_scanner","Дождись проверки контрольной копии",10,"Копия и оригинал совпадают. Протокол готов к закрытию.","scan"),
        choose("security_terminal","Закрой расследование верным выводом","Доказательства: подмена документов и незарегистрированная линия C.",
            {{id="weather",label="Случайный скачок питания"},{id="tamper",label="Подмена и линия C"},{id="nothing",label="Нарушений нет"}},"tamper"),
        inspect("staff_locker","Сдай маршрут и завершённый журнал","Расследование завершено. Теперь доступны дежурные контракты.","paper"),
    }},
}
local REPLAY_ORDER = {4,8,13,19,6,9,14,17}
for index,mission in ipairs(MISSIONS) do mission.index=index end

local function integer(value,default,low,high)
    local n=tonumber(value)
    if not n or n~=n or n==math.huge or n==-math.huge then n=default end
    return math.clamp(math.floor(n),low,high)
end
local function missionFor(progress)
    if progress.completed<#MISSIONS then return MISSIONS[progress.completed+1],"story" end
    return MISSIONS[REPLAY_ORDER[(progress.replays%#REPLAY_ORDER)+1]],"replay"
end
function Campaign.NormalizeProgress(value)
    value=type(value)=="table" and value or {}
    local result={version=1,completed=integer(value.completed,0,0,#MISSIONS),replays=integer(value.replays,0,0,1000000),step=1,records={}}
    if result.completed<#MISSIONS then result.replays=0 end
    local mission=missionFor(result)
    result.step=integer(value.step,1,1,#mission.steps)
    for index=1,math.floor(result.completed/3) do result.records[tostring(index)]=true end
    return result
end
function Campaign.MergeProgress(oldValue,newValue)
    local old,new=Campaign.NormalizeProgress(oldValue),Campaign.NormalizeProgress(newValue)
    local selected=new
    if old.completed>new.completed or (old.completed==new.completed and old.replays>new.replays) then selected=old end
    local result=Campaign.NormalizeProgress(selected)
    result.completed,result.replays=math.max(old.completed,new.completed),math.max(old.replays,new.replays)
    if old.completed==new.completed and old.replays==new.replays then result.step=math.max(old.step,new.step) end
    return Campaign.NormalizeProgress(result)
end
function Campaign.GetCatalog()
    local catalog={}
    for _,mission in ipairs(MISSIONS) do
        local stages={}
        for _,stage in ipairs(mission.steps) do
            stages[#stages+1]={kind=stage.kind,station=stage.station,objective=stage.objective,duration=stage.duration,quiet=stage.quiet==true}
        end
        catalog[#catalog+1]={id=mission.id,title=mission.title,chapter=mission.chapter,chapterTitle=CHAPTERS[mission.chapter].title,summary=mission.summary,steps=stages}
    end
    return catalog
end

function Campaign.new(ctx)
    assert(ctx and ctx.getProfile and ctx.getRound and ctx.addPrompt,"Missing Campaign bridge")
    return setmetatable({ctx=ctx,players=ctx.Players or game:GetService("Players"),
        workspace=ctx.Workspace or game:GetService("Workspace"),clock=ctx.clock or os.clock,
        running=false,dead=false,epoch=0,night=0,stations={},prompts={},runtimes={},quota={},
        rewardLedger={},contributionLedger={},progressRefs={},lastSync=0},Campaign)
end
function Campaign:_profile(player)
    local profile=player and self.ctx.getProfile(player)
    if not profile or not profile.ready then return nil end
    if self.progressRefs[player]~=profile.campaign or type(profile.campaign)~="table" then
        profile.campaign=Campaign.NormalizeProgress(profile.campaign)
        self.progressRefs[player]=profile.campaign
    end
    return profile
end
function Campaign:_runtime(player)
    local runtime=self.runtimes[player]
    if not runtime then
        runtime={revision=0,sequence=0,cooldown=0,wrongUntil=0,timer=nil,carry=nil}
        self.runtimes[player]=runtime
    end
    return runtime
end
function Campaign:_current(player)
    local profile=self:_profile(player)
    if not profile then return nil end
    local mission,kind=missionFor(profile.campaign)
    return mission,mission.steps[profile.campaign.step],profile.campaign,kind
end
function Campaign:_key(player,progress,mission,kind)
    return tostring(player.UserId)..":"..kind..":"..tostring(kind=="story" and mission.index or progress.replays)
end
function Campaign:_token(player)
    local mission,_,progress,kind=self:_current(player)
    if not mission then return "" end
    return table.concat({self.epoch,mission.id,kind,progress.replays,progress.step,self:_runtime(player).revision},":")
end
function Campaign:_notify(player,message)
    if self.ctx.notify then self.ctx.notify(player,message) end
end
function Campaign:_sound(kind,part,caption,player)
    if self.ctx.onSound then self.ctx.onSound(kind,part and part.Position or nil,caption,player) end
end
function Campaign:_eligible(player,ignoreQuota)
    if self.dead or not self.running or self.ctx.getRound().phase~="SHIFT" then return false end
    if not self:_profile(player) then return false end
    if not ignoreQuota and (self.quota[player.UserId] or 0)>=LIMIT_PER_SHIFT then return false end
    local character=player.Character
    local root=character and character:FindFirstChild("HumanoidRootPart")
    local humanoid=character and character:FindFirstChildOfClass("Humanoid")
    if not root or not humanoid or humanoid.Health<=0 then return false end
    if player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") then return false end
    if self.ctx.isPlayerEligible and not self.ctx.isPlayerEligible(player) then return false end
    return true,root,humanoid
end
function Campaign:_near(player,station,range,ignoreQuota)
    local eligible,root=self:_eligible(player,ignoreQuota)
    local part=station and station.part
    if not eligible or not part or not part.Parent then return false end
    if (root.Position-part.Position).Magnitude>(range or STATION_RANGE) then return false end
    if self.ctx.hasLineOfSight then return self.ctx.hasLineOfSight(player,part) end
    local head=player.Character:FindFirstChild("Head") or root
    local params=RaycastParams.new()
    params.FilterType=Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances={player.Character,part,self.folder}
    params.RespectCanCollide,params.IgnoreWater=true,true
    return self.workspace:Raycast(head.Position,part.Position-head.Position,params)==nil
end
function Campaign:_throttle(player)
    local runtime=self:_runtime(player)
    local now=self.clock()
    if now<runtime.cooldown or now<runtime.wrongUntil then return false end
    runtime.cooldown=now+.45
    return true
end
function Campaign:_changed(player)
    self:SendState(player)
    self:SyncPrompts()
    if self.ctx.onChanged then self.ctx.onChanged(player) end
end
function Campaign:_contribute(player,mission,progress,kind,step)
    local key=self:_key(player,progress,mission,kind)..":"..step
    if self.contributionLedger[key] then return end
    self.contributionLedger[key]=true
    if self.ctx.contribute then self.ctx.contribute(player,"campaign_"..mission.id,2) end
end
function Campaign:_setCarry(player,carry)
    self:_runtime(player).carry=carry
    player:SetAttribute("NightShiftCarrying",carry and "campaign" or nil)
    if self.ctx.applyCarry then self.ctx.applyCarry(player,carry and "campaign" or nil) end
end
function Campaign:_clearCarry(player)
    local runtime=self.runtimes[player]
    if not runtime or not runtime.carry then return false end
    if runtime.carry.part then
        if self.ctx.props then self.ctx.props.Destroy(runtime.carry.part) else runtime.carry.part:Destroy() end
    end
    self:_setCarry(player,nil)
    return true
end
function Campaign:_recoverCarryStep(player)
    local mission,_,progress=self:_current(player)
    if not mission then return false end
    local runtime=self:_runtime(player)
    if runtime.carry then return false end
    local pickupStep,pendingItem
    for index=1,progress.step-1 do
        local step=mission.steps[index]
        if step.kind=="pickup" then pickupStep,pendingItem=index,step.item
        elseif step.kind=="deliver" and step.item==pendingItem then pickupStep,pendingItem=nil,nil end
    end
    if pickupStep then
        progress.step=pickupStep
        runtime.sequence,runtime.timer=0,nil
        runtime.revision+=1
        return true
    end
    return false
end
function Campaign:DropItem(player,returnHome)
    local runtime=self.runtimes[player]
    if not runtime or not runtime.carry then return false end
    local label=runtime.carry.label
    self:_clearCarry(player)
    self:_recoverCarryStep(player)
    runtime.timer,runtime.sequence=nil,0
    self:_notify(player,label.." возвращён к месту выдачи. Этап можно повторить.")
    self:_changed(player)
    return true
end
function Campaign:_pickup(player,mission,stage,progress)
    local runtime=self:_runtime(player)
    if runtime.carry or player:GetAttribute("NightShiftCarrying") then
        self:_notify(player,"Сначала положи переносимый предмет клавишей G.")
        return false
    end
    local root=player.Character and player.Character:FindFirstChild("HumanoidRootPart")
    local part
    if self.ctx.props then
        part=self.ctx.props.Build("campaign",stage.item,self.folder,{name="NS41CampaignCarry_"..tostring(player.UserId)})
        if root then self.ctx.props.SetCarried(part,root) end
    else
        part=Instance.new("Part")
        part.Name="NS40CampaignCarry_"..tostring(player.UserId)
        part.Size=Vector3.new(1.25,.85,1)
        part.Color,part.Material=Color3.fromRGB(115,104,76),Enum.Material.Metal
        part.Anchored,part.CanCollide,part.CanTouch,part.CanQuery=true,false,false,false
        if root then part.CFrame=root.CFrame*CFrame.new(0,-.2,-1.5) end
        part.Parent=self.folder
    end
    part:SetAttribute("CampaignItem",stage.item)
    part:SetAttribute("OwnerUserId",player.UserId)
    self:_setCarry(player,{id=mission.id,label=stage.item,part=part,pickupStep=progress.step})
    return true
end
function Campaign:_advance(player)
    local mission,stage,progress,kind=self:_current(player)
    if not mission then return false end
    local runtime=self:_runtime(player)
    local station=self.stations[stage.station]
    self:_contribute(player,mission,progress,kind,progress.step)
    runtime.sequence,runtime.timer=0,nil
    runtime.revision+=1
    if stage.note then self:_notify(player,stage.note) end
    self:_sound(stage.sound or "interact",station and station.part,stage.objective,player)
    if mission.id=="noise_decoy" and stage.kind=="deliver" and self.ctx.onNoise and station then
        self.ctx.onNoise(station.part.Position,"decoy",65,player)
        self:_sound("alarm",station.part,"Шумовая приманка включена")
    end
    if progress.step<#mission.steps then progress.step+=1
    else
        self:_clearCarry(player)
        local rewardKey=self:_key(player,progress,mission,kind)
        if kind=="story" then progress.completed+=1 else progress.replays+=1 end
        progress.step=1
        if kind=="story" and progress.completed%3==0 then progress.records[tostring(mission.chapter)]=true end
        self.quota[player.UserId]=(self.quota[player.UserId] or 0)+1
        if not self.rewardLedger[rewardKey] then
            self.rewardLedger[rewardKey]=true
            if self.ctx.award then self.ctx.award(player,kind=="story" and (90+mission.chapter*12) or 70,kind=="story" and 60 or 35) end
        end
        self:_notify(player,"Контракт завершён: "..mission.title..". "..tostring(self.quota[player.UserId]).."/"..LIMIT_PER_SHIFT.." за смену.")
        self:_sound("mission_complete",station and station.part,"Контракт завершён",player)
        if progress.completed==#MISSIONS and kind=="story" then
            self:_notify(player,"Все 24 сюжетных контракта завершены. Открыты сменные дежурные контракты.")
        elseif (self.quota[player.UserId] or 0)>=LIMIT_PER_SHIFT then
            self:_notify(player,"Новые контракты откроются в следующую смену. Помоги команде с основными задачами.")
        end
    end
    self:_changed(player)
    return true
end
function Campaign:_wrong(player,message,station)
    local runtime=self:_runtime(player)
    runtime.sequence,runtime.timer=0,nil
    runtime.wrongUntil=self.clock()+1.5
    runtime.revision+=1
    self:_notify(player,message)
    self:_sound("fail",station and station.part,message,player)
    if self.ctx.onNoise and station then self.ctx.onNoise(station.part.Position,"panel_error",24,player) end
    self:_changed(player)
    return false
end
function Campaign:Interact(player,stationId,data)
    data=type(data)=="table" and data or {}
    local mission,stage,progress=self:_current(player)
    local station=self.stations[stationId]
    if data.token~=nil and data.token~=self:_token(player) then return false end
    local missionHere=mission and stage and stage.station==stationId and self:_eligible(player)
    if not missionHere and self.ctx.onExplore then return self.ctx.onExplore(player,stationId)==true end
    if not mission or not self:_near(player,station) or not self:_throttle(player) then return false end
    if stage.station~=stationId then
        local nextStation=self.stations[stage.station] or {}
        self:_notify(player,"Следующий этап: "..stage.objective..". "..(nextStation.roomLabel or nextStation.title or "Смотри вкладку «Миссии»."))
        return false
    end
    local runtime=self:_runtime(player)
    if stage.kind=="choice" or stage.kind=="sequence" then
        if self.ctx.remote then self.ctx.remote:FireClient(player,"CampaignPrompt",self:GetState(player)) end
        self:_sound("terminal",station.part,"Панель открыта",player)
        return true
    elseif stage.kind=="pickup" then
        if not self:_pickup(player,mission,stage,progress) then return false end
    elseif stage.kind=="deliver" then
        if not runtime.carry or runtime.carry.label~=stage.item or not runtime.carry.part or not runtime.carry.part.Parent then
            self:_clearCarry(player);self:_recoverCarryStep(player)
            self:_notify(player,"Нужен предмет: "..stage.item..". Забери его у места выдачи.")
            self:_changed(player)
            return false
        end
        self:_clearCarry(player)
    elseif stage.kind=="work" then
        if runtime.timer then self:_notify(player,"Проверка уже идёт. Оставайся рядом.");return false end
        if stage.quiet and player:GetAttribute("NightShiftSprinting") then return self:_wrong(player,"Останови бег перед тихим замером.",station) end
        runtime.timer={started=self.clock(),ends=self.clock()+stage.duration,token=self:_token(player),station=stationId,duration=stage.duration}
        self:_notify(player,stage.objective..". Оставайся у станции "..tostring(stage.duration).." сек.")
        self:_sound(stage.sound or "repair",station.part,stage.objective,player)
        self:_changed(player)
        return true
    end
    return self:_advance(player)
end
function Campaign:Choose(player,data)
    if type(data)~="table" or type(data.choice)~="string" or type(data.token)~="string" then return false end
    local mission,stage=self:_current(player)
    if not mission or (stage.kind~="choice" and stage.kind~="sequence") then return false end
    local station=self.stations[stage.station]
    if data.token~=self:_token(player) or not self:_near(player,station) or not self:_throttle(player) then return false end
    local allowed=false
    for _,option in ipairs(stage.options) do if option.id==data.choice then allowed=true;break end end
    if not allowed then return false end
    local runtime=self:_runtime(player)
    if stage.kind=="choice" then
        if data.choice~=stage.answer then return self:_wrong(player,"Ответ не совпадает с найденными данными. Проверь подсказку контракта.",station) end
    else
        if data.choice~=stage.order[runtime.sequence+1] then return self:_wrong(player,"Порядок нарушен. Начни последовательность заново по подсказке.",station) end
        runtime.sequence+=1
        self:_sound("switch",station.part,"Контур "..data.choice,player)
        if runtime.sequence<#stage.order then self:SendState(player);return true end
    end
    return self:_advance(player)
end
function Campaign:Assist(player,data)
    if type(data)~="table" or type(data.targetUserId)~="number" then return false end
    local target
    for _,other in ipairs(self.players:GetPlayers()) do if other.UserId==data.targetUserId then target=other;break end end
    if not target or target==player then return false end
    local mission,stage,progress,kind=self:_current(target)
    if not mission or stage.kind~="work" then return false end
    local runtime=self:_runtime(target)
    local station=self.stations[stage.station]
    if not runtime.timer or not self:_near(player,station,STATION_RANGE,true) or not self:_near(target,station) or not self:_throttle(player) then return false end
    if data.targetToken and data.targetToken~=self:_token(target) then return false end
    local key=self.epoch..":assist:"..tostring(player.UserId)..":"..self:_key(target,progress,mission,kind)..":"..progress.step
    if self.contributionLedger[key] then return false end
    local reduction=math.min(2,math.max(0,runtime.timer.ends-self.clock()-.5))
    if reduction<=0 then return false end
    self.contributionLedger[key]=true
    runtime.timer.ends-=reduction
    if self.ctx.contribute then self.ctx.contribute(player,"campaign_assist",2) end
    self:_notify(player,"Ты помог напарнику: проверка ускорена.")
    self:_sound("interact",station.part,"Помощь напарнику",player)
    self:SendState(target)
    return true
end
function Campaign:HandleAction(player,action,data)
    if action=="CampaignChoice" then return self:Choose(player,data)
    elseif action=="CampaignInteract" then
        if type(data)~="table" or type(data.stationId)~="string" or type(data.token)~="string" then return false end
        return self:Interact(player,data.stationId,data)
    elseif action=="CampaignAssist" then return self:Assist(player,data)
    elseif action=="CampaignSync" then self:SendState(player);return true end
    return false
end
function Campaign:Build(world,stations)
    assert(world and type(stations)=="table","Campaign needs Locations stations")
    for _,prompt in pairs(self.prompts) do if prompt.Parent then prompt:Destroy() end end
    for player in pairs(self.runtimes) do self:DropItem(player,true) end
    if self.folder then self.folder:Destroy() end
    self.world,self.stations,self.prompts=world,stations,{}
    self.folder=Instance.new("Folder")
    self.folder.Name,self.folder.Parent="NightShiftCampaignProps",world
    for _,mission in ipairs(MISSIONS) do for _,stage in ipairs(mission.steps) do
        local station=stations[stage.station]
        assert(station and station.part and station.part.Parent,"Missing mission station: "..stage.station)
    end end
    for id,station in pairs(stations) do
        local stationId=id
        local prompt=self.ctx.addPrompt(station.part,self.ctx.onExplore and "Осмотреть" or "Контракт / осмотреть",station.title or station.room or id,.55,
            function(player)self:Interact(player,stationId)end,{distance=6.2,enforceLineOfSight=true})
        prompt.Name="NS40CampaignPrompt_"..id
        prompt:SetAttribute("CampaignStation",id)
        prompt:SetAttribute("NS41Explorable", self.ctx.onExplore ~= nil)
        prompt.Enabled=self.ctx.onExplore ~= nil
        self.prompts[id]=prompt
    end
    return self
end
function Campaign:SyncPrompts()
    local activeStations={}
    if self.running then for _,player in ipairs(self.players:GetPlayers()) do
        local _,stage=self:_current(player)
        if stage and (self.quota[player.UserId] or 0)<LIMIT_PER_SHIFT then activeStations[stage.station]=true end
    end end
    for id,prompt in pairs(self.prompts) do if prompt.Parent then
        prompt.Enabled=self.ctx.onExplore~=nil or activeStations[id]==true
        if self.ctx.onExplore then prompt.ActionText="Осмотреть" end
    end end
end
function Campaign:OnPlayerAdded(player)
    if not self:_profile(player) then return end
    self:_runtime(player);self:_recoverCarryStep(player);self:_changed(player)
end
function Campaign:OnPlayerRemoving(player)
    self:DropItem(player,true)
    self.runtimes[player],self.progressRefs[player]=nil,nil
    -- Quota/reward ledger intentionally uses UserId and survives rejoin.
    self:SyncPrompts()
end
function Campaign:BeginShift(night)
    if self.dead then return end
    self.epoch+=1
    self.night,self.running=integer(night,1,1,1000000),true
    self.quota,self.contributionLedger={},{}
    for _,player in ipairs(self.players:GetPlayers()) do
        self:DropItem(player,true)
        local runtime=self:_runtime(player)
        runtime.timer,runtime.sequence,runtime.cooldown,runtime.wrongUntil=nil,0,0,0
        runtime.revision+=1
        self:_recoverCarryStep(player)
        self:SendState(player)
    end
    self:SyncPrompts()
end
function Campaign:EndShift()
    self.running=false
    for _,player in ipairs(self.players:GetPlayers()) do
        self:DropItem(player,true)
        local runtime=self.runtimes[player]
        if runtime then runtime.timer,runtime.sequence=nil,0;runtime.revision+=1 end
        self:SendState(player)
    end
    self:SyncPrompts()
end
function Campaign:HasActiveWork()
    if self.dead or not self.running or self.ctx.getRound().phase~="SHIFT" then return false end
    -- Hiding, a temporary downed state, and respawning must not end a shift
    -- while an online player still has a ready profile and an unused contract.
    for _,player in ipairs(self.players:GetPlayers()) do
        if self:_profile(player) and (self.quota[player.UserId] or 0)<LIMIT_PER_SHIFT then return true end
    end
    return false
end
function Campaign:GetState(player)
    local mission,stage,progress,kind=self:_current(player)
    if not mission then return {version="4.0",active=false,status="Профиль загружается",total=#MISSIONS,completed=0,options={},records={}} end
    local runtime=self:_runtime(player)
    local station=self.stations[stage.station] or {}
    local done=self.quota[player.UserId] or 0
    local active=self.running and self.ctx.getRound().phase=="SHIFT" and done<LIMIT_PER_SHIFT
    local options={}
    for _,option in ipairs(stage.options or {}) do options[#options+1]={id=option.id,label=option.label} end
    local records={}
    for index,chapter in ipairs(CHAPTERS) do
        if progress.records[tostring(index)] then records[#records+1]={id=tostring(index),title=chapter.record,text=chapter.text} end
    end
    local carry
    if runtime.carry then
        local destination=station.roomLabel or station.title or stage.station
        for index=progress.step,#mission.steps do
            if mission.steps[index].kind=="deliver" then
                local target=self.stations[mission.steps[index].station] or {}
                destination=target.roomLabel or target.title or mission.steps[index].station
                break
            end
        end
        carry={id=runtime.carry.id,label=runtime.carry.label,destination=destination}
    end
    local status=active and "Контракт доступен" or done>=LIMIT_PER_SHIFT and "Два контракта выполнены. Продолжение в следующую смену." or "Продолжение после начала смены"
    if runtime.timer then status="Проверка идёт — оставайся у станции" end
    local note=stage.hint or ""
    if stage.quiet then note="Не беги и не двигайся до окончания замера." end
    if note=="" and progress.step>1 then note=mission.steps[progress.step-1].note or "" end
    local near=active and self:_near(player,station) or false
    local assistTargets={}
    if self.running then for _,other in ipairs(self.players:GetPlayers()) do
        local otherRuntime=self.runtimes[other]
        if other~=player and otherRuntime and otherRuntime.timer then
            local otherMission,otherStage=self:_current(other)
            local otherStation=otherStage and self.stations[otherStage.station]
            if otherMission and self:_near(player,otherStation,STATION_RANGE,true) then
                assistTargets[#assistTargets+1]={userId=other.UserId,name=other.DisplayName or other.Name,
                    title=otherMission.title,token=self:_token(other),stationId=otherStage.station}
            end
        end
    end end
    return {version="4.0",active=active,completed=progress.completed,total=#MISSIONS,
        chapter=mission.chapter,chapters=#CHAPTERS,chapterTitle=CHAPTERS[mission.chapter].title,
        finishedStory=progress.completed>=#MISSIONS,replayCount=progress.replays,quota={done=done,limit=LIMIT_PER_SHIFT},
        mission={id=mission.id,title=mission.title,index=mission.index,kind=kind,summary=mission.summary,
            location=station.roomLabel or station.title or "",roomId=station.room,step=progress.step,steps=#mission.steps,objective=stage.objective,
            hint=note,stationId=stage.station,position=station.part and station.part.Position or station.position,type=stage.kind,near=near},
        options=options,token=self:_token(player),sequenceProgress={done=runtime.sequence,total=stage.order and #stage.order or 0},
        timer={active=runtime.timer~=nil,remaining=runtime.timer and math.max(0,math.ceil(runtime.timer.ends-self.clock())) or 0,total=runtime.timer and runtime.timer.duration or 0},
        carry=carry,records=records,status=status,assistTargets=assistTargets}
end
function Campaign:SendState(player)
    if self.dead or not self.ctx.remote or not self:_profile(player) then return end
    self.ctx.remote:FireClient(player,"CampaignState",self:GetState(player))
end
function Campaign:Tick(dt)
    if self.dead then return end
    local now=self.clock()
    for player,runtime in pairs(self.runtimes) do
        local eligible,root,humanoid=self:_eligible(player)
        if runtime.carry then
            if not eligible or not runtime.carry.part or not runtime.carry.part.Parent then self:DropItem(player,true)
            elseif root then
                if self.ctx.props then self.ctx.props.UpdateCarried(runtime.carry.part,root)
                else runtime.carry.part.CFrame=root.CFrame*CFrame.new(0,-.2,-1.5) end
            end
        end
        local timer=runtime.timer
        if timer then
            local _,stage=self:_current(player)
            local quietViolation=stage and stage.quiet and (player:GetAttribute("NightShiftSprinting") or humanoid and humanoid.MoveDirection.Magnitude>.15)
            if not eligible or not stage or timer.token~=self:_token(player) or not self:_near(player,self.stations[timer.station],STATION_RANGE+.5) or quietViolation then
                runtime.timer=nil
                self:_notify(player,quietViolation and "Тихий замер прерван движением. Повтори без бега и шагов." or "Проверка прервана: вернись к станции и начни заново.")
                self:SendState(player)
            elseif now>=timer.ends then self:_advance(player) end
        end
    end
    if now-self.lastSync>=1 then
        self.lastSync=now
        for _,player in ipairs(self.players:GetPlayers()) do self:SendState(player) end
    end
end
function Campaign:Destroy()
    if self.dead then return end
    self:EndShift()
    for player in pairs(self.runtimes) do self:_clearCarry(player) end
    for _,prompt in pairs(self.prompts) do if prompt.Parent then prompt:Destroy() end end
    if self.folder then self.folder:Destroy() end
    self.dead,self.runtimes,self.prompts=true,{},{}
end
return Campaign
