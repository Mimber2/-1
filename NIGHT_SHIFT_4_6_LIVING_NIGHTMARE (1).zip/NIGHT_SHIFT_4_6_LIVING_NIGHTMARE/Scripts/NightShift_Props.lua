-- NIGHT SHIFT 4.5: compact, jointed carry props shared by ordinary and story tasks.
-- The returned BasePart is a transparent bounding root. Visible pieces are welded
-- to it. A held prop uses a real character weld, not a server-tick teleport.
local Props = {}
local V, CF = Vector3.new, CFrame.new
local states = setmetatable({}, {__mode = "k"})
local C = {
    cardboard = Color3.fromRGB(151, 112, 73), edge = Color3.fromRGB(101, 73, 47),
    tape = Color3.fromRGB(196, 165, 105), paper = Color3.fromRGB(218, 213, 187),
    ink = Color3.fromRGB(43, 48, 44), metal = Color3.fromRGB(112, 124, 120),
    dark = Color3.fromRGB(36, 45, 45), green = Color3.fromRGB(63, 91, 77),
    amber = Color3.fromRGB(201, 152, 67), red = Color3.fromRGB(141, 60, 52),
    ceramic = Color3.fromRGB(218, 216, 198), blue = Color3.fromRGB(76, 114, 125),
}
local LABEL_STYLE = {
    ["Маршрутный лист"] = "clipboard", ["Коробка К-17"] = "box",
    ["Датчик температуры"] = "sensor", ["Проба воды"] = "sample",
    ["Реле связи"] = "relay", ["Папка К-17"] = "folder",
    ["Защитный блок R-2"] = "power", ["Контрольный зонд"] = "probe",
    ["Шумовая приманка"] = "decoy", ["Опечатанный пакет"] = "evidence",
    ["Магистральный модуль"] = "module", ["Итоговый журнал"] = "journal",
}
local SIZE = {
    box = V(1.45, 1, 1.08), practice = V(1.15, 1, .95), bag = V(.95, 1.3, .95), fuse = V(.32, .85, .32),
    clipboard = V(.85, .12, 1.05), folder = V(.95, .16, .8), journal = V(.9, .23, .82),
    sensor = V(.55, .7, .42), sample = V(.45, .8, .45), relay = V(.7, .55, .52),
    power = V(.95, .65, .55), probe = V(.45, 1.05, .45), decoy = V(.85, .7, .6),
    evidence = V(.95, .16, .75), module = V(1.1, .5, .75), kit = V(1.15, .65, .75),
}
local function styleFor(kind, label)
    if LABEL_STYLE[label] then return LABEL_STYLE[label] end
    return SIZE[kind] and kind or "kit"
end
local function stateFor(root)
    return root and states[root]
end
local function physicallySafe(part)
    part.CanCollide, part.CanTouch, part.CanQuery, part.Massless = false, false, false, true
    part.TopSurface, part.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
end
local function piece(state, name, size, localFrame, color, material, shape, transparency)
    local part = Instance.new("Part")
    part.Name, part.Size, part.Color = name, size, color or C.dark
    part.Material = material or Enum.Material.SmoothPlastic
    part.Shape = shape or Enum.PartType.Block
    part.Transparency = transparency or 0
    part.Anchored, part.CastShadow = false, true
    physicallySafe(part)
    part.CFrame = state.root.CFrame * localFrame
    part:SetAttribute("NS41PropPiece", true)
    part:SetAttribute("NS41LocalFrame", localFrame)
    part.Parent = state.root
    local weld = Instance.new("Weld")
    weld.Name, weld.Part0, weld.Part1 = "DetailJoint", state.root, part
    weld.C0, weld.C1, weld.Parent = localFrame, CF(), part
    state.parts[#state.parts + 1] = {part = part, frame = localFrame, transparency = part.Transparency}
    return part
end
local function label(state, part, value, face, primary, ink)
    local gui = Instance.new("SurfaceGui")
    gui.Name, gui.Face = "CarryLabel", face or Enum.NormalId.Front
    gui.SizingMode, gui.PixelsPerStud, gui.MaxDistance = Enum.SurfaceGuiSizingMode.PixelsPerStud, 100, 45
    gui.LightInfluence, gui.AlwaysOnTop, gui.Parent = .35, false, part
    local text = Instance.new("TextLabel")
    text.Name, text.Size, text.BackgroundTransparency = primary and "ItemLabel" or "Marking", UDim2.fromScale(1, 1), 1
    text.Font, text.TextColor3 = Enum.Font.GothamBold, ink or C.ink
    text.TextScaled, text.TextWrapped, text.Text = true, true, value
    text.Parent = gui
    state.guis[#state.guis + 1] = gui
    if primary then state.labels[#state.labels + 1] = text end
    return text
end
local function carton(state, size, value, color, practice)
    local x, y, z = size.X, size.Y, size.Z
    piece(state, "CardboardBody", size - V(.025, .025, .025), CF(), color or C.cardboard)
    for _, side in ipairs({-1, 1}) do
        piece(state, "FoldEdge", V(.024, y*.94, .024), CF(side*x*.48, 0, -z*.485), C.edge)
        piece(state, "FoldEdge", V(.024, y*.94, .024), CF(side*x*.48, 0, z*.485), C.edge)
        piece(state, "LidFold", V(x*.97, .018, .018), CF(0, y*.49, side*z*.45), C.edge)
        piece(state, "PackingTapeEnd", V(x*.16, y*.32, .018), CF(0, y*.325, side*z*.49), C.tape)
    end
    piece(state, "LidSeam", V(.018, .014, z*.96), CF(0, y*.497, 0), C.edge)
    piece(state, "PackingTape", V(x*.16, .02, z*.99), CF(0, y*.495, 0), C.tape)
    for _, side in ipairs({-1, 1}) do
        local plate = piece(state, "ShippingLabel", V(x*.52, y*.38, .012), CF(-x*.12, -y*.045, side*z*.496), C.paper)
        label(state, plate, value, side == -1 and Enum.NormalId.Front or Enum.NormalId.Back, true)
        local stamp = piece(state, "HandlingStamp", V(x*.18, y*.2, .012), CF(x*.32, -y*.19, side*z*.496), practice and C.green or C.ink)
        label(state, stamp, practice and "01" or "↑↑", side == -1 and Enum.NormalId.Front or Enum.NormalId.Back, false, C.paper)
    end
end
local function documents(state, size, value, style)
    local x,y,z = size.X,size.Y,size.Z
    local cover = style == "evidence" and C.paper or style == "clipboard" and C.edge or C.green
    piece(state, "DocumentCover", V(x,y*.55,z), CF(0,-y*.2,0), cover)
    for i=1,3 do
        piece(state, "PaperLayer" .. i, V(x*.89,.012,z*.88), CF(.005*i,y*.05+.012*i,-.005*i), C.paper)
    end
    local title = piece(state, "DocumentTitle", V(x*.74,.008,z*.24), CF(0,y*.45,-z*.15), C.paper)
    label(state,title,value,Enum.NormalId.Top,true)
    for i=1,4 do
        piece(state,"PrintedLine",V(x*(i==4 and .42 or .68),.006,.012),CF(-x*.05,y*.47,z*(.07+i*.06)),C.ink)
    end
    if style == "clipboard" then
        piece(state,"SteelClip",V(x*.38,.035,z*.11),CF(0,y*.46,-z*.41),C.metal,Enum.Material.Metal)
    elseif style == "evidence" then
        piece(state,"EvidenceSeal",V(x*.2,.012,z*.96),CF(x*.29,y*.48,0),C.red)
    else
        piece(state,"FolderSpine",V(x*.06,y,z),CF(-x*.47,0,0),C.edge)
        if style == "journal" then piece(state,"JournalBand",V(x*.08,.012,z),CF(x*.32,y*.48,0),C.red) end
    end
end
local function refuseBag(state,size)
    local x,y,z=size.X,size.Y,size.Z
    piece(state,"BagBody",V(x*.92,y*.8,z*.92),CF(0,-y*.08,0),C.dark,Enum.Material.SmoothPlastic,Enum.PartType.Ball)
    for _, side in ipairs({-1,1}) do
        piece(state,"BagGather",V(x*.38,y*.31,z*.4),CF(side*x*.14,y*.23,0)*CFrame.Angles(0,0,side*.35),C.dark,Enum.Material.SmoothPlastic,Enum.PartType.Ball)
    end
    piece(state,"BagTie",V(x*.35,y*.09,z*.24),CF(0,y*.405,0),C.blue)
    piece(state,"BagKnot",V(x*.23,y*.1,z*.2),CF(x*.08,y*.455,0),C.dark,Enum.Material.SmoothPlastic,Enum.PartType.Ball)
end
local function fuse(state,size)
    local x,y,z=size.X,size.Y,size.Z
    piece(state,"CeramicFuseBody",V(x*.75,y*.69,z*.75),CF(),C.ceramic)
    for _, side in ipairs({-1,1}) do
        piece(state,"MetalContact",V(x*.95,y*.17,z*.95),CF(0,side*y*.405,0),C.metal,Enum.Material.Metal)
    end
    local plate=piece(state,"FuseRating",V(x*.65,y*.28,.012),CF(0,0,-z*.386),C.ceramic)
    label(state,plate,"F1\n250V",Enum.NormalId.Front,true)
end
local function sample(state,size,value)
    local x,y,z=size.X,size.Y,size.Z
    piece(state,"SampleGlass",V(y*.76,x*.85,z*.85),CFrame.Angles(0,0,math.pi/2)*CF(-y*.05,0,0),C.blue,Enum.Material.Glass,Enum.PartType.Cylinder,.35)
    piece(state,"WaterSample",V(y*.42,x*.69,z*.69),CF(0,-y*.14,0)*CFrame.Angles(0,0,math.pi/2),Color3.fromRGB(79,109,104),Enum.Material.Glass,Enum.PartType.Cylinder,.25)
    piece(state,"SampleCap",V(y*.13,x*.95,z*.95),CF(0,y*.425,0)*CFrame.Angles(0,0,math.pi/2),C.dark,Enum.Material.Metal,Enum.PartType.Cylinder)
    local plate=piece(state,"SampleTag",V(x*.72,y*.26,.012),CF(0,-y*.05,-z*.43),C.paper)
    label(state,plate,value,Enum.NormalId.Front,true)
end
local function equipment(state,size,value,style)
    local x,y,z=size.X,size.Y,size.Z
    local tint = style == "power" and C.amber or style == "module" and C.blue or C.green
    piece(state,"EquipmentHousing",V(x*.98,y*.79,z*.96),CF(0,-y*.075,0),C.dark,Enum.Material.Metal)
    piece(state,"HousingLid",V(x*.99,y*.13,z*.98),CF(0,y*.385,0),tint,Enum.Material.Metal)
    for _, side in ipairs({-1,1}) do
        piece(state,"LidFastener",V(x*.07,.026,z*.07),CF(side*x*.39,y*.465,-z*.37),C.metal,Enum.Material.Metal)
        piece(state,"Terminal",V(x*.17,y*.15,z*.16),CF(side*x*.28,-y*.39,-z*.43),C.metal,Enum.Material.Metal)
    end
    local plate=piece(state,"EquipmentPlate",V(x*.72,y*.43,.012),CF(0,-y*.04,-z*.487),C.paper)
    label(state,plate,value,Enum.NormalId.Front,true)
    if style == "decoy" then
        for i=1,4 do piece(state,"SpeakerSlot",V(x*.66,.018,.018),CF(0,y*(.1-i*.1),z*.49),C.metal,Enum.Material.Metal) end
        piece(state,"DecoyDial",V(.12,.12,.035),CF(x*.31,y*.27,-z*.5),C.red,Enum.Material.SmoothPlastic,Enum.PartType.Ball)
    elseif style == "module" or style == "relay" or style == "power" then
        for i=1,3 do piece(state,"Connector",V(x*.1,y*.12,z*.09),CF(x*(-.2+i*.1),y*.13,z*.49),C.metal,Enum.Material.Metal) end
    elseif style == "sensor" or style == "probe" then
        piece(state,"InstrumentScreen",V(x*.46,y*.25,.016),CF(0,y*.19,z*.492),C.ink)
        piece(state,"Indicator",V(x*.09,y*.06,.02),CF(x*.27,y*.26,z*.495),C.amber,Enum.Material.Neon)
    else
        piece(state,"CarryHandle",V(x*.4,y*.1,z*.12),CF(0,y*.46,0),C.metal,Enum.Material.Metal)
    end
end

function Props.Build(kind,labelText,parent,options)
    options = type(options) == "table" and options or {}
    local value = type(labelText) == "string" and labelText or "СЛУЖЕБНЫЙ ПРЕДМЕТ"
    local style = styleFor(kind,value)
    local size = options.size or SIZE[style]
    local root = Instance.new("Part")
    root.Name, root.Size = options.name or "CarryProp", size
    root.CFrame, root.Transparency, root.Anchored = options.cframe or CF(), 1, true
    root.CastShadow = false
    physicallySafe(root)
    root:SetAttribute("NS41Prop", true)
    root:SetAttribute("CarryStyle", style)
    root:SetAttribute("CarryLabel", value)
    local state = {root=root,style=style,parts={},guis={},labels={},visible=true}
    states[root] = state
    if style == "box" or style == "practice" then carton(state,size,value,options.color,style=="practice")
    elseif style == "bag" then refuseBag(state,size)
    elseif style == "fuse" then fuse(state,size)
    elseif style == "clipboard" or style == "folder" or style == "journal" or style == "evidence" then documents(state,size,value,style)
    elseif style == "sample" then sample(state,size,value)
    else equipment(state,size,value,style) end
    root.Parent = parent
    if root.Destroying then root.Destroying:Connect(function() states[root]=nil end) end
    return root,state.labels[1]
end

function Props.SetVisible(root,visible)
    local state=stateFor(root)
    if not state then return false end
    state.visible=visible==true
    root.Transparency=1
    for _, entry in ipairs(state.parts) do if entry.part.Parent then entry.part.Transparency=state.visible and entry.transparency or 1 end end
    for _, gui in ipairs(state.guis) do if gui.Parent then gui.Enabled=state.visible end end
    return true
end

function Props.SetLabel(root,value)
    local state=stateFor(root)
    if not state or type(value)~="string" then return false end
    root:SetAttribute("CarryLabel",value)
    for _, text in ipairs(state.labels) do if text.Parent then text.Text=value end end
    return true
end

function Props.CarryOffset(root)
    local state=stateFor(root)
    local style=state and state.style or "box"
    if style=="clipboard" or style=="folder" or style=="journal" or style=="evidence" then
        return CF(.22,-.8,-1.25)*CFrame.Angles(math.rad(18),math.rad(-12),math.rad(-4))
    elseif style=="bag" then return CF(.65,-.8,-1.05)*CFrame.Angles(0,math.rad(12),math.rad(-6))
    elseif style=="box" or style=="practice" then return CF(0,-.65,-1.5)*CFrame.Angles(math.rad(-4),0,0)
    end
    return CF(.25,-.65,-1.3)*CFrame.Angles(math.rad(-8),math.rad(-15),0)
end

function Props.Release(root)
    local state=stateFor(root)
    if not state then return false end
    if state.carryJoint then state.carryJoint:Destroy();state.carryJoint=nil end
    state.holder=nil
    root:SetAttribute("CarryAttached",false)
    root.Anchored=true
    root.AssemblyLinearVelocity,root.AssemblyAngularVelocity=Vector3.zero,Vector3.zero
    return true
end

function Props.Place(root,frame)
    local state=stateFor(root)
    if not state then return false end
    Props.Release(root)
    root.CFrame=frame
    for _, entry in ipairs(state.parts) do
        if entry.part.Parent then
            entry.part.CFrame=frame*entry.frame
            entry.part.Anchored=false
        end
    end
    return true
end

function Props.SetCarried(root,holder)
    local state=stateFor(root)
    if not state or not root.Parent or not holder or not holder.Parent or not holder:IsA("BasePart") then return false end
    local offset=Props.CarryOffset(root)
    Props.Place(root,holder.CFrame*offset)
    local weld=Instance.new("Weld")
    weld.Name,weld.Part0,weld.Part1="CarryGrip",holder,root
    weld.C0,weld.C1=offset,CF()
    weld.Parent=root
    state.carryJoint,state.holder=weld,holder
    root.Anchored=false
    root:SetAttribute("CarryAttached",true)
    Props.SetVisible(root,true)
    return true
end

function Props.UpdateCarried(root,holder)
    local state=stateFor(root)
    if not state then return false end
    if state.carryJoint and state.carryJoint.Parent==root and state.holder==holder and holder and holder.Parent then return true end
    return Props.SetCarried(root,holder)
end

function Props.Destroy(root)
    if not root then return end
    Props.Release(root)
    states[root]=nil
    root:Destroy()
end

Props.LabelStyles=table.clone(LABEL_STYLE)
return Props
