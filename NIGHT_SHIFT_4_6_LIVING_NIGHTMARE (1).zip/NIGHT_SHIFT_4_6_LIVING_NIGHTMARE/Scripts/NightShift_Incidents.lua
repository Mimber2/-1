-- NIGHT SHIFT 4.5: server-authoritative, optional, multi-step incidents.
-- Incidents have visible controls and a finite deadline. They NEVER alter
-- campaign progress, permanently lock doors or change the main blackout state.
local Incidents = {}
Incidents.__index = Incidents
local V, RGB = Vector3.new, Color3.fromRGB
local LIST = {
    {id="surge", night=1, title="ПЕРЕГРЕВ ГЕНЕРАТОРА", room="Генераторная", station="generator_panel",
        controls={"Сбросить нагрузку", "Охладить двигатель", "Проверить частоту"}, order={2,1,3},
        sound="incident_surge", warning="Генератор перегревается. У панели есть три переключателя."},
    {id="flood", night=2, title="ПРОТЕЧКА В НАСОСНОЙ", room="Насосная B1", station="pump_console",
        controls={"Перекрыть байпас", "Запустить дренаж", "Проверить давление"}, order={1,3,2},
        sound="incident_flood", warning="В насосной вода. Остановите утечку через блок управления."},
    {id="desync", night=2, title="СБОЙ КАМЕР ОХРАНЫ", room="Комната охраны", station="security_terminal",
        controls={"Отключить канал", "Синхронизировать часы", "Перезапустить запись"}, order={1,2,3},
        sound="incident_camera", warning="Камеры теряют синхронизацию. Нужен перезапуск системы."},
    {id="radio", night=3, title="ПОСТОРОННИЙ СИГНАЛ", room="Серверная B1", station="comms_console",
        controls={"Понизить усиление", "Сменить частоту", "Заземлить линию"}, order={2,3,1},
        sound="incident_radio", warning="В линии посторонний голос. Проверьте серверную."},
    {id="archive", night=4, title="СИГНАЛ АРХИВА", room="Архив B1", station="archive_records",
        controls={"Проверить карточку", "Изолировать канал", "Подтвердить источник"}, order={3,1,2},
        sound="incident_archive", warning="В архиве зафиксировано движение, но камеры никого не показывают."},
}

function Incidents.new(ctx)
    return setmetatable({ctx=ctx,clock=ctx.clock or os.clock,random=ctx.random or Random.new(),
        devices={},phase="INTERMISSION",night=1,active=nil,nextAt=math.huge,
        sequence=0,lastId=nil,folder=nil,water=nil,ended=false,threatRequested=false,
        userCooldown=setmetatable({}, {__mode="k"})}, Incidents)
end

function Incidents:_part(name,size,frame,container,color,material)
    local part=Instance.new("Part")
    part.Name=name;part.Size=size;part.CFrame=frame;part.Anchored=true
    part.CanCollide=false;part.CanTouch=false;part.CanQuery=false;part.CastShadow=false
    part.TopSurface=Enum.SurfaceType.Smooth;part.BottomSurface=Enum.SurfaceType.Smooth
    part.Color=color or RGB(60,68,71);part.Material=material or Enum.Material.Metal
    part.Parent=container
    return part
end

function Incidents:_screen(part)
    local gui=Instance.new("SurfaceGui")
    gui.Name="StatusDisplay";gui.Face=Enum.NormalId.Front;gui.LightInfluence=0
    gui.SizingMode=Enum.SurfaceGuiSizingMode.PixelsPerStud;gui.PixelsPerStud=50
    gui.AlwaysOnTop=false;gui.MaxDistance=45;gui.Parent=part
    local label=Instance.new("TextLabel")
    label.BackgroundTransparency=1;label.Size=UDim2.fromScale(.94,.92)
    label.Position=UDim2.fromScale(.03,.04);label.TextScaled=true;label.TextWrapped=true
    label.Font=Enum.Font.GothamBold;label.TextColor3=RGB(206,229,209)
    label.Text="СИСТЕМА В НОРМЕ";label.Parent=gui
    return label
end

function Incidents:Build(world,stations)
    assert(not self.folder,"Build called twice")
    self.world=world
    local folder=Instance.new("Folder");folder.Name="NS43EmergencyStations";folder.Parent=world
    self.folder=folder
    for _,definition in ipairs(LIST) do
        local station=stations[definition.station]
        if station and station.part and station.part.Parent then
            local model=Instance.new("Model");model.Name="NS43_"..definition.id;model.Parent=folder
            local frame=station.part.CFrame*CFrame.new(0,-1.95,-.32)
            local base=self:_part("ControlPanel",V(2.25,1.55,.2),frame,model,RGB(48,63,67))
            local display=self:_part("Readout",V(1.98,.55,.06),frame*CFrame.new(0,.38,-.13),model,RGB(15,34,32),Enum.Material.SmoothPlastic)
            local text=self:_screen(display)
            local led=self:_part("WarningLED",V(.12,.12,.08),frame*CFrame.new(1.02,.66,-.15),model,RGB(95,180,125),Enum.Material.Neon)
            local buttons={}
            for i=1,3 do
                local knob=self:_part("Control"..i,V(.42,.42,.14),frame*CFrame.new((i-2)*.67,-.37,-.17),model,RGB(129,151,154))
                local rim=self:_part("Rim"..i,V(.48,.48,.04),frame*CFrame.new((i-2)*.67,-.37,-.24),model,RGB(27,31,36))
                local dot=self:_part("Touch"..i,V(.33,.33,.07),frame*CFrame.new((i-2)*.67,-.37,-.275),model,RGB(190,156,96),Enum.Material.Neon)
                local control={knob=knob,rim=rim,dot=dot,original=knob.CFrame,home=knob.Color}
                buttons[i]=control
                -- Existing addPrompt validates character, health, proximity, cooldown.
                control.prompt=self.ctx.addPrompt(knob,definition.controls[i],definition.room,.42,function(player)
                    self:Interact(player,definition.id,i)
                end,{distance=6,lineOfSight=false,enforceLineOfSight=true})
                control.prompt:SetAttribute("NS43IncidentControl",true)
                control.prompt:SetAttribute("IncidentId",definition.id)
            end
            self.devices[definition.id]={station=station,definition=definition,model=model,base=base,
                display=text,light=led,buttons=buttons}
        end
    end
    -- Non-colliding thin sheet; purely visual. It cannot trap a character or NPC.
    local water=self:_part("PumpRoomWater",V(20,.08,15),CFrame.new(26,-10.34,-120),folder,RGB(40,116,139),Enum.Material.Glass)
    water.Transparency=1
    self.water=water
    folder:SetAttribute("IncidentSystems",#LIST)
    self:_refresh()
    return self
end

function Incidents:_snapshot()
    local active=self.active
    if not active then return {active=false,phase=self.phase,sequence=self.sequence} end
    local definition=active.definition
    local index=definition.order[active.step]
    return {active=true,id=definition.id,title=definition.title,room=definition.room,
        action=index and definition.controls[index] or "Проверить оборудование",step=active.step,
        total=#definition.order,remaining=math.max(0,math.ceil(active.expires-self.clock())),
        errors=active.errors,phase=self.phase,sequence=self.sequence}
end

function Incidents:SendState(player)
    local snap=self:_snapshot()
    if player then self.ctx.remote:FireClient(player,"IncidentUpdate",snap)
    else self.ctx.remote:FireAllClients("IncidentUpdate",snap) end
end

function Incidents:_refresh()
    local active=self.active
    for id,device in pairs(self.devices) do
        local isActive=active and active.definition.id==id
        device.light.Color=isActive and RGB(224,100,70) or RGB(95,180,125)
        if isActive then
            local idx=active.definition.order[active.step]
            device.display.Text="АВАРИЯ · "..tostring(active.step).."/3\n"..active.definition.controls[idx]
        else
            device.display.Text="ЛИНИЯ В НОРМЕ\nОСМОТР E"
        end
        for i,control in ipairs(device.buttons) do
            local selected=isActive and active.definition.order[active.step]==i
            control.dot.Color=selected and RGB(244,178,72) or RGB(87,113,112)
            if control.prompt then
                control.prompt.ActionText=isActive and (selected and "Исправить · " or "Проверить · ")..device.definition.controls[i]
                    or "Осмотреть · "..device.definition.controls[i]
            end
        end
    end
    if self.water then
        self.water.Transparency=active and active.definition.id=="flood" and .52 or 1
        if not active or active.definition.id~="flood" then
            self.water.Size=V(20,.08,15);self.water.Position=V(26,-10.34,-120)
        end
    end
    if self.world then
        self.world:SetAttribute("NS43Incident",active and active.definition.id or "")
        self.world:SetAttribute("NS43CameraInterference",active and active.definition.id=="desync" or false)
        self.world:SetAttribute("NS43WaterLeak",active and active.definition.id=="flood" or false)
    end
end

function Incidents:_choose()
    local eligible={}
    for _,entry in ipairs(LIST) do
        if self.night >= entry.night and self.devices[entry.id] and entry.id~=self.lastId then
            table.insert(eligible,entry)
        end
    end
    if #eligible==0 then
        for _,entry in ipairs(LIST) do if self.night>=entry.night and self.devices[entry.id] then table.insert(eligible,entry) end end
    end
    return #eligible>0 and eligible[self.random:NextInteger(1,#eligible)] or nil
end

function Incidents:_begin()
    local definition=self:_choose()
    if not definition then self.nextAt=self.clock()+70;return end
    self.lastId=definition.id;self.sequence+=1;self.threatRequested=false
    self.active={definition=definition,step=1,errors=0,started=self.clock(),expires=self.clock()+80}
    self:_refresh()
    self:SendState()
    self.ctx.notifyAll("ВНЕШНЯЯ АВАРИЯ · "..definition.warning)
    self.ctx.sound(definition.sound,self.devices[definition.id].base.Position,definition.warning)
    self.ctx.noise(self.devices[definition.id].base.Position,"machinery",25)
end

function Incidents:Interact(player,id,index)
    local device=self.devices[id]
    if not device or not player or player.Parent~=self.ctx.Players then return false end
    local profile=self.ctx.getProfile(player)
    local character=player.Character
    local root=character and character:FindFirstChild("HumanoidRootPart")
    local humanoid=character and character:FindFirstChildOfClass("Humanoid")
    if not profile or not profile.ready or not root or not humanoid or humanoid.Health<=0 then return false end
    if player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") then return false end
    if (root.Position-device.base.Position).Magnitude>9 then return false end
    local now=self.clock()
    if now<(self.userCooldown[player] or 0) then return false end
    self.userCooldown[player]=now+.55
    local control=device.buttons[index]
    if not control then return false end
    local active=self.active
    if self.phase~="SHIFT" or not active or active.definition.id~=id then
        self.ctx.notify(player,"Диагностика: "..device.definition.controls[index]..". Неисправностей нет. Во время аварии тут появится порядок действий.")
        self.ctx.sound("incident_step",control.knob.Position,"Контакт проверен",player)
        return true
    end
    if now>=active.expires then return false end
    if active.definition.order[active.step]~=index then
        active.errors+=1
        self.ctx.notify(player,"НЕ ТОТ КОНТАКТ. Смотри на подсвеченную кнопку и подсказку. Прогресс не потерян.")
        self.ctx.sound("incident_wrong",control.knob.Position,"Неисправный контакт")
        self.ctx.noise(control.knob.Position,"machinery",27,player)
        if active.errors>=3 and not self.threatRequested then
            self.threatRequested=true
            self.ctx.pressure()
        end
        self:SendState(player)
        return false
    end
    active.step+=1
    control.knob.CFrame=control.original*CFrame.new(0,0,-.08)
    control.knob.Color=RGB(103,193,145)
    self.ctx.sound("incident_step",control.knob.Position,"Контакт переключён")
    self.ctx.noise(control.knob.Position,"repair",13,player)
    self.ctx.onFix(player,"incident_"..id)
    task.delay(.42,function()
        if control.knob and control.knob.Parent then
            control.knob.CFrame=control.original;control.knob.Color=control.home
        end
    end)
    if active.step>#active.definition.order then
        local name=active.definition.title
        self.ctx.notifyAll("АВАРИЯ УСТРАНЕНА · "..name)
        self.ctx.sound("incident_done",device.base.Position,"Система восстановлена")
        self.active=nil;self.nextAt=now+self.random:NextNumber(68,94)
    else
        self.ctx.notify(player,"Контакт принят. Следующее действие: "..active.definition.controls[active.definition.order[active.step]])
    end
    self.sequence+=1
    self:_refresh()
    self:SendState()
    return true
end

function Incidents:BeginShift(night)
    self:EndShift()
    self.phase="SHIFT";self.night=night or 1;self.ended=false
    self.nextAt=self.clock()+self.random:NextNumber(40,66)
    self:_refresh();self:SendState()
end

function Incidents:EndShift()
    self.phase="INTERMISSION";self.active=nil;self.nextAt=math.huge
    self.sequence+=1;self:_refresh();self:SendState()
end

function Incidents:Tick()
    if self.phase~="SHIFT" then return end
    local now=self.clock()
    local active=self.active
    if active then
        -- The leak has a visible rising waterline, with no collision or damage.
        if active.definition.id=="flood" and self.water then
            local level=math.clamp((now-active.started)/40,0,1)
            self.water.Size=V(20,.08+.45*level,15)
            self.water.Position=V(26,-10.34+.225*level,-120)
        end
        local lamp=self.devices[active.definition.id]
        if lamp and lamp.light then lamp.light.Color=math.floor(now*2)%2==0 and RGB(230,97,70) or RGB(115,42,40) end
        if now>=active.expires then
            local device=self.devices[active.definition.id]
            self.ctx.notifyAll("Авария затихла, но кто-то слышал оборудование. Дальше будьте осторожны.")
            if device then self.ctx.sound("incident_failed",device.base.Position,"Сигнал аварии обрывается") end
            if not self.threatRequested then self.ctx.pressure() end
            self.active=nil;self.sequence+=1;self.nextAt=now+self.random:NextNumber(80,110)
            self:_refresh();self:SendState()
        elseif now-(self.lastBroadcast or 0)>=3 then
            self.lastBroadcast=now;self:SendState()
        end
    elseif now>=self.nextAt then self:_begin() end
end

function Incidents:OnPlayerRemoving(player)self.userCooldown[player]=nil end
function Incidents:Destroy()
    self:EndShift();if self.folder then self.folder:Destroy();self.folder=nil end
    self.devices={};self.userCooldown=setmetatable({}, {__mode="k"})
end
function Incidents.GetDefinitions()return LIST end
return Incidents
