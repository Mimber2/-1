-- NIGHT SHIFT 4.0 PBR MATERIAL VARIANT SETUP
-- Upload the corresponding PNGs to Roblox first, then replace each 0 with its asset ID.
-- Run once from the Studio Command Bar or convert into a one-time Script.
local MaterialService = game:GetService("MaterialService")
local definitions = {
    {name="NS_Ceramic", base=Enum.Material.Slate, color=0, normal=0, roughness=0, metalness=0},
    {name="NS_Concrete", base=Enum.Material.Concrete, color=0, normal=0, roughness=0, metalness=0},
    {name="NS_BrushedSteel", base=Enum.Material.Metal, color=0, normal=0, roughness=0, metalness=0},
    {name="NS_Asphalt", base=Enum.Material.Asphalt, color=0, normal=0, roughness=0, metalness=0},
    {name="NS_Cardboard", base=Enum.Material.Cardboard, color=0, normal=0, roughness=0, metalness=0},
}
for _, definition in ipairs(definitions) do
    local variant = MaterialService:FindFirstChild(definition.name) or Instance.new("MaterialVariant")
    variant.Name = definition.name
    variant.BaseMaterial = definition.base
    if definition.color > 0 then variant.ColorMap = "rbxassetid://" .. definition.color end
    if definition.normal > 0 then variant.NormalMap = "rbxassetid://" .. definition.normal end
    if definition.roughness > 0 then variant.RoughnessMap = "rbxassetid://" .. definition.roughness end
    if definition.metalness > 0 then variant.MetalnessMap = "rbxassetid://" .. definition.metalness end
    variant.Parent = MaterialService
end
print("NIGHT SHIFT 3.7 PBR variants created. Assign the variants to the desired Parts after replacing the asset IDs.")
