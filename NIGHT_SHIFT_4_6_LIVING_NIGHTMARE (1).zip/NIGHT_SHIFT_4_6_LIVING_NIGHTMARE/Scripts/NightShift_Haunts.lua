-- NIGHT SHIFT 4.2: physical, optional horror interactions and controlled disturbances.
-- Never edits campaign progress or blocks a route. No scary events outside the shift.
local Haunts = {}
Haunts.__index = Haunts

local V, RGB = Vector3.new, Color3.fromRGB
local ACTION_TYPES = {
    retail_register="paper",archive_records="paper",loading_manifest="lever",generator_panel="lever",
    cold_sensor="dial",basement_breaker="lever",boiler_gauge="dial",workshop_bench="drawer",
    pump_console="lever",security_terminal="dial",comms_console="dial",staff_locker="drawer",dispatch_scanner="lever",
}
local DEVICE_DEFS = {
    {id="security_terminal",name="Шумный приёмник",action="Прослушать частоту",sound="tape_echo",
        messages={"Кто-то повторяет проверочный вызов. Голос звучит из отключённой трубки.","В наушнике три тихих удара. На частоте больше никого нет."}},
    {id="loading_manifest",name="Пломба погрузки",action="Потрогать пломбу",sound="metal_creak",
        messages={"Пломба ледяная. По ту сторону ворот на секунду слышится тяжёлый вдох.","Болты вибрируют, хотя снаружи нет ни одной машины."}},
    {id="retail_register",name="Лента кассы",action="Взять чек",sound="paper",
        messages={"Из кассы выходит чек: 03:17. Сдача: один человек.","Новая строка на чеке: НЕ СМОТРИ НАЗАД."}},
    {id="generator_panel",name="Пусковой ключ",action="Проверить ключ",sound="switch",
        messages={"Ключ проворачивается на четверть оборота и возвращается обратно. Мотор не запускается.","Гул в стене на мгновение повторяет ритм твоего дыхания."}},
    {id="cold_sensor",name="Термодатчик",action="Стереть иней",sound="glass_tap",
        messages={"За стеклом появляется отпечаток ладони с другой стороны.","Иней сложился в цифры 0317. Через секунду они исчезают."}},
    {id="basement_breaker",name="Резервный контакт",action="Проверить контакт",sound="relay_glitch",
        messages={"Контакт щёлкает дважды, а в соседнем помещении ему отвечают три щелчка.","На секунду светится линия B2. В схеме этой линии нет."}},
    {id="boiler_gauge",name="Дренажный клапан",action="Спустить воздух",sound="valve_release",noise=14,
        messages={"Клапан выпустил немного пара. Из трубы ответил странный низкий стук.","Давление нормально, но стрелка дрожит, когда кто-то проходит по коридору."}},
    {id="workshop_bench",name="Инструментальная полка",action="Пересчитать ключи",sound="metal_creak",
        messages={"На полке на один ключ больше, чем по описи.","Один ключ тёплый, словно его только что держали."}},
    {id="pump_console",name="Контрольная сирена",action="Проверить сигнал",sound="relay_glitch",
        messages={"Сирена отвечает коротким надломленным гудком. Основная тревога не включалась.","На табло вспыхивает номер неисправного датчика, но он не подключён."}},
    {id="archive_records",name="Запечатанная папка",action="Осмотреть печать",sound="paper",
        messages={"Под печатью написано имя сотрудника, который ещё не заступал на смену.","Лист внутри сырой. Снаружи папка совершенно сухая."}},
    {id="comms_console",name="Служебный микрофон",action="Прослушать запись",sound="mimic_voice",
        messages={"Запись называет тебя по должности и просит не отвечать в микрофон.","На ленте тишина, кроме звука чужих шагов возле микрофона."}},
    {id="staff_locker",name="Забытый шкафчик",action="Постучать",sound="interaction_knock",noise=12,
        messages={"Изнутри отвечают два коротких удара. Дверца заперта и пуста.","За дверцей что-то царапнуло металл, затем наступила тишина."}},
    {id="dispatch_scanner",name="Сканер возвратов",action="Просканировать ярлык",sound="scan",
        messages={"Сканер прочитал: ПОЛУЧАТЕЛЬ НЕ ОБНАРУЖЕН.","На экране отображается пункт назначения: АРХИВ / 03:17."}},
}

function Haunts.new(ctx)
    return setmetatable({ctx=ctx,devices={},active={},last={},playerCooldown=setmetatable({}, {__mode="k"}),
        clock=ctx.clock or os.clock,random=ctx.random or Random.new(),phase="INTERMISSION",nextEvent=math.huge,
        count=0,folder=nil},Haunts)
end

function Haunts:_part(name,size,frame,parent,color)
    local p=Instance.new("Part")
    p.Name=name;p.Size=size;p.CFrame=frame;p.Anchored=true;p.CanCollide=false;p.CanTouch=false
    p.CanQuery=false;p.CastShadow=false;p.Color=color or RGB(69,83,84);p.Material=Enum.Material.Metal;p.Parent=parent
    return p
end

function Haunts:Build(world,stations)
    assert(not self.folder,"Haunts.Build called twice")
    local folder=Instance.new("Folder");folder.Name="NS42OptionalInteractions";folder.Parent=world
    self.folder=folder
    for _,desc in ipairs(DEVICE_DEFS) do
        local station=stations[desc.id]
        if station and station.part and station.part.Parent then
            local frame=station.part.CFrame*CFrame.new(2.05,-1.42,-.38)
            local assembly=Instance.new("Model");assembly.Name="NS42_"..desc.id;assembly.Parent=folder
            local back=self:_part("ReaderHousing",V(.72,.75,.16),frame,assembly)
            local face=self:_part("ReaderFace",V(.54,.46,.06),frame*CFrame.new(0,.06,-.12),assembly,RGB(26,35,39))
            face.Material=Enum.Material.SmoothPlastic
            local lamp=self:_part("ReaderIndicator",V(.12,.08,.05),frame*CFrame.new(.22,.27,-.17),assembly,RGB(98,178,158))
            lamp.Material=Enum.Material.Neon
            local kind=ACTION_TYPES[desc.id] or "lever"
            local moving
            if kind=="paper" then
                moving=self:_part("EjectedReceipt",V(.31,.46,.025),frame*CFrame.new(-.08,-.35,-.19),assembly,RGB(215,203,171))
                moving.Material=Enum.Material.SmoothPlastic
            elseif kind=="drawer" then
                moving=self:_part("DrawerFront",V(.49,.22,.12),frame*CFrame.new(0,-.28,-.19),assembly,RGB(116,132,131))
                self:_part("DrawerPull",V(.21,.055,.11),frame*CFrame.new(0,-.28,-.30),assembly,RGB(204,177,120))
            elseif kind=="dial" then
                moving=self:_part("MeterNeedle",V(.045,.28,.045),frame*CFrame.new(-.1,-.21,-.22),assembly,RGB(232,199,126))
                moving.Material=Enum.Material.Neon
            else
                moving=self:_part("ToggleLever",V(.12,.35,.13),frame*CFrame.new(0,-.26,-.21),assembly,RGB(213,183,123))
            end
            local prompt=self.ctx.addPrompt(face,desc.action,desc.name,.45,function(player) self:Interact(player,desc.id) end,
                {distance=5.8,lineOfSight=false,enforceLineOfSight=true})
            self.devices[desc.id]={desc=desc,station=station,face=face,lamp=lamp,prompt=prompt,home=lamp.Color,
                kind=kind,moving=moving,homeFrame=moving.CFrame,model=assembly}
        end
    end
    folder:SetAttribute("OptionalInteractables",#DEVICE_DEFS)
    return self
end

function Haunts:_pulse(id,duration)
    local item=self.devices[id]
    if not item or not item.lamp.Parent then return end
    local now=self.clock()
    self.active[id]=now+(duration or 1.7)
    item.lamp.Color=RGB(244,148,80)
end

function Haunts:Interact(player,id)
    local item=self.devices[id]
    if not item or not player or player.Parent~=self.ctx.Players then return false end
    local profile=self.ctx.getProfile(player)
    local character=player.Character
    local root=character and character:FindFirstChild("HumanoidRootPart")
    local humanoid=character and character:FindFirstChildOfClass("Humanoid")
    if not profile or not profile.ready or not root or not humanoid or humanoid.Health<=0 then return false end
    if player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") then return false end
    if (root.Position-item.face.Position).Magnitude>7.6 then return false end
    local now=self.clock()
    local history=self.playerCooldown[player]
    if not history then history={};self.playerCooldown[player]=history end
    if now<(history[id] or 0) then return false end
    history[id]=now+7
    self.count+=1
    local msg=item.desc.messages[(self.count-1)%#item.desc.messages+1]
    self:_pulse(id,1.7)
    local moving=item.moving
    if moving and moving.Parent then
        local offset
        if item.kind=="paper" then offset=CFrame.new(0,-.14,-.24)
        elseif item.kind=="drawer" then offset=CFrame.new(0,0,-.18)
        elseif item.kind=="dial" then offset=CFrame.Angles(0,0,math.rad(65))
        else offset=CFrame.Angles(math.rad(-38),0,0) end
        moving.CFrame=item.homeFrame*offset
        local token=(item.animationToken or 0)+1
        item.animationToken=token
        task.delay(1.4,function()
            if item.animationToken==token and moving.Parent then moving.CFrame=item.homeFrame end
        end)
    end
    self.ctx.notify(player,msg)
    self.ctx.sound(item.desc.sound,item.face.Position,item.desc.action,player)
    if item.desc.noise and self.phase=="SHIFT" then self.ctx.noise(item.face.Position,"machinery",item.desc.noise,player) end
    return true
end

function Haunts:BeginShift(night)
    self.phase="SHIFT";self.night=night or 1
    self.nextEvent=self.clock()+self.random:NextNumber(24,38)
end

function Haunts:EndShift()
    self.phase="INTERMISSION";self.nextEvent=math.huge
    for id,item in pairs(self.devices) do
        if item.moving and item.moving.Parent then item.animationToken=(item.animationToken or 0)+1;item.moving.CFrame=item.homeFrame end
        if item.lamp and item.lamp.Parent then item.lamp.Color=item.home end
        self.active[id]=nil
    end
end

function Haunts:_disturb(now)
    local choices={}
    for id,item in pairs(self.devices) do
        local visitors={}
        for _,player in ipairs(self.ctx.Players:GetPlayers()) do
            local root=player.Character and player.Character:FindFirstChild("HumanoidRootPart")
            local human=player.Character and player.Character:FindFirstChildOfClass("Humanoid")
            if root and human and human.Health>0 and not player:GetAttribute("NightShiftDowned")
                and (root.Position-item.face.Position).Magnitude<37 then
                table.insert(visitors,player)
            end
        end
        if #visitors>0 and now-(self.last[id] or -100)>60 and not self.active[id] then
            table.insert(choices,{id=id,item=item,visitors=visitors})
        end
    end
    if #choices==0 then return end
    local choice=choices[self.random:NextInteger(1,#choices)]
    self.last[choice.id]=now;self:_pulse(choice.id,2.2)
    local caption=choice.item.desc.name..": странный звук"
    self.ctx.sound(self.random:NextInteger(1,3)==1 and "fear_sting" or choice.item.desc.sound,choice.item.face.Position,caption)
    for _,player in ipairs(choice.visitors) do
        if self.random:NextInteger(1,4)==1 then
            self.ctx.notify(player,"Из оборудования доносится шум. Можно осмотреть его без задания.")
        end
    end
end

function Haunts:Tick()
    local now=self.clock()
    for id,untilTime in pairs(self.active) do
        if now>=untilTime then
            local item=self.devices[id]
            if item and item.lamp.Parent then item.lamp.Color=item.home end
            self.active[id]=nil
        end
    end
    if self.phase~="SHIFT" or now<self.nextEvent then return end
    self:_disturb(now)
    self.nextEvent=now+self.random:NextNumber(40,65)
end

function Haunts:OnPlayerRemoving(player) self.playerCooldown[player]=nil end
function Haunts:Destroy()
    self:EndShift();if self.folder then self.folder:Destroy();self.folder=nil end
    self.devices={};self.playerCooldown=setmetatable({}, {__mode="k"})
end
function Haunts.GetStationIds()
    local ids={};for _,entry in ipairs(DEVICE_DEFS) do table.insert(ids,entry.id) end;return ids
end
return Haunts
