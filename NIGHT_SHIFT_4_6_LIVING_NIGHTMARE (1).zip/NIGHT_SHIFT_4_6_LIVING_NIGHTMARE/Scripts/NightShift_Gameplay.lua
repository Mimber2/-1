-- NIGHT SHIFT 4.5: server-owned objectives, jointed carry props, observations and customers.
-- All client requests are suggestions; position, phase, item ownership and progress
-- are checked here before any objective or optional reward is granted.
local Gameplay = {}
Gameplay.__index = Gameplay

local TASK_INFO = {
    restock = {title = "Пополнить полки", location = "Склад → торговый зал", steps = 2},
    generator = {title = "Восстановить питание", location = "Генераторная", steps = 3},
    trash = {title = "Вынести мусор", location = "Торговый зал → технический двор", steps = 5},
    cctv = {title = "Найти аномалию на камерах", location = "Комната охраны", steps = 1},
    breaker = {title = "Проверить резервный щит", location = "Подвал B1 · щитовая", steps = 3},
    cooler = {title = "Проверить холодильники", location = "Холодильный ряд", steps = 3},
    door = {title = "Закрыть заднюю дверь", location = "Погрузочная", steps = 1},
}
local TASK_ORDER = {"restock", "generator", "trash", "cctv", "breaker", "cooler", "door"}
local ANOMALY_OPTIONS = {
    {id = "silhouette", label = "Силуэт"},
    {id = "light", label = "Необычный свет"},
    {id = "open_door", label = "Открытый люк"},
}
local STORY = {
    "Запись 01. Предыдущая смена просила не оставлять погрузочную без наблюдения.",
    "Запись 02. В журнале появились чеки, выписанные на следующую ночь.",
    "Запись 03. Технический люк опечатали. На камерах пломба иногда исчезает.",
    "Запись 04. Голос по внутренней связи повторяет слова прошлого охранника.",
    "Запись 05. Все странности начинаются после обхода холодильного ряда.",
}
local WHITE = Color3.fromRGB(230, 237, 223)
local GREEN = Color3.fromRGB(80, 202, 141)
local AMBER = Color3.fromRGB(230, 167, 67)

local function cloneOptions(options)
    local result = {}
    for i, option in ipairs(options) do result[i] = {id = option.id, label = option.label} end
    return result
end

function Gameplay.new(context)
    assert(context and context.getProfile and context.getRound and context.completeTask, "Missing gameplay bridge")
    local self = setmetatable({}, Gameplay)
    self.ctx = context
    self.players = context.Players or game:GetService("Players")
    self.workspace = context.Workspace or game:GetService("Workspace")
    self.clock = context.clock or os.clock
    self.random = context.randomInteger or math.random
    self.tasks, self.items, self.carry, self.claims = {}, {}, {}, {}
    self.contribution, self.cooldowns, self.views = {}, {}, {}
    self.managedPrompts, self.anchors, self.corePrompts = {}, {}, {}
    self.shelfChoices, self.coolers, self.trashPiles, self.cameraChoices = {}, {}, {}, {}
    self.running, self.epoch, self.night, self.elapsed = false, 0, 0, 0
    self.syncAt, self.tickBudget, self.blackoutWasActive = 0, 0, false
    self.customerCount, self.customerAt, self.customer = 0, 35, nil
    self.anomaly = nil
    return self
end

function Gameplay:_notify(player, message)
    if self.ctx.notify then self.ctx.notify(player, message) end
end

function Gameplay:_sound(kind, position, caption, player)
    if self.ctx.onSound then self.ctx.onSound(kind, position, caption, player) end
end

function Gameplay:_profile(player)
    return player and self.ctx.getProfile(player)
end

function Gameplay:_eligible(player, allowPreparation)
    local profile = self:_profile(player)
    local character = player and player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if not profile or not profile.ready or not root or not humanoid or humanoid.Health <= 0 then return false end
    if player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") then return false end
    if self.ctx.isPlayerEligible and not self.ctx.isPlayerEligible(player) then return false end
    local phase = self.ctx.getRound().phase
    if phase ~= "SHIFT" and not (allowPreparation and phase == "INTERMISSION") then return false end
    return true, root
end

function Gameplay:_near(player, part, range, allowPreparation)
    local eligible, root = self:_eligible(player, allowPreparation)
    if not eligible or not part or not part.Parent then return false end
    if (root.Position - part.Position).Magnitude > (range or 7) then return false end
    if self.ctx.hasLineOfSight then return self.ctx.hasLineOfSight(player, part) end
    local character = player.Character
    local head = character:FindFirstChild("Head") or root
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = {character, part, self.folder}
    params.RespectCanCollide = true
    params.IgnoreWater = true
    return self.workspace:Raycast(head.Position, part.Position - head.Position, params) == nil
end

function Gameplay:_throttle(player, key, seconds)
    self.cooldowns[player] = self.cooldowns[player] or {}
    local now = self.clock()
    if now < (self.cooldowns[player][key] or 0) then return false end
    self.cooldowns[player][key] = now + seconds
    return true
end

function Gameplay:_active(id)
    local state = self.tasks[id]
    if not self.running or not state or not state.active or state.done then return false end
    local tasks = self.ctx.getRound().tasks
    if tasks and tasks[id] == true and not (id == "generator" and state.emergency) then return false end
    return true
end

function Gameplay:_find(name)
    return self.world and self.world:FindFirstChild(name, true)
end

function Gameplay:_part(name, size, position, color, material, transparency, parent)
    local part = self.ctx.makeDetail(name, size, position, color or AMBER,
        material or Enum.Material.Metal, transparency or 0, parent or self.folder)
    part.CanCollide, part.CanTouch, part.CanQuery = false, false, false
    return part
end

function Gameplay:_label(part, message, face, color)
    local gui = Instance.new("SurfaceGui")
    gui.Name = "NightShiftTaskSign"
    gui.Face = face or Enum.NormalId.Front
    gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
    gui.PixelsPerStud, gui.LightInfluence, gui.MaxDistance = 55, 0, 60
    gui.Parent = part
    local label = Instance.new("TextLabel")
    label.Size = UDim2.fromScale(1, 1)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.GothamBold
    label.TextColor3 = color or WHITE
    label.TextScaled, label.TextWrapped = true, true
    label.Text = message
    label.Parent = gui
    return label
end

function Gameplay:_prompt(name, position, action, title, hold, callback, enabled, options)
    local anchor = self:_part(name, Vector3.new(0.18, 0.18, 0.18), position, WHITE, Enum.Material.SmoothPlastic, 1)
    local prompt = self.ctx.addPrompt(anchor, action, title, hold, callback, options or {distance = 6.5})
    self.managedPrompts[#self.managedPrompts + 1] = {prompt = prompt, enabled = enabled}
    prompt.Enabled = false
    return prompt, anchor
end

function Gameplay:_newItem(key, kind, label, home, size, color, facing)
    local props = self.ctx.props
    local part, labelText
    if props then
        part, labelText = props.Build(kind, label, self.folder, {name = "Carry_" .. key, size = size, color = color})
    else
        part = self:_part("Carry_" .. key, size, home, color, Enum.Material.SmoothPlastic, 1)
    end
    local item = {key = key, kind = kind, label = label, part = part, home = home,
        available = false, owner = nil, droppedAt = nil, consumed = false, facing = facing or Vector3.new(0, 0, 1)}
    local frame = CFrame.lookAt(home, home + item.facing)
    if props then props.Place(part, frame); props.SetVisible(part, false) else part.CFrame = frame end
    self.items[key] = item
    if props then item.labelText = labelText
    else item.labelText = self:_label(part, kind == "fuse" and "F1" or label, Enum.NormalId.Front, WHITE) end
    item.prompt = self.ctx.addPrompt(part, "Взять", label, 0.65, function(player) self:Pickup(player, key) end, {distance = 6})
    self.managedPrompts[#self.managedPrompts + 1] = {prompt = item.prompt, enabled = function()
        return item.available and not item.owner and not item.consumed
    end}
    return item
end

function Gameplay:_showItem(item, available)
    item.available = available
    if self.ctx.props then
        self.ctx.props.SetVisible(item.part, available or item.owner ~= nil)
    else
        if not item.owner then item.part.Transparency = available and 0 or 1 end
        for _, child in ipairs(item.part:GetChildren()) do
            if child:IsA("SurfaceGui") then child.Enabled = available end
        end
    end
    item.prompt.Enabled = available and not item.owner and not item.consumed
end

function Gameplay:Build(world)
    self.world = world
    self.folder = Instance.new("Model")
    self.folder.Name = "NightShiftGameplay36"
    self.folder.Parent = world
    for id, name in pairs({restock = "StockCrate", generator = "Generator", trash = "TrashBin",
        cctv = "CCTVMonitor", breaker = "BasementBreakerPanel", door = "RearDoorTaskAnchor"}) do
        local body = self:_find(name)
        self.anchors[id] = body
        if body then self.corePrompts[id] = body:FindFirstChildOfClass("ProximityPrompt") end
    end
    for i, data in ipairs({{"AisleLeft", "СНЕКИ"}, {"AisleCenter", "НАПИТКИ"}, {"AisleRight", "БАКАЛЕЯ"}}) do
        local base = self:_find(data[1] .. "Base")
        if base then
            local choice = {name = data[2], part = base, products = {}}
            for _, part in ipairs(world:GetDescendants()) do
                if part:IsA("BasePart") and part.Name:sub(1, #data[1]) == data[1]
                    and (part.Name:find("Product") or part.Name:find("Bottle") or part.Name:find("Can") or part.Name:find("Pack") or part.Name:find("BoxBand") or part.Name:find("BoxLabel")) then
                    choice.products[#choice.products + 1] = {part = part, transparency = part.Transparency}
                end
            end
            self.shelfChoices[i] = choice
            local _, anchor = self:_prompt("RestockShelf" .. i, Vector3.new(base.Position.X, 3.0, base.Position.Z + base.Size.Z / 2 + 0.35),
                "Разложить товар", "Отдел: " .. data[2], 1.5, function(player) self:DeliverRestock(player, i) end,
                function() return self:_active("restock") and self.tasks.restock.target == i or self:_hasPracticeCarry() end)
            choice.anchor = anchor
        end
    end
    self:_newItem("restock", "box", "ТОВАР", Vector3.new(25.4, 3.8, -8.5), Vector3.new(1.25, 1.0, 1.0), Color3.fromRGB(157, 112, 68), Vector3.new(1, 0, 0))
    -- A preparation exercise remains available to new arrivals even on a later shared night.
    local practiceHome = Vector3.new(-14.5, 0.8, 24)
    local practice = self:_newItem("practice", "practice", "УЧЕБНАЯ КОРОБКА", practiceHome, Vector3.new(1.15, 1, 0.95), Color3.fromRGB(104, 157, 139))
    practice.training = true
    self:_showItem(practice, true)
    self:_newItem("trash", "bag", "МЕШОК С МУСОРОМ", Vector3.new(-32.55, 0.95, 18), Vector3.new(0.95, 1.3, 0.95), Color3.fromRGB(38, 49, 51), Vector3.new(1, 0, 0)).part.Shape = Enum.PartType.Ball
    self:_newItem("fuse", "fuse", "ПРЕДОХРАНИТЕЛЬ", Vector3.new(40.14, 3.4, -12.6), Vector3.new(0.32, 0.85, 0.32), Color3.fromRGB(191, 164, 96), Vector3.new(-1, 0, 0))
    self.fuseHomes = {Vector3.new(40.14, 3.4, -12.6), Vector3.new(-27.84, 3.4, -43)}
    for i, position in ipairs(self.fuseHomes) do
        local side = i == 1 and Vector3.new(-1, 0, 0) or Vector3.new(1, 0, 0)
        local cabinet = self:_part("FuseCabinet" .. i, Vector3.new(1.3, 1.65, 0.26), position - side * 0.34, Color3.fromRGB(55, 71, 76))
        cabinet.CFrame = CFrame.lookAt(cabinet.Position, cabinet.Position + side)
        local mount = self:_part("FuseCabinetMount" .. i, Vector3.new(1.1, 1.45, 0.2), cabinet.Position, Color3.fromRGB(47, 58, 64))
        mount.CFrame = cabinet.CFrame * CFrame.new(0, 0, 0.22)
        local sill = self:_part("FuseCabinetSill" .. i, Vector3.new(0.45, 0.1, 0.45), position, Color3.fromRGB(90, 104, 106))
        sill.CFrame = CFrame.lookAt(position, position + side) * CFrame.new(0, -0.48, 0.12)
        local plate = self:_part("FuseCabinetSign" .. i, Vector3.new(1.15, 0.3, 0.04), cabinet.Position, Color3.fromRGB(38, 50, 57))
        plate.CFrame = cabinet.CFrame * CFrame.new(0, 0.62, -0.15)
        self:_label(plate, "ЗАПАС · F1", Enum.NormalId.Front)
    end
    local dumpster = self:_find("OutdoorDumpster")
    local disposalPosition = dumpster and dumpster.Position + Vector3.new(-2.5, 0, 0) or Vector3.new(52.5, 2.1, 2)
    local _, disposal = self:_prompt("TrashDisposal36", disposalPosition, "Выбросить мешок", "Контейнер во дворе", 1.4,
        function(player) self:DeliverTrash(player) end, function() return self:_active("trash") and self.tasks.trash.stage >= 3 end)
    self.anchors.disposal = disposal
    for i, position in ipairs({Vector3.new(-25, 0.325, 13), Vector3.new(1.7, 0.325, 3), Vector3.new(-15, 0.325, -22)}) do
        local pieces = {}
        for n = 1, 3 do
            local piece = self:_part("Litter" .. i .. "_" .. n, Vector3.new(0.45, 0.035, 0.3), position + Vector3.new((n - 2) * 0.35, 0, (n % 2) * 0.25), Color3.fromRGB(181, 176, 149), Enum.Material.SmoothPlastic, 1)
            piece.CFrame = CFrame.new(piece.Position) * CFrame.Angles(0, math.rad(n * 37), 0)
            pieces[n] = piece
        end
        local _, anchor = self:_prompt("LitterControl" .. i, position + Vector3.new(0, 0.3, 0), "Собрать мусор", "Участок " .. i, 0.9,
            function(player) self:CollectTrash(player, i) end,
            function() return self:_active("trash") and not self.tasks.trash.collected[i] end)
        self.trashPiles[i] = {parts = pieces, anchor = anchor}
    end
    for i, x in ipairs({-34, -17, 13}) do
        local plate = self:_part("CoolerThermometer" .. i, Vector3.new(0.9, 1.2, 0.08), Vector3.new(x - 2.65, 4.15, -27.83), Color3.fromRGB(33, 51, 57))
        plate.CFrame = CFrame.lookAt(plate.Position, plate.Position + Vector3.new(0, 0, 1))
        local display = self:_label(plate, "+2°C\nНОРМА", Enum.NormalId.Front, GREEN)
        local prompt = self.ctx.addPrompt(plate, "Проверить температуру", "Холодильник " .. i, 1.1, function(player) self:InspectCooler(player, i) end, {distance = 7})
        self.coolers[i] = {plate = plate, display = display, prompt = prompt}
        self.managedPrompts[#self.managedPrompts + 1] = {prompt = prompt, enabled = function() return self:_active("cooler") end}
    end
    local breaker = self.anchors.breaker
    if breaker then
        self.breakerLabels = {}
        for i = 1, 3 do
            local lever = self:_part("BreakerSwitch36_" .. i, Vector3.new(0.18, 0.5, 0.12), breaker.Position + Vector3.new(-0.85 + (i - 1) * 0.85, -0.5, 0.49), AMBER)
            self.breakerLabels[i] = lever
        end
    end
    local cameraPoints = world:FindFirstChild("CameraPoints")
    if cameraPoints then
        for _, point in ipairs(cameraPoints:GetChildren()) do
            local index = point:GetAttribute("Order")
            if type(index) == "number" then self.cameraChoices[index] = {id = index, label = point:GetAttribute("Label") or point.Name, part = point} end
        end
    end
    -- Fixed wall-mounted service hatch in the loading bay, visible on Camera05.
    -- Keep this clear of HideLocker4 and in Camera05's direct sightline.
    local hatchFrame = CFrame.lookAt(Vector3.new(28.455, 5.8, -46), Vector3.new(27.455, 5.8, -46))
    self.hatchFrame = hatchFrame
    local back = self:_part("AnomalyHatchBack", Vector3.new(2.8, 3.2, 0.09), hatchFrame.Position, Color3.fromRGB(22, 30, 35))
    back.CFrame = hatchFrame
    self.hatch = self:_part("AnomalyHatchDoor", Vector3.new(2.7, 3.1, 0.12), hatchFrame.Position, Color3.fromRGB(125, 137, 132))
    self.hatchClosed = hatchFrame * CFrame.new(0, 0, -0.1)
    self.hatch.CFrame = self.hatchClosed
    self:_label(self.hatch, "ТЕХЛЮК\nЗАКРЫВАТЬ", Enum.NormalId.Front)
    self:SyncPrompts()
    return self
end

function Gameplay:_hasPracticeCarry()
    for _, item in pairs(self.carry) do if item.kind == "practice" then return true end end
    return false
end

function Gameplay:_restoreShelf()
    for _, shelf in ipairs(self.shelfChoices) do
        for _, entry in ipairs(shelf.products) do
            if entry.part.Parent then entry.part.Transparency = entry.transparency end
        end
    end
end

function Gameplay:BeginShift(night, activeIds)
    self:EndShift()
    self.running, self.night, self.elapsed, self.startedAt = true, night, 0, self.clock()
    self.epoch += 1
    self.tasks, self.claims, self.contribution = {}, {}, {}
    self.customerCount, self.customerAt = 0, 35
    self.blackoutWasActive = false
    for id, info in pairs(TASK_INFO) do
        local active = activeIds[id] == true
        self.tasks[id] = {id = id, selected = active, active = active, stage = 0, done = false, steps = info.steps}
    end
    self.tasks.restock.target = self.random(1, math.max(1, #self.shelfChoices))
    self.tasks.trash.collected = {}
    self.tasks.cooler.target = self.random(1, math.max(1, #self.coolers))
    self.tasks.generator.source = night <= 1 and 1 or self.random(1, #self.fuseHomes)
    self.items.fuse.facing = self.tasks.generator.source == 1 and Vector3.new(-1, 0, 0) or Vector3.new(1, 0, 0)
    self:_resetItem("restock", self:_active("restock"))
    self:_resetItem("trash", false)
    self:_resetItem("fuse", false, self.fuseHomes[self.tasks.generator.source])
    if self:_active("restock") then
        local choice = self.shelfChoices[self.tasks.restock.target]
        if choice then
            if self.ctx.props then self.ctx.props.SetLabel(self.items.restock.part, "ТОВАР\n" .. choice.name)
            else self.items.restock.labelText.Text = "ТОВАР\n" .. choice.name end
            for _, entry in ipairs(choice.products) do if entry.part.Parent then entry.part.Transparency = 1 end end
        end
    end
    for _, pile in ipairs(self.trashPiles) do
        for _, piece in ipairs(pile.parts) do piece.Transparency = self:_active("trash") and 0 or 1 end
    end
    for i, cooler in ipairs(self.coolers) do
        local fault = self:_active("cooler") and self.tasks.cooler.target == i
        cooler.display.Text = fault and "+12°C\nСБОЙ" or "+2°C\nНОРМА"
        cooler.display.TextColor3 = fault and AMBER or GREEN
    end
    for _, lever in ipairs(self.breakerLabels or {}) do lever.Color = AMBER; lever.Orientation = Vector3.new(0, 0, 0) end
    self:_spawnAnomaly()
    self:SyncPrompts()
    self:Broadcast()
end

function Gameplay:_resetItem(key, available, home)
    local item = self.items[key]
    if not item then return end
    if item.owner then self:_clearCarry(item.owner) end
    item.home = home or item.home
    item.owner, item.droppedAt, item.consumed = nil, nil, false
    local frame = CFrame.lookAt(item.home, item.home + item.facing)
    if self.ctx.props then self.ctx.props.Place(item.part, frame) else item.part.CFrame = frame end
    self:_showItem(item, available)
end

function Gameplay:_clearCarry(player)
    local item = self.carry[player]
    self.carry[player] = nil
    if item then
        item.owner = nil
        if self.ctx.props then self.ctx.props.Release(item.part) end
    end
    if player and item then
        player:SetAttribute("NightShiftCarrying", nil)
        if self.ctx.applyCarry then self.ctx.applyCarry(player, nil) end
    end
    return item
end

function Gameplay:DropItem(player, returnHome)
    local item = self:_clearCarry(player)
    if not item then return false end
    local position = item.home
    local character = player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    if not returnHome and root then
        local params = RaycastParams.new()
        params.FilterType = Enum.RaycastFilterType.Exclude
        params.FilterDescendantsInstances = {character, self.folder}
        params.RespectCanCollide = true
        local candidate = root.Position + root.CFrame.LookVector * 1.25
        local floor = self.workspace:Raycast(candidate + Vector3.new(0, 0.5, 0), Vector3.new(0, -7, 0), params)
        if floor and floor.Normal.Y > 0.7 and floor.Position.Y <= root.Position.Y - 0.8
            and floor.Position.Y > -14 and math.abs(floor.Position.X) < 88 and floor.Position.Z > -178 and floor.Position.Z < 120 then
            position = floor.Position + Vector3.new(0, item.part.Size.Y / 2 + 0.08, 0)
        end
    end
    local frame = CFrame.lookAt(position, position + item.facing)
    if self.ctx.props then self.ctx.props.Place(item.part, frame) else item.part.CFrame = frame end
    item.droppedAt = self.clock()
    self:_showItem(item, true)
    self:_sound("item_drop", position, "Предмет поставлен на пол", player)
    self:Broadcast()
    return true
end

function Gameplay:Pickup(player, key)
    local item = self.items[key]
    if not item or not item.available or item.owner or item.consumed or self.carry[player] or player:GetAttribute("NightShiftCarrying") then return false end
    if item.training then
        local profile = self:_profile(player)
        if not profile or profile.tutorialDone then return false end
    elseif not self.running then return false end
    if not self:_near(player, item.part, 6.5, item.training) or not self:_throttle(player, "pickup", 0.5) then return false end
    item.owner, item.droppedAt = player, nil
    if self.ctx.props then
        local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
        if not self.ctx.props.SetCarried(item.part, root) then item.owner = nil; return false end
    end
    self.carry[player] = item
    item.prompt.Enabled = false
    if not self.ctx.props then item.part.Transparency = 0 end
    player:SetAttribute("NightShiftCarrying", item.kind)
    if self.ctx.applyCarry then self.ctx.applyCarry(player, item.kind) end
    if key == "restock" and self.tasks.restock then self.tasks.restock.stage = 1 end
    if key == "trash" and self.tasks.trash then self.tasks.trash.stage = 4 end
    self:_tutorial(player, "pickup")
    self:RegisterContribution(player, "pickup_" .. key, 1)
    self:_sound("item_pickup", item.part.Position, "Предмет взят", player)
    self:Broadcast()
    return true
end

function Gameplay:_consume(player, key)
    local item = self.carry[player]
    if not item or item.key ~= key then return false end
    self:_clearCarry(player)
    item.consumed = true
    self:_showItem(item, false)
    return true
end

function Gameplay:RegisterContribution(player, kind, amount)
    if not self.running or not player or type(kind) ~= "string" then return false end
    local profile = self:_profile(player)
    if not profile or not profile.ready then return false end
    local contribution = self.contribution[player]
    if not contribution then contribution = {score = 0, kinds = {}}; self.contribution[player] = contribution end
    -- Repeated pickups, repeated claims and repeated reports cannot farm credit.
    if contribution.kinds[kind] then return false end
    contribution.kinds[kind] = true
    contribution.score += math.clamp(tonumber(amount) or 1, 1, 5)
    contribution.lastAt = self.clock()
    return true
end

function Gameplay:IsContributor(player)
    local value = self.contribution[player]
    return value ~= nil and value.score >= 2
end

function Gameplay:GetContributionSummary(player)
    local value = self.contribution[player]
    local kinds = {}
    if value then for kind in pairs(value.kinds) do kinds[#kinds + 1] = kind end end
    table.sort(kinds)
    return {score = value and value.score or 0, kinds = kinds, useful = self:IsContributor(player)}
end

function Gameplay:_finish(player, id)
    local state = self.tasks[id]
    if not state or state.done or state.finishing then return false end
    state.finishing = true
    self:RegisterContribution(player, "complete_" .. id, 3)
    local ok = self.ctx.completeTask(player, id) == true
    if ok then
        state.done, state.stage = true, state.steps
        self.claims[id] = nil
    end
    state.finishing = false
    if ok then
        self:_sound("task_success", self.anchors[id] and self.anchors[id].Position, "Задание выполнено", player)
        self:SyncPrompts()
        self:Broadcast()
    end
    return ok
end

function Gameplay:DeliverRestock(player, index)
    local shelf = self.shelfChoices[index]
    if not shelf or not self:_near(player, shelf.anchor, 6.5, true) then return false end
    local item = self.carry[player]
    if item and item.kind == "practice" then
        self:_consume(player, "practice")
        self:_tutorial(player, "delivery")
        self:_resetItem("practice", true)
        self:_notify(player, "Товар на месте. Теперь найди ближайший шкаф с надписью «УКРЫТИЕ».")
        self:Broadcast()
        return true
    end
    if not self:_active("restock") or self.tasks.restock.target ~= index then return false end
    if not item or item.key ~= "restock" then self:_notify(player, "Сначала возьми коробку на складе."); return false end
    if self:_finish(player, "restock") then
        self:_consume(player, "restock")
        for _, entry in ipairs(shelf.products) do if entry.part.Parent then entry.part.Transparency = entry.transparency end end
        self:_tutorial(player, "delivery")
        self:Broadcast()
        return true
    end
    return false
end

function Gameplay:CollectTrash(player, index)
    local state, pile = self.tasks.trash, self.trashPiles[index]
    if not self:_active("trash") or not pile or state.collected[index] or not self:_near(player, pile.anchor, 6) then return false end
    state.collected[index] = true
    state.stage += 1
    for _, piece in ipairs(pile.parts) do piece.Transparency = 1 end
    self:RegisterContribution(player, "litter_" .. index, 1)
    if state.stage == 3 then self:_showItem(self.items.trash, true); self:_notify(player, "Мусор собран. Возьми мешок у бака и вынеси во двор.") end
    self:_sound("cleanup", pile.anchor.Position, "Мусор собран", player)
    self:SyncPrompts(); self:Broadcast()
    return true
end

function Gameplay:DeliverTrash(player)
    if not self:_active("trash") or not self:_near(player, self.anchors.disposal, 6.5) then return false end
    local item = self.carry[player]
    if not item or item.key ~= "trash" then return false end
    if self:_finish(player, "trash") then self:_consume(player, "trash"); self:Broadcast(); return true end
    return false
end

function Gameplay:InspectCooler(player, index)
    if not self:_active("cooler") or not self.coolers[index] or not self:_near(player, self.coolers[index].plate, 7) then return false end
    local state = self.tasks.cooler
    if index ~= state.target then self:_notify(player, "Здесь +2°C. Проверь холодильник с предупреждением."); return false end
    if state.stage == 0 then
        state.stage = 1
        self:RegisterContribution(player, "cooler_diagnosis", 1)
        self:_notify(player, "Термостат сбился. Установи рабочую температуру на этой панели.")
    elseif state.stage == 1 then
        state.stage, state.readyAt = 2, self.clock() + 4
        self:RegisterContribution(player, "cooler_adjust", 1)
        self.coolers[index].display.Text = "+6°C\nЖДИТЕ"
        self:_sound("switch", self.coolers[index].plate.Position, "Термостат включён", player)
    elseif self.clock() < state.readyAt then
        self:_notify(player, "Температура ещё снижается. Подожди несколько секунд.")
        return false
    else
        if self:_finish(player, "cooler") then
            self.coolers[index].display.Text = "+2°C\nНОРМА"
            self.coolers[index].display.TextColor3 = GREEN
        end
    end
    self:SyncPrompts(); self:Broadcast()
    return true
end

function Gameplay:OnBlackout()
    if not self.running then return end
    local state = self.tasks.generator
    if not state then return end
    if state.done or not state.active then
        state.active, state.done, state.stage, state.emergency = true, false, 0, true
        state.source = 1
        self.items.fuse.facing = Vector3.new(-1, 0, 0)
        self:_resetItem("fuse", false, self.fuseHomes[1])
    else state.emergency = true end
    self.blackoutWasActive = true
    self:SyncPrompts(); self:Broadcast()
end

function Gameplay:_endBlackout()
    self.blackoutWasActive = false
    local state = self.tasks.generator
    if not state or not state.emergency then return end
    state.emergency = false
    local completed = self.ctx.getRound().tasks.generator == true
    -- Auto-restoration cancels only the extra emergency, never a selected unfinished objective.
    if not state.selected or completed then
        state.active, state.done, state.stage = state.selected, completed, completed and state.steps or 0
        self:_resetItem("fuse", false)
        self.claims.generator = nil
    end
    self:SyncPrompts()
    self:Broadcast()
end

function Gameplay:Interact(player, id)
    if not TASK_INFO[id] then return false end
    if id == "cctv" then
        if not self:_near(player, self.anchors.cctv, 12, true) then return false end
        self:_notify(player, "Ищи силуэт, необычный свет или открытый технический люк. Выбери камеру и сообщи о находке.")
        return true
    end
    if not self:_active(id) or not self:_near(player, self.anchors[id], 8) or not self:_throttle(player, "interact_" .. id, 0.5) then return false end
    local state = self.tasks[id]
    if id == "restock" then return self:Pickup(player, "restock") end
    if id == "trash" then
        if state.stage >= 3 then return self:Pickup(player, "trash") end
        self:_notify(player, "Собери три отмеченных участка мусора в торговом зале.")
        return true
    end
    if id == "generator" then
        if state.stage == 0 then
            state.stage = 1
            self:_showItem(self.items.fuse, true)
            self:RegisterContribution(player, "generator_diagnosis", 1)
            self:_notify(player, state.source == 1 and "Перегорел предохранитель. Запасной находится в шкафчике на товарном складе." or "Перегорел предохранитель. Запасной находится в шкафчике слева в погрузочной.")
        elseif state.stage == 1 then
            if not self.carry[player] or self.carry[player].key ~= "fuse" then self:_notify(player, "Принеси запасной предохранитель."); return false end
            self:_consume(player, "fuse")
            state.stage = 2
            self:RegisterContribution(player, "fuse_install", 2)
            self:_sound("switch", self.anchors.generator.Position, "Предохранитель установлен", player)
        else
            if self:_finish(player, "generator") then state.emergency = false end
        end
    elseif id == "breaker" then
        state.stage += 1
        self:RegisterContribution(player, "breaker_stage_" .. state.stage, 1)
        local lever = self.breakerLabels and self.breakerLabels[state.stage]
        if lever then lever.Color = GREEN; lever.CFrame = CFrame.new(lever.Position) * CFrame.Angles(0, 0, math.rad(25)) end
        self:_sound("switch", self.anchors.breaker.Position, "Резервный контур проверен", player)
        if state.stage >= 3 then
            if self:_finish(player, "breaker") then
                self.anchors.breaker:SetAttribute("Inspected", true)
                local lamp = self:_find("BasementBreakerStatusLamp")
                if lamp then lamp.Color = GREEN end
            end
        end
    elseif id == "door" then return false end -- The physical door controller owns closing.
    self:SyncPrompts(); self:Broadcast()
    return true
end

function Gameplay:_spawnAnomaly()
    self:_clearAnomaly()
    local kind = ANOMALY_OPTIONS[self.random(1, #ANOMALY_OPTIONS)].id
    local anomaly = {kind = kind, reported = false, camera = kind == "silhouette" and 2 or kind == "light" and 4 or 5, parts = {}}
    self.anomaly = anomaly
    if kind == "silhouette" then
        for _, spec in ipairs({{Vector3.new(0, 2.55, -13), Vector3.new(1.4, 2.8, 0.65)},
            {Vector3.new(0, 4.45, -13), Vector3.new(0.9, 0.95, 0.85)},
            {Vector3.new(-0.4, 0.95, -13), Vector3.new(0.48, 1.7, 0.5)}, {Vector3.new(0.4, 0.95, -13), Vector3.new(0.48, 1.7, 0.5)}}) do
            local piece = self:_part("CCTVAnomalySilhouette", spec[2], spec[1], Color3.fromRGB(9, 13, 18), Enum.Material.SmoothPlastic)
            piece:SetAttribute("CCTVOnly", true)
            anomaly.parts[#anomaly.parts + 1] = piece
        end
    elseif kind == "light" then
        -- Camera04 looks from above and behind the generator: the roof beacon
        -- stays visible where the former front-panel lamp was hidden by its casing.
        local base = self:_part("CCTVAnomalyBeaconBase", Vector3.new(0.5, 0.12, 0.5), Vector3.new(33.0, 3.485, -22.4), Color3.fromRGB(35, 43, 52))
        local lamp = self:_part("CCTVAnomalyBlueLamp", Vector3.new(0.42, 0.42, 0.42), Vector3.new(33.0, 3.755, -22.4), Color3.fromRGB(53, 105, 255), Enum.Material.Neon)
        lamp.Shape = Enum.PartType.Ball
        anomaly.parts[1] = lamp
        anomaly.parts[2] = base
        local glow = Instance.new("PointLight")
        glow.Color, glow.Brightness, glow.Range, glow.Shadows = lamp.Color, 1.0, 6, false
        glow.Parent = lamp
    elseif self.hatch then
        self.hatch.CFrame = self.hatchClosed * CFrame.new(-1.35, 0, 0) * CFrame.Angles(0, math.rad(75), 0) * CFrame.new(1.35, 0, 0)
    end
end

function Gameplay:_clearAnomaly()
    if self.anomaly then for _, part in ipairs(self.anomaly.parts) do if part.Parent then part:Destroy() end end end
    if self.hatch then self.hatch.CFrame = self.hatchClosed end
    self.anomaly = nil
end

function Gameplay:SetCCTV(player, camera, active)
    if active ~= true then
        self.views[player] = nil
        player:SetAttribute("NightShiftCCTV", false)
        player:SetAttribute("NightShiftCameraIndex", nil)
        return true
    end
    if type(camera) ~= "number" or camera % 1 ~= 0 or not self.cameraChoices[camera] or not self:_near(player, self.anchors.cctv, 12, true) then return false end
    local view = self.views[player]
    if not view or view.camera ~= camera then self.views[player] = {camera = camera, since = self.clock()} end
    player:SetAttribute("NightShiftCCTV", true)
    player:SetAttribute("NightShiftCameraIndex", camera)
    return true
end

function Gameplay:ReportAnomaly(player, camera, choice)
    local anomaly, view = self.anomaly, self.views[player]
    if not self.running or not anomaly or anomaly.reported or not view or view.camera ~= camera or self.clock() - view.since < 1 then return false end
    if not self:_near(player, self.anchors.cctv, 12) or not self:_throttle(player, "anomaly", 8) then return false end
    if camera ~= anomaly.camera or choice ~= anomaly.kind then
        self:_notify(player, "Сообщение не подтверждено. Внимательно проверь выбранную камеру.")
        self:_sound("task_error", self.anchors.cctv.Position, "Аномалия не подтверждена", player)
        self:Broadcast()
        return false
    end
    anomaly.reported = true
    self:RegisterContribution(player, "anomaly_report", 3)
    if self:_active("cctv") then self:_finish(player, "cctv")
    elseif self.ctx.award then self.ctx.award(player, 15, 12) end
    for _, part in ipairs(anomaly.parts) do if part.Parent then part:Destroy() end end
    anomaly.parts = {}
    if self.hatch then self.hatch.CFrame = self.hatchClosed end
    self:_notify(player, "Наблюдение подтверждено. Запись сохранена в журнал смены.")
    self:_sound("radio", self.anchors.cctv.Position, "Охрана: аномалия отмечена", player)
    self:Broadcast()
    return true
end

function Gameplay:_tutorial(player, event)
    local profile = self:_profile(player)
    if not profile or profile.tutorialDone then return end
    local step = math.clamp(tonumber(profile.tutorialStep) or 0, 0, 3)
    if event == "flashlight" and step == 0 then profile.tutorialStep = 1
    elseif event == "pickup" and step <= 1 then profile.tutorialStep = 1
    elseif event == "delivery" then profile.tutorialStep = 2
    elseif event == "safety" and step >= 2 then
        profile.tutorialStep, profile.tutorialDone = 3, true
        self:_notify(player, "Обход завершён. Следи за заданиями и предупреждай напарников об опасности.")
    end
end

function Gameplay:_tutorialState(player)
    local profile = self:_profile(player) or {}
    local step = math.clamp(tonumber(profile.tutorialStep) or 0, 0, 3)
    local hints = {
        "Возьми фонарь и включи его: F или кнопка фонаря.",
        "Возьми учебную коробку у входа и отнеси к любому отмеченному отделу. Коробка с задания тоже подходит.",
        "Найди ближайший шкаф с надписью «УКРЫТИЕ». Запомни путь к нему.",
        "Знакомство с магазином завершено.",
    }
    return {step = step, text = hints[step + 1], done = profile.tutorialDone == true, canSkip = true}
end

function Gameplay:_spawnCustomer()
    if self.customer or not self.folder or not self.running then return false end
    for _, player in ipairs(self.players:GetPlayers()) do
        local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
        if root and (root.Position - Vector3.new(0, 3.3, 28.5)).Magnitude < 4 then return false end
    end
    self.customerCount += 1
    local abnormal = self.night >= 2 and self.random(1, 3) == 1
    local returning = self.night >= 3 and not abnormal and self.random(1, 3) == 1
    local model = Instance.new("Model")
    model.Name, model.Parent = "NightCustomer36", self.folder
    local customer = {model = model, parts = {}, appearedAt = self.clock(), settled = false,
        leavingAt = nil, abnormal = abnormal, served = false, serial = self.customerCount,
        start = Vector3.new(0, 0.3, 28.5), destination = Vector3.new(0, 0.3, 21.8)}
    customer.frame = CFrame.lookAt(customer.start, customer.destination)
    self.customer = customer
    local dark = abnormal and Color3.fromRGB(35, 42, 42) or Color3.fromRGB(40, 54, 65)
    local skin = abnormal and Color3.fromRGB(155, 157, 145) or Color3.fromRGB(190, 164, 139)
    local pants = Color3.fromRGB(31, 38, 44)
    local function p(name, size, offset, color, role, material, shape)
        local part = self:_part(name, size, customer.frame:PointToWorldSpace(offset), color, material or Enum.Material.SmoothPlastic, 0, model)
        part.CFrame = customer.frame * CFrame.new(offset)
        if shape then part.Shape = shape end
        part.CastShadow = true
        customer.parts[#customer.parts + 1] = {part = part, offset = offset, role = role or "detail"}
        return part
    end
    p("CustomerTorso", Vector3.new(1.55, 2.0, 0.78), Vector3.new(0, 2.65, 0), dark, "torso", Enum.Material.Fabric)
    p("CustomerCoatFront", Vector3.new(.9, 1.55, .08), Vector3.new(0, 2.62, -.42), Color3.fromRGB(68, 78, 78), "coat", Enum.Material.Fabric)
    p("CustomerShirt", Vector3.new(.62, 1.25, .08), Vector3.new(0, 2.82, -.49), Color3.fromRGB(166, 160, 141), "shirt")
    p("CustomerCollarL", Vector3.new(.36, .28, .1), Vector3.new(-.22, 3.54, -.47), Color3.fromRGB(192, 185, 163), "collar")
    p("CustomerCollarR", Vector3.new(.36, .28, .1), Vector3.new(.22, 3.54, -.47), Color3.fromRGB(192, 185, 163), "collar")
    p("CustomerTie", Vector3.new(.12, .72, .07), Vector3.new(0, 3.02, -.55), abnormal and Color3.fromRGB(86, 35, 34) or Color3.fromRGB(80, 92, 91), "tie")
    p("CustomerNeck", Vector3.new(.38, .42, .38), Vector3.new(0, 3.72, 0), skin, "neck")
    local head = p("CustomerHead", Vector3.new(1.02, 1.12, .92), Vector3.new(0, 4.27, 0), skin, "head", Enum.Material.SmoothPlastic, Enum.PartType.Ball)
    p("CustomerHair", Vector3.new(1.08, .38, .96), Vector3.new(0, 4.78, .04), abnormal and Color3.fromRGB(24, 27, 26) or Color3.fromRGB(43, 38, 34), "hair", Enum.Material.Fabric)
    p("CustomerHairSideL", Vector3.new(.18, .62, .78), Vector3.new(-.48, 4.43, .04), Color3.fromRGB(29, 31, 30), "hair")
    p("CustomerHairSideR", Vector3.new(.18, .62, .78), Vector3.new(.48, 4.43, .04), Color3.fromRGB(29, 31, 30), "hair")
    p("CustomerNose", Vector3.new(.14, .2, .16), Vector3.new(0, 4.15, -.49), skin, "face")
    p("CustomerMouth", Vector3.new(.28, .045, .035), Vector3.new(0, 3.98, -.48), Color3.fromRGB(66, 45, 42), "face")
    p("CustomerEyeShadowL", Vector3.new(.25, .15, .045), Vector3.new(-.22, 4.33, -.455), abnormal and Color3.fromRGB(64, 43, 42) or Color3.fromRGB(117, 93, 78), "face")
    p("CustomerEyeShadowR", Vector3.new(.25, .15, .045), Vector3.new(.22, 4.33, -.455), abnormal and Color3.fromRGB(64, 43, 42) or Color3.fromRGB(117, 93, 78), "face")
    for _, side in ipairs({-1, 1}) do
        p("CustomerEar", Vector3.new(.16, .28, .2), Vector3.new(side * .53, 4.23, -.02), skin, "face", Enum.Material.SmoothPlastic, Enum.PartType.Ball)
        p("CustomerEye", Vector3.new(.105, .09, .045), Vector3.new(side * .22, 4.31, -.49), abnormal and Color3.fromRGB(115, 34, 31) or Color3.fromRGB(30, 33, 34), "eye", Enum.Material.Neon)
        p("CustomerArm", Vector3.new(.48, 1.12, .5), Vector3.new(side * 1.03, 2.78, .01), dark, side == -1 and "armL" or "armR", Enum.Material.Fabric)
        p("CustomerForearm", Vector3.new(.4, .82, .42), Vector3.new(side * 1.08, 1.82, -.04), dark, side == -1 and "forearmL" or "forearmR", Enum.Material.Fabric)
        p("CustomerHand", Vector3.new(.28, .34, .3), Vector3.new(side * 1.08, 1.27, -.08), skin, side == -1 and "handL" or "handR", Enum.Material.SmoothPlastic, Enum.PartType.Ball)
        p("CustomerLeg", Vector3.new(.58, 1.0, .62), Vector3.new(side * .42, .98, .02), pants, side == -1 and "legL" or "legR", Enum.Material.Fabric)
        p("CustomerShin", Vector3.new(.52, .62, .55), Vector3.new(side * .42, .43, .02), pants, side == -1 and "shinL" or "shinR", Enum.Material.Fabric)
        p("CustomerShoe", Vector3.new(.66, .25, .95), Vector3.new(side * .42, .14, -.12), Color3.fromRGB(17, 21, 25), side == -1 and "footL" or "footR", Enum.Material.Leather)
    end
    if returning then
        p("CustomerScarf", Vector3.new(.86, .2, .58), Vector3.new(0, 3.65, -.02), Color3.fromRGB(82, 103, 93), "scarf", Enum.Material.Fabric)
        p("CustomerGlassesL", Vector3.new(.26, .17, .045), Vector3.new(-.22, 4.36, -.5), Color3.fromRGB(25, 32, 36), "glasses", Enum.Material.Metal)
        p("CustomerGlassesR", Vector3.new(.26, .17, .045), Vector3.new(.22, 4.36, -.5), Color3.fromRGB(25, 32, 36), "glasses", Enum.Material.Metal)
    end
    if abnormal then
        p("CustomerNeckShadow", Vector3.new(.18, .58, .12), Vector3.new(.34, 3.76, -.2), Color3.fromRGB(55, 33, 34), "shadow")
        p("CustomerCoatTear", Vector3.new(.22, .86, .09), Vector3.new(-.58, 1.72, -.43), Color3.fromRGB(19, 25, 26), "coat")
    end
    customer.head = head
    customer.receipt = abnormal and ("ЧЕК · СМЕНА " .. tostring(self.night + 1) .. "\nДАТА: ЗАВТРА · ОПЛАЧЕНО")
        or ("ЧЕК · СМЕНА " .. tostring(self.night) .. "\n1 × МОЛОКО · ОПЛАЧЕНО")
    customer.text = abnormal and "Мне обещали оставить заказ. Дата на чеке верная."
        or returning and "Я снова за тем же заказом. В прошлый раз вы оставили мне записку о подвале."
        or "Добрый вечер. Я за оплаченным заказом."
    customer.addPart = p
    local bill = Instance.new("BillboardGui")
    bill.Name, bill.Size, bill.StudsOffset, bill.MaxDistance = "CustomerReceipt", UDim2.fromOffset(196, 58), Vector3.new(0, 2.05, 0), 18
    bill.AlwaysOnTop, bill.LightInfluence = false, 0
    bill.Parent = head
    local text = Instance.new("TextLabel")
    text.Size, text.BackgroundColor3, text.BackgroundTransparency = UDim2.fromScale(1, 1), Color3.fromRGB(13, 21, 27), 0.08
    text.Font, text.TextColor3, text.TextSize, text.TextScaled, text.TextWrapped = Enum.Font.GothamBold, WHITE, 11, false, true
    text.TextStrokeTransparency = 0.82
    text.Text = customer.receipt
    text.Parent = bill
    local billCorner = Instance.new("UICorner"); billCorner.CornerRadius = UDim.new(0, 6); billCorner.Parent = text
    local billStroke = Instance.new("UIStroke"); billStroke.Color = abnormal and Color3.fromRGB(171, 69, 62) or Color3.fromRGB(102, 133, 145); billStroke.Transparency = .32; billStroke.Thickness = 1; billStroke.Parent = text
    customer.servePrompt = self.ctx.addPrompt(head, "Выдать заказ", "Покупатель · проверь чек", 0.8, function(player) self:ServeCustomer(player, "serve") end, {distance = 8.5})
    customer.refusePrompt = self.ctx.addPrompt(head, "Отказать", "Недействительный чек", 0.8, function(player) self:ServeCustomer(player, "refuse") end, {distance = 8.5})
    customer.refusePrompt.KeyboardKeyCode, customer.refusePrompt.GamepadKeyCode = Enum.KeyCode.R, Enum.KeyCode.ButtonY
    customer.servePrompt.Enabled, customer.refusePrompt.Enabled = false, false
    self:_sound("door_chime", customer.start, "В магазин вошёл покупатель")
    self:Broadcast()
    return true
end

function Gameplay:ServeCustomer(player, choice)
    local customer = self.customer
    if choice ~= "serve" and choice ~= "refuse" then return false end
    if not customer or not customer.settled or customer.served or customer.leavingAt or not self:_near(player, customer.head, 8.5) then return false end
    customer.served, customer.leavingAt = true, self.clock()
    customer.servePrompt.Enabled, customer.refusePrompt.Enabled = false, false
    local correct = choice == (customer.abnormal and "refuse" or "serve")
    if choice == "serve" then customer.addPart("CustomerOrderBag", Vector3.new(0.65, 0.85, 0.5), Vector3.new(0.75, 1.9, -0.55), Color3.fromRGB(170, 156, 118)) end
    if correct then
        self:RegisterContribution(player, "customer_" .. customer.serial, 2)
        if self.ctx.award then self.ctx.award(player, 20, 14) end
        self:_notify(player, customer.abnormal and "Чек из следующей смены. Заказ отклонён, происшествие записано." or "Заказ выдан. Покупатель оставил благодарность.")
        self:_sound("task_success", customer.head.Position, "Обслуживание завершено", player)
    else
        self:_notify(player, customer.abnormal and "Дата на чеке не совпала. По внутренней связи раздался чужой голос…" or "Чек был действительным. Покупатель ушёл без заказа.")
        self:_sound("radio", customer.head.Position, "Помехи во внутренней связи", player)
        if customer.abnormal and self.ctx.onThreat then self.ctx.onThreat("customer_error", customer.head.Position) end
    end
    self:Broadcast()
    return correct
end

function Gameplay:_taskHint(id, state)
    if state.done then return "Выполнено" end
    if id == "restock" then
        local shelf = self.shelfChoices[state.target]
        return state.stage == 0 and "Возьми коробку на товарном складе" or ("Отнеси коробку в отдел «" .. (shelf and shelf.name or "СНЕКИ") .. "»")
    elseif id == "generator" then
        if state.stage == 0 then return "Осмотри генератор и найди причину сбоя" end
        if state.stage == 1 then return state.source == 1 and "Принеси предохранитель со склада" or "Принеси предохранитель из погрузочной" end
        return "Предохранитель установлен — запусти генератор"
    elseif id == "trash" then
        if state.stage < 3 then return "Собери мусор: " .. state.stage .. "/3 участка" end
        return "Возьми мешок у бака и вынеси во двор"
    elseif id == "cctv" then return "Найди аномалию и сообщи о ней на нужной камере"
    elseif id == "breaker" then return ({"Осмотри резервный щит", "Включи резервную линию", "Подтверди подачу питания"})[math.min(state.stage + 1, 3)]
    elseif id == "cooler" then return ({"Найди холодильник с +12°C", "Настрой термостат", "Дождись охлаждения и проверь температуру"})[math.min(state.stage + 1, 3)]
    else return "Закрой заднюю дверь у погрузочной" end
end

function Gameplay:GetState(player)
    local taskList, team = {}, {}
    local round = self.ctx.getRound()
    for _, id in ipairs(TASK_ORDER) do
        local state = self.tasks[id]
        if state and state.active then
            local info = TASK_INFO[id]
            local claimed = self.claims[id]
            local done = state.done or round.tasks and round.tasks[id] == true and not (id == "generator" and state.emergency)
            taskList[#taskList + 1] = {id = id, title = info.title, location = info.location, done = done,
                stageText = done and "Выполнено" or self:_taskHint(id, state), hint = self:_taskHint(id, state),
                progress = done and 1 or state.stage / state.steps, claimedBy = claimed and claimed.UserId or 0,
                claimedName = claimed and claimed.DisplayName or "", emergency = state.emergency == true}
        end
    end
    for _, teammate in ipairs(self.players:GetPlayers()) do
        local item = self.carry[teammate]
        local claimedTask
        for id, owner in pairs(self.claims) do if owner == teammate and self:_active(id) then claimedTask = id; break end end
        local status = teammate:GetAttribute("NightShiftDowned") and "Нужна помощь" or teammate:GetAttribute("NightShiftHidden") and "В укрытии"
            or self.views[teammate] and "Наблюдает камеры" or item and "Несёт предмет" or claimedTask and "Выполняет задачу" or "На обходе"
        local score = self.contribution[teammate] and self.contribution[teammate].score or 0
        team[#team + 1] = {userId = teammate.UserId, name = teammate.DisplayName or teammate.Name, status = status,
            carrying = item and item.label or "", contribution = score, score = score, claimedTask = claimedTask}
    end
    local item = self.carry[player]
    local carrying = item and {id = item.key, kind = item.kind, label = item.label,
        destination = item.kind == "box" and self:_taskHint("restock", self.tasks.restock) or item.kind == "fuse" and "Генераторная" or item.kind == "bag" and "Контейнер в техническом дворе" or "Любой отмеченный отдел"} or nil
    local cameras = {}
    for _, camera in ipairs(self.cameraChoices) do cameras[#cameras + 1] = {id = camera.id, label = camera.label} end
    local anomalies = {active = self.running and self.anomaly ~= nil and not self.anomaly.reported,
        options = cloneOptions(ANOMALY_OPTIONS), cameras = cameras, reported = self.anomaly and self.anomaly.reported or false,
        reportCooldown = math.max(0, math.ceil(((self.cooldowns[player] or {}).anomaly or 0) - self.clock()))}
    local customer = self.customer
    return {version = "3.6", epoch = self.epoch, tasks = taskList, carry = carrying, team = team,
        tutorial = self:_tutorialState(player), anomalies = anomalies, cctv = anomalies,
        customer = {active = customer ~= nil and not customer.served and not customer.leavingAt,
            waiting = customer and customer.settled or false, text = customer and customer.text or "",
            receipt = customer and customer.receipt or "", receiptHint = "Принимай только чеки текущей смены: " .. tostring(self.night)},
        story = {night = self.night, text = STORY[math.min(math.max(self.night, 1), #STORY)]}}
end

function Gameplay:Broadcast()
    self.syncAt = self.clock()
    if self.ctx.remote then
        for _, player in ipairs(self.players:GetPlayers()) do
            local profile = self:_profile(player)
            if profile and profile.ready then self.ctx.remote:FireClient(player, "GameplayState", self:GetState(player)) end
        end
    end
    if self.ctx.onChanged then self.ctx.onChanged() end
end

function Gameplay:SendState(player)
    local profile = self:_profile(player)
    if profile and profile.ready and self.ctx.remote then
        self.ctx.remote:FireClient(player, "GameplayState", self:GetState(player))
    end
end

function Gameplay:SyncPrompts()
    for id, prompt in pairs(self.corePrompts) do
        if prompt and prompt.Parent and id ~= "door" then
            prompt.Enabled = id == "cctv" or self:_active(id) == true
            if id == "restock" then prompt.Enabled = false end -- Actual box owns its pickup prompt.
            if id == "generator" and self.world and self.world:GetAttribute("GeneratorOverheated") == true then
                prompt.Enabled = false -- The dedicated overheat service sequence temporarily owns the generator.
            end
            if id == "trash" and self.tasks.trash and self.tasks.trash.stage >= 3 then prompt.Enabled = false end
            if self.tasks[id] then
                if id == "generator" then prompt.ActionText = ({"Осмотреть генератор", "Установить предохранитель", "Запустить генератор"})[math.min(3, self.tasks[id].stage + 1)]
                elseif id == "breaker" then prompt.ActionText = ({"Осмотреть щит", "Включить резерв", "Проверить питание"})[math.min(3, self.tasks[id].stage + 1)]
                elseif id == "trash" then prompt.ActionText = "Где собрать мусор?"
                elseif id == "cctv" then prompt.ActionText = "Смотреть камеры" end
            end
        end
    end
    for _, entry in ipairs(self.managedPrompts) do
        if entry.prompt.Parent then entry.prompt.Enabled = entry.enabled() == true end
    end
    for i, cooler in ipairs(self.coolers) do
        if self:_active("cooler") and self.tasks.cooler.target == i then
            cooler.prompt.ActionText = ({"Измерить температуру", "Настроить термостат", "Подтвердить +2°C"})[math.min(3, self.tasks.cooler.stage + 1)]
        else cooler.prompt.ActionText = "Проверить температуру" end
    end
end

function Gameplay:HandleAction(player, action, data)
    if type(action) ~= "string" or type(data) ~= "table" then return false end
    if action == "CCTVView" then return self:SetCCTV(player, data.camera, data.active) end
    if action == "DropItem" then
        if not self:_eligible(player, true) or not self:_throttle(player, "drop", 0.5) then return false end
        return self:DropItem(player, false)
    elseif action == "ClaimTask" then
        local id = data.taskId
        if not self:_eligible(player) or type(id) ~= "string" or not self:_active(id) or not self:_throttle(player, "claim", 2) then return false end
        if self.claims[id] and self.claims[id] ~= player then self:_notify(player, "За эту задачу уже взялся напарник. Ты можешь помочь ему."); return false end
        for taskId, owner in pairs(self.claims) do if owner == player then self.claims[taskId] = nil end end
        self.claims[id] = player
        self:Broadcast()
        return true
    elseif action == "Ping" then
        local texts = {help = "Нужна помощь", danger = "Опасность здесь", working = "Я занимаюсь этим", safe = "Здесь спокойно"}
        if not texts[data.kind] or not self:_eligible(player) or not self:_throttle(player, "ping", 5) then return false end
        local root = player.Character:FindFirstChild("HumanoidRootPart")
        local position = root.Position
        local view = self.views[player]
        if view and data.camera == view.camera and self:_near(player, self.anchors.cctv, 12) then
            local point = self.cameraChoices[view.camera].part
            position = point:GetAttribute("Target") or point.Position
            if data.kind == "danger" and self.ctx.hasThreatNear and self.ctx.hasThreatNear(position, 18) then
                self:RegisterContribution(player, "camera_warning", 2)
            end
        end
        if self.ctx.remote then self.ctx.remote:FireAllClients("TeamPing", {userId = player.UserId, name = player.DisplayName or player.Name,
            kind = data.kind, text = texts[data.kind], position = position, expiresIn = 7}) end
        self:_sound("radio", position, texts[data.kind], player)
        return true
    elseif action == "ReportAnomaly" then return self:ReportAnomaly(player, data.camera, data.choice or data.kind)
    elseif action == "ServeCustomer" then return self:ServeCustomer(player, data.choice)
    elseif action == "SkipTutorial" then
        local profile = self:_profile(player)
        if not profile or not profile.ready then return false end
        profile.tutorialDone, profile.tutorialStep = true, 3
        local item = self.carry[player]
        if item and item.training then self:DropItem(player, true) end
        self:Broadcast()
        return true
    elseif action == "TutorialStep" and data.step == "flashlight" then
        local character = player.Character
        local tool = character and character:FindFirstChild("NightShiftFlashlight")
        local handle = tool and tool:FindFirstChild("Handle")
        local beam = handle and handle:FindFirstChild("FlashlightBeam")
        if beam and beam.Enabled then self:_tutorial(player, "flashlight"); self:Broadcast(); return true end
    end
    return false
end

function Gameplay:Tick(dt)
    self.tickBudget += dt
    local now = self.clock()
    for player, item in pairs(self.carry) do
        local character = player.Character
        local root = character and character:FindFirstChild("HumanoidRootPart")
        local humanoid = character and character:FindFirstChildOfClass("Humanoid")
        if not root or not humanoid or humanoid.Health <= 0 or player:GetAttribute("NightShiftDowned") or player:GetAttribute("NightShiftHidden") then self:DropItem(player, true)
        elseif self.ctx.props then
            if not self.ctx.props.UpdateCarried(item.part, root) then self:DropItem(player, true) end
        else item.part.CFrame = root.CFrame * CFrame.new(0, -0.3, -1.5) end
    end
    local customer = self.customer
    if customer then
        local age = now - (customer.leavingAt or customer.appearedAt)
        local t = math.clamp(age / (customer.abnormal and 4.6 or 4.0), 0, 1)
        local a, b = customer.start, customer.destination
        if customer.leavingAt then a, b = b, a end
        local direction = (b - a).Unit
        local travelT = t * t * (3 - 2 * t)
        local position = a:Lerp(b, travelT)
        local gait = math.sin(age * (customer.abnormal and 7.2 or 6.4))
        local bob = t < 1 and math.abs(math.sin(age * (customer.abnormal and 14.4 or 12.8))) * .045 or 0
        local idleAge = customer.settledAt and math.max(0, now - customer.settledAt) or 0
        local headTurn = customer.abnormal and (math.sin(idleAge * .72) * .32 + math.sin(idleAge * .21) * .16)
            or customer.returning and math.sin(idleAge * .5) * .14 or 0
        local headTilt = customer.abnormal and (.18 + math.sin(idleAge * .84) * .1) or math.sin(age * .7) * .025
        local headOffset = Vector3.new(0, 4.27, 0)
        local headPose = CFrame.Angles(customer.abnormal and -.08 or 0, headTurn, headTilt)
        customer.frame = CFrame.lookAt(position + Vector3.new(0,bob,0), position + Vector3.new(0,bob,0) + direction)
        for _, rig in ipairs(customer.parts) do
            if rig.part.Parent then
                local pose = CFrame.new()
                if rig.role == "torso" then pose = CFrame.new(0,bob*.35,0) * CFrame.Angles(0,0,math.sin(age*1.7)*.025)
                elseif rig.role == "armL" then pose = CFrame.Angles(gait*.38,0,.08)
                elseif rig.role == "armR" then pose = CFrame.Angles(-gait*.38,0,-.08)
                elseif rig.role == "forearmL" then pose = CFrame.Angles(-.18 + gait*.22,0,.04)
                elseif rig.role == "forearmR" then pose = CFrame.Angles(-.18 - gait*.22,0,-.04)
                elseif rig.role == "handL" then pose = CFrame.Angles(math.abs(gait)*.08,0,.06)
                elseif rig.role == "handR" then pose = CFrame.Angles(math.abs(gait)*.08,0,-.06)
                elseif rig.role == "legL" then pose = CFrame.Angles(-gait*.32,0,0)
                elseif rig.role == "legR" then pose = CFrame.Angles(gait*.32,0,0)
                elseif rig.role == "shinL" then pose = CFrame.Angles(math.max(0,gait)*.24,0,0)
                elseif rig.role == "shinR" then pose = CFrame.Angles(math.max(0,-gait)*.24,0,0)
                elseif rig.role == "footL" then pose = CFrame.Angles(-math.max(0,gait)*.14,0,0)
                elseif rig.role == "footR" then pose = CFrame.Angles(-math.max(0,-gait)*.14,0,0)
                elseif rig.role == "head" then pose = headPose
                elseif rig.role == "neck" then pose = CFrame.Angles(0,headTurn*.25,headTilt*.35)
                elseif rig.role == "eye" and customer.abnormal then rig.part.Transparency = .04 + .22 * (0.5 + 0.5 * math.sin(now * 5.5)) end
                if rig.role == "face" or rig.role == "eye" or rig.role == "hair" or rig.role == "glasses" then
                    rig.part.CFrame = customer.frame * CFrame.new(headOffset) * headPose * CFrame.new(rig.offset - headOffset) * pose
                else
                    rig.part.CFrame = customer.frame * CFrame.new(rig.offset) * pose
                end
                if customer.leavingAt then rig.part.Transparency = math.clamp((age - 3.55) / .65, 0, 1) end
            end
        end
        if not customer.leavingAt and t >= 1 then
            if not customer.settled then customer.settledAt = now end
            customer.settled = true
            customer.servePrompt.Enabled, customer.refusePrompt.Enabled = true, true
            if now - customer.appearedAt > 55 then
                customer.leavingAt = now
                customer.servePrompt.Enabled, customer.refusePrompt.Enabled = false, false
            end
        elseif customer.leavingAt and t >= 1 then
            customer.model:Destroy(); self.customer = nil; self:Broadcast()
        end
    end
    if self.tickBudget < 0.5 then return end
    self.tickBudget = 0
    for _, player in ipairs(self.players:GetPlayers()) do
        local profile = self:_profile(player)
        if profile and profile.ready and not profile.tutorialDone then
            local character = player.Character
            local tool = character and character:FindFirstChild("NightShiftFlashlight")
            local handle = tool and tool:FindFirstChild("Handle")
            local beam = handle and handle:FindFirstChild("FlashlightBeam")
            if beam and beam.Enabled then self:_tutorial(player, "flashlight") end
            local root = character and character:FindFirstChild("HumanoidRootPart")
            if root and (tonumber(profile.tutorialStep) or 0) >= 2 then
                for i = 1, 4 do
                    local locker = self:_find("HideLocker" .. i)
                    local exit = locker and locker:GetAttribute("HideExit")
                    if exit and (root.Position - exit).Magnitude <= 5 then self:_tutorial(player, "safety"); break end
                end
            end
        end
        if self.views[player] and not self:_near(player, self.anchors.cctv, 12, true) then
            self:SetCCTV(player, nil, false)
            if self.ctx.remote then self.ctx.remote:FireClient(player, "CloseCCTV") end
        end
    end
    for _, item in pairs(self.items) do
        if item.available and not item.owner and item.droppedAt and now - item.droppedAt >= 45 then
            local frame = CFrame.lookAt(item.home, item.home + item.facing)
            if self.ctx.props then self.ctx.props.Place(item.part, frame) else item.part.CFrame = frame end
            item.droppedAt = nil
        end
    end
    if self.running then
        self.elapsed = now - self.startedAt
        local round = self.ctx.getRound()
        local blackout = self.ctx.isBlackout and self.ctx.isBlackout() or false
        if blackout and not self.blackoutWasActive then self:OnBlackout() end
        if not blackout and self.blackoutWasActive then self:_endBlackout() end
        if self.elapsed >= self.customerAt and not self.customer and self.customerCount < (self.night >= 3 and 2 or 1)
            and not round.monsterActive and not blackout and (round.timeLeft or 0) > 55 then
            if self:_spawnCustomer() then self.customerAt = self.elapsed + 105 else self.customerAt = self.elapsed + 5 end
        end
        local coolerState = self.tasks.cooler
        if coolerState and coolerState.stage == 2 and coolerState.readyAt and now >= coolerState.readyAt and not coolerState.done then
            self.coolers[coolerState.target].display.Text = "+2°C\nГОТОВО"
            self.coolers[coolerState.target].display.TextColor3 = GREEN
        end
    end
    self:SyncPrompts()
    if now - self.syncAt >= 1 then self:Broadcast() end
end

function Gameplay:EndShift()
    self.running = false
    local owners = {}
    for player in pairs(self.carry) do owners[#owners + 1] = player end
    for _, player in ipairs(owners) do self:DropItem(player, true) end
    for key, item in pairs(self.items) do
        if key ~= "practice" then self:_showItem(item, false) end
    end
    for player in pairs(self.views) do
        self:SetCCTV(player, nil, false)
        if self.ctx.remote then self.ctx.remote:FireClient(player, "CloseCCTV") end
    end
    self:_restoreShelf()
    self:_clearAnomaly()
    for _, pile in ipairs(self.trashPiles) do for _, piece in ipairs(pile.parts) do piece.Transparency = 1 end end
    if self.customer then self.customer.model:Destroy(); self.customer = nil end
    self:SyncPrompts()
end

function Gameplay:OnPlayerRemoving(player)
    self:DropItem(player, true)
    self:SetCCTV(player, nil, false)
    self.views[player], self.cooldowns[player], self.contribution[player] = nil, nil, nil
    for id, owner in pairs(self.claims) do if owner == player then self.claims[id] = nil end end
    self:Broadcast()
end

return Gameplay
