-- NIGHT SHIFT 4.6 - Living Nightmare, dynamic incidents and server-authoritative co-op horror
-- Keep this Script in ServerScriptService.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DataStoreService = game:GetService("DataStoreService")
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")
local PathfindingService = game:GetService("PathfindingService")
local MarketplaceService = game:GetService("MarketplaceService")
local TweenService = game:GetService("TweenService")

local CONFIG = {
    SHIFT_SECONDS = 420,
    INTERMISSION_SECONDS = 22,
    RESULTS_SECONDS = 12,
    AUTOSAVE_SECONDS = 90,
    TASKS_PER_SHIFT = 3,
    MAX_PLAYERS = 6,
    TASK_REWARD = 50,
    TASK_XP = 32,
    DATASTORE_NAME = "NightShift_Profile_v2",
    VIP_GAMEPASS_ID = 0, -- Replace 0 with your published VIP Game Pass ID.
    CASH_PRODUCT_ID = 0, -- Replace 0 with your published Developer Product ID.
}

local UPGRADE_COSTS = {
    Speed = {250, 550, 1050},
    Stamina = {220, 500, 950},
    Battery = {180, 420, 800},
}
local MAX_UPGRADE = 3
local MAX_STAMINA_BASE = 100
local MAX_BATTERY_BASE = 100
local DAILY_COOLDOWN = 24 * 60 * 60

local TEXT = {
    taskRestock = "Пополнить полки", taskGenerator = "Запустить генератор", taskDoor = "Закрыть заднюю дверь",
    taskTrash = "Убрать мусор", taskCCTV = "Проверить камеры",
    objCrate = "Ящик с товаром", objGenerator = "Генератор", objDoor = "Задняя дверь",
    objTrash = "Мусорный бак", objCCTV = "Монитор камер",
    actionRestock = "Пополнить", actionRepair = "Починить", actionLock = "Закрыть",
    actionClean = "Убрать", actionCheck = "Проверить",
    wait = "Дождитесь начала смены.", done = "Эта задача уже выполнена.", reward = "Команда выполнила: ", anomaly = "В магазине что-то есть. Не отходи один!",
    caught = "Тебя нашли. -25 наличных.", shiftReward = "Смена окончена! Награда: ", speedMax = "Скорость уже максимальна.",
    noCash = "Не хватает наличных.", upgradeOK = "Улучшение куплено!", shiftStart = "Смена началась! Выполняй задания и доживи до утра.",
    profileWait = "Профиль ещё загружается.", flashEmpty = "Фонарь разряжен. Возьми запасную батарею в охране или щитовой B1.", flashEquip = "Сначала возьми фонарь в руки.",
    hideIn = "Ты спрятался. Если монстр заметил тебя, он может проверить шкаф.", hideOut = "Ты вышел из укрытия.", blackout = "АВАРИЯ: свет отключился. Найди генератор.", falseAlarm = "Система охраны зафиксировала движение.",
    passMissing = "Покупки Robux пока не настроены. См. инструкцию.", dailyWait = "Уже получено. Вернись позже.", dailyOK = "Ежедневная награда получена!",
    levelUp = "Новый уровень!", noStamina = "Нет выносливости.",
    flicker = "Скачки напряжения. Держите фонари под рукой.",
}

local remote = ReplicatedStorage:FindFirstChild("NightShiftRemote")
if not remote then
    remote = Instance.new("RemoteEvent")
    remote.Name = "NightShiftRemote"
    remote.Parent = ReplicatedStorage
end

local store
local legacyStore
local storeOk, storeResult = pcall(function()
    return DataStoreService:GetDataStore(CONFIG.DATASTORE_NAME)
end)
if storeOk then
    store = storeResult
else
    print("[NIGHT SHIFT 4.6] Studio preview: DataStore progress is temporary until the place is published and API Services are enabled.")
end
local legacyOk, legacyResult = pcall(function()
    return DataStoreService:GetDataStore("NightShift_Profile_v1")
end)
if legacyOk then legacyStore = legacyResult end

local profiles = {}
local saveLocks = {}
local lastActionAt = {}
local lastHitAt = {}
local lastRecoveryAt = {}
local hiddenState = {}
local taskPrompts = {}
local doorControllers = {}
local world
local decorFolder
local lights = {}
local monsterModel
local monsterToken = 0
local eventToken = 0
local colorEffect
local originalLighting = {}
local originalLightColors = {}
local generatorStatusLamp
local generatorStatusLight
local generatorWarningLight
local alarmBeacons = {}
local generatorWarningBeacon
local generatorWarningActive, generatorWarningToken = false, 0
local generatorOverheatActive, generatorOverheatStage, generatorOverheatToken = false, 0, 0
local setTaskPromptsEnabled
local gameplay, threat, recovery, director, campaign, locations, Campaign, exploration, haunts, incidents
local batteryUsed, lastMovementNoise, preferenceSaveTokens = {}, {}, {}
local DEFAULT_PREFERENCES = {
    masterVolume = 1, ambientVolume = 0.55, effectsVolume = 0.7, threatVolume = 0.85, uiVolume = 0.55,
    reducedFlashes = true, cameraShake = false, captions = true, highContrast = false,
    quality = "auto", mix = "balanced", fov = 76, textScale = 1, brightness = 0, objectiveMarker = true,
    incidentHints = true, reducedInterference = false,
}
local function sanitizePreferences(value)
    local result = table.clone(DEFAULT_PREFERENCES)
    if type(value) ~= "table" then return result end
    local function finite(key, lo, hi)
        local n = tonumber(value[key])
        if n and n == n and n ~= math.huge and n ~= -math.huge then result[key] = math.clamp(n, lo, hi) end
    end
    for _, key in ipairs({"masterVolume", "ambientVolume", "effectsVolume", "threatVolume", "uiVolume"}) do finite(key, 0, 1) end
    finite("fov", 68, 90); finite("textScale", 1, 1.2); finite("brightness", 0, 0.12)
    for _, key in ipairs({"reducedFlashes", "cameraShake", "captions", "highContrast", "objectiveMarker", "incidentHints", "reducedInterference"}) do
        if type(value[key]) == "boolean" then result[key] = value[key] end
    end
    if value.quality == "low" or value.quality == "standard" then result.quality = value.quality end
    if value.mix == "night" then result.mix = "night" end
    -- Preserve the mute intent of a saved 3.x profile while adding independent channels.
    if result.effectsVolume == 0 then
        if value.threatVolume == nil then result.threatVolume = 0 end
        if value.uiVolume == nil then result.uiVolume = 0 end
        if result.ambientVolume == 0 and value.masterVolume == nil then result.masterVolume = 0 end
    end
    return result
end
local function emitWorldSound(kind, position, caption, player, options)
    local payload = {kind = kind, position = position, caption = caption}
    if type(options) == "table" then
        for _, key in ipairs({"duration", "intensity", "volume", "pitch"}) do payload[key] = options[key] end
    end
    if player then remote:FireClient(player, "NS36Sound", payload) else remote:FireAllClients("NS36Sound", payload) end
end
local function emitNoise(position, kind, radius, player)
    if threat then threat:Noise(position, kind, radius, player) end
end

local generatorMotorToken = 0
local function setGeneratorState(state, announce)
    generatorMotorToken += 1
    local generator = world and world:FindFirstChild("Generator", true)
    if not generator then return end
    generator:SetAttribute("NSGeneratorState", state)
    if announce then
        local kind = state == "OFF" and "generator_stop" or state == "STARTING" and "generator_start" or "generator_run"
        emitWorldSound(kind, generator.Position, state == "OFF" and "Мотор генератора остановился" or state == "STARTING" and "Стартер проворачивает двигатель" or "Генератор набрал обороты")
    end
end
local function startGeneratorMotor()
    setGeneratorState("STARTING", true)
    local token, currentWorld = generatorMotorToken, world
    task.delay(2.4, function()
        if token == generatorMotorToken and world == currentWorld and world and world.Parent and world:GetAttribute("PowerState") ~= "OFF" then
            setGeneratorState("RUNNING", true)
        end
    end)
end

local TASK_DEFS = {
    {id = "restock", location = "Товарный склад", title = TEXT.taskRestock, action = TEXT.actionRestock, object = TEXT.objCrate, hold = 1.4},
    {id = "generator", location = "Генераторная", title = TEXT.taskGenerator, action = TEXT.actionRepair, object = TEXT.objGenerator, hold = 2.4},
    {id = "door", location = "Задний выход", title = TEXT.taskDoor, action = TEXT.actionLock, object = TEXT.objDoor, hold = 1.6},
    {id = "trash", location = "Торговый зал", title = TEXT.taskTrash, action = TEXT.actionClean, object = TEXT.objTrash, hold = 1.2},
    {id = "cctv", location = "Комната охраны", title = TEXT.taskCCTV, action = TEXT.actionCheck, object = TEXT.objCCTV, hold = 1.8},
    {id = "breaker", location = "Подвал B1 · щитовая", title = "Проверить резервный щит", action = "Осмотреть", object = "Резервный щит", hold = 2.2, firstNight = 2},
    {id = "cooler", location = "Холодильный ряд", title = "Проверить холодильники", action = "Проверить", object = "Холодильник", hold = 1.2, firstNight = 2},
}

local round = {
    phase = "INTERMISSION",
    timeLeft = CONFIG.INTERMISSION_SECONDS,
    number = 0,
    tasks = {},
    activeTasks = {},
    monsterActive = false,
    eventName = "",
    playerCaught = {},
    tasksPerShift = CONFIG.TASKS_PER_SHIFT,
    participation = {},
    resultSuccess = false,
}

local function notify(player, message)
    if player and player.Parent == Players then remote:FireClient(player, "Notify", tostring(message)) end
end

local function maxStamina(profile)
    return MAX_STAMINA_BASE + (profile.staminaLevel * 20)
end

local function maxBattery(profile)
    return MAX_BATTERY_BASE + (profile.batteryLevel * 25)
end

local function xpForNextLevel(level)
    return 100 + math.max(0, level - 1) * 60
end

local function refreshProfile(player)
    local profile = profiles[player]
    if not profile then return end
    local stats = player:FindFirstChild("leaderstats")
    if stats then
        stats.Cash.Value = profile.cash
        stats.Nights.Value = profile.nights
        stats.Level.Value = profile.level
    end
    local secondsUntilDaily = math.max(0, DAILY_COOLDOWN - (os.time() - (profile.lastDaily or 0)))
    remote:FireClient(player, "Profile", {
        cash = profile.cash, nights = profile.nights, level = profile.level, xp = profile.xp,
        xpNext = xpForNextLevel(profile.level), speedLevel = profile.speedLevel,
        staminaLevel = profile.staminaLevel, batteryLevel = profile.batteryLevel,
        vip = profile.vip == true, dailyReady = secondsUntilDaily <= 0, dailySeconds = secondsUntilDaily,
        vipReady = CONFIG.VIP_GAMEPASS_ID > 0, cashProductReady = CONFIG.CASH_PRODUCT_ID > 0,
        tutorialStep = profile.tutorialStep or 0, tutorialDone = profile.tutorialDone == true,
    })
end

local function refreshVitals(player)
    local profile = profiles[player]
    if not profile then return end
    remote:FireClient(player, "Vitals", {
        stamina = profile.stamina or maxStamina(profile), maxStamina = maxStamina(profile),
        battery = profile.battery or maxBattery(profile), maxBattery = maxBattery(profile),
    })
end

local function updateStats(player)
    local profile = profiles[player]
    local stats = player:FindFirstChild("leaderstats")
    if not profile or not stats then return end
    stats.Cash.Value = profile.cash
    stats.Nights.Value = profile.nights
    stats.Level.Value = profile.level
end

local function award(player, cashAmount, xpAmount)
    local profile = profiles[player]
    if not profile or not profile.ready then return end
    local cash = math.floor(cashAmount or 0)
    if cash > 0 and profile.vip then cash = math.floor(cash * 1.15) end
    profile.cash = math.clamp(profile.cash + cash, 0, 2000000000)
    profile.xp = math.max(0, profile.xp + math.floor(xpAmount or 0))
    local leveled = false
    while profile.level < 10000 and profile.xp >= xpForNextLevel(profile.level) do
        profile.xp -= xpForNextLevel(profile.level)
        profile.level += 1
        leveled = true
    end
    updateStats(player)
    refreshProfile(player)
    if leveled then notify(player, TEXT.levelUp .. " " .. profile.level .. "!") end
end

local function defaultProfile()
    return {
        cash = 0, nights = 0, level = 1, xp = 0,
        speedLevel = 0, staminaLevel = 0, batteryLevel = 0,
        lastDaily = 0, deaths = 0, tasksCompleted = 0,
        processedReceipts = {},
        tutorialStep = 0, tutorialDone = false, preferences = sanitizePreferences(nil),
        campaign = Campaign and Campaign.NormalizeProgress(nil) or {version = 1, completed = 0, step = 1, records = {}, replays = 0},
        stamina = MAX_STAMINA_BASE, battery = MAX_BATTERY_BASE,
        vip = false, loaded = false, ready = false,
    }
end

local function sanitizeProfile(data, profile)
    if type(data) ~= "table" then return end
    profile.cash = math.floor(math.clamp(tonumber(data.cash) or 0, 0, 2000000000))
    profile.nights = math.floor(math.clamp(tonumber(data.nights) or 0, 0, 2000000000))
    profile.level = math.floor(math.clamp(tonumber(data.level) or 1, 1, 10000))
    profile.xp = math.floor(math.clamp(tonumber(data.xp) or 0, 0, xpForNextLevel(profile.level) - 1))
    profile.speedLevel = math.floor(math.clamp(tonumber(data.speedLevel) or 0, 0, MAX_UPGRADE))
    profile.staminaLevel = math.floor(math.clamp(tonumber(data.staminaLevel) or 0, 0, MAX_UPGRADE))
    profile.batteryLevel = math.floor(math.clamp(tonumber(data.batteryLevel) or 0, 0, MAX_UPGRADE))
    profile.lastDaily = math.floor(math.max(0, tonumber(data.lastDaily) or 0))
    profile.deaths = math.floor(math.max(0, tonumber(data.deaths) or 0))
    profile.tasksCompleted = math.floor(math.max(0, tonumber(data.tasksCompleted) or 0))
    profile.tutorialStep = math.clamp(math.floor(tonumber(data.tutorialStep) or 0), 0, 3)
    profile.tutorialDone = data.tutorialDone == true
    profile.preferences = sanitizePreferences(data.preferences)
    if Campaign then profile.campaign = Campaign.NormalizeProgress(data.campaign) end
    if type(data.processedReceipts) == "table" then
        profile.processedReceipts = {}
        for purchaseId, granted in pairs(data.processedReceipts) do
            if type(purchaseId) == "string" and granted == true then profile.processedReceipts[purchaseId] = true end
        end
    end
end

local function profileSnapshot(profile)
    local receipts = {}
    for purchaseId, granted in pairs(profile.processedReceipts) do receipts[purchaseId] = granted end
    return {
        version = 4, cash = profile.cash, nights = profile.nights, level = profile.level, xp = profile.xp,
        speedLevel = profile.speedLevel, staminaLevel = profile.staminaLevel, batteryLevel = profile.batteryLevel,
        lastDaily = profile.lastDaily, deaths = profile.deaths, tasksCompleted = profile.tasksCompleted,
        campaign = Campaign and Campaign.NormalizeProgress(profile.campaign) or profile.campaign,
        processedReceipts = receipts, tutorialStep = profile.tutorialStep or 0, tutorialDone = profile.tutorialDone == true, preferences = sanitizePreferences(profile.preferences),
    }
end

local function saveProfile(player, finalSave)
    local profile = profiles[player]
    if not profile or not store or not profile.loaded then return false end
    -- A leave/shutdown save must not silently disappear behind an autosave or receipt.
    local deadline = os.clock() + 12
    while saveLocks[player] and finalSave and os.clock() < deadline do task.wait(0.1) end
    if saveLocks[player] or profiles[player] ~= profile then return false end
    saveLocks[player] = true
    local payload = profileSnapshot(profile)
    local ok, err
    for attempt = 1, 3 do
        ok, err = pcall(function()
            store:UpdateAsync("u_" .. player.UserId, function(old)
                if type(old) == "table" and type(old.processedReceipts) == "table" then
                    for purchaseId, granted in pairs(old.processedReceipts) do
                        if granted == true then payload.processedReceipts[purchaseId] = true end
                    end
                end
                if Campaign then payload.campaign = Campaign.MergeProgress(type(old) == "table" and old.campaign or nil, payload.campaign) end
                return payload
            end)
        end)
        if ok then break end
        if attempt < 3 then task.wait(0.4 * attempt) end
    end
    saveLocks[player] = nil
    if not ok then warn("NightShift save failed for " .. player.UserId .. ": " .. tostring(err)) end
    return ok
end

local function loadProfile(player)
    local profile = defaultProfile()
    profiles[player] = profile
    if store then
        local ok, data = pcall(function()
            return store:GetAsync("u_" .. player.UserId)
        end)
        if ok then
            if data == nil and legacyStore then
                local legacyReadOk, legacyData = pcall(function()
                    return legacyStore:GetAsync("u_" .. player.UserId)
                end)
                if legacyReadOk then
                    sanitizeProfile(legacyData, profile)
                    profile.loaded = true
                else
                    warn("NightShift legacy profile load failed for " .. player.UserId .. ": " .. tostring(legacyData))
                    profile.loaded = false
                end
            else
                sanitizeProfile(data, profile)
                profile.loaded = true
            end
        else
            warn("NightShift load failed for " .. player.UserId .. ": " .. tostring(data))
            profile.loaded = false -- Never overwrite an existing profile after a failed load.
        end
    end
    profile.ready = true
    if player.Parent ~= Players then return end
    if not profile.loaded then
        notify(player, "Прогресс этой сессии временный: хранилище недоступно. Сохранённый профиль не перезаписан.")
    end
    profile.stamina = maxStamina(profile)
    profile.battery = maxBattery(profile)
    refreshProfile(player)
    refreshVitals(player)
    remote:FireClient(player, "Preferences", sanitizePreferences(profile.preferences))
    if gameplay then gameplay:SendState(player) end
    if campaign then campaign:OnPlayerAdded(player) end
    if player.Character then
        task.defer(function()
            local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
            if humanoid then humanoid.WalkSpeed = 16 + profile.speedLevel * 2 end
        end)
    end
end

local function makePart(name, size, position, color, material, parent, transparency)
    local part = Instance.new("Part")
    part.Name = name
    part.Size = size
    part.Position = position
    part.Anchored = true
    part.CanTouch = false
    part.Color = color or Color3.fromRGB(80, 85, 95)
    part.Material = material or Enum.Material.SmoothPlastic
    part.TopSurface = Enum.SurfaceType.Smooth
    part.BottomSurface = Enum.SurfaceType.Smooth
    part.CastShadow = true
    if transparency then part.Transparency = transparency end
    part.Parent = parent or world
    return part
end

-- Decorative parts are non-interactive: they enrich the scene without blocking players or prompts.
local function makeDetail(name, size, position, color, material, transparency, parent)
    local part = makePart(name, size, position, color, material, parent or decorFolder or world, transparency)
    part.CanCollide = false
    part.CanTouch = false
    part.CanQuery = false
    part.CastShadow = true
    return part
end

local function makeVerticalCylinder(name, diameter, height, position, color, material, parent)
    local part = makeDetail(name, Vector3.new(height, diameter, diameter), position, color, material, nil, parent)
    part.Shape = Enum.PartType.Cylinder
    -- Roblox cylinder axis is local X; rotate it upright.
    part.CFrame = CFrame.new(position) * CFrame.Angles(0, 0, math.rad(90))
    return part
end

local function addLight(position, brightness, range, color)
    local tint = color or Color3.fromRGB(218, 229, 242)
    local fixture = makePart("CeilingFixture", Vector3.new(5.2, 0.32, 2.2), position, Color3.fromRGB(174, 184, 194), Enum.Material.Metal)
    fixture.CanCollide = false
    local diffuser = makePart("LampDiffuser", Vector3.new(4.7, 0.1, 1.7), position + Vector3.new(0, -0.2, 0), Color3.fromRGB(160, 171, 184), Enum.Material.SmoothPlastic)
    diffuser.CanCollide = false
    local glow = makePart("LampGlow", Vector3.new(4.4, 0.035, 1.45), position + Vector3.new(0, -0.27, 0), tint:Lerp(Color3.fromRGB(75, 86, 101), 0.42), Enum.Material.SmoothPlastic)
    glow.CanCollide = false

    local point = Instance.new("PointLight")
    point.Color = tint
    point.Brightness = (brightness or 1.8) * 0.34
    point.Range = range or 32
    point.Shadows = false
    point.Parent = glow

    local surface = Instance.new("SurfaceLight")
    surface.Name = "Downlight"
    surface.Face = Enum.NormalId.Bottom
    surface.Color = tint
    surface.Brightness = (brightness or 1.8) * 0.58
    surface.Range = range or 32
    surface.Angle = 120
    surface.Shadows = (brightness or 1.8) >= 2.1
    surface.Parent = diffuser

    table.insert(lights, point)
    table.insert(lights, surface)
    originalLightColors[point] = point.Color
    originalLightColors[surface] = surface.Color
    return point
end

-- A physical rotating warning beacon. The red dome stays visible while a narrow
-- spotlight sweeps around it, producing the moving pool of light of a real siren.
local function addRotatingAlarmBeacon(name, position)
    local model = Instance.new("Model")
    model.Name = name
    model.Parent = world
    local base = makeDetail(name .. "Base", Vector3.new(1.05, 0.2, 1.05), position, Color3.fromRGB(35, 41, 47), Enum.Material.Metal, 0, model)
    local collar = makeDetail(name .. "Collar", Vector3.new(0.92, 0.16, 0.92), position + Vector3.new(0, 0.16, 0), Color3.fromRGB(104, 35, 33), Enum.Material.Metal, 0, model)
    local dome = makeDetail(name .. "Dome", Vector3.new(0.86, 0.78, 0.86), position + Vector3.new(0, 0.58, 0), Color3.fromRGB(255, 48, 40), Enum.Material.Neon, 0.28, model)
    dome.Shape = Enum.PartType.Ball
    local rotor = makeDetail(name .. "Rotor", Vector3.new(0.12, 0.09, 0.72), position + Vector3.new(0, 0.58, 0), Color3.fromRGB(255, 70, 55), Enum.Material.Neon, 0.04, model)
    rotor.CanQuery = false
    local sweep = Instance.new("SpotLight")
    sweep.Name = "RotatingSweep"
    sweep.Face = Enum.NormalId.Front
    sweep.Color = Color3.fromRGB(255, 38, 31)
    sweep.Brightness = 0
    sweep.Range = 30
    sweep.Angle = 72
    sweep.Shadows = false
    sweep.Parent = rotor
    local glow = Instance.new("PointLight")
    glow.Name = "BeaconGlow"
    glow.Color = Color3.fromRGB(255, 35, 28)
    glow.Brightness = 0.08
    glow.Range = 9
    glow.Shadows = false
    glow.Parent = dome
    table.insert(alarmBeacons, {model = model, base = base, collar = collar, dome = dome, rotor = rotor,
        sweep = sweep, glow = glow, position = position, phase = #alarmBeacons * 1.7})
    return model
end

local function stopAlarmBeacons()
    if world then world:SetAttribute("EmergencyAlarmActive", false) end
    generatorWarningToken += 1
    generatorWarningActive = false
    for _, beacon in ipairs(alarmBeacons) do
        if beacon.model and beacon.model.Parent then
            beacon.sweep.Brightness = 0
            beacon.glow.Brightness = 0.08
            beacon.dome.Transparency = 0.28
            beacon.dome.Color = Color3.fromRGB(255, 48, 40)
            beacon.rotor.Color = Color3.fromRGB(255, 70, 55)
            beacon.rotor.CFrame = CFrame.new(beacon.position + Vector3.new(0, 0.58, 0))
        end
    end
end

local function setGeneratorWarning(active)
    active = active == true and round.phase == "SHIFT" and not (world and world:GetAttribute("EmergencyAlarmActive") == true)
    if generatorWarningActive == active then return end
    generatorWarningActive = active
    generatorWarningToken += 1
    local token = generatorWarningToken
    local beacon = generatorWarningBeacon
    if not active then
        if beacon and beacon.model and beacon.model.Parent then
            beacon.sweep.Brightness = 0
            beacon.glow.Brightness = 0.08
            beacon.dome.Transparency = 0.28
            beacon.rotor.CFrame = CFrame.new(beacon.position + Vector3.new(0, 0.58, 0))
        end
        return
    end
    emitWorldSound("generator_warning", Vector3.new(32, 3, -23), "Генератор требует обслуживания")
    task.spawn(function()
        local started = os.clock()
        while generatorWarningToken == token and generatorWarningActive and round.phase == "SHIFT"
            and world and world:GetAttribute("EmergencyAlarmActive") ~= true do
            local elapsed = os.clock() - started
            local pulse = 0.5 + 0.5 * math.sin(elapsed * math.pi * 2.1)
            local sweep = 0.5 + 0.5 * math.sin(elapsed * 1.65)
            if beacon and beacon.model and beacon.model.Parent then
                beacon.rotor.CFrame = CFrame.new(beacon.position + Vector3.new(0, 0.58, 0)) * CFrame.Angles(0, elapsed * 3.5, 0)
                beacon.sweep.Brightness = 0.55 + 1.35 * sweep
                beacon.glow.Brightness = 0.18 + 1.05 * pulse
                beacon.dome.Transparency = 0.38 - 0.13 * pulse
                beacon.dome.Color = Color3.fromRGB(255, 43 + math.floor(20 * (1 - pulse)), 34)
            end
            if generatorWarningLight and generatorWarningLight.Parent then generatorWarningLight.Brightness = 0.35 + 0.58 * pulse end
            if generatorStatusLight and generatorStatusLight.Parent then generatorStatusLight.Brightness = 0.28 + 0.42 * pulse end
            task.wait(0.06)
        end
        if generatorWarningToken == token then
            generatorWarningActive = false
            if beacon and beacon.model and beacon.model.Parent then
                beacon.sweep.Brightness = 0
                beacon.glow.Brightness = 0.08
                beacon.dome.Transparency = 0.28
                beacon.rotor.CFrame = CFrame.new(beacon.position + Vector3.new(0, 0.58, 0))
            end
        end
    end)
end

local function addTextSign(part, text, face, textColor)
    local surface = Instance.new("SurfaceGui")
    surface.Name = "ReadableSign_" .. (face or Enum.NormalId.Front).Name
    surface.Face = face or Enum.NormalId.Front
    surface.LightInfluence = 0
    surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
    surface.PixelsPerStud = 45
    surface.MaxDistance = 95
    surface.AlwaysOnTop = false
    surface.Parent = part
    local label = Instance.new("TextLabel")
    label.Position = UDim2.fromScale(0.045, 0.07)
    label.Size = UDim2.fromScale(0.91, 0.86)
    label.BackgroundTransparency = 1
    label.Text = text
    label.TextColor3 = textColor or Color3.fromRGB(255, 240, 220)
    label.TextStrokeTransparency = 0.82
    label.TextScaled = true
    label.TextWrapped = true
    label.Font = Enum.Font.GothamBold
    label.Parent = surface
    return surface
end

local function addPrompt(part, actionText, objectText, holdDuration, callback, options)
    options = options or {}
    local prompt = Instance.new("ProximityPrompt")
    prompt.ActionText = actionText
    prompt.ObjectText = objectText
    prompt.KeyboardKeyCode = Enum.KeyCode.E
    prompt.GamepadKeyCode = Enum.KeyCode.ButtonX
    prompt.HoldDuration = holdDuration or 1
    prompt.MaxActivationDistance = options.distance or 8
    prompt.RequiresLineOfSight = options.lineOfSight ~= false
    -- The map has many nearby inspection points. A single global prompt prevents
    -- Roblox from stacking repeated "Осмотр" cards over the whole screen.
    prompt.Exclusivity = Enum.ProximityPromptExclusivity.OneGlobally
    prompt:SetAttribute("AllowWhileHidden", options.allowHidden == true)
    prompt.Style = Enum.ProximityPromptStyle.Custom
    prompt.Parent = part
    local triggeredAt = setmetatable({}, {__mode = "k"})
    prompt.Triggered:Connect(function(player)
        if not prompt.Enabled or not part.Parent then return end
        local character = player.Character
        local root = character and character:FindFirstChild("HumanoidRootPart")
        local humanoid = character and character:FindFirstChildOfClass("Humanoid")
        if not root or not humanoid or humanoid.Health <= 0 or player:GetAttribute("NightShiftDowned") then return end
        if (root.Position - part.Position).Magnitude > prompt.MaxActivationDistance + 2 then return end
        if not profiles[player] or not profiles[player].ready then notify(player, TEXT.profileWait) return end
        local hidden = player:GetAttribute("NightShiftHidden")
        if hidden and not prompt:GetAttribute("AllowWhileHidden") then notify(player, "Сначала выйди из укрытия."); return end
        local now = os.clock()
        if now - (triggeredAt[player] or -10) < 0.45 then return end
        -- A replicated prompt must not allow tasks to be completed through a wall.
        if not hidden and (options.lineOfSight ~= false or options.enforceLineOfSight == true) then
            local params = RaycastParams.new()
            params.FilterType = Enum.RaycastFilterType.Exclude
            params.FilterDescendantsInstances = {character, part, decorFolder}
            params.RespectCanCollide = true
            local head = character:FindFirstChild("Head") or root
            if Workspace:Raycast(head.Position, part.Position - head.Position, params) then return end
        end
        triggeredAt[player] = now
        callback(player)
    end)
    return prompt
end

-- All moving doors use absolute transforms, stationary controls on both sides,
-- a shared busy lock, and an obstruction check before AND after closing.
local function addDoorController(panel, openCFrame, title, anchors, accessories, options)
    options = options or {}
    local closedCFrame = panel.CFrame
    local members = {{part = panel, closed = closedCFrame, open = openCFrame}}
    for _, part in ipairs(accessories or {}) do
        table.insert(members, {part = part, closed = part.CFrame, open = openCFrame * closedCFrame:ToObjectSpace(part.CFrame)})
    end
    local controller = {IsOpen = options.open == true, Busy = false, Prompts = {}, Panel = panel}
    panel:SetAttribute("DoorLeaf", true)
    panel:SetAttribute("NightShiftDoor", true)
    panel:SetAttribute("ClosedCFrame", closedCFrame)
    panel:SetAttribute("OpenCFrame", openCFrame)
    doorControllers[panel] = controller
    local function occupied()
        local characters = {}
        for _, player in ipairs(Players:GetPlayers()) do
            if player.Character then table.insert(characters, player.Character) end
        end
        if #characters == 0 then return false end
        local params = OverlapParams.new()
        params.FilterType = Enum.RaycastFilterType.Include
        params.FilterDescendantsInstances = characters
        params.MaxParts = 1
        return #Workspace:GetPartBoundsInBox(closedCFrame, panel.Size + Vector3.new(0.8, 0.1, 0.8), params) > 0
    end
    local function publish()
        panel:SetAttribute("IsOpen", controller.IsOpen)
        panel:SetAttribute("DoorBusy", controller.Busy)
        panel:SetAttribute("DoorState", controller.Busy and "MOVING" or (controller.IsOpen and "OPEN" or "CLOSED"))
        for _, prompt in ipairs(controller.Prompts) do
            prompt.ActionText = controller.IsOpen and "Закрыть" or "Открыть"
        end
    end
    local function animate(opening)
        panel.CanCollide = false
        local firstTween
        for _, member in ipairs(members) do
            local tween = TweenService:Create(member.part, TweenInfo.new(options.duration or 0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {CFrame = opening and member.open or member.closed})
            if not firstTween then firstTween = tween end
            tween:Play()
        end
        firstTween.Completed:Wait()
    end
    function controller:SetOpen(opening, player)
        if self.Busy or not panel.Parent then return false end
        if self.IsOpen == opening then return true end
        if not opening and occupied() then
            notify(player, "Проём занят. Отойди от двери и попробуй ещё раз.")
            return false
        end
        self.Busy = true
        publish()
        if emitWorldSound then emitWorldSound("door", panel.Position, opening and "Открывается дверь" or "Закрывается дверь") end
        if emitNoise then emitNoise(panel.Position, "door", opening and 15 or 23, player) end
        animate(opening)
        if not panel.Parent then self.Busy = false return false end
        if not opening and occupied() then
            animate(true)
            self.IsOpen = true
            self.Busy = false
            panel.CanCollide = true
            publish()
            notify(player, "Дверь снова открылась: кто-то стоит в проёме.")
            return false
        end
        self.IsOpen = opening
        self.Busy = false
        panel.CanCollide = true
        publish()
        return true
    end
    for i, position in ipairs(anchors) do
        local anchor = makeDetail(panel.Name .. "Control" .. i, Vector3.new(0.35, 0.35, 0.35), position, Color3.fromRGB(0, 0, 0), Enum.Material.SmoothPlastic, 1)
        local prompt = addPrompt(anchor, "Открыть", title, 0.25, function(player)
            controller:SetOpen(not controller.IsOpen, player)
        end, {distance = options.distance or 6})
        prompt.KeyboardKeyCode = options.key or Enum.KeyCode.E
        prompt.GamepadKeyCode = options.gamepad or Enum.KeyCode.ButtonX
        table.insert(controller.Prompts, prompt)
    end
    for _, member in ipairs(members) do member.part.CFrame = controller.IsOpen and member.open or member.closed end
    publish()
    return controller
end

local function addWayfinding(name, position, width, text, facing, color, doubleSided)
    local sign = makeDetail(name, Vector3.new(width, 1.05, 0.16), position, color or Color3.fromRGB(43, 86, 78), Enum.Material.Metal)
    sign.CFrame = CFrame.lookAt(position, position + facing)
    addTextSign(sign, text, Enum.NormalId.Front, Color3.fromRGB(235, 243, 223))
    if doubleSided then addTextSign(sign, text, Enum.NormalId.Back, Color3.fromRGB(235, 243, 223)) end
    return sign
end

-- A prop's front is always local -Z. Body, doors, labels and handles share one frame.
local function makeFurnitureAssembly(name, origin, facing)
    local model = Instance.new("Model")
    model.Name = name .. "Assembly"
    model.Parent = world
    local frame = CFrame.lookAt(origin, origin + facing)
    local function addPart(partName, size, offset, color, material, transparency, collidable, localRotation)
        local part = makePart(partName, size, origin, color, material or Enum.Material.Metal, model, transparency)
        part.CFrame = frame * CFrame.new(offset) * (localRotation or CFrame.new())
        part.CanCollide = collidable == true
        part.CanTouch = false
        part.CanQuery = collidable == true
        part.CastShadow = (transparency or 0) < 1
        return part
    end
    return model, frame, addPart
end

local function addShelf(name, position, width, depth)
    local base = makePart(name .. "Base", Vector3.new(width, 0.48, depth), position + Vector3.new(0, 0.34, 0), Color3.fromRGB(43, 49, 56), Enum.Material.Metal)
    makePart(name .. "Back", Vector3.new(width, 5.6, 0.22), position + Vector3.new(0, 3.1, -depth / 2 + 0.12), Color3.fromRGB(58, 66, 73), Enum.Material.DiamondPlate)

    -- Structural uprights, cross-bracing and front lips make each aisle fixture read as a real retail gondola.
    for _, xOffset in ipairs({-width / 2 + 0.12, width / 2 - 0.12}) do
        makePart(name .. "Upright", Vector3.new(0.22, 5.65, 0.28), position + Vector3.new(xOffset, 3.12, -depth / 2 + 0.12), Color3.fromRGB(83, 92, 99), Enum.Material.Metal)
        makeDetail(name .. "Foot", Vector3.new(0.5, 0.16, depth + 0.25), position + Vector3.new(xOffset, 0.22, 0), Color3.fromRGB(28, 33, 38), Enum.Material.Metal)
    end

    local productColors = {
        Color3.fromRGB(151, 67, 54), Color3.fromRGB(173, 132, 63),
        Color3.fromRGB(58, 112, 98), Color3.fromRGB(63, 91, 133),
        Color3.fromRGB(125, 92, 126), Color3.fromRGB(178, 169, 145),
    }
    for level = 1, 3 do
        local shelfY = 0.65 + level * 1.45
        makePart(name .. "Shelf" .. level, Vector3.new(width, 0.2, depth), position + Vector3.new(0, shelfY, 0), Color3.fromRGB(111, 119, 124), Enum.Material.Metal)
        makeDetail(name .. "ShelfLip" .. level, Vector3.new(width - 0.2, 0.12, 0.12), position + Vector3.new(0, shelfY + 0.1, depth / 2 - 0.08), Color3.fromRGB(157, 165, 168), Enum.Material.Metal)
        makeDetail(name .. "ShelfShadow" .. level, Vector3.new(width - 0.25, 0.035, depth - 0.35), position + Vector3.new(0, shelfY + 0.13, -0.03), Color3.fromRGB(33, 38, 42), Enum.Material.SmoothPlastic)

        for slot = 1, 5 do
            local x = position.X - width / 2 + (slot * width / 6)
            local z = position.Z + 0.25
            local y = position.Y + shelfY + 0.63
            local color = productColors[((slot + level * 2) % #productColors) + 1]
            local variant = (slot + level) % 3
            if variant == 0 then
                local can = makeVerticalCylinder(name .. "Can", 0.58, 0.86, Vector3.new(x, y, z), color, Enum.Material.Metal)
                can.Reflectance = 0.08
                makeDetail(name .. "CanLabel", Vector3.new(0.38, 0.34, 0.035), Vector3.new(x, y, z + 0.3), Color3.fromRGB(226, 216, 190), Enum.Material.SmoothPlastic)
                makeVerticalCylinder(name .. "CanTop", 0.42, 0.07, Vector3.new(x, y + 0.45, z), Color3.fromRGB(177, 183, 184), Enum.Material.Metal)
            elseif variant == 1 then
                makeVerticalCylinder(name .. "Bottle", 0.52, 0.92, Vector3.new(x, y, z), color, Enum.Material.SmoothPlastic)
                makeVerticalCylinder(name .. "BottleNeck", 0.25, 0.22, Vector3.new(x, y + 0.53, z), color, Enum.Material.SmoothPlastic)
                makeVerticalCylinder(name .. "BottleCap", 0.27, 0.12, Vector3.new(x, y + 0.69, z), Color3.fromRGB(202, 194, 167), Enum.Material.SmoothPlastic)
                makeDetail(name .. "BottleLabel", Vector3.new(0.38, 0.26, 0.035), Vector3.new(x, y, z + 0.27), Color3.fromRGB(225, 218, 196), Enum.Material.SmoothPlastic)
            else
                local pack = makeDetail(name .. "ProductPack", Vector3.new(0.88, 1.02, 0.78), Vector3.new(x, y, z), color, Enum.Material.SmoothPlastic)
                makeDetail(name .. "PackTop", Vector3.new(0.78, 0.08, 0.7), Vector3.new(x, y + 0.55, z), Color3.fromRGB(208, 199, 175), Enum.Material.SmoothPlastic)
                makeDetail(name .. "PackLabel", Vector3.new(0.58, 0.35, 0.035), Vector3.new(x, y, z + 0.405), Color3.fromRGB(225, 216, 190), Enum.Material.SmoothPlastic)
            end
        end
    end
    return base
end


local function addPalletStack(name, position, crateColor, facing)
    local _, _, p = makeFurnitureAssembly(name, position, facing or Vector3.new(0, 0, 1))
    p(name .. "PalletBase", Vector3.new(3.8, 0.34, 3.2), Vector3.new(0, 0.22, 0), Color3.fromRGB(104, 76, 54), Enum.Material.WoodPlanks, nil, true)
    for i = -1, 1 do
        p(name .. "PalletSlat", Vector3.new(3.75, 0.08, 0.22), Vector3.new(0, 0.42, i * 0.9), Color3.fromRGB(131, 97, 68), Enum.Material.Wood)
    end
    for level = 0, 1 do
        for _, xOffset in ipairs({-0.9, 0.9}) do
            local shade = crateColor or Color3.fromRGB(153, 98, 57)
            local offset = Vector3.new(xOffset, 0.95 + level * 1.04, 0.45 - level * 0.22)
            p(name .. "Box", Vector3.new(1.45, 1.0, 1.15), offset, shade, Enum.Material.Cardboard)
            p(name .. "Tape", Vector3.new(0.16, 1.02, 1.18), offset, Color3.fromRGB(214, 197, 159), Enum.Material.SmoothPlastic)
            p(name .. "Label", Vector3.new(0.55, 0.28, 0.03), offset + Vector3.new(0, 0, -0.59), Color3.fromRGB(229, 223, 205), Enum.Material.SmoothPlastic)
        end
    end
end

local function addBasketStack(name, position)
    for i = 0, 4 do
        local basket = makeDetail(name .. "Basket", Vector3.new(1.5, 0.28, 1.0), position + Vector3.new(0, 0.28 + i * 0.16, 0), Color3.fromRGB(156, 28, 28), Enum.Material.Metal)
        makeDetail(name .. "BasketLip", Vector3.new(1.58, 0.05, 1.08), basket.Position + Vector3.new(0, 0.13, 0), Color3.fromRGB(186, 40, 40), Enum.Material.Metal)
        makeDetail(name .. "BasketHandle", Vector3.new(0.08, 0.36, 0.9), basket.Position + Vector3.new(-0.62, 0.18, 0), Color3.fromRGB(214, 214, 220), Enum.Material.Metal)
        makeDetail(name .. "BasketHandle", Vector3.new(0.08, 0.36, 0.9), basket.Position + Vector3.new(0.62, 0.18, 0), Color3.fromRGB(214, 214, 220), Enum.Material.Metal)
    end
end

local function addCheckoutLane(index, x, z)
    local belt = makePart("CheckoutBelt" .. index, Vector3.new(5.2, 0.22, 1.75), Vector3.new(x, 3.98, z), Color3.fromRGB(21, 25, 30), Enum.Material.Metal)
    for i = -2, 2 do
        makeDetail("BeltRib" .. index, Vector3.new(0.08, 0.03, 1.55), belt.Position + Vector3.new(i * 0.85, 0.12, 0), Color3.fromRGB(86, 94, 101), Enum.Material.Metal)
    end
    makePart("CheckoutGuard" .. index, Vector3.new(0.08, 0.55, 1.8), Vector3.new(x + 2.5, 4.2, z), Color3.fromRGB(157, 161, 168), Enum.Material.Metal)
    makePart("CheckoutGuard" .. index, Vector3.new(0.08, 0.55, 1.8), Vector3.new(x - 2.5, 4.2, z), Color3.fromRGB(157, 161, 168), Enum.Material.Metal)
    local scanner = makeDetail("Scanner" .. index, Vector3.new(0.9, 0.45, 0.65), Vector3.new(x + 1.75, 4.28, z - 0.82), Color3.fromRGB(30, 36, 43), Enum.Material.Metal)
    makeDetail("ScannerGlow" .. index, Vector3.new(0.45, 0.03, 0.3), scanner.Position + Vector3.new(0, 0.24, 0), Color3.fromRGB(219, 72, 72), Enum.Material.Neon)
    -- Bank terminals face the customer; the separate cash registers face the cashier.
    local _, _, terminalPart = makeFurnitureAssembly("PaymentTerminal" .. index, Vector3.new(x - 1.95, 4.53, z + 0.65), Vector3.new(0, 0, 1))
    terminalPart("PaymentTerminal" .. index, Vector3.new(0.7, 0.8, 0.3), Vector3.new(0, 0, 0), Color3.fromRGB(42, 52, 60))
    local screen = terminalPart("TerminalScreen" .. index, Vector3.new(0.54, 0.32, 0.04), Vector3.new(0, 0.18, -0.177), Color3.fromRGB(93, 180, 167), Enum.Material.Neon)
    addTextSign(screen, "ОПЛАТА", Enum.NormalId.Front, Color3.fromRGB(207, 248, 225))
    terminalPart("TerminalStand" .. index, Vector3.new(0.45, 0.1, 0.45), Vector3.new(0, -0.42, 0.02), Color3.fromRGB(31, 39, 46))
    for row = 0, 2 do
        for col = -1, 1 do
            terminalPart("TerminalKey" .. index, Vector3.new(0.1, 0.07, 0.04), Vector3.new(col * 0.16, -0.07 - row * 0.1, -0.178), Color3.fromRGB(166, 177, 178), Enum.Material.SmoothPlastic)
        end
    end
    local _, _, rackPart = makeFurnitureAssembly("ImpulseRack" .. index, Vector3.new(x + 2.6, 4.36, z + 0.86), Vector3.new(0, 0, 1))
    rackPart("ImpulseRack" .. index, Vector3.new(1.0, 0.9, 0.06), Vector3.new(0, 0, 0.22), Color3.fromRGB(80, 89, 96))
    for _, side in ipairs({-1, 1}) do
        rackPart("ImpulseRackSide" .. index, Vector3.new(0.06, 0.9, 0.5), Vector3.new(side * 0.47, 0, 0), Color3.fromRGB(80, 89, 96))
    end
    for row = 0, 1 do
        rackPart("ImpulseRackShelf" .. index, Vector3.new(0.9, 0.06, 0.46), Vector3.new(0, -0.32 + row * 0.34, 0), Color3.fromRGB(112, 124, 130))
        for col = 0, 1 do
            rackPart("Candy" .. index, Vector3.new(0.26, 0.18, 0.18), Vector3.new(-0.18 + col * 0.36, -0.2 + row * 0.34, -0.1), Color3.fromRGB(186 - row * 15, 95 + col * 35, 74 + row * 28), Enum.Material.SmoothPlastic)
        end
    end
end

local function addEndcapDisplay(name, position)
    local _, _, p = makeFurnitureAssembly(name, position, Vector3.new(0, 0, 1))
    -- Retain the collision envelope, but leave the visible customer-facing shelves open.
    local body = p(name .. "Body", Vector3.new(2.2, 4.6, 2.4), Vector3.new(0, 2.45, 0), Color3.fromRGB(71, 78, 86), Enum.Material.Metal, 1, true)
    p(name .. "Back", Vector3.new(2.2, 4.6, 0.14), Vector3.new(0, 2.45, 1.13), Color3.fromRGB(71, 78, 86))
    for _, side in ipairs({-1, 1}) do
        p(name .. "Side", Vector3.new(0.14, 4.6, 2.26), Vector3.new(side * 1.03, 2.45, 0), Color3.fromRGB(71, 78, 86))
    end
    p(name .. "Base", Vector3.new(2.2, 0.18, 2.4), Vector3.new(0, 0.24, 0), Color3.fromRGB(51, 61, 69))
    p(name .. "Top", Vector3.new(2.2, 0.14, 2.4), Vector3.new(0, 4.68, 0), Color3.fromRGB(71, 78, 86))
    local header = p(name .. "Header", Vector3.new(2.2, 0.42, 0.12), Vector3.new(0, 4.44, -1.15), Color3.fromRGB(170, 111, 58))
    addTextSign(header, "АКЦИЯ", Enum.NormalId.Front, Color3.fromRGB(248, 236, 209))
    for level = 0, 2 do
        p(name .. "Shelf", Vector3.new(1.95, 0.14, 2.1), Vector3.new(0, 1.05 + level * 1.05, 0), Color3.fromRGB(115, 123, 129))
        p(name .. "ShelfLip", Vector3.new(1.95, 0.14, 0.08), Vector3.new(0, 1.14 + level * 1.05, -1.02), Color3.fromRGB(184, 190, 184))
        for col = -1, 1 do
            local offset = Vector3.new(col * 0.54, 1.52 + level * 1.05, -0.48)
            local can = p(name .. "DisplayCan", Vector3.new(0.8, 0.48, 0.48), offset, Color3.fromRGB(176 - level * 14, 86 + col * 30, 72 + level * 24), Enum.Material.Metal, nil, false, CFrame.Angles(0, 0, math.rad(90)))
            can.Shape = Enum.PartType.Cylinder
            p(name .. "ProductLabel", Vector3.new(0.32, 0.24, 0.025), offset + Vector3.new(0, 0, -0.25), Color3.fromRGB(232, 222, 197), Enum.Material.SmoothPlastic)
        end
    end
    return body
end

local function addCooler(name, x)
    local _, _, p = makeFurnitureAssembly(name, Vector3.new(x, 4.2, -29), Vector3.new(0, 0, 1))
    p("Cooler", Vector3.new(8, 8, 2), Vector3.new(0, 0, 0), Color3.fromRGB(45, 62, 73), Enum.Material.Metal, 1, true)
    p("CoolerBack", Vector3.new(8, 8, 0.16), Vector3.new(0, 0, 0.92), Color3.fromRGB(45, 62, 73))
    for _, side in ipairs({-1, 1}) do
        p("CoolerSide", Vector3.new(0.18, 8, 2), Vector3.new(side * 3.91, 0, 0), Color3.fromRGB(45, 62, 73))
        p("CoolerEdge", Vector3.new(8, 0.36, 2), Vector3.new(0, side * 3.82, 0), Color3.fromRGB(45, 62, 73))
        p("CoolerOuterVerticalFrame", Vector3.new(0.28, 7, 0.24), Vector3.new(side * 3.78, 0, -1.04), Color3.fromRGB(139, 154, 159))
        p("CoolerOuterHorizontalFrame", Vector3.new(8, 0.6, 0.24), Vector3.new(0, side * 3.48, -1.04), Color3.fromRGB(139, 154, 159))
        p("CoolerGlass", Vector3.new(3.65, 6.6, 0.1), Vector3.new(side * 1.87, 0.05, -1.08), Color3.fromRGB(112, 173, 192), Enum.Material.Glass, 0.72)
        p("CoolerDoorFrame", Vector3.new(0.09, 6.7, 0.16), Vector3.new(side * 0.045, 0.05, -1.14), Color3.fromRGB(139, 154, 159))
        p("CoolerHandle", Vector3.new(0.1, 1.8, 0.16), Vector3.new(side * 0.22, -0.05, -1.25), Color3.fromRGB(203, 209, 214))
    end
    local strip = p("CoolerLight", Vector3.new(0.16, 6.2, 0.12), Vector3.new(3.64, 0, -0.88), Color3.fromRGB(120, 206, 230), Enum.Material.Neon)
    local coolerLight = Instance.new("PointLight")
    coolerLight.Color = Color3.fromRGB(120, 206, 230)
    coolerLight.Brightness = 0.7
    coolerLight.Range = 11
    coolerLight.Parent = strip
    table.insert(lights, coolerLight); originalLightColors[coolerLight] = coolerLight.Color
    for shelfY = 2, 6, 2 do
        p("CoolerInteriorShelf", Vector3.new(7.3, 0.08, 1.65), Vector3.new(0, shelfY - 4.2, 0), Color3.fromRGB(130, 145, 151))
        for slot = -2, 2 do
            local bottleColor = ({Color3.fromRGB(62, 120, 99), Color3.fromRGB(65, 104, 151), Color3.fromRGB(156, 93, 58), Color3.fromRGB(178, 160, 104), Color3.fromRGB(91, 126, 130)})[slot + 3]
            local offset = Vector3.new(slot * 1.05, shelfY - 4.2 + 0.48, -0.3)
            local bottle = p("CoolerBottle", Vector3.new(0.88, 0.34, 0.34), offset, bottleColor, Enum.Material.SmoothPlastic, nil, false, CFrame.Angles(0, 0, math.rad(90)))
            bottle.Shape = Enum.PartType.Cylinder
            local cap = p("CoolerBottleCap", Vector3.new(0.12, 0.19, 0.19), offset + Vector3.new(0, 0.49, 0), Color3.fromRGB(208, 201, 178), Enum.Material.SmoothPlastic, nil, false, CFrame.Angles(0, 0, math.rad(90)))
            cap.Shape = Enum.PartType.Cylinder
            p("CoolerBottleLabel", Vector3.new(0.24, 0.25, 0.025), offset + Vector3.new(0, 0, -0.177), Color3.fromRGB(227, 221, 198), Enum.Material.SmoothPlastic)
        end
    end
end

local function addShoppingCart(name, position, angle)
    local model = Instance.new("Model")
    model.Name = name
    model.Parent = decorFolder or world
    local pivot = makeDetail(name .. "Pivot", Vector3.new(0.2, 0.2, 0.2), position, Color3.fromRGB(0, 0, 0), Enum.Material.SmoothPlastic, 1, model)
    local cartFrame = CFrame.new(position) * CFrame.Angles(0, math.rad(angle or 0), 0)
    local function p(partName, size, offset, color, material, transparency)
        local part = makeDetail(partName, size, position + offset, color, material or Enum.Material.Metal, transparency, model)
        part.CFrame = cartFrame * CFrame.new(offset)
        return part
    end
    p(name .. "Basket", Vector3.new(2.6, 1.0, 1.8), Vector3.new(0, 1.25, 0), Color3.fromRGB(163, 172, 179), Enum.Material.DiamondPlate)
    p(name .. "Handle", Vector3.new(0.3, 0.12, 2.2), Vector3.new(-1.2, 2.1, 0), Color3.fromRGB(224, 82, 82), Enum.Material.SmoothPlastic)
    p(name .. "Base", Vector3.new(2.2, 0.12, 1.55), Vector3.new(0.1, 0.55, 0), Color3.fromRGB(136, 145, 152), Enum.Material.Metal)
    for _, side in ipairs({-1, 1}) do
        for _, endz in ipairs({-0.7, 0.7}) do
            local wheel = p(name .. "Wheel", Vector3.new(0.12, 0.28, 0.28), Vector3.new(side * 1.0, 0.26, endz), Color3.fromRGB(38, 42, 48), Enum.Material.SmoothPlastic)
            wheel.Shape = Enum.PartType.Cylinder
            wheel.CFrame = wheel.CFrame * CFrame.Angles(0, math.rad(90), 0)
        end
    end
    return model
end

local function addParkingLamp(name, position)
    -- The arm points into the parking area from either side of the site.
    local facing = position.X > 0 and Vector3.new(-1, 0, 0) or Vector3.new(1, 0, 0)
    local model, frame, p = makeFurnitureAssembly(name, position, facing)
    local pole = p(name .. "Pole", Vector3.new(0.55, 16, 0.55), Vector3.new(0, 8, 0), Color3.fromRGB(90, 99, 108), Enum.Material.Metal, nil, true)
    p(name .. "Arm", Vector3.new(0.24, 0.24, 4), Vector3.new(0, 15.5, -1.75), Color3.fromRGB(90, 99, 108), Enum.Material.Metal, nil, true)
    p(name .. "Lamp", Vector3.new(0.9, 0.36, 1.2), Vector3.new(0, 15.3, -3.4), Color3.fromRGB(182, 187, 193), Enum.Material.Metal, nil, false)
    local glow = p(name .. "Glow", Vector3.new(0.7, 0.06, 0.9), Vector3.new(0, 15.03, -3.4), Color3.fromRGB(216, 223, 229), Enum.Material.Neon, nil, false)
    local surface = Instance.new("SurfaceLight")
    surface.Face = Enum.NormalId.Bottom
    surface.Range = 32
    surface.Angle = 110
    surface.Color = Color3.fromRGB(214, 225, 238)
    surface.Brightness = 0.55
    surface.Shadows = false
    surface.Parent = glow
    table.insert(lights, surface)
    originalLightColors[surface] = surface.Color
    return pole
end

local function addCeilingSign(name, position, text, color)
    local sign = makePart(name, Vector3.new(7.4, 1.05, 0.18), position, color or Color3.fromRGB(73, 109, 142), Enum.Material.Metal)
    sign.CanCollide = false
    addTextSign(sign, text, Enum.NormalId.Front, Color3.fromRGB(246, 240, 223))
    addTextSign(sign, text, Enum.NormalId.Back, Color3.fromRGB(246, 240, 223))
end

local function addTree(x, z)
    local trunk = makeVerticalCylinder("TreeTrunk", 2.1, 8.5, Vector3.new(x, 4.1, z), Color3.fromRGB(70, 52, 40), Enum.Material.Wood)
    trunk.CanCollide = true
    for _, offset in ipairs({
        Vector3.new(0, 9.0, 0), Vector3.new(-2.2, 8.0, 0.8),
        Vector3.new(2.0, 8.2, -0.7), Vector3.new(0.8, 10.5, 1.1),
    }) do
        local crown = makePart("TreeFoliage", Vector3.new(7.2, 7.2, 7.2), Vector3.new(x, 0, z) + offset, Color3.fromRGB(27, 55, 47), Enum.Material.Grass)
        crown.Shape = Enum.PartType.Ball
        crown.CanCollide = false
    end
end

local function addCar(x, z, bodyColor)
    -- Canonical front is local -Z; the whole car faces +Z along the parking lines.
    local car, frame, p = makeFurnitureAssembly("ParkedCar", Vector3.new(x, 0, z), Vector3.new(0, 0, 1))
    local body = p("CarBody", Vector3.new(5.3, 1.8, 11.5), Vector3.new(0, 1.55, 0), bodyColor, Enum.Material.Metal, nil, true)
    body.Reflectance = 0.12
    p("CarHood", Vector3.new(5.15, 0.22, 3.4), Vector3.new(0, 2.5, -3.8), bodyColor:Lerp(Color3.fromRGB(220, 220, 220), 0.08), Enum.Material.Metal, nil, true)
    p("CarTrunk", Vector3.new(5.1, 0.2, 2.8), Vector3.new(0, 2.48, 4), bodyColor, Enum.Material.Metal, nil, true)
    p("CarCabin", Vector3.new(4.45, 2.15, 6.1), Vector3.new(0, 3.35, 0.35), Color3.fromRGB(26, 37, 47), Enum.Material.Glass, 0.28, false)
    p("Windshield", Vector3.new(4.1, 1.55, 0.14), Vector3.new(0, 3.42, -2.5), Color3.fromRGB(79, 112, 130), Enum.Material.Glass, 0.42, false)
    p("RearWindow", Vector3.new(4, 1.45, 0.14), Vector3.new(0, 3.4, 3.15), Color3.fromRGB(65, 91, 108), Enum.Material.Glass, 0.48, false)
    for _, side in ipairs({-1, 1}) do
        p("SideWindow", Vector3.new(0.08, 1.35, 5), Vector3.new(side * 2.24, 3.5, 0.35), Color3.fromRGB(77, 111, 130), Enum.Material.Glass, 0.4, false)
        p("DoorTrim", Vector3.new(0.12, 0.08, 5.2), Vector3.new(side * 2.66, 2.55, 0.25), Color3.fromRGB(31, 36, 42), Enum.Material.Metal, nil, true)
        p("SideMirror", Vector3.new(0.55, 0.4, 0.55), Vector3.new(side * 2.65, 3, -2.3), Color3.fromRGB(35, 42, 48), Enum.Material.Metal, nil, true)
    end
    p("FrontBumper", Vector3.new(5.35, 0.55, 0.35), Vector3.new(0, 1.35, -5.8), Color3.fromRGB(31, 37, 43), Enum.Material.Metal, nil, true)
    p("RearBumper", Vector3.new(5.35, 0.55, 0.35), Vector3.new(0, 1.35, 5.8), Color3.fromRGB(31, 37, 43), Enum.Material.Metal, nil, true)
    p("FrontGrille", Vector3.new(1.8, 0.62, 0.08), Vector3.new(0, 1.9, -5.86), Color3.fromRGB(17, 21, 25), Enum.Material.Metal, nil, true)
    for _, side in ipairs({-1, 1}) do
        p("Headlight", Vector3.new(0.82, 0.45, 0.16), Vector3.new(side * 1.85, 2.05, -5.86), Color3.fromRGB(222, 220, 190), Enum.Material.Glass, nil, true)
        p("TailLight", Vector3.new(0.78, 0.55, 0.16), Vector3.new(side * 1.85, 1.95, 5.86), Color3.fromRGB(145, 43, 38), Enum.Material.Neon, nil, false)
        for _, axleZ in ipairs({-3.7, 3.7}) do
            -- A wheel's axle is local X, perpendicular to the direction of travel.
            local wheel = p("CarWheel", Vector3.new(0.72, 1.45, 1.45), Vector3.new(side * 2.6, 0.8, axleZ), Color3.fromRGB(17, 19, 22), Enum.Material.Rubber, nil, true)
            wheel.Shape = Enum.PartType.Cylinder
            local rim = p("WheelRim", Vector3.new(0.75, 0.8, 0.8), Vector3.new(side * 2.6, 0.8, axleZ), Color3.fromRGB(111, 119, 124), Enum.Material.Metal, nil, false)
            rim.Shape = Enum.PartType.Cylinder
        end
    end
end

local function addServiceDumpster(name, position, size, color, collidable)
    -- Front faces the central alley. Rear wheels and lid hinge face the wall.
    local model, frame, p = makeFurnitureAssembly(name, position, Vector3.new(-1, 0, 0))
    local body = p(name, size, Vector3.new(0, 0, 0), color, Enum.Material.Metal, nil, collidable)
    p("DumpsterLid", Vector3.new(size.X + 0.3, 0.24, size.Z + 0.3), Vector3.new(0, size.Y / 2 + 0.14, 0), Color3.fromRGB(27, 35, 39), Enum.Material.Metal, nil, collidable)
    p("DumpsterLidHinge", Vector3.new(size.X - 0.5, 0.12, 0.16), Vector3.new(0, size.Y / 2 + 0.28, size.Z / 2), Color3.fromRGB(73, 86, 89), Enum.Material.Metal, nil, false)
    local diameter = name == "OutdoorDumpster" and 0.75 or 0.42
    local thickness = name == "OutdoorDumpster" and 0.45 or 0.28
    for _, side in ipairs({-1, 1}) do
        local wheel = p("DumpsterWheel", Vector3.new(thickness, diameter, diameter), Vector3.new(side * size.X * 0.36, -size.Y / 2 + diameter / 2 - 0.1, size.Z / 2 - 0.1), Color3.fromRGB(22, 25, 29), Enum.Material.Rubber, nil, false)
        wheel.Shape = Enum.PartType.Cylinder
    end
    return body
end

local function addVisualOverhaul()
    -- VISUAL 3.1.1: industrial retail architecture, believable fixtures and environmental storytelling.
    local rng = Random.new(3107)

    -- Suspended ceiling grid, service trays and ventilation runs.
    for x = -35, 35, 7 do
        makeDetail("CeilingGridLong", Vector3.new(0.16, 0.18, 59), Vector3.new(x, 20.05, 0), Color3.fromRGB(69, 77, 84), Enum.Material.Metal)
    end
    for z = -27, 27, 7.5 do
        makeDetail("CeilingGridCross", Vector3.new(80, 0.16, 0.16), Vector3.new(0, 20.05, z), Color3.fromRGB(69, 77, 84), Enum.Material.Metal)
    end
    for _, x in ipairs({-31, -17, 0, 17, 31}) do
        makeDetail("CeilingAcousticPanel", Vector3.new(5.8, 0.12, 5.9), Vector3.new(x, 20.22, -7), Color3.fromRGB(77, 84, 91), Enum.Material.SmoothPlastic)
    end
    for _, z in ipairs({-23, -11, 1, 13, 25}) do
        makeDetail("CeilingServicePipe", Vector3.new(76, 0.28, 0.28), Vector3.new(0, 19.45, z), Color3.fromRGB(93, 101, 107), Enum.Material.Metal)
        makeDetail("PipeBracket", Vector3.new(0.18, 0.75, 0.5), Vector3.new(-28, 19.75, z), Color3.fromRGB(48, 55, 62), Enum.Material.Metal)
        makeDetail("PipeBracket", Vector3.new(0.18, 0.75, 0.5), Vector3.new(28, 19.75, z), Color3.fromRGB(48, 55, 62), Enum.Material.Metal)
    end
    for _, x in ipairs({-34, -21, -7, 7, 21, 34}) do
        local emergency = makeDetail("CeilingEmergencyFixture", Vector3.new(1.1, 0.3, 0.7), Vector3.new(x, 19.7, -29), Color3.fromRGB(119, 31, 29), Enum.Material.Metal)
        makeDetail("EmergencyLens", Vector3.new(0.8, 0.12, 0.5), emergency.Position + Vector3.new(0, -0.18, 0), Color3.fromRGB(255, 58, 42), Enum.Material.Neon)
    end

    -- Better ceiling lighting: warm-neutral pools inside, colder spill around the loading bay.
    for _, p in ipairs({
        Vector3.new(-34, 19.15, 12), Vector3.new(-17, 19.15, 12), Vector3.new(0, 19.15, 12),
        Vector3.new(17, 19.15, 12), Vector3.new(34, 19.15, 12),
        Vector3.new(-34, 19.15, -12), Vector3.new(-17, 19.15, -12), Vector3.new(0, 19.15, -12),
        Vector3.new(17, 19.15, -12), Vector3.new(34, 19.15, -12),
    }) do
        addLight(p, 1.25, 27, Color3.fromRGB(190, 201, 214))
    end

    -- Wall cladding, skirting, conduit and readable safety signage.
    for _, z in ipairs({-25, -13, 11, 23}) do
        makeDetail("LeftWallCladding", Vector3.new(0.12, 7.4, 8.8), Vector3.new(-40.86, 6.0, z), Color3.fromRGB(54, 62, 72), Enum.Material.Metal)
        makeDetail("RightWallCladding", Vector3.new(0.12, 7.4, 8.8), Vector3.new(40.86, 6.0, z), Color3.fromRGB(54, 62, 72), Enum.Material.Metal)
        makeDetail("LeftWallRail", Vector3.new(0.2, 0.16, 8.8), Vector3.new(-40.72, 10.0, z), Color3.fromRGB(120, 128, 133), Enum.Material.Metal)
        makeDetail("RightWallRail", Vector3.new(0.2, 0.16, 8.8), Vector3.new(40.72, 10.0, z), Color3.fromRGB(120, 128, 133), Enum.Material.Metal)
    end
    makeDetail("LeftWallConduit", Vector3.new(0.18, 0.18, 58), Vector3.new(-40.72, 17.8, 0), Color3.fromRGB(94, 102, 108), Enum.Material.Metal)
    makeDetail("RightWallConduit", Vector3.new(0.18, 0.18, 58), Vector3.new(40.72, 17.8, 0), Color3.fromRGB(94, 102, 108), Enum.Material.Metal)

    local function wallPoster(name, position, face, text, color)
        local poster = makeDetail(name, Vector3.new(0.12, 3.8, 3.0), position, color or Color3.fromRGB(42, 54, 60), Enum.Material.Metal)
        addTextSign(poster, text, face, Color3.fromRGB(226, 231, 222))
        return poster
    end
    wallPoster("SafetyPosterLeft", Vector3.new(-40.68, 8.0, -19), Enum.NormalId.Right, "ПРАВИЛА\nБЕЗОПАСНОСТИ", Color3.fromRGB(48, 76, 70))
    wallPoster("StaffPosterLeft", Vector3.new(-40.68, 8.0, 4), Enum.NormalId.Right, "STAFF ONLY\nНЕ ВХОДИТЬ", Color3.fromRGB(80, 53, 43))
    wallPoster("SafetyPosterRight", Vector3.new(40.68, 8.0, -17), Enum.NormalId.Left, "АВАРИЙНЫЙ\nВЫХОД", Color3.fromRGB(37, 75, 61))
    wallPoster("ShiftPosterRight", Vector3.new(40.68, 8.0, 8), Enum.NormalId.Left, "NIGHTMART\n24 / 7", Color3.fromRGB(48, 60, 78))

    -- Physical CCTV assemblies are built from the CameraPoints definitions in buildWorld().

    -- The two complete checkout lanes already include their belts and scanners.
    for _, x in ipairs({-6, 6}) do
        -- One customer terminal per lane is built by addCheckoutLane.
        makeDetail("ReceiptPrinter", Vector3.new(1.0, 0.55, 0.75), Vector3.new(x - 1.85, 4.28, 16.3), Color3.fromRGB(46, 51, 56), Enum.Material.Metal)
    end
    -- The basket stack is by the entrance; the counter edge stays clear of the terminals.

    -- Refrigerator shells, glass and contents are built together by addCooler.

    -- One operator workstation, with clear access from the entrance and both side aisles.
    makeDetail("OfficeDeskMat", Vector3.new(7.5, 0.04, 2.2), Vector3.new(32, 2.53, 27), Color3.fromRGB(36, 44, 49), Enum.Material.Fabric)
    makeDetail("OfficeKeyboard", Vector3.new(2.3, 0.12, 0.75), Vector3.new(32, 2.64, 26.1), Color3.fromRGB(25, 29, 33), Enum.Material.SmoothPlastic)
    for key = 1, 12 do
        makeDetail("KeyboardKey", Vector3.new(0.11, 0.035, 0.12), Vector3.new(30.95 + (key - 1) * 0.19, 2.72, 26.1), Color3.fromRGB(124, 132, 134), Enum.Material.SmoothPlastic)
    end
    makeDetail("OfficeMouse", Vector3.new(0.26, 0.14, 0.4), Vector3.new(33.6, 2.64, 26.1), Color3.fromRGB(25, 29, 33), Enum.Material.SmoothPlastic)
    makeDetail("OfficeChairSeat", Vector3.new(2.2, 0.45, 2), Vector3.new(32, 1.75, 23.5), Color3.fromRGB(36, 43, 49), Enum.Material.Fabric)
    makeDetail("OfficeChairBack", Vector3.new(2, 2.4, 0.38), Vector3.new(32, 3, 22.7), Color3.fromRGB(31, 39, 45), Enum.Material.Fabric)
    makeDetail("OfficeChairPost", Vector3.new(0.25, 1.2, 0.25), Vector3.new(32, 1.1, 23.5), Color3.fromRGB(96, 104, 109), Enum.Material.Metal)
    for _, offset in ipairs({Vector3.new(-0.7, 0.3, -0.65), Vector3.new(0.7, 0.3, -0.65), Vector3.new(-0.7, 0.3, 0.65), Vector3.new(0.7, 0.3, 0.65)}) do
        makeDetail("OfficeChairLeg", Vector3.new(0.12, 0.5, 0.12), Vector3.new(32, 0.45, 23.5) + offset, Color3.fromRGB(83, 91, 97), Enum.Material.Metal)
    end
    local _, _, cabinetPart = makeFurnitureAssembly("OfficeFileCabinet", Vector3.new(38.6, 2.4, 14.3), Vector3.new(-1, 0, 0))
    cabinetPart("OfficeFileCabinet", Vector3.new(2.2, 4.2, 2.1), Vector3.new(0, 0, 0), Color3.fromRGB(68, 77, 83), Enum.Material.Metal, nil, true)
    for drawer = 0, 2 do
        local drawerY = -1.4 + drawer * 1.4
        cabinetPart("FileDrawer", Vector3.new(1.98, 1.22, 0.1), Vector3.new(0, drawerY, -1.105), Color3.fromRGB(102, 115, 122))
        cabinetPart("DrawerHandle", Vector3.new(0.65, 0.1, 0.14), Vector3.new(0, drawerY + 0.22, -1.23), Color3.fromRGB(180, 183, 174))
        cabinetPart("DrawerLabel", Vector3.new(0.55, 0.22, 0.025), Vector3.new(0, drawerY - 0.22, -1.171), Color3.fromRGB(220, 216, 196), Enum.Material.SmoothPlastic)
    end
    local mug = makeVerticalCylinder("CoffeeMug", 0.58, 0.68, Vector3.new(35.7, 2.95, 26.8), Color3.fromRGB(177, 179, 166), Enum.Material.SmoothPlastic)
    makeDetail("CoffeeSurface", Vector3.new(0.35, 0.025, 0.35), mug.Position + Vector3.new(0, 0.35, 0), Color3.fromRGB(42, 31, 24), Enum.Material.SmoothPlastic)
    addWayfinding("OfficeHelp", Vector3.new(23.15, 5.5, 18), 5.3, "КАМЕРЫ: E\nВЫХОД ИЗ ПРОСМОТРА: E", Vector3.new(1, 0, 0), Color3.fromRGB(46, 66, 72))

    -- Both wall-mounted safety assemblies face the usable interior side.
    for _, data in ipairs({
        {name = "FireSafetyWest", position = Vector3.new(-40.15, 2.6, 15), facing = Vector3.new(1, 0, 0)},
        {name = "FireSafetyEast", position = Vector3.new(40.15, 2.6, 3), facing = Vector3.new(-1, 0, 0)},
    }) do
        local safety, safetyFrame, safetyPart = makeFurnitureAssembly(data.name, data.position, data.facing)
        safetyPart("ExtinguisherWallBracket", Vector3.new(0.6, 1.55, 0.06), Vector3.new(0, 0, 0.33), Color3.fromRGB(63, 71, 78), Enum.Material.Metal, 0, false)
        local extinguisher = safetyPart("FireExtinguisher", Vector3.new(2.1, 0.72, 0.72), Vector3.new(0, 0, 0), Color3.fromRGB(143, 42, 34), Enum.Material.Metal, 0, false, CFrame.Angles(0, 0, math.rad(90)))
        extinguisher.Shape = Enum.PartType.Cylinder
        safetyPart("ExtinguisherLabel", Vector3.new(0.42, 0.65, 0.04), Vector3.new(0, 0, -0.38), Color3.fromRGB(223, 216, 194), Enum.Material.SmoothPlastic, 0, false)
        safetyPart("ExtinguisherHandle", Vector3.new(0.65, 0.12, 0.12), Vector3.new(0, 1.1, 0), Color3.fromRGB(35, 39, 42), Enum.Material.Metal, 0, false)
        safetyPart("AlarmCallPoint", Vector3.new(0.45, 0.55, 0.18), Vector3.new(0, 1.8, 0.25), Color3.fromRGB(151, 44, 37), Enum.Material.Metal, 0, false)
        safetyPart("AlarmCallPointFace", Vector3.new(0.32, 0.32, 0.02), Vector3.new(0, 1.8, 0.145), Color3.fromRGB(226, 218, 200), Enum.Material.SmoothPlastic, 0, false)
        safetyPart("AlarmCallPointButton", Vector3.new(0.13, 0.13, 0.035), Vector3.new(0, 1.8, 0.1175), Color3.fromRGB(159, 34, 31), Enum.Material.Metal, 0, false)
        safety:SetAttribute("WallFront", safetyFrame.LookVector)
    end

    -- Loading dock: roller shutter, dock bumpers, hazard stripes and stacked utility drums.
    -- Animated roller-shutter slats are created with the loading dock shell in addPremiumLocations().
    for _, x in ipairs({-22, 22}) do
        makeDetail("DockBumper", Vector3.new(1.1, 3.0, 0.8), Vector3.new(x, 1.7, -61), Color3.fromRGB(31, 36, 39), Enum.Material.Rubber)
        makeDetail("DockGuard", Vector3.new(0.35, 2.2, 0.35), Vector3.new(x, 1.4, -58.8), Color3.fromRGB(193, 145, 55), Enum.Material.Metal)
    end
    for _, pos in ipairs({Vector3.new(24, 1.1, -52), Vector3.new(25.8, 1.1, -52)}) do
        local drum = makeVerticalCylinder("IndustrialDrum", 1.35, 2.2, pos, Color3.fromRGB(62, 83, 88), Enum.Material.Metal)
        makeDetail("DrumRim", Vector3.new(1.42, 0.12, 1.42), pos + Vector3.new(0, 1.1, 0), Color3.fromRGB(132, 141, 140), Enum.Material.Metal)
    end

    -- Outdoor perimeter: concrete curbs, bollards, dumpster and weathered parking details.
    for _, x in ipairs({-78, 78}) do
        makeDetail("ParkingCurb", Vector3.new(1.2, 0.65, 92), Vector3.new(x, 0.0, 72), Color3.fromRGB(83, 87, 88), Enum.Material.Concrete)
        for z = 34, 108, 18 do
            local post = makeDetail("ParkingBollard", Vector3.new(0.72, 2.1, 0.72), Vector3.new(x - (x > 0 and 2 or -2), 1.0, z), Color3.fromRGB(91, 99, 101), Enum.Material.Metal)
            makeDetail("BollardReflector", Vector3.new(0.76, 0.22, 0.76), post.Position + Vector3.new(0, 0.45, 0), Color3.fromRGB(194, 153, 66), Enum.Material.Neon)
        end
    end
    for x = -12, 12, 6 do
        makeDetail("EntranceBollard", Vector3.new(0.65, 1.6, 0.65), Vector3.new(x, 0.8, 36), Color3.fromRGB(47, 55, 61), Enum.Material.Metal)
        makeDetail("EntranceBollardBand", Vector3.new(0.68, 0.18, 0.68), Vector3.new(x, 1.1, 36), Color3.fromRGB(193, 147, 57), Enum.Material.Metal)
    end

    addServiceDumpster("OutdoorDumpster", Vector3.new(55, 2.1, 2), Vector3.new(7.5, 4.2, 4.2), Color3.fromRGB(42, 70, 62), false)

    -- Broken puddles and grime patches catch the ceiling light without making the floor slippery.
    for i = 1, 16 do
        local x = rng:NextNumber(-37, 37)
        local z = rng:NextNumber(-27, 27)
        local puddle = makeDetail("FloorPuddle", Vector3.new(rng:NextNumber(1.1, 3.2), 0.018, rng:NextNumber(0.7, 1.8)), Vector3.new(x, 0.318, z), Color3.fromRGB(69, 78, 84), Enum.Material.Glass, 0.68)
        puddle.Reflectance = 0.18
    end
    for i = 1, 24 do
        local x = rng:NextNumber(-38, 38)
        local z = rng:NextNumber(-28, 28)
        local scuff = makeDetail("FloorScuff", Vector3.new(rng:NextNumber(0.45, 1.3), 0.012, rng:NextNumber(0.2, 0.55)), Vector3.new(x, 0.316, z), Color3.fromRGB(48, 53, 57), Enum.Material.SmoothPlastic, 0.35)
        scuff.Orientation = Vector3.new(0, rng:NextNumber(0, 180), 0)
    end

    -- Small practical details make the store feel staffed and used rather than like a grey blockout.
    for _, pos in ipairs({Vector3.new(-35, 0.8, 25), Vector3.new(35, 0.8, 25), Vector3.new(-39, 0.8, -29)}) do
        makeDetail("FloorSafetyMarking", Vector3.new(5.5, 0.025, 0.18), pos, Color3.fromRGB(185, 145, 59), Enum.Material.SmoothPlastic)
    end
    local wallClock = makeDetail("StaffClock", Vector3.new(0.18, 1.6, 1.6), Vector3.new(37.5, 8.5, 30.2), Color3.fromRGB(220, 217, 198), Enum.Material.SmoothPlastic)
    wallClock.Shape = Enum.PartType.Cylinder
    wallClock.Orientation = Vector3.new(0, 90, 0)
    makeDetail("ClockCenter", Vector3.new(0.16, 0.16, 0.04), wallClock.Position + Vector3.new(0, 0, -0.13), Color3.fromRGB(35, 39, 42), Enum.Material.Metal)
    makeDetail("ClockHandMinute", Vector3.new(0.06, 0.62, 0.04), wallClock.Position + Vector3.new(0, 0.25, -0.13), Color3.fromRGB(35, 39, 42), Enum.Material.Metal)
    makeDetail("ClockHandHour", Vector3.new(0.48, 0.06, 0.04), wallClock.Position + Vector3.new(-0.2, -0.04, -0.13), Color3.fromRGB(35, 39, 42), Enum.Material.Metal)

    world:SetAttribute("VisualVersion", "3.6")
end

local completeTask
local restoreHidden
local restoreLighting

local function toggleHide(player, locker)
    if player:GetAttribute("NightShiftDowned") then return end
    if player:GetAttribute("NightShiftHidden") then
        restoreHidden(player)
        notify(player, TEXT.hideOut)
        return
    end
    local character = player.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    local root = character and character:FindFirstChild("HumanoidRootPart")
    if not humanoid or humanoid.Health <= 0 or not root or not locker or not locker.Parent then return end
    local occupant = locker:GetAttribute("OccupiedBy")
    if occupant and occupant ~= player.UserId then notify(player, "Это укрытие уже занято."); return end
    local exitPosition = locker:GetAttribute("HideExit")
    local hidePosition = locker:GetAttribute("HidePosition")
    local saved = {
        character = character, root = root, locker = locker, anchored = root.Anchored,
        exitCFrame = typeof(exitPosition) == "Vector3" and CFrame.new(exitPosition) or root.CFrame,
        walkSpeed = humanoid.WalkSpeed, jumpPower = humanoid.JumpPower, jumpHeight = humanoid.JumpHeight,
        autoRotate = humanoid.AutoRotate, parts = {},
    }
    if threat then threat:OnHide(player, locker) end
    if campaign then campaign:DropItem(player, true) end
    if gameplay then gameplay:DropItem(player, true) end
    emitWorldSound("locker", locker.Position, "Закрывается укрытие")
    locker:SetAttribute("OccupiedBy", player.UserId)
    for _, item in ipairs(character:GetDescendants()) do
        if item:IsA("BasePart") then
            saved.parts[item] = {transparency = item.Transparency, canCollide = item.CanCollide}
            item.Transparency = 1
            item.CanCollide = false
        elseif item:IsA("Decal") then
            saved.parts[item] = {transparency = item.Transparency}
            item.Transparency = 1
        elseif item:IsA("Light") and (item.Name == "FlashlightBeam" or item.Name == "FlashlightFill" or item.Name == "FlashlightGlow") then
            item.Enabled = false
        end
    end
    hiddenState[player] = saved
    root.Anchored = true
    if typeof(hidePosition) == "Vector3" then character:PivotTo(CFrame.new(hidePosition)) end
    player:SetAttribute("NightShiftHidden", true)
    player:SetAttribute("NightShiftSprinting", false)
    humanoid.WalkSpeed = 0
    humanoid.JumpPower = 0
    humanoid.JumpHeight = 0
    humanoid.AutoRotate = false
    remote:FireClient(player, "FlashlightState", false)
    notify(player, TEXT.hideIn .. " Q — выйти.")
end

local addPremiumLocations
local function buildWorld()
    lights = {}
    originalLightColors = {}
    taskPrompts = {}
    doorControllers = {}
    local oldWorld = Workspace:FindFirstChild("NightShiftWorld")
    if oldWorld then oldWorld:Destroy() end
    local oldBaseplate = Workspace:FindFirstChild("Baseplate")
    if oldBaseplate and oldBaseplate:IsA("BasePart") then oldBaseplate:Destroy() end
    for _, existingSpawn in ipairs(Workspace:GetChildren()) do
        if existingSpawn:IsA("SpawnLocation") then existingSpawn:Destroy() end
    end
    world = Instance.new("Folder")
    world.Name = "NightShiftWorld"
    world.Parent = Workspace
    decorFolder = Instance.new("Folder")
    decorFolder.Name = "VisualOverhaul_3_6"
    decorFolder.Parent = world
    Lighting.ClockTime = 0.35
    pcall(function()
        Lighting.LightingStyle = Enum.LightingStyle.Realistic
        Lighting.PrioritizeLightingQuality = true
        Lighting.ExposureCompensation = -0.22
        Lighting.Technology = Enum.Technology.Future
    end)
    Lighting.EnvironmentDiffuseScale = 0.72
    Lighting.EnvironmentSpecularScale = 0.88
    Lighting.ShadowSoftness = 0.48
    Lighting.Brightness = 1.58
    Lighting.Ambient = Color3.fromRGB(29, 33, 42)
    Lighting.OutdoorAmbient = Color3.fromRGB(18, 22, 31)
    Lighting.FogColor = Color3.fromRGB(15, 19, 28)
    Lighting.FogStart = 88
    Lighting.FogEnd = 340
    Lighting.GlobalShadows = true
    local atmosphere = Lighting:FindFirstChild("NightShiftAtmosphere") or Instance.new("Atmosphere")
    atmosphere.Name = "NightShiftAtmosphere"
    atmosphere.Density = 0.17
    atmosphere.Offset = 0.025
    atmosphere.Color = Color3.fromRGB(137, 151, 171)
    atmosphere.Decay = Color3.fromRGB(19, 24, 34)
    atmosphere.Glare = 0.035
    atmosphere.Haze = 0.85
    atmosphere.Parent = Lighting
    colorEffect = Lighting:FindFirstChild("NightShiftColor") or Instance.new("ColorCorrectionEffect")
    colorEffect.Name = "NightShiftColor"
    colorEffect.Brightness = -0.015
    colorEffect.Contrast = 0.2
    colorEffect.Saturation = -0.07
    colorEffect.TintColor = Color3.fromRGB(204, 215, 231)
    colorEffect.Parent = Lighting
    local bloom = Lighting:FindFirstChild("NightShiftBloom") or Instance.new("BloomEffect")
    bloom.Name = "NightShiftBloom"
    bloom.Intensity = 0.048
    bloom.Size = 12
    bloom.Threshold = 2.15
    bloom.Parent = Lighting
    local sunRays = Lighting:FindFirstChild("NightShiftSunRays") or Instance.new("SunRaysEffect")
    sunRays.Name = "NightShiftSunRays"
    sunRays.Intensity = 0.008
    sunRays.Spread = 0.12
    sunRays.Parent = Lighting

    makePart("GroundFront", Vector3.new(220, 1, 203), Vector3.new(0, -1.05, 49.5), Color3.fromRGB(29, 34, 39), Enum.Material.Asphalt)
    makePart("GroundWest", Vector3.new(76, 1, 64), Vector3.new(-72, -1.05, -84), Color3.fromRGB(29, 34, 39), Enum.Material.Asphalt)
    makePart("GroundEast", Vector3.new(66, 1, 64), Vector3.new(77, -1.05, -84), Color3.fromRGB(29, 34, 39), Enum.Material.Asphalt)
    makePart("GroundRear", Vector3.new(78, 1, 6), Vector3.new(5, -1.05, -113), Color3.fromRGB(29, 34, 39), Enum.Material.Asphalt)
    -- Solid, visible site boundaries prevent accidental walks into the void.
    for _, x in ipairs({-109, 109}) do
        makePart("SiteBoundarySide", Vector3.new(1.4, 14, 267), Vector3.new(x, 6.45, 17.5), Color3.fromRGB(43, 53, 59), Enum.Material.Concrete)
    end
    for _, z in ipairs({-115, 150}) do
        makePart("SiteBoundaryEnd", Vector3.new(218, 14, 1.4), Vector3.new(0, 6.45, z), Color3.fromRGB(43, 53, 59), Enum.Material.Concrete)
    end
    -- Retaining walls protect the underground footprint; the loading bay has its own entrance.
    makePart("BasementRetainingWest", Vector3.new(1, 8, 62), Vector3.new(-34, 3.45, -83), Color3.fromRGB(42, 49, 54), Enum.Material.Concrete)
    makePart("BasementRetainingEast", Vector3.new(1, 8, 62), Vector3.new(44, 3.45, -83), Color3.fromRGB(42, 49, 54), Enum.Material.Concrete)
    makePart("BasementRetainingRear", Vector3.new(78, 8, 1), Vector3.new(5, 3.45, -110), Color3.fromRGB(42, 49, 54), Enum.Material.Concrete)
    makePart("BasementRetainingFrontWest", Vector3.new(5, 8, 1), Vector3.new(-31.5, 3.45, -52), Color3.fromRGB(42, 49, 54), Enum.Material.Concrete)
    makePart("BasementRetainingFrontEast", Vector3.new(15, 8, 1), Vector3.new(36.5, 3.45, -52), Color3.fromRGB(42, 49, 54), Enum.Material.Concrete)
    makePart("ParkingLot", Vector3.new(190, 0.35, 100), Vector3.new(0, -0.35, 74), Color3.fromRGB(38, 42, 48), Enum.Material.Asphalt)
    makePart("Road", Vector3.new(220, 0.4, 24), Vector3.new(0, -0.3, 137), Color3.fromRGB(29, 32, 38), Enum.Material.Asphalt)
    for x = -72, 72, 24 do
        makePart("ParkingLine", Vector3.new(0.22, 0.06, 23), Vector3.new(x, -0.13, 70), Color3.fromRGB(157, 151, 129), Enum.Material.SmoothPlastic)
    end
    for x = -95, 95, 19 do
        makePart("RoadDash", Vector3.new(9, 0.08, 0.5), Vector3.new(x, -0.06, 137), Color3.fromRGB(172, 164, 137), Enum.Material.SmoothPlastic)
    end
    addTree(-86, 28); addTree(88, 34); addTree(-93, 91); addTree(94, 95)
    addCar(-48, 71, Color3.fromRGB(63, 82, 104))
    addCar(49, 77, Color3.fromRGB(103, 65, 56))
    addParkingLamp("ParkingLampWest", Vector3.new(-78, 0, 63))
    addParkingLamp("ParkingLampEast", Vector3.new(76, 0, 84))

    makePart("StoreFloor", Vector3.new(84, 0.5, 64), Vector3.new(0, 0.05, 0), Color3.fromRGB(54, 58, 64), Enum.Material.Slate)
    -- NIGHT SHIFT 4.1 visual pass: layered retail architecture and detailed store fixtures.
    local wall = Color3.fromRGB(43, 49, 61)
    makePart("FloorBorderFront", Vector3.new(82, 0.08, 0.35), Vector3.new(0, 0.34, 31.2), Color3.fromRGB(135, 47, 42), Enum.Material.Metal)
    makePart("FloorBorderBack", Vector3.new(82, 0.08, 0.35), Vector3.new(0, 0.34, -31.2), Color3.fromRGB(135, 47, 42), Enum.Material.Metal)
    for x = -38, 38, 9.5 do
        makePart("TileJoint", Vector3.new(0.045, 0.012, 60), Vector3.new(x, 0.306, 0), Color3.fromRGB(24, 28, 34), Enum.Material.SmoothPlastic)
    end
    for z = -27, 27, 9 do
        makePart("TileJoint", Vector3.new(80, 0.012, 0.045), Vector3.new(0, 0.306, z), Color3.fromRGB(24, 28, 34), Enum.Material.SmoothPlastic)
    end
    for _, wear in ipairs({
        Vector3.new(-12, 0.315, 8), Vector3.new(9, 0.315, 9.5), Vector3.new(22, 0.315, -4),
        Vector3.new(-24, 0.315, -10), Vector3.new(-2, 0.315, -12), Vector3.new(15, 0.315, 2),
    }) do
        local scuff = makeDetail("FloorScuff", Vector3.new(2.8, 0.01, 1.4), wear, Color3.fromRGB(69, 73, 78), Enum.Material.SmoothPlastic, 0.45)
        scuff.Orientation = Vector3.new(0, math.random(0, 180), 0)
    end
    makePart("WallKickLeft", Vector3.new(0.18, 1.2, 62), Vector3.new(-40.88, 0.85, 0), Color3.fromRGB(92, 101, 110), Enum.Material.DiamondPlate)
    for _, z in ipairs({-17.75, 17.75}) do
        makeDetail("WallKickRight", Vector3.new(0.18, 1.2, 26.5), Vector3.new(40.88, 0.85, z), Color3.fromRGB(92, 101, 110), Enum.Material.DiamondPlate)
    end
    makePart("CeilingBeamA", Vector3.new(82, 0.7, 0.8), Vector3.new(0, 20.2, 5), Color3.fromRGB(36, 43, 52), Enum.Material.Metal)
    makePart("CeilingBeamB", Vector3.new(82, 0.7, 0.8), Vector3.new(0, 20.2, -18), Color3.fromRGB(36, 43, 52), Enum.Material.Metal)
    makePart("VentDuct", Vector3.new(5, 1.1, 47), Vector3.new(36, 19.2, -4), Color3.fromRGB(83, 91, 99), Enum.Material.Metal)
    for x = -31, 31, 31 do
        local vent = makePart("VentGrille", Vector3.new(4.2, 0.08, 0.12), Vector3.new(x, 18.55, -4), Color3.fromRGB(27, 32, 38), Enum.Material.Metal)
        vent.CanCollide = false
    end
    makePart("LeftWall", Vector3.new(2, 21, 64), Vector3.new(-42, 10.5, 0), wall, Enum.Material.Concrete)
    makePart("RightWallFront", Vector3.new(2, 21, 28), Vector3.new(42, 10.5, -18), wall, Enum.Material.Concrete)
    makePart("RightWallBack", Vector3.new(2, 21, 28), Vector3.new(42, 10.5, 18), wall, Enum.Material.Concrete)
    makePart("RightWallDoorHeader", Vector3.new(2, 8.1, 8), Vector3.new(42, 16.95, 0), wall, Enum.Material.Concrete)
    makeDetail("ServiceDoorLintel", Vector3.new(0.28, 0.3, 8.4), Vector3.new(40.82, 13.05, 0), Color3.fromRGB(110, 119, 124), Enum.Material.Metal)
    makePart("BackWallLeft", Vector3.new(32, 21, 2), Vector3.new(-26, 10.5, -32), wall, Enum.Material.Concrete)
    makePart("BackWallRight", Vector3.new(32, 21, 2), Vector3.new(26, 10.5, -32), wall, Enum.Material.Concrete)
    makePart("BackWallHeader", Vector3.new(20, 8, 2), Vector3.new(0, 17, -32), wall, Enum.Material.Concrete)
    -- The emergency exit is 8 studs wide; infill the unused 6-stud gaps on both sides.
    makePart("BackDoorInfillLeft", Vector3.new(6, 13, 2), Vector3.new(-7, 6.5, -32), wall, Enum.Material.Concrete)
    makePart("BackDoorInfillRight", Vector3.new(6, 13, 2), Vector3.new(7, 6.5, -32), wall, Enum.Material.Concrete)
    makePart("BackDoorOpeningHeader", Vector3.new(8, 3.1, 2), Vector3.new(0, 11.45, -32), wall, Enum.Material.Concrete)
    makeDetail("BackDoorFrameLeft", Vector3.new(0.28, 9.8, 0.28), Vector3.new(-4.12, 5.2, -30.88), Color3.fromRGB(112, 119, 122), Enum.Material.Metal)
    makeDetail("BackDoorFrameRight", Vector3.new(0.28, 9.8, 0.28), Vector3.new(4.12, 5.2, -30.88), Color3.fromRGB(112, 119, 122), Enum.Material.Metal)
    makeDetail("BackDoorLintel", Vector3.new(8.5, 0.3, 0.28), Vector3.new(0, 10.05, -30.88), Color3.fromRGB(112, 119, 122), Enum.Material.Metal)
    makePart("FrontWallLeft", Vector3.new(31, 21, 2), Vector3.new(-26.5, 10.5, 32), wall, Enum.Material.Concrete)
    makePart("FrontWallRight", Vector3.new(31, 21, 2), Vector3.new(26.5, 10.5, 32), wall, Enum.Material.Concrete)
    makePart("StorefrontUpperWall", Vector3.new(22, 6, 2), Vector3.new(0, 18, 32), wall, Enum.Material.Concrete)
    makePart("StorefrontDoorTransom", Vector3.new(8, 2.1, 0.24), Vector3.new(0, 13.95, 31.15), Color3.fromRGB(105, 147, 168), Enum.Material.Glass, world, 0.42)
    for _, x in ipairs({-7, 7}) do
        makePart("StorefrontWindowSill", Vector3.new(6, 0.7, 0.3), Vector3.new(x, 0.65, 31.15), Color3.fromRGB(74, 86, 96), Enum.Material.Metal)
    end
    makePart("RoofBack", Vector3.new(84, 1, 30), Vector3.new(0, 21, -17), Color3.fromRGB(33, 38, 48), Enum.Material.Metal)
    makePart("RoofSides", Vector3.new(84, 1, 12), Vector3.new(0, 21, 26), Color3.fromRGB(33, 38, 48), Enum.Material.Metal)
    -- Complete the previously missing centre roof span (RoofBack ends at Z=-2; RoofSides starts at Z=20).
    makePart("RoofCenter", Vector3.new(84, 1, 22), Vector3.new(0, 21, 9), Color3.fromRGB(33, 38, 48), Enum.Material.Metal)
    makePart("RoofInnerLiner", Vector3.new(82, 0.12, 21.5), Vector3.new(0, 20.42, 9), Color3.fromRGB(53, 61, 69), Enum.Material.Metal)
    makePart("StorefrontEdgeColumnWest", Vector3.new(1, 14.7, 1), Vector3.new(-10.5, 7.65, 31.2), Color3.fromRGB(83, 99, 110), Enum.Material.Metal)
    makePart("StorefrontEdgeColumnEast", Vector3.new(1, 14.7, 1), Vector3.new(10.5, 7.65, 31.2), Color3.fromRGB(83, 99, 110), Enum.Material.Metal)
    -- Full-height shopfront glazing and a clear, non-blocking double-door entrance.
    for _, x in ipairs({-7, 7}) do
        local pane = makePart("StorefrontWindow", Vector3.new(6, 14, 0.24), Vector3.new(x, 8, 31.15), Color3.fromRGB(105, 147, 168), Enum.Material.Glass, world, 0.42)
        pane.CanCollide = true
        pane.CanTouch = false
        makeDetail("StorefrontMullion", Vector3.new(0.12, 14, 0.32), Vector3.new(x - 2.85, 8, 31.0), Color3.fromRGB(109, 120, 128), Enum.Material.Metal)
        makeDetail("StorefrontMullion", Vector3.new(0.12, 14, 0.32), Vector3.new(x + 2.85, 8, 31.0), Color3.fromRGB(109, 120, 128), Enum.Material.Metal)
    end
    for _, x in ipairs({-2, 2}) do
        local doorPane = makePart(x < 0 and "EntranceGlassDoorLeft" or "EntranceGlassDoorRight", Vector3.new(3.9, 12.6, 0.18), Vector3.new(x, 6.6, 31.05), Color3.fromRGB(116, 158, 177), Enum.Material.Glass, world, 0.58)
        local edge = makeDetail("EntranceDoorEdge", Vector3.new(0.1, 12.6, 0.25), Vector3.new(x + (x < 0 and 1.9 or -1.9), 6.6, 31.05), Color3.fromRGB(112, 123, 130), Enum.Material.Metal)
        local handle = makeDetail("EntranceDoorHandle", Vector3.new(0.12, 1.6, 0.4), Vector3.new(x + (x < 0 and 1.5 or -1.5), 4.1, 31.05), Color3.fromRGB(185, 195, 199), Enum.Material.Metal)
        addDoorController(doorPane, doorPane.CFrame * CFrame.new(x < 0 and -4.1 or 4.1, 0, 0), "Вход в магазин", {Vector3.new(x, 3.5, 28.8), Vector3.new(x, 3.5, 33.1)}, {edge, handle}, {open = true, distance = 5})
    end
    makeDetail("EntranceDoorHeader", Vector3.new(8.3, 0.3, 0.42), Vector3.new(0, 13.05, 30.95), Color3.fromRGB(112, 123, 130), Enum.Material.Metal)
    makePart("EntryMat", Vector3.new(18, 0.12, 7), Vector3.new(0, 0.37, 27), Color3.fromRGB(42, 52, 60), Enum.Material.Fabric)

    local counter = makePart("CheckoutCounter", Vector3.new(18, 3.4, 4), Vector3.new(0, 2, 17), Color3.fromRGB(77, 55, 46), Enum.Material.WoodPlanks)
    makePart("CounterTop", Vector3.new(18.5, 0.35, 4.4), Vector3.new(0, 3.9, 17), Color3.fromRGB(127, 96, 72), Enum.Material.Wood)
    makeDetail("CheckoutToeKick", Vector3.new(17.8, 0.22, 3.8), Vector3.new(0, 0.28, 17.1), Color3.fromRGB(28, 32, 37), Enum.Material.Metal)
    for x = -6, 6, 12 do
        local till = makePart("CashRegister", Vector3.new(2.2, 1, 1.4), Vector3.new(x, 4.55, 16), Color3.fromRGB(30, 37, 47), Enum.Material.Metal)
        local screen = makePart("RegisterScreen", Vector3.new(1.7, 0.9, 0.12), Vector3.new(x, 5.05, 15.25), Color3.fromRGB(50, 170, 145), Enum.Material.Neon)
        screen.CanCollide = false
    end
    addCheckoutLane(1, -6, 17.95)
    addCheckoutLane(2, 6, 17.95)
    addBasketStack("BasketStackFront", Vector3.new(-11.8, 0.15, 21.8))
    addShoppingCart("CartFrontA", Vector3.new(13.5, 0.0, 22.5), -18)
    addShoppingCart("CartFrontB", Vector3.new(16.3, 0.0, 23.8), -8)
    addShelf("AisleLeft", Vector3.new(-25, 0, -1), 7, 4)
    addShelf("AisleCenter", Vector3.new(-8, 0, -6), 7, 4)
    addShelf("AisleRight", Vector3.new(10, 0, -6), 7, 4)
    addShelf("AisleFarRight", Vector3.new(13, 0, 6), 6.4, 4)
    addEndcapDisplay("EndcapA", Vector3.new(-20.8, 0, 3.8))
    addEndcapDisplay("EndcapB", Vector3.new(-3.8, 0, -1.2))
    addEndcapDisplay("EndcapC", Vector3.new(14.2, 0, -1.2))
    addEndcapDisplay("EndcapD", Vector3.new(17.6, 0, 8.5))
    addCeilingSign("CheckoutHeader", Vector3.new(0, 11.6, 12.3), "КАССЫ", Color3.fromRGB(104, 67, 50))
    addCeilingSign("StockHeader", Vector3.new(32, 11.2, 10), "ОХРАНА / ПЕРСОНАЛ", Color3.fromRGB(68, 102, 94))
    for _, signData in ipairs({
        {x = -25, label = "1  |  СНЕКИ", color = Color3.fromRGB(176, 91, 55)},
        {x = -8, label = "2  |  НАПИТКИ", color = Color3.fromRGB(58, 123, 153)},
        {x = 10, label = "3  |  БАКАЛЕЯ", color = Color3.fromRGB(126, 111, 65)},
        {x = 13, z = 7.3, label = "4  |  БЫТОВАЯ ХИМИЯ", color = Color3.fromRGB(71, 125, 91)},
    }) do
        local sign = makePart("AisleSign", Vector3.new(8, 1.35, 0.22), Vector3.new(signData.x, 10.6, signData.z or -2), signData.color, Enum.Material.Metal)
        sign.CanCollide = false
        addTextSign(sign, signData.label, Enum.NormalId.Front, Color3.fromRGB(246, 239, 220))
        addTextSign(sign, signData.label, Enum.NormalId.Back, Color3.fromRGB(246, 239, 220))
    end

    for i, x in ipairs({-34, -17, 13}) do
        addCooler("Cooler" .. i, x)
    end
    addPalletStack("PalletStackA", Vector3.new(-28, 0, -20), Color3.fromRGB(154, 106, 61))
    addPalletStack("PalletStackB", Vector3.new(-20, 0, -20), Color3.fromRGB(136, 95, 55))
    addPalletStack("PalletStackC", Vector3.new(38, 0, -8.5), Color3.fromRGB(118, 88, 55), Vector3.new(-1, 0, 0))

    -- Storage vestibule: a six-stud door and an unobstructed route to the generator.
    makePart("StockDividerBack", Vector3.new(1.2, 12, 28), Vector3.new(21, 6.3, -18), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("StockroomFrontWallLeft", Vector3.new(7, 12, 1), Vector3.new(24.5, 6.3, -4.2), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("StockroomFrontWallRight", Vector3.new(8, 12, 1), Vector3.new(38, 6.3, -4.2), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("StockroomDoorHeader", Vector3.new(6, 2, 1), Vector3.new(31, 11.3, -4.2), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("StockroomCeiling", Vector3.new(20.5, 0.55, 27.5), Vector3.new(31.5, 12.55, -18), Color3.fromRGB(35, 42, 50), Enum.Material.Metal)
    addLight(Vector3.new(31.5, 11.8, -8.5), 0.9, 16, Color3.fromRGB(198, 211, 219))
    makeDetail("StockroomDoorJambLeft", Vector3.new(0.18, 10, 0.25), Vector3.new(28, 5.3, -3.62), Color3.fromRGB(112, 119, 125), Enum.Material.Metal)
    makeDetail("StockroomDoorJambRight", Vector3.new(0.18, 10, 0.25), Vector3.new(34, 5.3, -3.62), Color3.fromRGB(112, 119, 125), Enum.Material.Metal)
    local stockDoor = makePart("StockroomDoor", Vector3.new(5.8, 9.9, 0.35), Vector3.new(31, 5.25, -3.55), Color3.fromRGB(66, 86, 91), Enum.Material.Metal)
    local stockHandle = makeDetail("StockroomDoorHandle", Vector3.new(0.16, 1.4, 0.3), Vector3.new(28.8, 4.2, -3.32), Color3.fromRGB(183, 190, 187), Enum.Material.Metal)
    addDoorController(stockDoor, stockDoor.CFrame * CFrame.new(6.9, 0, 0), "Склад", {Vector3.new(31, 4, -1.8), Vector3.new(31, 4, -6)}, {stockHandle})
    addWayfinding("StockroomSign", Vector3.new(31, 11, -3.57), 7.8, "СКЛАД  /  ГЕНЕРАТОРНАЯ", Vector3.new(0, 0, 1))
    makeDetail("StockDoorTrack", Vector3.new(13.3, 0.2, 0.3), Vector3.new(34.5, 10.35, -3.48), Color3.fromRGB(122, 133, 138), Enum.Material.Metal)
    for _, x in ipairs({29, 35}) do
        makeDetail("StockRouteMarking", Vector3.new(0.1, 0.02, 10), Vector3.new(x, 0.32, -9.5), Color3.fromRGB(197, 153, 66), Enum.Material.SmoothPlastic)
    end
    makePart("GeneratorRoomWestWall", Vector3.new(0.4, 11.5, 16), Vector3.new(21.8, 6.05, -23), Color3.fromRGB(45, 53, 61), Enum.Material.Concrete)
    makePart("GeneratorRoomEastWall", Vector3.new(0.4, 11.5, 16), Vector3.new(40.8, 6.05, -23), Color3.fromRGB(45, 53, 61), Enum.Material.Concrete)
    makePart("GeneratorRoomRearWall", Vector3.new(19.4, 11.5, 0.4), Vector3.new(31.3, 6.05, -31), Color3.fromRGB(45, 53, 61), Enum.Material.Concrete)
    makePart("GeneratorRoomFrontLeft", Vector3.new(6.4, 11.5, 0.6), Vector3.new(24.8, 6.05, -15), Color3.fromRGB(45, 53, 61), Enum.Material.Concrete)
    makePart("GeneratorRoomFrontRight", Vector3.new(5, 11.5, 0.6), Vector3.new(38.5, 6.05, -15), Color3.fromRGB(45, 53, 61), Enum.Material.Concrete)
    makePart("GeneratorRoomHeader", Vector3.new(8, 2.1, 0.6), Vector3.new(32, 10.65, -15), Color3.fromRGB(45, 53, 61), Enum.Material.Concrete)
    makePart("GeneratorRoomCeiling", Vector3.new(19.4, 0.45, 16), Vector3.new(31.3, 11.95, -23), Color3.fromRGB(34, 41, 49), Enum.Material.Metal)
    addLight(Vector3.new(32, 11.25, -21), 1.2, 19, Color3.fromRGB(204, 215, 216))
    makeDetail("GeneratorAlarmBeaconMount", Vector3.new(0.35, 1.0, 1.5), Vector3.new(35, 11.2, -22), Color3.fromRGB(76, 86, 91), Enum.Material.Metal)
    addRotatingAlarmBeacon("GeneratorAlarmBeacon", Vector3.new(35, 10.6, -22))
    generatorWarningBeacon = alarmBeacons[#alarmBeacons]
    addWayfinding("GeneratorRoomSign", Vector3.new(32, 10.4, -14.61), 7.6, "ГЕНЕРАТОРНАЯ", Vector3.new(0, 0, 1), Color3.fromRGB(90, 69, 44))
    makeDetail("GeneratorServiceMat", Vector3.new(7.2, 0.04, 3), Vector3.new(32, 0.33, -19), Color3.fromRGB(32, 39, 42), Enum.Material.DiamondPlate)
    for _, x in ipairs({27.5, 36.5}) do
        makeDetail("GeneratorSafetyLine", Vector3.new(0.12, 0.02, 8), Vector3.new(x, 0.32, -23), Color3.fromRGB(210, 164, 63), Enum.Material.SmoothPlastic)
    end
    makeDetail("GeneratorWallVent", Vector3.new(5.3, 2.1, 0.18), Vector3.new(32, 8.3, -30.68), Color3.fromRGB(27, 36, 41), Enum.Material.Metal)
    for i = 0, 7 do
        makeDetail("GeneratorVentLouvre", Vector3.new(5.1, 0.08, 0.15), Vector3.new(32, 7.4 + i * 0.25, -30.5), Color3.fromRGB(103, 119, 125), Enum.Material.Metal)
    end
    makeDetail("GeneratorExhaustRiser", Vector3.new(0.35, 6.5, 0.35), Vector3.new(35.8, 5.9, -27.8), Color3.fromRGB(99, 111, 119), Enum.Material.Metal)
    makeDetail("GeneratorCableTray", Vector3.new(0.55, 0.25, 12), Vector3.new(39.9, 9.9, -23), Color3.fromRGB(85, 97, 108), Enum.Material.Metal)
    addWayfinding("GeneratorSafetyPlate", Vector3.new(25, 5.9, -30.67), 4.3, "240 V  /  ОСТОРОЖНО", Vector3.new(0, 0, 1), Color3.fromRGB(130, 98, 44))
    makePart("OfficeDividerLeft", Vector3.new(5, 10, 1), Vector3.new(24.5, 5, 11), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("OfficeDividerRight", Vector3.new(5, 10, 1), Vector3.new(37.5, 5, 11), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("OfficeDoorHeader", Vector3.new(8, 1.8, 1), Vector3.new(31, 9, 11), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    -- Complete staff/security office: side walls, rear wall and a dedicated ceiling.
    makePart("OfficeWestWall", Vector3.new(1, 10, 20), Vector3.new(22.5, 5, 21), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("OfficeEastWall", Vector3.new(1, 10, 20), Vector3.new(40.5, 5, 21), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("OfficeRearWall", Vector3.new(18, 10, 1), Vector3.new(31.5, 5, 31), Color3.fromRGB(49, 55, 66), Enum.Material.Concrete)
    makePart("OfficeCeiling", Vector3.new(18, 0.6, 20), Vector3.new(31.5, 10.1, 21), Color3.fromRGB(36, 43, 51), Enum.Material.Metal)
    addLight(Vector3.new(32, 9.35, 21), 0.62, 14, Color3.fromRGB(190, 203, 215))
    makeDetail("OfficeDoorJambLeft", Vector3.new(0.22, 10, 0.28), Vector3.new(27.1, 5, 10.35), Color3.fromRGB(112, 119, 125), Enum.Material.Metal)
    makeDetail("OfficeDoorJambRight", Vector3.new(0.22, 10, 0.28), Vector3.new(34.9, 5, 10.35), Color3.fromRGB(112, 119, 125), Enum.Material.Metal)
    local officeSign = makePart("OfficeDoorSign", Vector3.new(6.8, 0.8, 0.16), Vector3.new(31, 9.2, 10.25), Color3.fromRGB(45, 83, 70), Enum.Material.Metal)
    officeSign.CanCollide = false
    addTextSign(officeSign, "ОХРАНА / STAFF ONLY", Enum.NormalId.Front, Color3.fromRGB(226, 240, 225))
    makePart("OfficeDesk", Vector3.new(10, 2, 3), Vector3.new(32, 1.5, 27), Color3.fromRGB(77, 59, 47), Enum.Material.Wood)
    local monitor = makePart("CCTVMonitor", Vector3.new(4, 2.6, 0.35), Vector3.new(32, 4, 27.6), Color3.fromRGB(26, 43, 48), Enum.Material.Metal)
    makeDetail("CCTVMonitorStand", Vector3.new(0.45, 0.6, 0.5), Vector3.new(32, 2.8, 27.6), Color3.fromRGB(40, 52, 57), Enum.Material.Metal)
    local monitorGlow = makeDetail("CCTVScreen", Vector3.new(3.6, 2.1, 0.08), Vector3.new(32, 4.05, 27.38), Color3.fromRGB(54, 155, 132), Enum.Material.Neon)
    addTextSign(monitorGlow, "CCTV  /  6 КАМЕР\nE — ПРОСМОТР", Enum.NormalId.Front, Color3.fromRGB(220, 255, 225))
    local _, _, cratePart = makeFurnitureAssembly("StockCrate", Vector3.new(24.4, 1.8, -8.5), Vector3.new(1, 0, 0))
    local crate = cratePart("StockCrate", Vector3.new(3.6, 3, 3.2), Vector3.new(0, 0, 0), Color3.fromRGB(125, 84, 48), Enum.Material.WoodPlanks, nil, true)
    for i = -1, 1 do
        cratePart("CrateSlat", Vector3.new(0.2, 2.7, 3.3), Vector3.new(i * 1.2, 0, 0), Color3.fromRGB(153, 108, 64), Enum.Material.Wood)
    end
    local crateLabel = cratePart("StockCrateLabel", Vector3.new(3.1, 1.05, 0.16), Vector3.new(0, 0.5, -1.74), Color3.fromRGB(109, 81, 45))
    addTextSign(crateLabel, "ТОВАР НА ПОЛКИ", Enum.NormalId.Front, Color3.fromRGB(235, 243, 223))
    -- Industrial backup generator: frame, acoustic housing, engine, radiator, exhaust and a readable control panel.
    local generator = makePart("Generator", Vector3.new(4.8, 2.55, 3.25), Vector3.new(32, 1.95, -23), Color3.fromRGB(54, 65, 73), Enum.Material.Metal)
    generator.Reflectance = 0.08
    makePart("GeneratorSkid", Vector3.new(5.25, 0.32, 3.8), Vector3.new(32, 0.53, -23), Color3.fromRGB(31, 38, 43), Enum.Material.DiamondPlate)
    for _, offset in ipairs({Vector3.new(-2.05, 0.28, -1.45), Vector3.new(2.05, 0.28, -1.45), Vector3.new(-2.05, 0.28, 1.45), Vector3.new(2.05, 0.28, 1.45)}) do
        makePart("GeneratorRubberMount", Vector3.new(0.52, 0.48, 0.52), Vector3.new(32, 0, -23) + offset, Color3.fromRGB(25, 29, 32), Enum.Material.Rubber)
    end
    makeDetail("GeneratorServicePanel", Vector3.new(2.0, 1.65, 0.12), Vector3.new(33.0, 2.15, -21.32), Color3.fromRGB(37, 47, 54), Enum.Material.Metal)
    local controlScreen = makeDetail("GeneratorControlScreen", Vector3.new(0.92, 0.52, 0.08), Vector3.new(33.0, 2.62, -21.22), Color3.fromRGB(74, 155, 137), Enum.Material.Glass)
    addTextSign(controlScreen, "GEN / 240V", Enum.NormalId.Back, Color3.fromRGB(210, 255, 232))
    for _, xOffset in ipairs({-0.55, 0.0, 0.55}) do
        local button = makeDetail("GeneratorControlButton", Vector3.new(0.12, 0.22, 0.22), Vector3.new(33.0 + xOffset, 1.82, -21.22), Color3.fromRGB(193, 55, 45), Enum.Material.Neon)
        button.Shape = Enum.PartType.Cylinder
        button.CFrame = CFrame.new(button.Position) * CFrame.Angles(0, math.rad(90), 0)
    end
    local genLamp = Instance.new("PointLight")
    genLamp.Color = Color3.fromRGB(255, 105, 65)
    genLamp.Brightness = 0.85
    genLamp.Range = 10
    genLamp.Parent = generator
    table.insert(lights, genLamp); originalLightColors[genLamp] = genLamp.Color
    local statusLamp = makeDetail("GeneratorStatusLamp", Vector3.new(0.22, 0.22, 0.12), Vector3.new(34.05, 2.75, -21.22), Color3.fromRGB(255, 65, 48), Enum.Material.Neon)
    statusLamp.Shape = Enum.PartType.Ball
    local statusLight = Instance.new("PointLight")
    statusLight.Color = Color3.fromRGB(255, 70, 48)
    statusLight.Brightness = 0.65
    statusLight.Range = 6
    statusLight.Parent = statusLamp
    table.insert(lights, statusLight); originalLightColors[statusLight] = statusLight.Color
    generatorStatusLamp = statusLamp
    generatorStatusLight = statusLight
    generatorWarningLight = genLamp
    -- Radiator grille and cooling fan housing.
    local generatorRadiator = makePart("GeneratorRadiator", Vector3.new(1.65, 1.75, 0.18), Vector3.new(29.55, 1.95, -21.27), Color3.fromRGB(26, 32, 37), Enum.Material.Metal)
    for i = 0, 7 do
        makeDetail("GeneratorRadiatorFin", Vector3.new(1.48, 0.055, 0.08), Vector3.new(29.55, 1.25 + i * 0.2, -21.14), Color3.fromRGB(103, 113, 119), Enum.Material.Metal)
    end
    local fanHub = makeDetail("GeneratorFanHub", Vector3.new(0.18, 0.46, 0.46), Vector3.new(29.55, 1.95, -21.12), Color3.fromRGB(127, 137, 142), Enum.Material.Metal)
    fanHub.Shape = Enum.PartType.Cylinder
    fanHub.CFrame = CFrame.new(fanHub.Position) * CFrame.Angles(0, math.rad(90), 0)
    for i = 0, 3 do
        local angle = math.rad(i * 90)
        local blade = makeDetail("GeneratorFanBlade", Vector3.new(0.16, 0.68, 0.08), Vector3.new(29.55 + math.cos(angle) * 0.34, 1.95 + math.sin(angle) * 0.34, -21.08), Color3.fromRGB(74, 83, 89), Enum.Material.Metal)
        blade.Orientation = Vector3.new(0, 0, i * 90)
    end
    -- Engine block and fuel hardware on the service side.
    local engineBlock = makeDetail("GeneratorEngineBlock", Vector3.new(1.8, 1.45, 1.45), Vector3.new(32.0, 2.05, -24.05), Color3.fromRGB(91, 99, 102), Enum.Material.Metal)
    for i = 0, 3 do
        local cylinder = makeDetail("GeneratorEngineCylinder", Vector3.new(0.82, 0.42, 0.42), Vector3.new(31.35 + i * 0.43, 2.55, -24.25), Color3.fromRGB(113, 119, 119), Enum.Material.Metal)
        cylinder.Shape = Enum.PartType.Cylinder
        cylinder.CFrame = CFrame.new(cylinder.Position) * CFrame.Angles(0, 0, math.rad(90))
    end
    local exhaust = makeDetail("GeneratorExhaust", Vector3.new(1.25, 0.22, 0.22), Vector3.new(33.9, 3.0, -24.2), Color3.fromRGB(112, 119, 122), Enum.Material.Metal)
    exhaust.Shape = Enum.PartType.Cylinder
    exhaust.CFrame = CFrame.new(exhaust.Position)
    local muffler = makeDetail("GeneratorMuffler", Vector3.new(0.95, 0.42, 0.42), Vector3.new(34.45, 3.0, -24.2), Color3.fromRGB(64, 72, 77), Enum.Material.Metal)
    muffler.Shape = Enum.PartType.Cylinder
    muffler.CFrame = CFrame.new(muffler.Position)
    makeDetail("GeneratorExhaustElbow", Vector3.new(1.05, 0.22, 0.22), Vector3.new(35.3, 3, -24.2), Color3.fromRGB(98, 111, 118), Enum.Material.Metal)
    makeDetail("GeneratorExhaustToRiser", Vector3.new(0.22, 0.22, 3.6), Vector3.new(35.8, 3, -26), Color3.fromRGB(98, 111, 118), Enum.Material.Metal)
    makeDetail("GeneratorFuelCap", Vector3.new(0.5, 0.16, 0.5), Vector3.new(33.6, 3.3, -23.4), Color3.fromRGB(172, 148, 92), Enum.Material.Metal)
    makeDetail("GeneratorWarningStripe", Vector3.new(0.12, 1.8, 0.04), Vector3.new(30.15, 1.95, -21.18), Color3.fromRGB(224, 169, 56), Enum.Material.Metal)
    for _, boltOffset in ipairs({Vector3.new(-1.8, 1.0, -1.64), Vector3.new(1.8, 1.0, -1.64), Vector3.new(-1.8, 2.9, -1.64), Vector3.new(1.8, 2.9, -1.64)}) do
        local bolt = makeDetail("GeneratorBolt", Vector3.new(0.14, 0.14, 0.08), Vector3.new(32, 0, -23) + boltOffset, Color3.fromRGB(166, 174, 177), Enum.Material.Metal)
        bolt.Shape = Enum.PartType.Ball
    end
    makePart("GeneratorVent", Vector3.new(3.8, 0.12, 1.25), Vector3.new(32, 3.28, -23), Color3.fromRGB(30, 34, 39), Enum.Material.Metal)
    for i = 0, 8 do
        makeDetail("GeneratorTopVentSlat", Vector3.new(0.08, 0.07, 1.12), Vector3.new(30.35 + i * 0.41, 3.39, -23), Color3.fromRGB(119, 127, 131), Enum.Material.Metal)
    end

    local backDoor = makePart("BackDoor", Vector3.new(7.8, 9.6, 0.4), Vector3.new(0, 5.1, -30.65), Color3.fromRGB(61, 81, 77), Enum.Material.Metal)
    local backDoorHandle = makeDetail("DoorHandle", Vector3.new(2.8, 0.18, 0.24), Vector3.new(1.1, 4.2, -30.3), Color3.fromRGB(194, 185, 144), Enum.Material.Metal)
    local backDoorController = addDoorController(backDoor, CFrame.new(-3.9, 5.1, -30.65) * CFrame.Angles(0, math.rad(-90), 0) * CFrame.new(3.9, 0, 0), "Задний выход", {Vector3.new(2.7, 4.2, -28.6), Vector3.new(2.7, 4.2, -33.7)}, {backDoorHandle}, {open = true, key = Enum.KeyCode.R, gamepad = Enum.KeyCode.ButtonY})
    addWayfinding("ExitSign", Vector3.new(0, 10.75, -30.9), 7.4, "ПОГРУЗКА  /  ПОДВАЛ B1", Vector3.new(0, 0, 1), Color3.fromRGB(30, 105, 76))
    addWayfinding("ExitReturnSign", Vector3.new(0, 10.75, -33.84), 7.4, "МАГАЗИН  /  ВЫХОД", Vector3.new(0, 0, -1))
    for _, x in ipairs({-39, 39}) do
        local warning = makePart("HazardStripe", Vector3.new(0.16, 9, 0.08), Vector3.new(x, 5.5, 25), Color3.fromRGB(195, 151, 65), Enum.Material.Metal)
        warning.CanCollide = false
    end
    local trash = makePart("TrashBin", Vector3.new(4, 4, 4), Vector3.new(-35, 2.2, 18), Color3.fromRGB(46, 71, 65), Enum.Material.Metal)
    makePart("TrashLid", Vector3.new(4.4, 0.35, 4.3), Vector3.new(-35, 4.35, 18), Color3.fromRGB(31, 48, 43), Enum.Material.Metal)

    -- Hiding places sit against walls, outside all through routes and doorway approaches.
    for index, data in ipairs({
        {position = Vector3.new(-38.8, 3.9, 6), exit = Vector3.new(-34.7, 3.3, 6)},
        {position = Vector3.new(-38.8, 3.9, -8), exit = Vector3.new(-34.7, 3.3, -8)},
        {position = Vector3.new(25, 3.9, 28.7), exit = Vector3.new(25, 3.3, 24.3)},
        {position = Vector3.new(26.8, 3.9, -42), exit = Vector3.new(22.5, 3.3, -42)},
    }) do
        local locker = makePart("HideLocker" .. index, Vector3.new(3.6, 7.2, 2.4), data.position, Color3.fromRGB(54, 68, 79), Enum.Material.Metal)
        local target = Vector3.new(data.exit.X, data.position.Y, data.exit.Z)
        locker.CFrame = CFrame.lookAt(data.position, target)
        locker:SetAttribute("HidePosition", Vector3.new(data.position.X, 3.3, data.position.Z))
        locker:SetAttribute("HideExit", data.exit)
        locker:SetAttribute("LockerId", "Locker" .. index)
        local door = makeDetail("LockerDoor", Vector3.new(3.3, 6.85, 0.12), data.position, Color3.fromRGB(74, 91, 103), Enum.Material.Metal)
        door.CFrame = locker.CFrame * CFrame.new(0, 0, -1.25)
        local handle = makeDetail("LockerHandle", Vector3.new(0.16, 0.9, 0.18), data.position, Color3.fromRGB(190, 170, 130), Enum.Material.Metal)
        handle.CFrame = locker.CFrame * CFrame.new(1, -0.4, -1.39)
        for y = 1.5, 2.2, 0.23 do
            local vent = makeDetail("LockerVent", Vector3.new(1.7, 0.06, 0.04), data.position, Color3.fromRGB(27, 38, 43), Enum.Material.Metal)
            vent.CFrame = locker.CFrame * CFrame.new(0, y, -1.34)
        end
        local anchor = makeDetail("LockerPrompt" .. index, Vector3.new(0.2, 0.2, 0.2), data.position, Color3.fromRGB(0, 0, 0), Enum.Material.SmoothPlastic, 1)
        anchor.CFrame = locker.CFrame * CFrame.new(0, -0.5, -1.45)
        addPrompt(anchor, "Спрятаться / выйти", "Укрытие " .. index, 0.35, function(player) toggleHide(player, locker) end, {allowHidden = true, lineOfSight = false, enforceLineOfSight = true, distance = 5.5})
        addTextSign(door, "УКРЫТИЕ", Enum.NormalId.Front, Color3.fromRGB(199, 222, 210))
    end

    local neonSign = makePart("NeonSign", Vector3.new(24, 3, 0.5), Vector3.new(0, 17, 35), Color3.fromRGB(255, 102, 65), Enum.Material.Neon)
    neonSign.CanCollide = false
    addTextSign(neonSign, "NIGHT SHIFT", Enum.NormalId.Back, Color3.fromRGB(255, 244, 220))
    local insideSign = makePart("InsideSign", Vector3.new(16, 1.5, 0.25), Vector3.new(0, 14, 24), Color3.fromRGB(40, 100, 100), Enum.Material.Neon)
    insideSign.CanCollide = false
    addTextSign(insideSign, "OPEN 24 HOURS", Enum.NormalId.Front, Color3.fromRGB(210, 255, 238))
    addTextSign(insideSign, "OPEN 24 HOURS", Enum.NormalId.Back, Color3.fromRGB(210, 255, 238))

    addLight(Vector3.new(-27, 19.2, 12), 0.92, 24)
    addLight(Vector3.new(-8, 19.2, 12), 0.96, 25)
    addLight(Vector3.new(12, 19.2, 12), 0.96, 25)
    addLight(Vector3.new(29, 19.2, 12), 0.86, 23)
    addLight(Vector3.new(-25, 19.2, -14), 0.84, 22)
    addLight(Vector3.new(0, 19.2, -14), 0.8, 21)
    addLight(Vector3.new(30, 19.2, -14), 0.7, 20)

    -- Loading bay: level thresholds, a continuous floor, and a shaft open along its full length.
    makePart("LoadingBayThreshold", Vector3.new(10, 0.5, 4), Vector3.new(0, 0.05, -33), Color3.fromRGB(63, 72, 76), Enum.Material.DiamondPlate)
    makePart("LoadingBayFloorLeft", Vector3.new(32, 0.6, 29), Vector3.new(-13, 0, -47.5), Color3.fromRGB(43, 48, 53), Enum.Material.Concrete)
    makePart("LoadingBayFloorRight", Vector3.new(18, 0.6, 29), Vector3.new(20, 0, -47.5), Color3.fromRGB(43, 48, 53), Enum.Material.Concrete)
    makePart("LoadingBayFloorFront", Vector3.new(8, 0.6, 21), Vector3.new(7, 0, -43.5), Color3.fromRGB(43, 48, 53), Enum.Material.Concrete)
    makePart("LoadingBayWallLeft", Vector3.new(1, 11, 30), Vector3.new(-29, 5.8, -47), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayWallRight", Vector3.new(1, 11, 30), Vector3.new(29, 5.8, -47), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayFrontWest", Vector3.new(25, 11, 0.7), Vector3.new(-16.5, 5.8, -33.4), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayFrontEast", Vector3.new(25, 11, 0.7), Vector3.new(16.5, 5.8, -33.4), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayFrontHeader", Vector3.new(8, 1.3, 0.7), Vector3.new(0, 10.65, -33.4), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayRearWallLeft", Vector3.new(8.5, 11, 1), Vector3.new(-24.75, 5.8, -62), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayRearWallMiddle", Vector3.new(6, 11, 1), Vector3.new(-0.5, 5.8, -62), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayRearWallRight", Vector3.new(6.5, 11, 1), Vector3.new(14.75, 5.8, -62), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayYardDoorRight", Vector3.new(4, 11, 1), Vector3.new(27, 5.8, -62), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayYardDoorHeader", Vector3.new(7, 2, 1), Vector3.new(21.5, 10.3, -62), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    addWayfinding("YardAccessSign", Vector3.new(21.5, 10.1, -61.4), 6.5, "ТЕХНИЧЕСКИЙ ДВОР", Vector3.new(0, 0, 1))
    makePart("LoadingBayStairHeader", Vector3.new(9, 1.2, 1), Vector3.new(7, 10.7, -62), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayRearLintel", Vector3.new(17, 1.4, 1), Vector3.new(-12, 10.6, -62), Color3.fromRGB(45, 51, 60), Enum.Material.Concrete)
    makePart("LoadingBayRoof", Vector3.new(58, 0.8, 30), Vector3.new(0, 11.7, -47), Color3.fromRGB(32, 38, 46), Enum.Material.Metal)
    addLight(Vector3.new(-12, 10.85, -47), 1.0, 21, Color3.fromRGB(181, 199, 215))
    addLight(Vector3.new(17, 10.85, -47), 0.9, 18, Color3.fromRGB(181, 199, 215))
    makeDetail("LoadingBayBeaconMount", Vector3.new(0.35, 1.2, 1.5), Vector3.new(7, 10.7, -47), Color3.fromRGB(76, 86, 91), Enum.Material.Metal)
    addRotatingAlarmBeacon("LoadingBayAlarmBeacon", Vector3.new(7, 10.0, -47))
    makePart("LoadingYardApronLeft", Vector3.new(34, 0.6, 18), Vector3.new(-14, 0, -71), Color3.fromRGB(39, 44, 49), Enum.Material.Asphalt)
    makePart("LoadingYardApronRight", Vector3.new(20, 0.6, 18), Vector3.new(21, 0, -71), Color3.fromRGB(39, 44, 49), Enum.Material.Asphalt)
    for _, x in ipairs({-30.5, 30.5}) do
        makePart("LoadingYardSideBarrier", Vector3.new(1, 7, 18), Vector3.new(x, 3.8, -71), Color3.fromRGB(49, 62, 65), Enum.Material.Metal)
    end
    makePart("LoadingYardRearBarrierLeft", Vector3.new(22, 7, 1), Vector3.new(-20, 3.8, -80), Color3.fromRGB(49, 62, 65), Enum.Material.Metal)
    makePart("LoadingYardRearBarrierRight", Vector3.new(22, 7, 1), Vector3.new(20, 3.8, -80), Color3.fromRGB(49, 62, 65), Enum.Material.Metal)
    local outerGate = makePart("LoadingYardOuterGate", Vector3.new(17.5, 6.5, 0.35), Vector3.new(0, 3.55, -80.3), Color3.fromRGB(55, 66, 72), Enum.Material.Metal)
    local outerGateSlats = {}
    for y = 0.55, 6.1, 0.55 do
        table.insert(outerGateSlats, makeDetail("LoadingYardGateSlat", Vector3.new(17.2, 0.08, 0.08), Vector3.new(0, y, -80.08), Color3.fromRGB(115, 126, 130), Enum.Material.Metal))
    end
    addDoorController(outerGate, outerGate.CFrame * CFrame.new(0, 7.3, 0), "Задний выезд", {Vector3.new(-9.5, 2.5, -78.2), Vector3.new(9.5, 2.5, -78.2)}, outerGateSlats, {duration = 1.25, distance = 7, open = true})
    local loadingDoor = makePart("LoadingDockShutter", Vector3.new(16.8, 9.6, 0.35), Vector3.new(-12, 5.1, -62.58), Color3.fromRGB(57, 65, 72), Enum.Material.Metal)
    local shutterSlats = {}
    for y = 0.8, 9.4, 0.72 do
        local slat = makeDetail("LoadingDockShutterSlat", Vector3.new(16.5, 0.1, 0.08), Vector3.new(-12, y, -62.36), Color3.fromRGB(102, 111, 117), Enum.Material.Metal)
        table.insert(shutterSlats, slat)
    end
    addDoorController(loadingDoor, loadingDoor.CFrame * CFrame.new(0, 10.2, 0), "Погрузочные ворота", {Vector3.new(-12, 3.8, -60.5), Vector3.new(-12, 3.8, -64.7)}, shutterSlats, {duration = 1.1})
    -- The outer dock continues beyond the shutter: a proper rear delivery yard,
    -- not an abrupt empty plane. A clear central lane remains traversable.
    makePart("LoadingOuterYardFloor", Vector3.new(60, 0.45, 31), Vector3.new(0, 0.075, -96), Color3.fromRGB(42, 48, 53), Enum.Material.Asphalt)
    makePart("LoadingOuterYardKerbLeft", Vector3.new(0.5, 0.34, 30), Vector3.new(-30, 0.08, -96), Color3.fromRGB(83, 91, 94), Enum.Material.Concrete)
    makePart("LoadingOuterYardKerbRight", Vector3.new(0.5, 0.34, 30), Vector3.new(30, 0.08, -96), Color3.fromRGB(83, 91, 94), Enum.Material.Concrete)
    for _, x in ipairs({-25, -19, 19, 25}) do
        makeDetail("LoadingOuterYardLaneStripe", Vector3.new(0.12, 0.025, 23), Vector3.new(x, 0.32, -96), Color3.fromRGB(204, 159, 67), Enum.Material.Neon)
    end
    for _, z in ipairs({-108}) do
        makePart("LoadingOuterYardFenceRail", Vector3.new(59, 0.12, 0.12), Vector3.new(0, 4.3, z), Color3.fromRGB(100, 111, 117), Enum.Material.Metal)
        makePart("LoadingOuterYardFenceRail", Vector3.new(59, 0.12, 0.12), Vector3.new(0, 1.0, z), Color3.fromRGB(100, 111, 117), Enum.Material.Metal)
        for x = -29, 29, 4 do
            makePart("LoadingOuterYardFencePost", Vector3.new(0.16, 5.8, 0.16), Vector3.new(x, 2.7, z), Color3.fromRGB(88, 99, 105), Enum.Material.Metal)
        end
    end
    for _, x in ipairs({-29.5, 29.5}) do
        makePart("LoadingOuterYardSideFenceRail", Vector3.new(0.12, 0.12, 30), Vector3.new(x, 4.3, -96), Color3.fromRGB(100, 111, 117), Enum.Material.Metal)
        makePart("LoadingOuterYardSideFenceRail", Vector3.new(0.12, 0.12, 30), Vector3.new(x, 1.0, -96), Color3.fromRGB(100, 111, 117), Enum.Material.Metal)
        for z = -82, -108, -4 do
            makePart("LoadingOuterYardSideFencePost", Vector3.new(0.16, 5.8, 0.16), Vector3.new(x, 2.7, z), Color3.fromRGB(88, 99, 105), Enum.Material.Metal)
        end
    end
    -- Parked delivery trailer to the west, leaving the centre route clear.
    local trailer = makePart("LoadingDeliveryTrailer", Vector3.new(12.5, 6.2, 18), Vector3.new(-21.5, 3.4, -96), Color3.fromRGB(62, 73, 79), Enum.Material.Metal)
    makeDetail("LoadingTrailerRoof", Vector3.new(12.8, 0.22, 18.3), trailer.Position + Vector3.new(0, 3.18, 0), Color3.fromRGB(91, 103, 109), Enum.Material.Metal)
    for _, z in ipairs({-103, -97, -91}) do
        makeDetail("LoadingTrailerRib", Vector3.new(12.2, 0.1, 0.08), Vector3.new(-21.5, 3.25, z), Color3.fromRGB(118, 128, 132), Enum.Material.Metal)
    end
    local trailerDoor = makeDetail("LoadingTrailerRearDoor", Vector3.new(0.12, 5.5, 5.8), Vector3.new(-15.15, 3.3, -96), Color3.fromRGB(43, 52, 59), Enum.Material.Metal)
    for _, x in ipairs({-28.1, -14.9}) do
        local wheel = makeDetail("LoadingTrailerWheel", Vector3.new(0.72, 1.6, 1.6), Vector3.new(x, 1.1, -101.5), Color3.fromRGB(18, 21, 24), Enum.Material.Rubber)
        wheel.Shape = Enum.PartType.Cylinder
        local wheel2 = makeDetail("LoadingTrailerWheel", Vector3.new(0.72, 1.6, 1.6), Vector3.new(x, 1.1, -90.5), Color3.fromRGB(18, 21, 24), Enum.Material.Rubber)
        wheel2.Shape = Enum.PartType.Cylinder
    end
    local trailerLabel = makeDetail("LoadingTrailerLogo", Vector3.new(0.12, 1.4, 5.5), Vector3.new(-15.12, 4.0, -96), Color3.fromRGB(37, 56, 63), Enum.Material.Metal)
    addTextSign(trailerLabel, "NIGHTMART\nЛОГИСТИКА", Enum.NormalId.Left, Color3.fromRGB(224, 232, 220))
    -- Right-side utility cage, stacked freight and a service cabinet.
    local cage = makePart("LoadingFreightCage", Vector3.new(8.5, 4.2, 5.2), Vector3.new(21.3, 2.4, -88.8), Color3.fromRGB(54, 67, 72), Enum.Material.Metal)
    cage.Transparency = 0.12
    for x = 17.2, 25.4, 1.1 do makeDetail("LoadingFreightCageBar", Vector3.new(0.07, 4.1, 0.07), Vector3.new(x, 2.4, -86.1), Color3.fromRGB(130, 139, 139), Enum.Material.Metal) end
    for y = 0.7, 4.3, 0.8 do makeDetail("LoadingFreightCageRail", Vector3.new(8.4, 0.07, 0.07), Vector3.new(21.3, y, -86.1), Color3.fromRGB(130, 139, 139), Enum.Material.Metal) end
    for i = 0, 2 do
        local crate = makePart("LoadingOuterCrate", Vector3.new(2.3, 2.1, 2.3), Vector3.new(18.2 + i * 2.4, 1.35, -98.5), i % 2 == 0 and Color3.fromRGB(117, 85, 54) or Color3.fromRGB(80, 91, 96), Enum.Material.WoodPlanks)
        makeDetail("LoadingOuterCrateBand", Vector3.new(2.32, 0.12, 0.08), crate.Position + Vector3.new(0, 0, -1.17), Color3.fromRGB(164, 132, 82), Enum.Material.Metal)
    end
    local yardCabinet = makePart("LoadingOuterPowerCabinet", Vector3.new(2.5, 4.6, 1.3), Vector3.new(27, 2.6, -103.5), Color3.fromRGB(48, 60, 66), Enum.Material.Metal)
    local yardLabel = makeDetail("LoadingOuterPowerLabel", Vector3.new(0.1, 1.1, 1.8), yardCabinet.Position + Vector3.new(-1.3, 0.5, 0), Color3.fromRGB(38, 47, 52), Enum.Material.Metal)
    addTextSign(yardLabel, "ЩИТ\nB-OUT", Enum.NormalId.Left, Color3.fromRGB(230, 216, 177))
    -- Drain grates, oil stains and rain puddles add scale without blocking movement.
    makeDetail("LoadingOuterDrain", Vector3.new(8, 0.035, 0.75), Vector3.new(3, 0.32, -105), Color3.fromRGB(27, 32, 36), Enum.Material.DiamondPlate)
    for i = 0, 9 do makeDetail("LoadingOuterDrainSlot", Vector3.new(0.08, 0.02, 0.62), Vector3.new(-0.5 + i * 0.75, 0.34, -105), Color3.fromRGB(129, 137, 137), Enum.Material.Metal) end
    for i = 0, 4 do
        local puddle = makeDetail("LoadingOuterPuddle", Vector3.new(2.1 + (i % 2), 0.018, 0.7 + (i % 3) * 0.18), Vector3.new(3 + i * 4.1, 0.33, -91 + (i % 2) * 4), Color3.fromRGB(56, 73, 83), Enum.Material.Glass, 0.38)
        puddle.Reflectance = 0.28
    end
    local outerFloodlight = makeDetail("LoadingOuterFloodlight", Vector3.new(1.2, 0.4, 0.7), Vector3.new(27.2, 6.4, -107.1), Color3.fromRGB(188, 204, 211), Enum.Material.Metal)
    local outerLight = Instance.new("PointLight")
    outerLight.Color = Color3.fromRGB(175, 202, 218); outerLight.Brightness = 1.35; outerLight.Range = 25; outerLight.Shadows = true; outerLight.Parent = outerFloodlight
    makeDetail("LoadingOuterBeaconPost", Vector3.new(0.2, 4.4, 0.2), Vector3.new(4, 3.9, -107.1), Color3.fromRGB(82, 91, 96), Enum.Material.Metal)
    addRotatingAlarmBeacon("LoadingOuterYardAlarmBeacon", Vector3.new(4, 6.1, -107.1))
    addWayfinding("LoadingOuterYardSign", Vector3.new(0, 6.8, -106.7), 7.2, "ЗАДНИЙ ДВОР\nВЫЕЗД / B-OUT", Vector3.new(0, 0, 1), Color3.fromRGB(44, 76, 68))
    addWayfinding("BasementEntranceSign", Vector3.new(3.09, 4.2, -55.9), 3.4, "ПОДВАЛ B1  /  СПУСК", Vector3.new(1, 0, 0), Color3.fromRGB(103, 83, 48))
    addWayfinding("LoadingReturnSign", Vector3.new(-7, 5.8, -33.84), 4.5, "МАГАЗИН  /  ВЫХОД", Vector3.new(0, 0, -1))
    -- A compact information plate sits beside the door; the lintel carries the exit sign.
    local dockSign = makePart("LoadingBaySign", Vector3.new(5.8, 1.15, 0.16), Vector3.new(8.2, 5.8, -33.84), Color3.fromRGB(46, 65, 73), Enum.Material.Metal)
    dockSign.CanCollide = false
    addTextSign(dockSign, "ПОГРУЗОЧНАЯ\nСЛУЖЕБНАЯ ЗОНА", Enum.NormalId.Front, Color3.fromRGB(210, 235, 226))
    for _, pos in ipairs({Vector3.new(-18, 0.15, -53), Vector3.new(17, 0.15, -54)}) do
        local assembly, frame, p = makeFurnitureAssembly("LoadingPallet", pos, Vector3.new(0, 0, 1))
        p("WoodPallet", Vector3.new(8, 0.45, 5), Vector3.new(0, 0, 0), Color3.fromRGB(108, 75, 48), Enum.Material.WoodPlanks, nil, true)
        for plank = 1, 4 do
            p("PalletSlat", Vector3.new(0.22, 0.35, 5.2), Vector3.new(-3 + plank * 1.7, 0.32, 0), Color3.fromRGB(145, 102, 63), Enum.Material.Wood, nil, true)
        end
        p("ShippingCarton", Vector3.new(3.2, 3.1, 3.2), Vector3.new(0, 1.95, 0), Color3.fromRGB(126, 91, 58), Enum.Material.Cardboard, nil, true)
        local label = p("CartonLabel", Vector3.new(1.5, 0.9, 0.04), Vector3.new(0, 1.95, -1.63), Color3.fromRGB(215, 205, 177), Enum.Material.SmoothPlastic, nil, false)
        addTextSign(label, "NIGHTMART", Enum.NormalId.Front, Color3.fromRGB(50, 48, 43))
    end
    local redBeacon = makePart("LoadingBeacon", Vector3.new(0.8, 0.8, 0.8), Vector3.new(25, 9.5, -35), Color3.fromRGB(255, 45, 38), Enum.Material.Neon)
    redBeacon.Shape = Enum.PartType.Ball
    redBeacon.CanCollide = false
    local beaconLight = Instance.new("PointLight")
    beaconLight.Color = Color3.fromRGB(255, 42, 32)
    beaconLight.Brightness = 1.6
    beaconLight.Range = 18
    beaconLight.Parent = redBeacon
    table.insert(lights, beaconLight); originalLightColors[beaconLight] = beaconLight.Color
    for _, x in ipairs({-65, 65}) do
        local pole = makePart("ParkingLampPole", Vector3.new(0.7, 16, 0.7), Vector3.new(x, 8, 56), Color3.fromRGB(44, 50, 58), Enum.Material.Metal)
        local head = makePart("ParkingLampHead", Vector3.new(5, 0.5, 2), Vector3.new(x, 16, 56), Color3.fromRGB(170, 191, 210), Enum.Material.Metal)
        local lamp = Instance.new("PointLight")
        lamp.Color = Color3.fromRGB(178, 202, 255)
        lamp.Brightness = 1.8
        lamp.Range = 34
        lamp.Parent = head
        table.insert(lights, lamp); originalLightColors[lamp] = lamp.Color
    end

    addVisualOverhaul()
    addPremiumLocations()

    local spawn = Instance.new("SpawnLocation")
    spawn.Name = "NightShiftSpawn"
    spawn.Size = Vector3.new(6, 0.2, 5)
    spawn.Position = Vector3.new(0, 0.35, 25)
    spawn.Anchored = true
    spawn.Transparency = 1
    spawn.CanCollide = false
    spawn.Neutral = true
    spawn.Duration = 0
    spawn.Parent = world

    taskPrompts.restock = addPrompt(crate, TEXT.actionRestock, TEXT.objCrate, 1.4, function(player) if gameplay then gameplay:Interact(player, "restock") end end)
    taskPrompts.generator = addPrompt(generator, TEXT.actionRepair, TEXT.objGenerator, 2.4, function(player)
        if gameplay then gameplay:Interact(player, "generator") end
    end)
    taskPrompts.generatorOverheatGuide = addPrompt(controlScreen, "Показать инструкцию", "Перегрев генератора", 0.2, function(player)
        if not generatorOverheatActive or generatorOverheatStage ~= 0 then return end
        remote:FireClient(player, "GeneratorOverheatGuide", {
            title = "ПЕРЕГРЕВ ГЕНЕРАТОРА",
            summary = "Температура двигателя превысила норму. Не запускай его повторно, пока не восстановишь охлаждение.",
            steps = {
                "Останови двигатель на панели генератора.",
                "Очисти решётку радиатора от пыли и мусора.",
                "Подожди, пока система охлаждения сбросит температуру.",
                "Перезапусти генератор после сигнала о нормальной температуре."
            }
        })
    end, {distance = 7})
    taskPrompts.generatorOverheatStop = addPrompt(generator, "Остановить двигатель", "Обслуживание перегрева", 0.8, function(player)
        if not generatorOverheatActive or generatorOverheatStage ~= 1 then return end
        generatorOverheatStage = 2
        setGeneratorState("OFF", true)
        notify(player, "Двигатель остановлен. Теперь очисти решётку радиатора.")
        setTaskPromptsEnabled()
    end, {distance = 7})
    taskPrompts.generatorOverheatClean = addPrompt(generatorRadiator, "Очистить радиатор", "Решётка охлаждения", 1.8, function(player)
        if not generatorOverheatActive or generatorOverheatStage ~= 2 then return end
        generatorOverheatStage = 3
        emitWorldSound("switch", generatorRadiator.Position, "Решётка радиатора очищена", player)
        notify(player, "Решётка очищена. Подожди, пока двигатель остынет.")
        setTaskPromptsEnabled()
        local coolingToken = generatorOverheatToken
        task.delay(6, function()
            if coolingToken ~= generatorOverheatToken or not generatorOverheatActive
                or generatorOverheatStage ~= 3 or round.phase ~= "SHIFT" then return end
            generatorOverheatStage = 4
            setTaskPromptsEnabled()
            remote:FireAllClients("Notify", "Температура генератора в норме. Можно перезапустить двигатель.")
        end)
    end, {distance = 6})
    taskPrompts.generatorOverheatRestart = addPrompt(generator, "Перезапустить двигатель", "Охлаждение завершено", 1.0, function(player)
        if not generatorOverheatActive or generatorOverheatStage ~= 4 then return end
        generatorOverheatActive, generatorOverheatStage = false, 0
        generatorOverheatToken += 1
        if world then world:SetAttribute("GeneratorOverheated", false) end
        startGeneratorMotor()
        setTaskPromptsEnabled()
        remote:FireAllClients("Notify", "ПЕРЕГРЕВ УСТРАНЁН. Генератор снова работает в штатном режиме.")
    end, {distance = 7})
    taskPrompts.generatorOverheatGuide.Enabled = false
    taskPrompts.generatorOverheatStop.Enabled = false
    taskPrompts.generatorOverheatClean.Enabled = false
    taskPrompts.generatorOverheatRestart.Enabled = false
    local doorTaskAnchor = makeDetail("RearDoorTaskAnchor", Vector3.new(0.2, 0.2, 0.2), Vector3.new(2.8, 4.1, -29.7), Color3.fromRGB(0, 0, 0), Enum.Material.SmoothPlastic, 1)
    taskPrompts.door = addPrompt(doorTaskAnchor, TEXT.actionLock, TEXT.objDoor, 1.1, function(player)
        if backDoorController:SetOpen(false, player) then completeTask(player, "door") end
    end, {distance = 6})
    taskPrompts.trash = addPrompt(trash, TEXT.actionClean, TEXT.objTrash, 1.2, function(player) if gameplay then gameplay:Interact(player, "trash") end end)
    taskPrompts.cctv = addPrompt(monitor, "Смотреть камеры", TEXT.objCCTV, 0.5, function(player)
        if gameplay and gameplay:Interact(player, "cctv") then remote:FireClient(player, "OpenCCTV") end
    end)
    taskPrompts.cctv:SetAttribute("AlwaysAvailable", true)
    local cameraPoints = Instance.new("Folder")
    cameraPoints.Name = "CameraPoints"
    cameraPoints.Parent = world
    for index, cameraData in ipairs({
        {label = "01 · Вход и кассы", position = Vector3.new(-38, 14, 28), target = Vector3.new(0, 2, 14)},
        {label = "02 · Торговый зал", position = Vector3.new(-38, 14, -28), target = Vector3.new(1, 2, -2)},
        {label = "03 · Склад", position = Vector3.new(39.5, 10.5, -6.1), target = Vector3.new(25, 2, -10)},
        {label = "04 · Генераторная", position = Vector3.new(39.5, 10.3, -29.5), target = Vector3.new(31, 2, -21)},
        {label = "05 · Погрузочная", position = Vector3.new(-26.8, 9.7, -59.5), target = Vector3.new(10, 2, -44)},
        {label = "06 · Подвал B1", position = Vector3.new(21, -2.4, -80.4), target = Vector3.new(1, -7.4, -96)},
    }) do
        local facing = (cameraData.target - cameraData.position).Unit
        local camera, cameraFrame, cameraPart = makeFurnitureAssembly(string.format("SecurityCamera%02d", index), cameraData.position, facing)
        camera:SetAttribute("CameraPoint", string.format("Cam%02d", index))
        camera:SetAttribute("Target", cameraData.target)
        camera:SetAttribute("OpticalOrigin", cameraData.position)

        -- The optical origin is the real CCTV viewpoint. Every visible piece stays
        -- behind it (+local Z), so neither the casing nor the lens covers the feed.
        cameraPart("SecurityCameraHousing", Vector3.new(1.25, 0.75, 0.88), Vector3.new(0, 0.05, 0.78), Color3.fromRGB(34, 41, 47), Enum.Material.Metal, 0, false)
        local ring = cameraPart("SecurityCameraLensRing", Vector3.new(0.16, 0.48, 0.48), Vector3.new(0, 0.02, 0.28), Color3.fromRGB(18, 24, 29), Enum.Material.Metal, 0, false, CFrame.Angles(0, math.rad(90), 0))
        ring.Shape = Enum.PartType.Cylinder
        local lens = cameraPart("SecurityCameraLens", Vector3.new(0.06, 0.34, 0.34), Vector3.new(0, 0.02, 0.17), Color3.fromRGB(71, 105, 116), Enum.Material.Glass, 0.12, false, CFrame.Angles(0, math.rad(90), 0))
        lens.Shape = Enum.PartType.Cylinder
        local status = cameraPart("CameraStatusLED", Vector3.new(0.12, 0.12, 0.12), Vector3.new(0.42, 0.22, 0.28), Color3.fromRGB(190, 42, 34), Enum.Material.Neon, 0, false)
        status.Shape = Enum.PartType.Ball
        cameraPart("SecurityCameraMount", Vector3.new(0.16, 0.16, 0.28), Vector3.new(0, 0.05, 1.32), Color3.fromRGB(93, 102, 108), Enum.Material.Metal, 0, false)
        cameraPart("SecurityCameraWallPlate", Vector3.new(0.5, 0.5, 0.12), Vector3.new(0, 0.05, 1.48), Color3.fromRGB(76, 85, 92), Enum.Material.Metal, 0, false)

        local point = makeDetail(string.format("Cam%02d", index), Vector3.new(0.2, 0.2, 0.2), cameraData.position, Color3.fromRGB(0, 0, 0), Enum.Material.SmoothPlastic, 1, cameraPoints)
        point.CFrame = cameraFrame
        point:SetAttribute("Label", cameraData.label)
        point:SetAttribute("Order", index)
        point:SetAttribute("Target", cameraData.target)
    end

    -- Structural audit: fail fast if a critical room shell is missing from a future edit.
    local requiredGeometry = {
        "RoofCenter", "OfficeWestWall", "OfficeEastWall", "OfficeRearWall", "OfficeCeiling",
        "BackDoorInfillLeft", "BackDoorInfillRight", "FrontWallLeft", "FrontWallRight", "LoadingBayRoof",
        "StockroomFrontWallLeft", "StockroomFrontWallRight", "StockroomCeiling",
        "GeneratorRoomWestWall", "GeneratorRoomEastWall", "GeneratorRoomRearWall", "GeneratorRoomCeiling",
        "LoadingBayRearWallLeft", "LoadingBayRearWallRight", "LoadingBayRearLintel", "LoadingDockShutter",
        "ColdStorageFloor", "ColdStorageCeiling", "ColdStorageWestWall", "ColdStorageRearWall", "ColdStorageFrontWall",
        "BasementCeiling", "BasementWallBack", "BasementStairwellWallLeft", "BasementStairwellWallRight",
        "BasementStairwellRoof", "BasementStairEntranceHeader", "BasementStairwellEndHeader", "BasementStairUnderEntryWall",
        "BasementPumpPartitionLeft", "BasementPumpPartitionRight", "BasementPumpPartitionHeader",
        "RightWallDoorHeader", "StorefrontUpperWall", "StorefrontDoorTransom", "OfficeDoorHeader", "BackDoorOpeningHeader",
        "BoilerRoomFloor", "BoilerRoomCeiling", "BoilerRoomEastWall", "BoilerRoomRearWall", "BoilerRoomFrontWall",
    }
    local missingGeometry = {}
    for _, requiredName in ipairs(requiredGeometry) do
        if not world:FindFirstChild(requiredName, true) then table.insert(missingGeometry, requiredName) end
    end
    if #missingGeometry > 0 then
        error("Map layout audit failed; missing geometry: " .. table.concat(missingGeometry, ", "))
    end
    world:SetAttribute("ShellAudit", "PASS")
    world:SetAttribute("LayoutVersion", "3.6")
end


addPremiumLocations = function()
    -- Side service alley: a fully walkable exterior extension through the new sliding staff door.
    makePart("ServiceAlleyFloor", Vector3.new(40, 0.45, 44), Vector3.new(62, -0.34, 0), Color3.fromRGB(43, 47, 52), Enum.Material.Asphalt)
    makePart("ServiceAlleyThreshold", Vector3.new(6, 0.46, 10), Vector3.new(44, -0.32, 0), Color3.fromRGB(57, 62, 67), Enum.Material.Concrete)
    makePart("ServiceAlleyEndWall", Vector3.new(1, 10, 44), Vector3.new(82, 4.7, 0), Color3.fromRGB(42, 49, 58), Enum.Material.Concrete)
    makePart("ServiceAlleyNorthWall", Vector3.new(40, 10, 1), Vector3.new(62, 4.7, -22), Color3.fromRGB(42, 49, 58), Enum.Material.Concrete)
    makePart("ServiceAlleySouthWall", Vector3.new(40, 10, 1), Vector3.new(62, 4.7, 22), Color3.fromRGB(42, 49, 58), Enum.Material.Concrete)
    for _, z in ipairs({-17, -9, 0, 9, 17}) do
        makeDetail("AlleyWallConduit", Vector3.new(0.12, 0.12, 7.8), Vector3.new(80.9, 7.3, z), Color3.fromRGB(93, 101, 107), Enum.Material.Metal)
    end
    local sideDoor = makePart("ServiceAlleyDoor", Vector3.new(1.1, 12.6, 7.8), Vector3.new(41.45, 6.6, 0), Color3.fromRGB(61, 72, 80), Enum.Material.Metal)
    sideDoor.Reflectance = 0.06
    makeDetail("ServiceDoorJamb", Vector3.new(0.22, 13.0, 0.28), Vector3.new(40.82, 6.6, -4.0), Color3.fromRGB(110, 119, 124), Enum.Material.Metal)
    makeDetail("ServiceDoorJamb", Vector3.new(0.22, 13.0, 0.28), Vector3.new(40.82, 6.6, 4.0), Color3.fromRGB(110, 119, 124), Enum.Material.Metal)
    local serviceHandle = makeDetail("ServiceDoorHandle", Vector3.new(0.18, 1.4, 0.16), Vector3.new(40.8, 4.4, -2.4), Color3.fromRGB(180, 188, 185), Enum.Material.Metal)
    local servicePushBar = makeDetail("ServiceDoorPushBar", Vector3.new(0.18, 0.32, 4.8), Vector3.new(40.8, 4.1, 0), Color3.fromRGB(196, 201, 194), Enum.Material.Metal)
    local serviceCloser = makeDetail("ServiceDoorCloser", Vector3.new(1.15, 0.22, 0.42), Vector3.new(41.45, 12.85, 0), Color3.fromRGB(43, 51, 57), Enum.Material.Metal)
    local serviceReader = makeDetail("ServiceDoorCardReader", Vector3.new(0.22, 1.0, 0.56), Vector3.new(42.08, 6.0, -3.25), Color3.fromRGB(31, 42, 48), Enum.Material.Metal)
    makeDetail("ServiceDoorReaderLED", Vector3.new(0.08, 0.12, 0.08), Vector3.new(41.93, 6.25, -3.25), Color3.fromRGB(92, 202, 139), Enum.Material.Neon)
    addDoorController(sideDoor, sideDoor.CFrame * CFrame.new(0, 0, 8.8), "Служебный выход", {Vector3.new(39.3, 4, 0), Vector3.new(44, 4, 0)}, {serviceHandle, servicePushBar, serviceCloser})
    local serviceSign = makePart("ServiceDoorSign", Vector3.new(0.16, 0.9, 5.5), Vector3.new(40.78, 14.2, 0), Color3.fromRGB(46, 83, 72), Enum.Material.Metal)
    serviceSign.CanCollide = false
    addTextSign(serviceSign, "ВЫХОД ПЕРСОНАЛА  •  E", Enum.NormalId.Left, Color3.fromRGB(226, 244, 230))

    -- Chain-link fence, utility equipment, bins and wet ground make the alley a separate readable space.
    for _, x in ipairs({48, 56, 64, 72, 80}) do
        for _, z in ipairs({-21.3, 21.3}) do
            makePart("AlleyFencePost", Vector3.new(0.18, 5.8, 0.18), Vector3.new(x, 2.8, z), Color3.fromRGB(95, 105, 111), Enum.Material.Metal)
        end
    end
    for _, y in ipairs({1.0, 4.2}) do
        makeDetail("AlleyFenceRail", Vector3.new(32, 0.12, 0.12), Vector3.new(64, y, -21.3), Color3.fromRGB(101, 111, 117), Enum.Material.Metal)
        makeDetail("AlleyFenceRail", Vector3.new(32, 0.12, 0.12), Vector3.new(64, y, 21.3), Color3.fromRGB(101, 111, 117), Enum.Material.Metal)
    end
    for i = 0, 9 do
        makeDetail("AlleyFenceMesh", Vector3.new(3.5, 4.7, 0.035), Vector3.new(48 + i * 3.5, 2.7, -21.3), Color3.fromRGB(93, 105, 111), Enum.Material.Metal, 0.35)
        makeDetail("AlleyFenceMesh", Vector3.new(3.5, 4.7, 0.035), Vector3.new(48 + i * 3.5, 2.7, 21.3), Color3.fromRGB(93, 105, 111), Enum.Material.Metal, 0.35)
    end
    addServiceDumpster("AlleyDumpsterA", Vector3.new(74, 2.2, -12), Vector3.new(6.5, 4.2, 4.2), Color3.fromRGB(40, 78, 65), true)
    addServiceDumpster("AlleyDumpsterB", Vector3.new(74, 2.2, 1), Vector3.new(6.5, 4.2, 4.2), Color3.fromRGB(48, 61, 76), true)
    do
        local model, frame, p = makeFurnitureAssembly("AlleyTransformer", Vector3.new(54, 2.7, -12), Vector3.new(0, 0, 1))
        p("AlleyTransformer", Vector3.new(5.2, 5.4, 4.2), Vector3.new(0, 0, 0), Color3.fromRGB(55, 66, 74), Enum.Material.Metal, nil, true)
        p("TransformerBase", Vector3.new(5.8, 0.45, 4.8), Vector3.new(0, -2.65, 0), Color3.fromRGB(29, 35, 41), Enum.Material.DiamondPlate, nil, true)
        -- Cooling fins occupy the rear (+local Z / -world Z), clear of the front panel.
        for i = 0, 7 do
            p("TransformerCoolingFin", Vector3.new(0.22, 3.8, 2.8), Vector3.new(-2.2 + i * 0.62, 0, 2.25), Color3.fromRGB(100, 109, 114), Enum.Material.Metal, nil, false)
        end
        p("TransformerServicePanel", Vector3.new(4.6, 4.75, 0.08), Vector3.new(0, 0, -2.14), Color3.fromRGB(68, 82, 89), Enum.Material.Metal, nil, false)
        p("TransformerWarningPlate", Vector3.new(1.6, 1, 0.08), Vector3.new(0, 0.4, -2.22), Color3.fromRGB(196, 151, 53), Enum.Material.Metal, nil, false)
        for _, x in ipairs({-2.06, 2.06}) do
            for _, y in ipairs({-2.12, 2.12}) do
                local bolt = p("TransformerPanelBolt", Vector3.new(0.09, 0.09, 0.06), Vector3.new(x, y, -2.22), Color3.fromRGB(157, 166, 168), Enum.Material.Metal, nil, false)
                bolt.Shape = Enum.PartType.Ball
            end
        end
    end
    for i = 0, 5 do
        local puddle = makeDetail("AlleyRainPuddle", Vector3.new(2.6 + (i % 3), 0.025, 1.1 + (i % 2) * 0.5), Vector3.new(48 + i * 5.4, -0.08, 7 + (i % 2) * 3), Color3.fromRGB(54, 69, 80), Enum.Material.Glass, 0.42)
        puddle.Reflectance = 0.28
    end
    addLight(Vector3.new(59, 9.0, 0), 1.0, 28, Color3.fromRGB(173, 195, 218))
    addLight(Vector3.new(77, 8.0, -16), 0.65, 18, Color3.fromRGB(202, 177, 142))
    makeDetail("ServiceAlleyBeaconBracket", Vector3.new(0.3, 0.35, 3.2), Vector3.new(62, 8.2, 20.0), Color3.fromRGB(74, 84, 90), Enum.Material.Metal)
    addRotatingAlarmBeacon("ServiceAlleyAlarmBeacon", Vector3.new(62, 8.2, 18.2))

    -- Detailed service yard: the centre lane stays open from the staff door to the bins.
    local alleyDrain = makeDetail("AlleyDrainChannel", Vector3.new(26, 0.035, 0.42), Vector3.new(64, -0.08, 10.5), Color3.fromRGB(26, 31, 35), Enum.Material.DiamondPlate)
    for i = 0, 11 do
        makeDetail("AlleyDrainSlot", Vector3.new(0.08, 0.025, 0.34), Vector3.new(52 + i * 2.2, -0.055, 10.5), Color3.fromRGB(118, 127, 129), Enum.Material.Metal)
    end
    for _, z in ipairs({-18.8, 18.8}) do
        makeDetail("AlleyYellowSafetyLine", Vector3.new(31, 0.025, 0.12), Vector3.new(64, -0.07, z), Color3.fromRGB(205, 158, 62), Enum.Material.Neon)
    end
    -- Outdoor condenser units and ducting along the north wall.
    for index, x in ipairs({53, 66}) do
        local unit = makePart("AlleyHVACUnit" .. index, Vector3.new(5.2, 3.4, 3.2), Vector3.new(x, 1.585, -17.4), Color3.fromRGB(55, 65, 72), Enum.Material.Metal)
        makeDetail("AlleyHVACFront", Vector3.new(4.55, 2.75, 0.12), Vector3.new(x, 1.635, -15.76), Color3.fromRGB(31, 39, 45), Enum.Material.Metal)
        for slat = 0, 8 do
            makeDetail("AlleyHVACGrille", Vector3.new(4.2, 0.08, 0.08), Vector3.new(x, 0.455 + slat * 0.29, -15.66), Color3.fromRGB(122, 132, 137), Enum.Material.Metal)
        end
        local fan = makeDetail("AlleyHVACFanHub", Vector3.new(0.16, 0.16, 0.16), Vector3.new(x, 1.635, -15.55), Color3.fromRGB(145, 154, 157), Enum.Material.Metal)
        fan.Shape = Enum.PartType.Ball
        makeDetail("AlleyHVACPipe", Vector3.new(0.22, 0.22, 4.2), Vector3.new(x + 2.45, 3.65, -17.2), Color3.fromRGB(118, 126, 130), Enum.Material.Metal)
        unit:SetAttribute("NS40Ambient", "vent")
    end
    -- Power cabinet, hose reel, and cable trunking near the rear wall.
    local alleyCabinet = makePart("AlleyPowerCabinet", Vector3.new(3.4, 5.6, 1.5), Vector3.new(49.2, 2.8, 13.8), Color3.fromRGB(48, 60, 67), Enum.Material.Metal)
    makeDetail("AlleyCabinetDoor", Vector3.new(3.1, 5.25, 0.08), Vector3.new(49.2, 2.8, 13.0), Color3.fromRGB(75, 88, 94), Enum.Material.Metal)
    makeDetail("AlleyCabinetWarning", Vector3.new(0.9, 0.55, 0.05), Vector3.new(49.2, 4.35, 12.93), Color3.fromRGB(194, 144, 53), Enum.Material.Metal)
    local cabinetLabel = makeDetail("AlleyCabinetLabel", Vector3.new(1.7, 0.75, 0.05), Vector3.new(49.2, 3.55, 12.91), Color3.fromRGB(36, 45, 50), Enum.Material.Metal)
    addTextSign(cabinetLabel, "240 V\nОПАСНО", Enum.NormalId.Front, Color3.fromRGB(241, 225, 190))
    local hose = makeDetail("AlleyHoseReel", Vector3.new(0.28, 1.65, 1.65), Vector3.new(50.8, 2.4, 20.8), Color3.fromRGB(131, 48, 38), Enum.Material.Metal)
    hose.Shape = Enum.PartType.Cylinder
    hose.CFrame = CFrame.new(hose.Position) * CFrame.Angles(0, math.rad(90), 0)
    local hoseCore = makeDetail("AlleyHoseCore", Vector3.new(0.32, 0.48, 0.48), hose.Position, Color3.fromRGB(180, 188, 185), Enum.Material.Metal)
    hoseCore.Shape = Enum.PartType.Cylinder
    hoseCore.CFrame = CFrame.new(hoseCore.Position) * CFrame.Angles(0, math.rad(90), 0)
    for index, x in ipairs({56, 63, 70}) do
        local bollard = makePart("AlleyBollard", Vector3.new(2.0, 0.42, 0.42), Vector3.new(x, 0.885, 18.8), Color3.fromRGB(190, 151, 62), Enum.Material.Metal)
        bollard.Shape = Enum.PartType.Cylinder
        bollard.CFrame = CFrame.new(bollard.Position) * CFrame.Angles(0, 0, math.rad(90))
        for band = 0, 2 do makeDetail("AlleyBollardStripe", Vector3.new(0.44, 0.18, 0.44), Vector3.new(x, 0.35 + band * 0.58, 18.8), Color3.fromRGB(28, 33, 38), Enum.Material.Metal) end
    end
    -- A camera and a wall lamp make the personnel exit legible from both sides.
    local alleyCamera = makeDetail("ServiceAlleyCamera", Vector3.new(0.85, 0.5, 0.62), Vector3.new(43.4, 8.4, -4.2), Color3.fromRGB(28, 35, 41), Enum.Material.Metal)
    alleyCamera.CFrame = CFrame.lookAt(alleyCamera.Position, alleyCamera.Position + Vector3.new(1, -0.2, 0.35))
    local exitLens = makeDetail("ServiceExitLampLens", Vector3.new(1.0, 0.18, 0.6), Vector3.new(43.2, 11.8, 0), Color3.fromRGB(182, 218, 194), Enum.Material.Neon)
    local exitLamp = Instance.new("PointLight")
    exitLamp.Color = Color3.fromRGB(166, 218, 184); exitLamp.Brightness = 0.8; exitLamp.Range = 14; exitLamp.Shadows = false; exitLamp.Parent = exitLens
    local exitPlate = makeDetail("ServiceExitDirectionPlate", Vector3.new(0.16, 1.0, 5.8), Vector3.new(43.08, 12.9, 0), Color3.fromRGB(36, 76, 62), Enum.Material.Metal)
    addTextSign(exitPlate, "СЛУЖЕБНЫЙ ВЫХОД\nНЕ ЗАГРОМОЖДАТЬ", Enum.NormalId.Left, Color3.fromRGB(226, 244, 230))
    -- Floor wear and small rain puddles catch the cold exterior lighting.
    for i = 0, 5 do
        local puddle = makeDetail("AlleyWetPatch", Vector3.new(2.4 + (i % 2) * 1.2, 0.018, 0.75 + (i % 3) * 0.22), Vector3.new(53 + i * 4.2, -0.075, -5 + (i % 2) * 4), Color3.fromRGB(54, 69, 80), Enum.Material.Glass, 0.42)
        puddle.Reflectance = 0.24
    end

    -- B1 floor and ceiling start past the bottom of the stairs; nothing caps the flight.
    makePart("BasementFloor", Vector3.new(35.9, 0.6, 28.9), Vector3.new(7, -10.8, -93), Color3.fromRGB(43, 49, 54), Enum.Material.Concrete)
    makePart("BasementCorridorFloor", Vector3.new(8.4, 0.6, 6), Vector3.new(7, -10.8, -79), Color3.fromRGB(43, 49, 54), Enum.Material.Concrete)
    makePart("BasementCeiling", Vector3.new(35.9, 0.7, 28.9), Vector3.new(7, -0.45, -93), Color3.fromRGB(34, 40, 47), Enum.Material.Metal)
    makePart("BasementWallLeftRear", Vector3.new(0.9, 10.4, 13), Vector3.new(-10.5, -5.5, -100.5), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BasementWallLeftFront", Vector3.new(0.9, 10.4, 9), Vector3.new(-10.5, -5.5, -83.5), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BasementWallRightRear", Vector3.new(0.9, 10.4, 10), Vector3.new(24.5, -5.5, -102), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BasementWallRightFront", Vector3.new(0.9, 10.4, 11), Vector3.new(24.5, -5.5, -84.5), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BasementWallBack", Vector3.new(35.9, 10.4, 0.9), Vector3.new(7, -5.5, -107), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BasementWallFrontLeft", Vector3.new(13.5, 10.4, 0.9), Vector3.new(-3.75, -5.5, -79), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BasementWallFrontRight", Vector3.new(13.5, 10.4, 0.9), Vector3.new(17.75, -5.5, -79), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BasementStairwellWallLeft", Vector3.new(0.5, 22.3, 26), Vector3.new(2.75, 0.15, -67), Color3.fromRGB(49, 56, 63), Enum.Material.Concrete)
    makePart("BasementStairwellWallRight", Vector3.new(0.5, 22.3, 26), Vector3.new(11.25, 0.15, -67), Color3.fromRGB(49, 56, 63), Enum.Material.Concrete)
    makePart("BasementStairwellRoof", Vector3.new(9, 0.6, 18), Vector3.new(7, 11.6, -71), Color3.fromRGB(38, 46, 54), Enum.Material.Metal)
    makePart("BasementStairEntranceHeader", Vector3.new(9, 2, 0.6), Vector3.new(7, 10.3, -54), Color3.fromRGB(49, 56, 63), Enum.Material.Concrete)
    makePart("BasementStairUnderEntryWall", Vector3.new(8, 10.7, 0.3), Vector3.new(7, -5.65, -54.15), Color3.fromRGB(49, 56, 63), Enum.Material.Concrete)
    makePart("BasementStairwellEndHeader", Vector3.new(8, 13.1, 0.8), Vector3.new(7, 4.75, -79.4), Color3.fromRGB(49, 56, 63), Enum.Material.Concrete)
    for i = 1, 18 do
        local top = 0.3 - i * 0.6
        local step = makePart("BasementStairStep", Vector3.new(8, 0.6, 1.35), Vector3.new(7, top - 0.3, -54 - (i - 0.5) * 1.35), Color3.fromRGB(67, 75, 82), Enum.Material.DiamondPlate)
        makeDetail("BasementStairNosing", Vector3.new(7.8, 0.025, 0.1), step.Position + Vector3.new(0, 0.3125, -0.6), Color3.fromRGB(203, 166, 82), Enum.Material.Metal)
    end
    makePart("BasementStairLanding", Vector3.new(8, 0.6, 3), Vector3.new(7, -10.8, -79.8), Color3.fromRGB(65, 72, 78), Enum.Material.DiamondPlate)
    for _, x in ipairs({3.25, 10.75}) do
        local handrail = makeDetail("BasementStairHandrail", Vector3.new(0.13, 0.13, 26.6), Vector3.new(x, -2.1, -66.15), Color3.fromRGB(153, 164, 170), Enum.Material.Metal)
        handrail.CFrame = CFrame.new(handrail.Position) * CFrame.Angles(-math.atan(0.6 / 1.35), 0, 0)
        for i = 0, 5 do
            local z = -54.6 - i * 4.35
            local top = 0.3 + (z + 54) * (0.6 / 1.35)
            makeDetail("StairRailPost", Vector3.new(0.13, 3.1, 0.13), Vector3.new(x, top + 1.55, z), Color3.fromRGB(123, 138, 146), Enum.Material.Metal)
        end
    end
    for _, data in ipairs({{z = -55, y = 7.1}, {z = -66, y = 2.6}, {z = -77, y = -1.8}}) do
        local housing = makeDetail("StairWallFixture", Vector3.new(0.3, 1.2, 0.9), Vector3.new(10.85, data.y, data.z), Color3.fromRGB(69, 79, 87), Enum.Material.Metal)
        local lens = makeDetail("StairWallFixtureLens", Vector3.new(0.08, 0.9, 0.66), Vector3.new(10.66, data.y, data.z), Color3.fromRGB(213, 202, 173), Enum.Material.Neon)
        local stairLight = Instance.new("PointLight")
        stairLight.Color = Color3.fromRGB(213, 202, 173)
        stairLight.Brightness = 0.9
        stairLight.Range = 16
        stairLight.Shadows = false
        stairLight.Parent = lens
        table.insert(lights, stairLight); originalLightColors[stairLight] = stairLight.Color
    end
    for _, data in ipairs({{z = -55, y = 2.5}, {z = -66, y = -2.4}, {z = -77, y = -7.3}}) do
        local lens = makeDetail("StairEmergencyMarker", Vector3.new(0.08, 0.35, 0.65), Vector3.new(10.9, data.y, data.z), Color3.fromRGB(232, 164, 64), Enum.Material.Neon)
        local light = Instance.new("PointLight")
        light.Name = "BatteryEmergencyLight"
        light.Color = Color3.fromRGB(224, 153, 64)
        light.Range = 7
        light.Brightness = 0.45
        light.Shadows = false
        light.Parent = lens
    end
    addWayfinding("StairExitDirection", Vector3.new(7, -0.95, -79.88), 6.8, "МАГАЗИН  /  НАВЕРХ", Vector3.new(0, 0, -1))
    -- Pipework and cable trays along the basement ceiling.
    for _, x in ipairs({-5, 2, 9, 16, 21}) do
        makeDetail("BasementCeilingPipe", Vector3.new(0.24, 0.24, 29), Vector3.new(x, -1.15, -91), Color3.fromRGB(111, 119, 123), Enum.Material.Metal)
        makeDetail("BasementPipeBracket", Vector3.new(0.8, 0.14, 0.14), Vector3.new(x, -1.35, -91), Color3.fromRGB(47, 54, 60), Enum.Material.Metal)
    end
    -- Cross-wall separates the pump bay from the rear electrical bay; a 6-stud doorway stays open.
    makePart("BasementPumpPartitionLeft", Vector3.new(12.5, 9.7, 0.75), Vector3.new(-4.25, -5.65, -99.5), Color3.fromRGB(46, 53, 60), Enum.Material.Concrete)
    makePart("BasementPumpPartitionRight", Vector3.new(16.5, 9.7, 0.75), Vector3.new(16.25, -5.65, -99.5), Color3.fromRGB(46, 53, 60), Enum.Material.Concrete)
    makePart("BasementPumpPartitionHeader", Vector3.new(6, 1.3, 0.75), Vector3.new(5, -1.45, -99.5), Color3.fromRGB(46, 53, 60), Enum.Material.Concrete)
    makeDetail("BasementPumpDoorJambLeft", Vector3.new(0.22, 9.2, 0.24), Vector3.new(2.0, -5.8, -99.5), Color3.fromRGB(116, 125, 130), Enum.Material.Metal)
    makeDetail("BasementPumpDoorJambRight", Vector3.new(0.22, 9.2, 0.24), Vector3.new(8.0, -5.8, -99.5), Color3.fromRGB(116, 125, 130), Enum.Material.Metal)
    local breaker = makePart("BasementBreakerPanel", Vector3.new(3.6, 5.0, 0.55), Vector3.new(19.5, -7.2, -104.2), Color3.fromRGB(49, 61, 68), Enum.Material.Metal)
    makeDetail("BreakerPanelDoor", Vector3.new(3.2, 4.55, 0.12), breaker.Position + Vector3.new(0, 0, 0.34), Color3.fromRGB(69, 82, 89), Enum.Material.Metal)
    local breakerLamp = makeDetail("BasementBreakerStatusLamp", Vector3.new(0.22, 0.22, 0.12), breaker.Position + Vector3.new(1.1, 1.75, 0.43), Color3.fromRGB(224, 52, 42), Enum.Material.Neon)
    breakerLamp.Shape = Enum.PartType.Ball
    local breakerPrompt = addPrompt(breaker, "Проверить щит", "Резервный контур · B1", 2.2, function(player)
        if gameplay then gameplay:Interact(player, "breaker") end
    end)
    breakerPrompt.ActionText = "Проверить щит"
    taskPrompts.breaker = breakerPrompt
    local pump = makePart("BasementWaterPump", Vector3.new(3.6, 2.4, 2.4), Vector3.new(-5.8, -9.35, -88), Color3.fromRGB(57, 72, 79), Enum.Material.Metal)
    local pumpMotor = makeDetail("PumpMotor", Vector3.new(1.2, 1.3, 1.2), pump.Position + Vector3.new(1.1, 0.2, 0), Color3.fromRGB(107, 116, 119), Enum.Material.Metal)
    pumpMotor.Shape = Enum.PartType.Cylinder
    pumpMotor.CFrame = CFrame.new(pumpMotor.Position) * CFrame.Angles(0, 0, math.rad(90))
    local pumpPipe = makeDetail("PumpPipe", Vector3.new(4.8, 0.22, 0.22), pump.Position + Vector3.new(0.2, 1.4, -1.3), Color3.fromRGB(121, 130, 134), Enum.Material.Metal)
    pumpPipe.Shape = Enum.PartType.Cylinder
    pumpPipe.CFrame = CFrame.new(pumpPipe.Position) * CFrame.Angles(0, math.rad(90), 0)
    local tank = makePart("BasementPressureTank", Vector3.new(5.4, 2.8, 2.8), Vector3.new(16.5, -7.65, -84), Color3.fromRGB(68, 79, 85), Enum.Material.Metal)
    tank.Shape = Enum.PartType.Cylinder
    tank.Orientation = Vector3.new(0, 0, 90)
    for i = 0, 3 do
        makeDetail("PressureTankBand", Vector3.new(2.92, 0.12, 2.92), tank.Position + Vector3.new(0, -1.55 + i * 1.0, 0), Color3.fromRGB(126, 134, 137), Enum.Material.Metal)
    end
    for i = 0, 5 do
        local puddle = makeDetail("BasementWater", Vector3.new(2.2 + (i % 2), 0.025, 1.1), Vector3.new(-7 + i * 4.5, -10.47, -96 + (i % 3) * 2), Color3.fromRGB(44, 65, 77), Enum.Material.Glass, 0.42)
        puddle.Reflectance = 0.32
    end
    local basementLamp = makePart("BasementEmergencyLamp", Vector3.new(0.8, 0.35, 0.8), Vector3.new(7, -1.45, -91), Color3.fromRGB(210, 44, 37), Enum.Material.Neon)
    basementLamp.CanCollide = false
    local basementLight = Instance.new("PointLight")
    basementLight.Color = Color3.fromRGB(255, 64, 48)
    basementLight.Brightness = 0.9
    basementLight.Range = 18
    basementLight.Parent = basementLamp
    -- Battery-powered escape lighting stays on during generator blackouts.
    basementLight.Name = "BatteryEmergencyLight"
    addLight(Vector3.new(-6, -1.8, -88), 0.68, 18, Color3.fromRGB(174, 193, 211))
    addLight(Vector3.new(19, -1.8, -96), 0.58, 16, Color3.fromRGB(174, 193, 211))
    local basementSign = makePart("BasementSign", Vector3.new(3.6, 1.1, 0.12), Vector3.new(3.1, -4.5, -76.3), Color3.fromRGB(60, 70, 75), Enum.Material.Metal)
    basementSign.CanCollide = false
    basementSign.CFrame = CFrame.lookAt(basementSign.Position, basementSign.Position + Vector3.new(1, 0, 0))
    addTextSign(basementSign, "ТЕХНИЧЕСКИЙ УРОВЕНЬ  B1", Enum.NormalId.Front, Color3.fromRGB(218, 227, 224))

    -- New enclosed cold-storage room west of the main B1 corridor.
    makePart("ColdStorageFloor", Vector3.new(22, 0.6, 24), Vector3.new(-21.5, -10.8, -92), Color3.fromRGB(48, 57, 64), Enum.Material.Concrete)
    makePart("ColdStorageCeiling", Vector3.new(22, 0.7, 24), Vector3.new(-21.5, -0.45, -92), Color3.fromRGB(34, 42, 49), Enum.Material.Metal)
    makePart("ColdStorageWestWall", Vector3.new(0.9, 10.4, 24), Vector3.new(-32.5, -5.5, -92), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("ColdStorageRearWall", Vector3.new(22, 10.4, 0.9), Vector3.new(-21.5, -5.5, -104), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("ColdStorageFrontWall", Vector3.new(22, 10.4, 0.9), Vector3.new(-21.5, -5.5, -80), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    for _, x in ipairs({-29, -23, -17}) do
        makePart("ColdStorageRackUpright", Vector3.new(0.18, 7.2, 1.2), Vector3.new(x, -6.8, -100.5), Color3.fromRGB(103, 114, 121), Enum.Material.Metal)
        for level = 0, 2 do
            makePart("ColdStorageRackShelf", Vector3.new(4.8, 0.18, 1.4), Vector3.new(x + 2.2, -9.3 + level * 2.2, -100.5), Color3.fromRGB(83, 95, 103), Enum.Material.Metal)
        end
    end
    for i = 0, 5 do
        local freezerBox = makePart("ColdStorageCrate", Vector3.new(1.15, 1.35, 1.0), Vector3.new(-30 + (i % 3) * 4.2, -9.75, -88 + math.floor(i / 3) * 4.2), Color3.fromRGB(173, 184, 188), Enum.Material.Metal)
        makeDetail("ColdStorageCrateLatch", Vector3.new(0.2, 0.35, 0.08), freezerBox.Position + Vector3.new(0, 0, -0.54), Color3.fromRGB(83, 105, 116), Enum.Material.Metal)
    end
    addWayfinding("ColdStorageSign", Vector3.new(-9.95, -1.4, -91), 5.5, "ХОЛОДНЫЙ СКЛАД", Vector3.new(1, 0, 0), Color3.fromRGB(58, 101, 125))
    addLight(Vector3.new(-21.5, -1.8, -92), 0.72, 16, Color3.fromRGB(151, 205, 225))
    addLight(Vector3.new(-28, -1.8, -100), 0.48, 12, Color3.fromRGB(151, 205, 225))

    -- New enclosed boiler/control room east of B1, with service access through the east wall.
    makePart("BoilerRoomFloor", Vector3.new(18, 0.6, 24), Vector3.new(33.5, -10.8, -92), Color3.fromRGB(45, 52, 58), Enum.Material.Concrete)
    makePart("BoilerRoomCeiling", Vector3.new(18, 0.7, 24), Vector3.new(33.5, -0.45, -92), Color3.fromRGB(33, 40, 47), Enum.Material.Metal)
    makePart("BoilerRoomEastWall", Vector3.new(0.9, 10.4, 24), Vector3.new(42.5, -5.5, -92), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BoilerRoomRearWall", Vector3.new(18, 10.4, 0.9), Vector3.new(33.5, -5.5, -104), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BoilerRoomFrontWall", Vector3.new(18, 10.4, 0.9), Vector3.new(33.5, -5.5, -80), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    for i = 0, 1 do
        local boiler = makeVerticalCylinder("BoilerPressureVessel", 3.2, 6.4, Vector3.new(29 + i * 8, -7.35, -86), Color3.fromRGB(76, 91, 99), Enum.Material.Metal)
        makeDetail("BoilerTopCap", Vector3.new(3.35, 0.22, 3.35), boiler.Position + Vector3.new(0, 3.1, 0), Color3.fromRGB(131, 142, 146), Enum.Material.Metal)
        makeDetail("BoilerGauge", Vector3.new(0.7, 0.7, 0.18), boiler.Position + Vector3.new(0, 1.2, -1.58), Color3.fromRGB(187, 196, 190), Enum.Material.Metal)
        makeDetail("BoilerGaugeFace", Vector3.new(0.5, 0.5, 0.06), boiler.Position + Vector3.new(0, 1.2, -1.7), Color3.fromRGB(54, 83, 82), Enum.Material.Neon)
        makeDetail("BoilerPipe", Vector3.new(0.2, 0.2, 5.2), boiler.Position + Vector3.new(0, 2.5, 2.1), Color3.fromRGB(124, 133, 137), Enum.Material.Metal)
    end
    addWayfinding("BoilerRoomSign", Vector3.new(23.95, -1.4, -93.5), 6, "КОТЕЛЬНАЯ", Vector3.new(-1, 0, 0), Color3.fromRGB(91, 75, 48))
    addLight(Vector3.new(33.5, -1.8, -92), 0.68, 16, Color3.fromRGB(216, 184, 137))
    addLight(Vector3.new(39, -1.8, -100), 0.42, 12, Color3.fromRGB(216, 184, 137))
    makePart("ColdStorageDoorHeader", Vector3.new(0.9, 1.8, 6), Vector3.new(-10.5, -1.4, -91), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BoilerRoomDoorHeader", Vector3.new(0.9, 1.8, 7), Vector3.new(24.5, -1.4, -93.5), Color3.fromRGB(47, 54, 61), Enum.Material.Concrete)
    makePart("BasementOfficeThreshold", Vector3.new(1.5, 0.6, 7), Vector3.new(24.5, -10.8, -93.5), Color3.fromRGB(52, 61, 67), Enum.Material.Concrete)
    makePart("BasementColdThreshold", Vector3.new(1.5, 0.6, 6), Vector3.new(-10.5, -10.8, -91), Color3.fromRGB(52, 61, 67), Enum.Material.Concrete)
    addWayfinding("BasementBreakerSign", Vector3.new(5, -1.45, -99.05), 5.4, "ЭЛЕКТРОЩИТОВАЯ", Vector3.new(0, 0, 1), Color3.fromRGB(95, 78, 49))
    -- Metal door frames around the new side-room openings.
    for _, z in ipairs({-94, -88}) do
        makeDetail("ColdStorageDoorFrame", Vector3.new(0.22, 10.2, 0.24), Vector3.new(-10.0, -5.5, z), Color3.fromRGB(117, 127, 132), Enum.Material.Metal)
    end
    for _, z in ipairs({-97, -90}) do
        makeDetail("BoilerRoomDoorFrame", Vector3.new(0.22, 10.2, 0.24), Vector3.new(24.0, -5.5, z), Color3.fromRGB(117, 127, 132), Enum.Material.Metal)
    end

    -- More convincing security station: wall of CCTV screens, desk equipment and a radio rack.
    for i = 0, 3 do
        local screenX = 27.0 + i * 2.2
        local screen = makeDetail("SecurityMonitor", Vector3.new(1.9, 1.25, 0.16), Vector3.new(screenX, 6.6, 30.25), Color3.fromRGB(33, 49, 53), Enum.Material.Metal)
        local glass = makeDetail("SecurityMonitorGlass", Vector3.new(1.72, 1.05, 0.05), screen.Position + Vector3.new(0, 0, -0.11), Color3.fromRGB(56 + i * 8, 111 + i * 4, 99 + i * 5), Enum.Material.Glass, 0.12)
        addTextSign(glass, "CAM 0" .. tostring(i + 1), Enum.NormalId.Front, Color3.fromRGB(205, 238, 216))
    end
    local _, _, radioPart = makeFurnitureAssembly("SecurityRadioRack", Vector3.new(38.5, 2.8, 19), Vector3.new(-1, 0, 0))
    radioPart("SecurityRadioRack", Vector3.new(2.2, 4.8, 1.4), Vector3.new(0, 0, 0), Color3.fromRGB(35, 43, 49), Enum.Material.Metal, nil, true)
    for i = 0, 3 do
        radioPart("RadioRackSlot", Vector3.new(1.75, 0.62, 0.08), Vector3.new(0, 1.55 - i * 1.0, -0.75), Color3.fromRGB(68, 83, 88))
        radioPart("RadioRackLED", Vector3.new(0.12, 0.12, 0.08), Vector3.new(0.65, 1.55 - i * 1.0, -0.82), Color3.fromRGB(82, 205, 143), Enum.Material.Neon)
    end
end

local function activeTaskList()
    local list = {}
    for _, def in ipairs(TASK_DEFS) do
        if round.activeTasks[def.id] then
            table.insert(list, {id = def.id, title = def.title, location = def.location, done = round.tasks[def.id] == true})
        end
    end
    return list
end

local function getDifficultyTier()
    return math.clamp(1 + math.floor(math.max(0, round.number - 1) / 2), 1, 5)
end

local function getDifficultyLabel()
    local labels = {"СПОКОЙНО", "НАПРЯЖЕНИЕ", "ОПАСНО", "КРИТИЧЕСКИ", "КОШМАР"}
    return labels[getDifficultyTier()]
end

local function makeStatePayload()
    return {
        phase = round.phase, timeLeft = round.timeLeft, number = round.number,
        tasks = round.tasks, taskList = activeTaskList(), monsterActive = round.monsterActive,
        eventName = round.eventName, difficultyTier = getDifficultyTier(),
        difficultyLabel = getDifficultyLabel(), playerCount = #Players:GetPlayers(),
        maxPlayers = CONFIG.MAX_PLAYERS, tasksPerShift = round.tasksPerShift,
        resultSuccess = round.resultSuccess,
        resultLabel = round.resultSuccess and "СМЕНА ВЫПОЛНЕНА" or "СМЕНА ПРОВАЛЕНА",
    }
end

local function broadcastState()
    remote:FireAllClients("State", makeStatePayload())
end

setTaskPromptsEnabled = function()
    local needsService = round.eventName == TEXT.blackout
        or (round.activeTasks.generator and not round.tasks.generator) or generatorOverheatActive
    local statusColor = needsService and Color3.fromRGB(255, 85, 48) or Color3.fromRGB(82, 222, 145)
    if generatorStatusLamp and generatorStatusLamp.Parent then generatorStatusLamp.Color = statusColor end
    if generatorStatusLight and generatorStatusLight.Parent then generatorStatusLight.Color = statusColor; generatorStatusLight.Brightness = needsService and 0.65 or 0.35 end
    if generatorWarningLight and generatorWarningLight.Parent then generatorWarningLight.Color = statusColor; generatorWarningLight.Brightness = needsService and 0.85 or 0.25 end
    if world then world:SetAttribute("GeneratorOverheated", generatorOverheatActive) end
    setGeneratorWarning(needsService)
    for id, prompt in pairs(taskPrompts) do
        local emergencyRepair = id == "generator" and round.eventName == TEXT.blackout
        local enabled = prompt:GetAttribute("AlwaysAvailable") == true
            or (round.phase == "SHIFT" and (emergencyRepair or (round.activeTasks[id] == true and round.tasks[id] ~= true)))
        if id == "generator" and generatorOverheatActive then enabled = false end
        if id == "generatorOverheatGuide" then
            enabled = round.phase == "SHIFT" and generatorOverheatActive and generatorOverheatStage == 0
        elseif id == "generatorOverheatStop" then
            enabled = round.phase == "SHIFT" and generatorOverheatActive and generatorOverheatStage == 1
        elseif id == "generatorOverheatClean" then
            enabled = round.phase == "SHIFT" and generatorOverheatActive and generatorOverheatStage == 2
        elseif id == "generatorOverheatRestart" then
            enabled = round.phase == "SHIFT" and generatorOverheatActive and generatorOverheatStage == 4
        end
        prompt.Enabled = enabled
        if id == "generator" then prompt.ActionText = emergencyRepair and "Восстановить питание" or TEXT.actionRepair end
    end
    if gameplay then gameplay:SyncPrompts() end
end

local function scheduleGeneratorOverheat()
    generatorOverheatToken += 1
    local token = generatorOverheatToken
    generatorOverheatActive, generatorOverheatStage = false, 0
    if world then world:SetAttribute("GeneratorOverheated", false) end
    if round.number < 2 then return end -- Keep the first shift as a safe tutorial.
    local delaySeconds = math.random(85, 135)
    local function attemptOverheat()
        if token ~= generatorOverheatToken or round.phase ~= "SHIFT" or generatorOverheatActive then return end
        if not world or world:GetAttribute("PowerState") ~= "ON"
            or world:GetAttribute("EmergencyAlarmActive") == true then
            task.delay(12, attemptOverheat)
            return
        end
        generatorOverheatActive, generatorOverheatStage = true, 0
        world:SetAttribute("GeneratorOverheated", true)
        setTaskPromptsEnabled()
        remote:FireAllClients("Notify", "ПЕРЕГРЕВ ГЕНЕРАТОРА! Подойди к панели и открой диагностику, чтобы узнать порядок обслуживания.")
    end
    task.delay(delaySeconds, attemptOverheat)
end

local function allTasksComplete()
    local count = 0
    for id in pairs(round.activeTasks) do
        if round.tasks[id] then count += 1 end
    end
    return count > 0 and count == round.tasksPerShift
end

completeTask = function(player, taskId)
    if round.phase ~= "SHIFT" then notify(player, TEXT.wait); return false end
    if not profiles[player] or not profiles[player].ready then notify(player, TEXT.profileWait); return false end
    local repairedBlackout = taskId == "generator" and round.eventName == TEXT.blackout
    if repairedBlackout then
        eventToken += 1 -- Cancel the pending blackout timer and any flicker coroutine.
        restoreLighting()
        notify(player, "Питание восстановлено.")
    end
    if taskId == "generator" and (repairedBlackout or (round.activeTasks.generator and not round.tasks.generator)) then startGeneratorMotor() end
    if not round.activeTasks[taskId] then
        if not repairedBlackout then notify(player, TEXT.wait) end
        return repairedBlackout
    end
    if round.tasks[taskId] then
        if not repairedBlackout then notify(player, TEXT.done) end
        return repairedBlackout
    end
    round.tasks[taskId] = true
    if gameplay then gameplay:RegisterContribution(player, "complete_" .. taskId, 3) end
    emitWorldSound("task", player.Character and player.Character:GetPivot().Position, "Задание выполнено")
    local nightBonus = math.min(18, math.max(0, round.number - 1) * 2)
    local taskCashReward = CONFIG.TASK_REWARD + nightBonus
    for _, participant in ipairs(Players:GetPlayers()) do
        if profiles[participant] and profiles[participant].ready and (participant == player or not gameplay or gameplay:IsContributor(participant)) then
            profiles[participant].tasksCompleted += 1
            award(participant, taskCashReward, CONFIG.TASK_XP + math.floor(nightBonus / 2))
        end
    end
    local title = TEXT.taskRestock
    for _, def in ipairs(TASK_DEFS) do if def.id == taskId then title = def.title break end end
    remote:FireAllClients("Notify", TEXT.reward .. title .. ". Награда начислена участникам с полезным вкладом.")
    if allTasksComplete() then
        round.finishWindow = 60
        remote:FireAllClients("Notify", campaign and campaign:HasActiveWork() and "Задания команды готовы. Продолжайте личные контракты до конца смены." or "Основные задания готовы. Заключительная проверка — не больше минуты до конца смены.")
    end
    setTaskPromptsEnabled()
    broadcastState()
    return true
end

restoreLighting = function()
    if world then world:SetAttribute("PowerState", "ON") end
    stopAlarmBeacons()
    setGeneratorState("RUNNING", false)
    emitWorldSound("alarm_stop")
    for _, light in ipairs(lights) do
        if light and light.Parent then
            light.Enabled = true
            local originalColor = originalLightColors[light]
            if originalColor then light.Color = originalColor end
        end
    end
    if colorEffect then
        colorEffect.Brightness = -0.015
        colorEffect.Saturation = -0.07
        colorEffect.Contrast = 0.2
        colorEffect.TintColor = Color3.fromRGB(204, 215, 231)
    end
    Lighting.Brightness = 1.58
    round.eventName = ""
    setTaskPromptsEnabled()
    broadcastState()
end

local function startBlackout(duration)
    if round.phase ~= "SHIFT" then return end
    eventToken += 1
    local token = eventToken
    if generatorOverheatActive then
        generatorOverheatToken += 1
        generatorOverheatActive, generatorOverheatStage = false, 0
        if world then world:SetAttribute("GeneratorOverheated", false) end
    end
    stopAlarmBeacons()
    round.eventName = TEXT.blackout
    if world then world:SetAttribute("PowerState", "OFF") end
    setGeneratorState("OFF", true)
    emitWorldSound("alarm_stop")
    remote:FireAllClients("Notify", TEXT.blackout .. " Резервное питание включится автоматически, если ремонт затянется.")
    emitWorldSound("powerDown", Vector3.new(32, 3, -23), "Питание отключилось")
    for _, light in ipairs(lights) do if light and light.Parent then light.Enabled = false end end
    Lighting.Brightness = 0.22
    if colorEffect then colorEffect.Brightness = -0.16; colorEffect.Saturation = -0.4 end
    if gameplay then gameplay:OnBlackout() end
    setTaskPromptsEnabled()
    broadcastState()
    task.delay(duration, function()
        if eventToken == token and round.phase == "SHIFT" then restoreLighting(); startGeneratorMotor(); emitWorldSound("powerOn", Vector3.new(32, 3, -23), "Резервное питание восстановлено") end
    end)
end

local function startFalseAlarm(duration)
    eventToken += 1
    local token = eventToken
    duration = math.clamp(tonumber(duration) or 8, 2, 18)
    round.eventName = TEXT.falseAlarm
    if world then world:SetAttribute("EmergencyAlarmActive", true) end
    generatorWarningToken += 1
    generatorWarningActive = false
    emitWorldSound("alarm_start", nil, "Тревога системы охраны", nil, {duration = duration})
    remote:FireAllClients("Notify", TEXT.falseAlarm)
    local oldTint = colorEffect and colorEffect.TintColor
    broadcastState()
    task.spawn(function()
        local started = os.clock()
        while eventToken == token and round.phase == "SHIFT" and os.clock() - started < duration do
            local elapsed = os.clock() - started
            for _, beacon in ipairs(alarmBeacons) do
                if beacon.model and beacon.model.Parent then
                    local sweep = 0.5 + 0.5 * math.sin(elapsed * 2.4 + beacon.phase)
                    local flash = math.max(0, math.sin(elapsed * math.pi * 2.25 + beacon.phase)) ^ 1.8
                    beacon.rotor.CFrame = CFrame.new(beacon.position + Vector3.new(0, 0.58, 0)) * CFrame.Angles(0, elapsed * 5.4 + beacon.phase, 0)
                    beacon.sweep.Brightness = 1.4 + 2.8 * sweep
                    beacon.glow.Brightness = 0.25 + 2.2 * flash
                    beacon.dome.Transparency = 0.34 - 0.18 * flash
                    beacon.dome.Color = Color3.fromRGB(255, 35 + math.floor(22 * (1 - flash)), 30)
                    beacon.rotor.Color = Color3.fromRGB(255, 75 + math.floor(30 * (1 - sweep)), 55)
                end
            end
            if colorEffect then
                local pulse = 0.5 + 0.5 * math.sin(elapsed * math.pi * 2.25)
                colorEffect.TintColor = Color3.fromRGB(255, 225 - math.floor(55 * pulse), 220 - math.floor(45 * pulse))
            end
            task.wait(0.045)
        end
        if eventToken == token then
            if round.phase == "SHIFT" then
                if colorEffect and oldTint then colorEffect.TintColor = oldTint end
                restoreLighting()
            else
                stopAlarmBeacons()
            end
        end
    end)
end

local function startLightFlicker(duration)
    if round.phase ~= "SHIFT" then return end
    eventToken += 1
    local token = eventToken
    stopAlarmBeacons()
    emitWorldSound("alarm_stop")
    round.eventName = TEXT.flicker
    setTaskPromptsEnabled()
    remote:FireAllClients("NS36Visual", {kind = "flicker", duration = duration})
    emitWorldSound("flicker", Vector3.new(0, 14, 0), "Короткие перебои освещения")
    broadcastState()
    task.delay(duration, function()
        if eventToken == token and round.phase == "SHIFT" then round.eventName = ""; broadcastState() end
    end)
end

local MONSTER_TYPES = {
    {name="THE WATCHER",speed=12.0,color=Color3.fromRGB(15,18,26),eye=Color3.fromRGB(255,54,54),minNight=1,rig="watcher"},
    {name="THE RUNNER",speed=16.5,color=Color3.fromRGB(28,14,17),eye=Color3.fromRGB(255,125,50),minNight=1,rig="runner"},
    {name="THE SHADE",speed=11.5,color=Color3.fromRGB(8,11,20),eye=Color3.fromRGB(125,160,255),minNight=1,rig="shade"},
    -- New archetypes begin after players have learned normal pursuit.
    {name="THE CRAWLER",speed=13.0,color=Color3.fromRGB(17,26,24),eye=Color3.fromRGB(115,237,171),minNight=3,rig="crawler"},
    {name="THE IMITATOR",speed=11.3,color=Color3.fromRGB(39,39,36),eye=Color3.fromRGB(212,221,184),minNight=4,rig="imitator"},
}

local function clearMonster()
    if threat then threat:Stop() end
    monsterToken += 1
    if monsterModel then monsterModel:Destroy(); monsterModel = nil end
    round.monsterActive = false
end

local function monsterPart(model, name, size, position, color, shape)
    local part = Instance.new("Part")
    part.Name = name
    part.Size = size
    part.Position = position
    part.Anchored = true
    part.CanCollide = false
    part.CanTouch = false
    part.CanQuery = false
    part.Color = color
    part.Material = Enum.Material.SmoothPlastic
    if shape then part.Shape = shape end
    part.Parent = model
    return part
end

local function spawnMonster()
    if monsterModel or round.phase ~= "SHIFT" or not threat then return false end
    monsterToken += 1
    local myToken = monsterToken
    local available = {}
    for _,kind in ipairs(MONSTER_TYPES) do
        if round.number >= kind.minNight then table.insert(available,kind) end
    end
    local variant=available[math.random(1,#available)]
    local model = Instance.new("Model")
    model.Name = variant.name:gsub(" ", "_")
    model.Parent = world
    -- These anchors sit in clear aisles. Never materialize directly on a player.
    local spawnPoints = {
        Vector3.new(-18, 4.2, -45), Vector3.new(-32, 4.2, -20),
        Vector3.new(0, 4.2, 5), Vector3.new(60, 4.2, 0),
    }
    for _, point in ipairs(locations and locations.spawnPoints or {}) do table.insert(spawnPoints, point) end
    -- Crawlers begin in the underground service wing; never spawn in front of someone.
    if variant.rig=="crawler" and locations then
        spawnPoints = table.clone(locations.spawnPoints)
    end
    local base = threat:ChooseSpawn(spawnPoints)
    if not base then model:Destroy(); return false end
    round.monsterActive = true
    local monsterDuration = math.min(82, 52 + math.max(0, round.number - 1) * 3)
    local rigParts = {}
    local function rigPart(name, size, offset, color, shape, material, rotation, kind)
        local part = monsterPart(model, name, size, base + offset, color or variant.color, shape)
        part.Material = material or Enum.Material.Slate
        part.CastShadow = true
        local rigOffset=offset
        if variant.rig=="crawler" then
            -- Floor contact remains at root.Y-4.1; head/torso stay noticeably lower.
            rigOffset=Vector3.new(offset.X*1.13,offset.Y*.65-1.25,offset.Z*1.1)
        end
        local localCFrame = CFrame.new(rigOffset) * (rotation or CFrame.new())
        part.CFrame = CFrame.new(base) * localCFrame
        table.insert(rigParts, {part = part, localCFrame = localCFrame, kind = kind})
        return part
    end
    local root = monsterPart(model, "Root", Vector3.new(1, 1, 1), base, variant.color)
    root.Transparency = 1
    root.CanQuery = false
    model.PrimaryPart = root

    -- Organic, hunched silhouette made from layered forms rather than six rigid cuboids.
    rigPart("TorsoMass", Vector3.new(2.15, 3.65, 1.48), Vector3.new(0, 0, 0), Color3.fromRGB(18, 21, 27), Enum.PartType.Ball, Enum.Material.Slate, CFrame.Angles(math.rad(8), 0, 0), "torso")
    rigPart("ShoulderMass", Vector3.new(3.25, 1.3, 1.55), Vector3.new(0, 1.15, 0.02), Color3.fromRGB(12, 15, 21), Enum.PartType.Ball, Enum.Material.Slate, CFrame.Angles(math.rad(-8), 0, 0), "shoulders")
    rigPart("Neck", Vector3.new(1.35, 0.82, 0.82), Vector3.new(0, 2.05, -0.03), Color3.fromRGB(14, 17, 22), Enum.PartType.Cylinder, Enum.Material.Slate, CFrame.Angles(0, 0, math.rad(90)), "neck")
    local head = rigPart("Head", Vector3.new(1.78, 2.05, 1.48), Vector3.new(0, 2.88, -0.18), Color3.fromRGB(12, 15, 21), Enum.PartType.Ball, Enum.Material.Slate, CFrame.Angles(math.rad(-9), 0, 0), "head")
    local jaw = rigPart("LowerJaw", Vector3.new(1.2, 0.62, 0.78), Vector3.new(0, 2.12, -0.72), Color3.fromRGB(5, 7, 11), Enum.PartType.Ball, Enum.Material.Slate, CFrame.Angles(math.rad(-12), 0, 0), "jaw")
    for _, side in ipairs({-1, 1}) do
        rigPart("EyeSocket", Vector3.new(0.52, 0.38, 0.18), Vector3.new(side * 0.48, 3.02, -0.91), Color3.fromRGB(3, 4, 7), Enum.PartType.Ball, Enum.Material.SmoothPlastic, nil, "face")
        local eye = rigPart("Eye", Vector3.new(0.19, 0.15, 0.08), Vector3.new(side * 0.48, 3.02, -1.02), variant.eye, Enum.PartType.Ball, Enum.Material.Neon, nil, "face")
        local eyeGlow = Instance.new("PointLight")
        eyeGlow.Color = variant.eye
        eyeGlow.Brightness = 0.75
        eyeGlow.Range = 5
        eyeGlow.Parent = eye
        rigPart("CheekBone", Vector3.new(0.48, 0.72, 0.42), Vector3.new(side * 0.62, 2.48, -0.48), Color3.fromRGB(20, 23, 28), Enum.PartType.Ball, Enum.Material.Slate, nil, "face")
        rigPart("Shoulder", Vector3.new(1.25, 1.45, 1.2), Vector3.new(side * 1.45, 1.05, 0.04), Color3.fromRGB(12, 15, 20), Enum.PartType.Ball, Enum.Material.Slate, CFrame.Angles(0, 0, math.rad(side * 12)), side == -1 and "shoulderL" or "shoulderR")
        rigPart("UpperArm", Vector3.new(2.1, 0.7, 0.72), Vector3.new(side * 1.62, -0.05, -0.02), Color3.fromRGB(17, 20, 26), Enum.PartType.Cylinder, Enum.Material.Slate, CFrame.Angles(0, 0, math.rad(90)), side == -1 and "armL" or "armR")
        rigPart("Forearm", Vector3.new(1.95, 0.58, 0.6), Vector3.new(side * 1.78, -1.42, -0.18), Color3.fromRGB(11, 14, 20), Enum.PartType.Cylinder, Enum.Material.Slate, CFrame.Angles(0, 0, math.rad(90)), side == -1 and "forearmL" or "forearmR")
        rigPart("Hand", Vector3.new(0.72, 0.68, 0.6), Vector3.new(side * 1.82, -2.28, -0.28), Color3.fromRGB(8, 10, 15), Enum.PartType.Ball, Enum.Material.Slate, nil, side == -1 and "handL" or "handR")
        for claw = 1, 4 do
            local x = side * (1.58 + claw * 0.16)
            rigPart("FingerClaw", Vector3.new(0.72, 0.13, 0.14), Vector3.new(x, -2.72, -0.52 - (claw % 2) * 0.12), Color3.fromRGB(4, 5, 8), Enum.PartType.Cylinder, Enum.Material.Slate, CFrame.Angles(math.rad(-15), 0, math.rad(90)), "claw")
        end
        rigPart("Thigh", Vector3.new(1.85, 0.92, 0.95), Vector3.new(side * 0.66, -2.05, 0.02), Color3.fromRGB(13, 16, 22), Enum.PartType.Cylinder, Enum.Material.Slate, CFrame.Angles(0, 0, math.rad(90)), side == -1 and "legL" or "legR")
        rigPart("Shin", Vector3.new(1.55, 0.66, 0.7), Vector3.new(side * 0.68, -3.02, -0.08), Color3.fromRGB(9, 12, 18), Enum.PartType.Cylinder, Enum.Material.Slate, CFrame.Angles(0, 0, math.rad(90)), side == -1 and "shinL" or "shinR")
        rigPart("Foot", Vector3.new(0.82, 0.5, 1.35), Vector3.new(side * 0.68, -3.72, -0.28), Color3.fromRGB(5, 7, 11), Enum.PartType.Ball, Enum.Material.Slate, nil, side == -1 and "footL" or "footR")
        rigPart("BackSpine", Vector3.new(0.34, 1.05, 0.34), Vector3.new(side * 0.78, 1.62, 0.78), Color3.fromRGB(5, 7, 11), Enum.PartType.Ball, Enum.Material.CorrodedMetal, CFrame.Angles(math.rad(22), 0, math.rad(side * 12)), "spine")
    end
    for rib = 1, 4 do
        local y = 0.72 - rib * 0.54
        rigPart("RibArc", Vector3.new(1.82 - rib * 0.08, 0.14, 0.16), Vector3.new(0, y, -0.7), Color3.fromRGB(48, 53, 58), Enum.PartType.Cylinder, Enum.Material.CorrodedMetal, nil, "rib")
    end
    for tooth = 1, 4 do
        rigPart("Teeth", Vector3.new(0.13, 0.24, 0.12), Vector3.new(-0.36 + tooth * 0.24, 2.16, -1.08), Color3.fromRGB(190, 187, 167), Enum.PartType.Ball, Enum.Material.SmoothPlastic, nil, "face")
    end
    for _, side in ipairs({-1, 1}) do
        rigPart("WorkCoat" .. side, Vector3.new(1.15, 3.15, 0.16), Vector3.new(side * .63, -.22, -.78), Color3.fromRGB(36, 43, 40), nil, Enum.Material.Fabric, CFrame.Angles(0, 0, side * .08), "coat")
        rigPart("TornHem" .. side, Vector3.new(1.05, 1.3, .13), Vector3.new(side * .67, -2.1, -.68), Color3.fromRGB(25, 32, 31), nil, Enum.Material.Fabric, CFrame.Angles(.18, 0, side * .1), "coat")
    end
    rigPart("BrokenAntenna", Vector3.new(.08, 1.55, .08), Vector3.new(-1.2, 2.4, .25), Color3.fromRGB(93, 100, 95), nil, Enum.Material.Metal, CFrame.Angles(0, 0, .27), "antenna")
    if variant.rig=="imitator" then
        rigPart("EmployeeBadge",Vector3.new(.68,.38,.08),Vector3.new(.6,.68,-.91),Color3.fromRGB(207,196,161),nil,Enum.Material.Metal,nil,"badge")
        rigPart("BadgeStripe",Vector3.new(.57,.09,.1),Vector3.new(.6,.7,-.99),Color3.fromRGB(121,20,28),nil,Enum.Material.Neon,nil,"badge")
        rigPart("DistortedCapBrim",Vector3.new(1.95,.13,.88),Vector3.new(0,3.82,-.58),Color3.fromRGB(46,49,44),nil,Enum.Material.Fabric,CFrame.Angles(-.11,0,0),"cap")
        rigPart("NameTag",Vector3.new(.92,.12,.08),Vector3.new(-.52,.42,-.92),Color3.fromRGB(228,223,209),nil,Enum.Material.SmoothPlastic,nil,"badge")
    elseif variant.rig=="crawler" then
        for _,side in ipairs({-1,1}) do
            rigPart("GroundClaw",Vector3.new(.75,.15,.16),Vector3.new(side*1.92,-3.5,-1.6),Color3.fromRGB(140,154,123),Enum.PartType.Cylinder,Enum.Material.Metal,CFrame.Angles(0,0,math.rad(90)),"claw")
        end
        rigPart("DorsalSpine",Vector3.new(.2,1.8,.2),Vector3.new(0,.45,.88),Color3.fromRGB(83,112,93),nil,Enum.Material.CorrodedMetal,CFrame.Angles(.3,0,0),"spine")
    end
    local chestCore = rigPart("ChestCore", Vector3.new(0.38, 0.5, 0.12), Vector3.new(0, 0.45, -0.86), variant.eye, Enum.PartType.Ball, Enum.Material.Neon, nil, "core")
    local coreLight = Instance.new("PointLight")
    coreLight.Color = variant.eye
    coreLight.Brightness = 0.28
    coreLight.Range = 6
    coreLight.Parent = chestCore

    monsterModel = model
    model:SetAttribute("Archetype", variant.rig)
    -- The hunt warning is global; the spawn glimpse is only for nearby players.
    for _,player in ipairs(Players:GetPlayers()) do
        local pivot=player.Character and player.Character:FindFirstChild("HumanoidRootPart")
        if pivot and (pivot.Position-root.Position).Magnitude<35 then
            remote:FireClient(player,"Scare",{name=variant.name})
        end
    end
    emitWorldSound(variant.rig=="crawler" and "crawler_scrape" or variant.rig=="imitator" and "mimic_voice" or "monster_notice",
        root.Position,"Что-то появилось среди стеллажей")
    broadcastState()

    threat:Start(model, root, variant, rigParts, monsterDuration)
    return true
end

local function giveFlashlight(player)
    local backpack = player:FindFirstChildOfClass("Backpack") or player:WaitForChild("Backpack", 5)
    if not backpack then return end
    if backpack:FindFirstChild("NightShiftFlashlight") or (player.Character and player.Character:FindFirstChild("NightShiftFlashlight")) then return end
    local tool = Instance.new("Tool")
    tool.Name = "NightShiftFlashlight"
    tool.ToolTip = "F - toggle flashlight"
    tool.RequiresHandle = true
    tool.CanBeDropped = false
    tool.Parent = backpack
    local handle = Instance.new("Part")
    handle.Name = "Handle"
    handle.Size = Vector3.new(0.48, 0.48, 2.15)
    handle.Color = Color3.fromRGB(28, 35, 42)
    handle.Material = Enum.Material.Metal
    handle.Reflectance = 0.08
    handle.CanCollide = false
    handle.CanTouch = false
    handle.Massless = true
    handle.Parent = tool
    local lens = Instance.new("Part")
    lens.Name = "Lens"
    lens.Size = Vector3.new(0.4, 0.4, 0.16)
    lens.Color = Color3.fromRGB(204, 224, 242)
    lens.Material = Enum.Material.Glass
    lens.Reflectance = 0.18
    lens.CanCollide = false
    lens.CanTouch = false
    lens.Massless = true
    lens.CFrame = handle.CFrame * CFrame.new(0, 0, -1)
    lens.Parent = tool
    local weld = Instance.new("WeldConstraint")
    weld.Part0 = handle
    weld.Part1 = lens
    weld.Parent = handle
    local spot = Instance.new("SpotLight")
    spot.Name = "FlashlightBeam"
    spot.Face = Enum.NormalId.Front
    spot.Color = Color3.fromRGB(218, 232, 248)
    spot.Brightness = 3.15
    spot.Range = 54
    spot.Angle = 50
    spot.Shadows = true
    spot.Enabled = false
    spot.Parent = handle
    local fill = Instance.new("SpotLight")
    fill.Name = "FlashlightFill"
    fill.Face = Enum.NormalId.Front
    fill.Color = Color3.fromRGB(185, 210, 236)
    fill.Brightness = 0.48
    fill.Range = 25
    fill.Angle = 78
    fill.Shadows = false
    fill.Enabled = false
    fill.Parent = handle
    local point = Instance.new("PointLight")
    point.Name = "FlashlightGlow"
    point.Color = Color3.fromRGB(206, 226, 248)
    point.Brightness = 0.28
    point.Range = 7
    point.Enabled = false
    point.Parent = handle
    tool.Unequipped:Connect(function()
        spot.Enabled = false
        local fill = handle:FindFirstChild("FlashlightFill")
        if fill then fill.Enabled = false end
        point.Enabled = false
        if player.Parent == Players then remote:FireClient(player, "FlashlightState", false) end
    end)
    tool.Equipped:Connect(function()
        if player.Parent == Players then remote:FireClient(player, "FlashlightState", spot.Enabled) end
    end)
end

local function setFlashlight(player, enabled)
    local profile = profiles[player]
    if not profile or not profile.ready then notify(player, TEXT.profileWait); return end
    local character = player.Character
    local tool = character and character:FindFirstChild("NightShiftFlashlight")
    local handle = tool and tool:FindFirstChild("Handle")
    local spot = handle and handle:FindFirstChild("FlashlightBeam")
    local fill = handle and handle:FindFirstChild("FlashlightFill")
    local point = handle and handle:FindFirstChild("FlashlightGlow")
    if not spot or not point then notify(player, TEXT.flashEquip); return end
    if enabled and (player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned")) then notify(player, "Выйди из укрытия, чтобы включить фонарь."); return end
    if enabled and (profile.battery or 0) <= 0 then notify(player, TEXT.flashEmpty); return end
    spot.Enabled = enabled
    if fill then fill.Enabled = enabled end
    point.Enabled = enabled
    remote:FireClient(player, "FlashlightState", enabled)
end

restoreHidden = function(player)
    local saved = hiddenState[player]
    hiddenState[player] = nil
    player:SetAttribute("NightShiftHidden", false)
    if not saved then return end
    if saved.locker and saved.locker.Parent then emitWorldSound("locker", saved.locker.Position, "Открывается укрытие") end
    if saved.locker and saved.locker.Parent and saved.locker:GetAttribute("OccupiedBy") == player.UserId then
        saved.locker:SetAttribute("OccupiedBy", nil)
    end
    local character = saved.character
    if character and character.Parent and character == player.Character and saved.root and saved.root.Parent then
        character:PivotTo(saved.exitCFrame)
        saved.root.AssemblyLinearVelocity = Vector3.zero
        saved.root.AssemblyAngularVelocity = Vector3.zero
        saved.root.Anchored = saved.anchored
    end
    for part, values in pairs(saved.parts) do
        if part and part.Parent then
            part.Transparency = values.transparency
            if values.canCollide ~= nil then part.CanCollide = values.canCollide end
        end
    end
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if humanoid then
        humanoid.AutoRotate = saved.autoRotate
        local profile = profiles[player]
        humanoid.WalkSpeed = profile and (16 + profile.speedLevel * 2) or saved.walkSpeed
        humanoid.JumpPower = saved.jumpPower
        humanoid.JumpHeight = saved.jumpHeight
    end
end

local function applyWalkSpeed(player)
    local profile = profiles[player]
    local character = player.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if not profile or not humanoid then return end
    if player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") then humanoid.WalkSpeed = 0; humanoid.JumpPower = 0; humanoid.JumpHeight = 0; return end
    local speed = 16 + profile.speedLevel * 2
    if player:GetAttribute("NightShiftCarrying") then speed = math.max(12, speed - 3) end
    if player:GetAttribute("NightShiftSprinting") and (profile.stamina or 0) > 0 then speed += 8 end
    humanoid.WalkSpeed = speed
end

local function onPlayerAdded(player)
    if #Players:GetPlayers() > CONFIG.MAX_PLAYERS then
        player:Kick("Этот сервер рассчитан максимум на 6 сотрудников.")
        return
    end
    local spawnLocation = world and world:FindFirstChild("NightShiftSpawn")
    if spawnLocation and spawnLocation:IsA("SpawnLocation") then
        player.RespawnLocation = spawnLocation
    end
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player
    for _, statName in ipairs({"Cash", "Nights", "Level"}) do
        local value = Instance.new("IntValue")
        value.Name = statName
        value.Value = 0
        value.Parent = leaderstats
    end
    player:SetAttribute("NightShiftHidden", false)
    player:SetAttribute("NightShiftSprinting", false)
    player.CharacterRemoving:Connect(function()
        if campaign then campaign:DropItem(player, true) end
        if gameplay then gameplay:DropItem(player, true) end
        if recovery then recovery:OnCharacterRemoving(player) end
        restoreHidden(player)
        remote:FireClient(player, "FlashlightState", false)
    end)
    player.CharacterAdded:Connect(function(character)
        player:SetAttribute("NightShiftDowned", false)
        player:SetAttribute("NightShiftCarrying", nil)
        restoreHidden(player)
        player:SetAttribute("NightShiftHidden", false)
        player:SetAttribute("NightShiftSprinting", false)
        hiddenState[player] = nil
        local humanoid = character:WaitForChild("Humanoid", 8)
        if humanoid then
            humanoid.Died:Connect(function()
                restoreHidden(player)
                if round.phase == "SHIFT" then round.playerCaught[player] = true end
            end)
        end
        task.wait(0.35)
        if player.Parent ~= Players or player.Character ~= character then return end
        giveFlashlight(player)
        applyWalkSpeed(player)
    end)
    task.spawn(function()
        loadProfile(player)
        if player.Parent == Players then
            giveFlashlight(player)
            remote:FireClient(player, "State", makeStatePayload())
            if CONFIG.VIP_GAMEPASS_ID > 0 then
                local ok, owns = pcall(function() return MarketplaceService:UserOwnsGamePassAsync(player.UserId, CONFIG.VIP_GAMEPASS_ID) end)
                if ok and owns and profiles[player] then profiles[player].vip = true; refreshProfile(player) end
            end
        end
    end)
end

local function rateLimit(player, action, interval)
    lastActionAt[player] = lastActionAt[player] or {}
    local now = os.clock()
    local previous = lastActionAt[player][action] or 0
    if now - previous < interval then return false end
    lastActionAt[player][action] = now
    return true
end

local NS36_ACTIONS = {SetPreferences = true, SecondChance = true, ClaimTask = true, DropItem = true,
    Ping = true, ReportAnomaly = true, ServeCustomer = true, TutorialStep = true, SkipTutorial = true, CCTVView = true, CampaignChoice = true, CampaignInteract = true, CampaignAssist = true}
remote.OnServerEvent:Connect(function(player, action, value)
    if typeof(action) ~= "string" then return end
    if action == "GeneratorOverheatStart" then
        if not rateLimit(player, action, 0.5) then return end
        local profile = profiles[player]
        local character = player.Character
        local root = character and character:FindFirstChild("HumanoidRootPart")
        local generator = world and world:FindFirstChild("Generator", true)
        if not profile or not profile.ready or not root or not generator or round.phase ~= "SHIFT"
            or not generatorOverheatActive or generatorOverheatStage ~= 0
            or (root.Position - generator.Position).Magnitude > 12
            or player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") then
            return
        end
        generatorOverheatStage = 1
        setTaskPromptsEnabled()
        notify(player, "Шаг 1/3: останови двигатель. Затем очисти радиатор и дождись охлаждения.")
        return
    end
    if action == "NS36Action" then
        if type(value) ~= "table" or type(value.action) ~= "string" or not NS36_ACTIONS[value.action] then return end
        if not rateLimit(player, "NS36:" .. value.action, value.action == "SetPreferences" and 0.15 or 0.12) then return end
        local profile = profiles[player]
        if not profile or not profile.ready then return end
        if value.action == "SetPreferences" then
            profile.preferences = sanitizePreferences(value.preferences)
            remote:FireClient(player, "Preferences", profile.preferences)
            preferenceSaveTokens[player] = (preferenceSaveTokens[player] or 0) + 1
            local token = preferenceSaveTokens[player]
            task.delay(3, function() if profiles[player] == profile and preferenceSaveTokens[player] == token then saveProfile(player) end end)
        elseif value.action == "SecondChance" then
            if recovery then recovery:SecondChance(player) end
        elseif value.action == "DropItem" then
            if not campaign or not campaign:DropItem(player, true) then
                if gameplay then gameplay:HandleAction(player, value.action, value) end
            end
        elseif value.action == "CampaignChoice" or value.action == "CampaignInteract" or value.action == "CampaignAssist" then
            if campaign then campaign:HandleAction(player, value.action, value) end
        elseif gameplay then gameplay:HandleAction(player, value.action, value) end
        return
    end
    if action == "RequestState" then
        if not rateLimit(player, action, 0.5) then return end
        remote:FireClient(player, "State", makeStatePayload())
        if gameplay then gameplay:SendState(player) end
        if campaign then campaign:SendState(player) end
        if incidents then incidents:SendState(player) end
        if locations then
            local rooms = {}
            for _, room in ipairs(locations.rooms or {}) do
                table.insert(rooms, {id = room.id, label = room.label, center = room.center, floorY = room.floorY, bounds = room.bounds, hint = room.hint})
            end
            remote:FireClient(player, "WorldGuide", {rooms = rooms})
        end
        if profiles[player] then remote:FireClient(player, "Preferences", sanitizePreferences(profiles[player].preferences)) end
        refreshProfile(player)
        refreshVitals(player)
        return
    end
    if action == "ExitHide" then
        if not rateLimit(player, action, 0.25) then return end
        if player:GetAttribute("NightShiftHidden") then restoreHidden(player); notify(player, TEXT.hideOut) end
        return
    end
    if action == "Sprint" then
        if typeof(value) ~= "boolean" then return end
        -- Always accept release, even when it follows the press in the same frame.
        if value and not rateLimit(player, action, 0.08) then return end
        local profile = profiles[player]
        if not profile or not profile.ready then return end
        local wantsSprint = value and round.phase == "SHIFT" and not player:GetAttribute("NightShiftHidden") and not player:GetAttribute("NightShiftDowned") and (profile.stamina or 0) > 2
        player:SetAttribute("NightShiftSprinting", wantsSprint)
        applyWalkSpeed(player)
        return
    end
    if action == "Flashlight" then
        if not rateLimit(player, action, 0.18) then return end
        local character = player.Character
        local tool = character and character:FindFirstChild("NightShiftFlashlight")
        local handle = tool and tool:FindFirstChild("Handle")
        local spot = handle and handle:FindFirstChild("FlashlightBeam")
        setFlashlight(player, not (spot and spot.Enabled))
        return
    end
    if action == "BuyUpgrade" then
        if not rateLimit(player, action, 0.35) then return end
        local profile = profiles[player]
        if not profile or not profile.ready or typeof(value) ~= "string" then return end
        local costs = UPGRADE_COSTS[value]
        if not costs then return end
        local levelKey = string.lower(string.sub(value, 1, 1)) .. string.sub(value, 2) .. "Level"
        local level = profile[levelKey]
        if type(level) ~= "number" then return end
        local cost = costs[level + 1]
        if not cost then notify(player, "Это улучшение уже максимальное."); return end
        if profile.cash < cost then notify(player, TEXT.noCash); return end
        profile.cash -= cost
        profile[levelKey] += 1
        if value == "Speed" then applyWalkSpeed(player) end
        if value == "Stamina" then profile.stamina = maxStamina(profile) end
        if value == "Battery" then profile.battery = maxBattery(profile) end
        refreshProfile(player)
        refreshVitals(player)
        emitWorldSound("purchase", nil, "Улучшение приобретено", player)
        notify(player, TEXT.upgradeOK)
        saveProfile(player)
        return
    end
    if action == "ClaimDaily" then
        if not rateLimit(player, action, 1) then return end
        local profile = profiles[player]
        if not profile or not profile.ready then notify(player, TEXT.profileWait); return end
        if os.time() - (profile.lastDaily or 0) < DAILY_COOLDOWN then notify(player, TEXT.dailyWait); refreshProfile(player); return end
        profile.lastDaily = os.time()
        local reward = 250 + profile.level * 15
        award(player, reward, 40)
        emitWorldSound("purchase", nil, "Награда получена", player)
        notify(player, TEXT.dailyOK .. " +" .. reward)
        saveProfile(player)
        return
    end
    if action == "PromptPass" then
        if not rateLimit(player, action, 1) then return end
        if value == "VIP" and CONFIG.VIP_GAMEPASS_ID > 0 then
            remote:FireClient(player, "PromptPass", CONFIG.VIP_GAMEPASS_ID)
        else
            notify(player, TEXT.passMissing)
        end
        return
    end
    if action == "PromptProduct" then
        if not rateLimit(player, action, 1) then return end
        if value == "Cash" and CONFIG.CASH_PRODUCT_ID > 0 then
            remote:FireClient(player, "PromptProduct", CONFIG.CASH_PRODUCT_ID)
        else
            notify(player, TEXT.passMissing)
        end
        return
    end
end)

MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(player, gamePassId, wasPurchased)
    if wasPurchased and gamePassId == CONFIG.VIP_GAMEPASS_ID and profiles[player] then
        profiles[player].vip = true
        refreshProfile(player)
        notify(player, "VIP activated! +15% rewards")
        saveProfile(player)
    end
end)

local productRewards = {}
if CONFIG.CASH_PRODUCT_ID > 0 then productRewards[CONFIG.CASH_PRODUCT_ID] = 750 end
MarketplaceService.ProcessReceipt = function(receiptInfo)
    local player = Players:GetPlayerByUserId(receiptInfo.PlayerId)
    if not player then return Enum.ProductPurchaseDecision.NotProcessedYet end
    local reward = productRewards[receiptInfo.ProductId]
    if not reward then
        warn("NightShift: unconfigured Developer Product receipt " .. tostring(receiptInfo.ProductId))
        return Enum.ProductPurchaseDecision.NotProcessedYet
    end
    local profile = profiles[player]
    if not profile or not profile.ready or not profile.loaded or not store or saveLocks[player] then
        return Enum.ProductPurchaseDecision.NotProcessedYet
    end
    local purchaseId = tostring(receiptInfo.PurchaseId)
    if profile.processedReceipts[purchaseId] then return Enum.ProductPurchaseDecision.PurchaseGranted end
    local payload = profileSnapshot(profile)
    payload.cash = math.clamp(payload.cash + reward, 0, 2000000000)
    payload.processedReceipts[purchaseId] = true
    saveLocks[player] = true
    local ok, updated = pcall(function()
        return store:UpdateAsync("u_" .. player.UserId, function(old)
            if type(old) == "table" and type(old.processedReceipts) == "table" then
                if old.processedReceipts[purchaseId] then return old end
                for receiptKey, receiptValue in pairs(old.processedReceipts) do
                    if receiptValue == true then payload.processedReceipts[receiptKey] = true end
                end
            end
            return payload
        end)
    end)
    if not ok or type(updated) ~= "table" or type(updated.processedReceipts) ~= "table" or not updated.processedReceipts[purchaseId] then
        saveLocks[player] = nil
        warn("NightShift receipt update failed for " .. player.UserId .. ": " .. tostring(updated))
        return Enum.ProductPurchaseDecision.NotProcessedYet
    end
    -- Awards/upgrades may have changed while UpdateAsync yielded. Add only this grant.
    profile.cash = math.clamp(profile.cash + reward, 0, 2000000000)
    for receiptKey, granted in pairs(updated.processedReceipts) do
        if granted == true then profile.processedReceipts[receiptKey] = true end
    end
    saveLocks[player] = nil
    if player.Parent == Players then
        updateStats(player)
        refreshProfile(player)
        notify(player, "Покупка получена: +" .. reward .. " наличных")
    end

    return Enum.ProductPurchaseDecision.PurchaseGranted
end

-- Build the complete map before the first player can spawn.
local worldBuildOk, worldBuildError = pcall(buildWorld)
if not worldBuildOk then
    warn("[NIGHT SHIFT 4.6] MAP BUILD FAILED: " .. tostring(worldBuildError))
    error("[NIGHT SHIFT 4.6] World bootstrap failed; see Output for details.")
end
local Locations = require(script.Parent:WaitForChild("NightShift_Locations"))
locations = Locations.Build({
    world = world, makePart = makePart, addTextSign = addTextSign, addPrompt = addPrompt, toggleHide = toggleHide,
    registerLight = function(light) table.insert(lights, light); originalLightColors[light] = light.Color end,
})
makeDetail("BasementAlarmBeaconMount", Vector3.new(0.35, 1.0, 1.5), Vector3.new(7, -1.5, -141), Color3.fromRGB(76, 86, 91), Enum.Material.Metal)
addRotatingAlarmBeacon("BasementAlarmBeacon", Vector3.new(7, -2.1, -141))
world:SetAttribute("LayoutVersion", "4.6")
-- The map is complete before feature modules receive its real interactables.
do
    local Props = require(script.Parent:WaitForChild("NightShift_Props"))
    local Exploration = require(script.Parent:WaitForChild("NightShift_Exploration"))
    local Haunts = require(script.Parent:WaitForChild("NightShift_Haunts"))
    local Incidents = require(script.Parent:WaitForChild("NightShift_Incidents"))
    local Gameplay = require(script.Parent:WaitForChild("NightShift_Gameplay"))
    local Threat = require(script.Parent:WaitForChild("NightShift_Threat"))
    local Recovery = require(script.Parent:WaitForChild("NightShift_Recovery"))
    local Director = require(script.Parent:WaitForChild("NightShift_Director"))
    Campaign = require(script.Parent:WaitForChild("NightShift_Campaign"))
    local random = Random.new()
    local function eligible(player)
        local profile = profiles[player]
        local human = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
        return profile ~= nil and profile.ready == true and human ~= nil and human.Health > 0
            and not player:GetAttribute("NightShiftDowned") and not player:GetAttribute("NightShiftHidden")
    end
    gameplay = Gameplay.new({
        props = Props,
        Players = Players, Workspace = Workspace, remote = remote, notify = notify,
        getProfile = function(player) return profiles[player] end,
        getRound = function() return round end,
        completeTask = completeTask, restoreLighting = restoreLighting,
        addPrompt = addPrompt, makePart = makePart, makeDetail = makeDetail, addTextSign = addTextSign,
        signFont = Enum.Font.GothamBold,
        clock = os.clock, random = random, randomInteger = function(a, b) return random:NextInteger(a, b) end, award = award,
        isPlayerEligible = eligible, isBlackout = function() return round.eventName == TEXT.blackout end,
        onNoise = emitNoise, onSound = emitWorldSound, onChanged = broadcastState,
        hasThreatNear = function(position, radius)
            return monsterModel ~= nil and monsterModel.PrimaryPart ~= nil
                and (monsterModel.PrimaryPart.Position - position).Magnitude <= radius
        end,
        onThreat = function(_, position)
            emitNoise(position, "customer_error", 60)
            emitWorldSound("anomaly", position, "Из кассы слышится резкий сигнал")
            if director then director:RequestThreat() end
        end,
        applyCarry = function(player, kind)
            player:SetAttribute("NightShiftCarrying", kind)
            player:SetAttribute("NightShiftSprinting", false)
            applyWalkSpeed(player)
        end,
    })
    gameplay:Build(world)
    exploration = Exploration.new({
        Players = Players, Workspace = Workspace, clock = os.clock,
        getProfile = function(player) return profiles[player] end,
        getPower = function() return world:GetAttribute("PowerState") ~= "OFF" end,
        onSound = emitWorldSound, onNoise = emitNoise, notify = notify,
        onInspect = function(player, payload)
            if campaign then
                local state = campaign:GetState(player)
                payload.contractActive = state.active == true
                if state.mission then
                    payload.nextObjective, payload.nextRoom = state.mission.objective, state.mission.location
                end
            end
            remote:FireClient(player, "ExploreResult", payload)
        end,
    })
    exploration:Build(world, locations.stations)
    campaign = Campaign.new({
        props = Props,
        onExplore = function(player, stationId) return exploration:Interact(player, stationId) end,
        Players = Players, Workspace = Workspace, remote = remote, notify = notify, award = award,
        getProfile = function(player) return profiles[player] end, getRound = function() return round end,
        addPrompt = addPrompt, clock = os.clock, onSound = emitWorldSound, onNoise = emitNoise,
        isPlayerEligible = eligible,
        contribute = function(player, kind, amount) gameplay:RegisterContribution(player, kind, amount) end,
        applyCarry = function(player, kind)
            player:SetAttribute("NightShiftCarrying", kind)
            player:SetAttribute("NightShiftSprinting", false)
            applyWalkSpeed(player)
        end,
    })
    campaign:Build(world, locations.stations)
    haunts=Haunts.new({Players=Players,clock=os.clock,random=random,getProfile=function(player)return profiles[player]end,
        getRound=function()return round end,addPrompt=addPrompt,notify=notify,sound=emitWorldSound,noise=emitNoise})
    haunts:Build(world,locations.stations)
    incidents=Incidents.new({Players=Players,remote=remote,clock=os.clock,random=random,
        getProfile=function(player)return profiles[player]end,getRound=function()return round end,
        addPrompt=addPrompt,sound=emitWorldSound,noise=emitNoise,notify=notify,
        notifyAll=function(message)remote:FireAllClients("Notify",message)end,
        onFix=function(player,kind)if gameplay then gameplay:RegisterContribution(player,kind,3)end end,
        pressure=function()if director then director:RequestThreat()end end})
    incidents:Build(world,locations.stations)
    recovery = Recovery.new({
        Players = Players, Workspace = Workspace, remote = remote, notify = notify, clock = os.clock,
        getRound = function() return round end, getProfile = function(player) return profiles[player] end,
        addPrompt = addPrompt, applyWalkSpeed = applyWalkSpeed, setFlashlight = setFlashlight,
        forceExit = restoreHidden, dropCarry = function(player)
            if campaign then campaign:DropItem(player, true) end
            gameplay:DropItem(player, true)
        end,
        contribute = function(player, kind, amount) gameplay:RegisterContribution(player, kind, amount * 2) end,
        award = award, sound = emitWorldSound,
    })
    threat = Threat.new({
        Players = Players, Workspace = Workspace, PathfindingService = PathfindingService,
        clock = os.clock, random = random, notify = notify, sound = emitWorldSound,
        getRound = function() return round end, getWorld = function() return world end,
        getDoors = function() return doorControllers end,
        getPatrolPoints = function() return locations and locations.patrolPoints or {} end,
        cue = function(player, value) remote:FireClient(player, "ThreatSense", value) end,
        getHiddenLocker = function(player) return hiddenState[player] and hiddenState[player].locker end,
        forceExit = restoreHidden, isBlackout = function() return round.eventName == TEXT.blackout end,
        isTargetable = function(player)
            local profile = profiles[player]
            return profile ~= nil and profile.ready and recovery:CanAct(player)
                and os.clock() - (recovery.lastCatch[player] or -100) >= 14
        end,
        onCaught = function(player) return recovery:Catch(player) end,
        onExpired = function(model) if monsterModel == model then clearMonster(); broadcastState() end end,
    })
    director = Director.new({
        clock = os.clock, random = random, getRound = function() return round end,
        spawn = spawnMonster, blackout = startBlackout, alarm = startFalseAlarm, flicker = startLightFlicker,
        warning = function(message) remote:FireAllClients("Notify", message); emitWorldSound("monster_notice", nil, message) end,
        teamStruggling = function()
            local ready, downed = 0, 0
            for _, player in ipairs(Players:GetPlayers()) do
                local profile = profiles[player]
                if profile and profile.ready then
                    ready += 1
                    if player:GetAttribute("NightShiftDowned") then downed += 1 end
                end
            end
            return ready > 0 and downed >= math.ceil(ready / 2)
        end,
        trainingPending = function()
            for _, player in ipairs(Players:GetPlayers()) do
                local profile = profiles[player]
                if profile and profile.ready and not profile.tutorialDone and (profile.tutorialStep or 0) < 2 then return true end
            end
            return false
        end,
        teamSeparated = function()
            local positions = {}
            for _, player in ipairs(Players:GetPlayers()) do
                local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
                if root and eligible(player) then table.insert(positions, root.Position) end
            end
            if #positions < 2 then return false end
            for index, position in ipairs(positions) do
                local nearest = math.huge
                for other, value in ipairs(positions) do if other ~= index then nearest = math.min(nearest, (position - value).Magnitude) end end
                if nearest > 48 then return true end
            end
            return false
        end,
    })
    world:SetAttribute("PowerState", "ON")
    world:SetAttribute("EmergencyAlarmActive", false)
    setGeneratorState("RUNNING", false)

    -- Two fixed supplies are recoverable and outside all circulation paths.
    for index, data in ipairs({
        {position = Vector3.new(36.2, 2.83, 27.9), facing = Vector3.new(0, 0, -1)},
        {position = Vector3.new(16, -10.22, -101.8), facing = Vector3.new(0, 0, 1)},
    }) do
        local _, frame, p = makeFurnitureAssembly("BatterySupply" .. index, data.position, data.facing)
        local box = p("BatterySupply", Vector3.new(1.2, 0.56, 0.8), Vector3.new(), Color3.fromRGB(65, 92, 88), Enum.Material.Metal)
        for x = -1, 1 do
            local cell = p("BatteryCell", Vector3.new(0.3, 0.2, 0.2), Vector3.new(x * 0.3, 0.37, 0), Color3.fromRGB(214, 172, 76), Enum.Material.Metal)
            cell.Shape = Enum.PartType.Cylinder
        end
        p("BatterySignPost", Vector3.new(0.08, 0.55, 0.08), Vector3.new(0, 0.55, 0.3), Color3.fromRGB(112, 128, 135), Enum.Material.Metal)
        local plate = p("BatterySupplySign", Vector3.new(1.8, 0.7, 0.08), Vector3.new(0, 1.05, 0.3), Color3.fromRGB(39, 62, 64), Enum.Material.Metal)
        addTextSign(plate, "БАТАРЕИ\nE · +45", Enum.NormalId.Front, Color3.fromRGB(241, 229, 188))
        addPrompt(box, "Взять батарею", "Запас заряда · 2 за смену", 1.2, function(player)
            if round.phase ~= "SHIFT" then notify(player, "Во время подготовки фонарь заряжается автоматически."); return end
            local profile = profiles[player]
            if not profile or not eligible(player) then return end
            if (batteryUsed[player] or 0) >= 2 then notify(player, "Две запасные батареи этой смены уже использованы."); return end
            if profile.battery >= maxBattery(profile) - 10 then notify(player, "Заряд почти полный. Оставь батарею на потом."); return end
            batteryUsed[player] = (batteryUsed[player] or 0) + 1
            profile.battery = math.min(maxBattery(profile), profile.battery + 45)
            refreshVitals(player)
            emitWorldSound("interact", box.Position, "Батарея заменена", player)
            notify(player, "Заряд +45. Осталось запасных батарей: " .. tostring(2 - batteryUsed[player]))
        end, {distance = 7})
    end
end

setTaskPromptsEnabled()
print("[NIGHT SHIFT 4.6] MAP READY | " .. tostring(#world:GetDescendants()) .. " world objects | max players " .. CONFIG.MAX_PLAYERS .. " | shell present | rooms: retail, stockroom, generator, security, loading dock, cold storage, boiler room, service alley")

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(function(player)
    restoreHidden(player)
    if campaign then campaign:OnPlayerRemoving(player) end
    if exploration then exploration:OnPlayerRemoving(player) end
    if haunts then haunts:OnPlayerRemoving(player) end
    if incidents then incidents:OnPlayerRemoving(player) end
    saveProfile(player, true)
    if gameplay then gameplay:OnPlayerRemoving(player) end
    if recovery then recovery:OnPlayerRemoving(player) end
    batteryUsed[player], lastMovementNoise[player], preferenceSaveTokens[player] = nil, nil, nil
    round.participation[player] = nil
    round.playerCaught[player] = nil
    profiles[player] = nil
    lastHitAt[player] = nil
    lastRecoveryAt[player] = nil
    lastActionAt[player] = nil
    hiddenState[player] = nil
    saveLocks[player] = nil
end)
for _, player in ipairs(Players:GetPlayers()) do onPlayerAdded(player) end

game:BindToClose(function()
    local pending = 0
    for _, player in ipairs(Players:GetPlayers()) do
        pending += 1
        task.spawn(function()
            saveProfile(player, true)
            pending -= 1
        end)
    end
    local deadline = os.clock() + 25
    while pending > 0 and os.clock() < deadline do task.wait(0.1) end
end)


-- Stamina and flashlight battery are server controlled. Client requests cannot set their values.
task.spawn(function()
    local lastVitals = 0
    while true do
        task.wait(0.25)
        if gameplay then gameplay:Tick(0.25) end
        if campaign then campaign:Tick(0.25) end
        if exploration then exploration:Tick(0.25) end
        if haunts then haunts:Tick() end
        if incidents then incidents:Tick() end
        if recovery then recovery:Tick() end
        for _, player in ipairs(Players:GetPlayers()) do
            local profile = profiles[player]
            if profile then
                local maxS = maxStamina(profile)
                local maxB = maxBattery(profile)
                local character = player.Character
                local humanoid = character and character:FindFirstChildOfClass("Humanoid")
                local root = character and character:FindFirstChild("HumanoidRootPart")
                if root and humanoid and humanoid.Health > 0 then
                    local position = root.Position
                    local outsideMap = position.Y < -28 or math.abs(position.X) > 118 or position.Z > 158 or position.Z < -182
                    if outsideMap and (not lastRecoveryAt[player] or os.clock() - lastRecoveryAt[player] >= 2) then
                        lastRecoveryAt[player] = os.clock()
                        restoreHidden(player)
                        local spawn = world and world:FindFirstChild("NightShiftSpawn")
                        local safePosition = spawn and spawn.Position + Vector3.new(0, 4, 0) or Vector3.new(0, 4.2, 25)
                        character:PivotTo(CFrame.new(safePosition))
                        root.AssemblyLinearVelocity = Vector3.zero
                        root.AssemblyAngularVelocity = Vector3.zero
                        player:SetAttribute("NightShiftSprinting", false)
                        applyWalkSpeed(player)
                        notify(player, "Персонаж возвращён ко входу: выход за границы карты. Прогресс смены сохранён.")
                    end
                end
                if round.phase == "SHIFT" and player:GetAttribute("NightShiftSprinting") and not player:GetAttribute("NightShiftHidden") and humanoid and humanoid.MoveDirection.Magnitude > 0.1 then
                    profile.stamina = math.max(0, (profile.stamina or maxS) - 1.25)
                    if profile.stamina <= 0 then
                        player:SetAttribute("NightShiftSprinting", false)
                        applyWalkSpeed(player)
                        notify(player, TEXT.noStamina)
                    end
                else
                    profile.stamina = math.min(maxS, (profile.stamina or maxS) + 0.875)
                end
                if round.phase == "SHIFT" and root and humanoid and not player:GetAttribute("NightShiftHidden") and not player:GetAttribute("NightShiftDowned") and humanoid.MoveDirection.Magnitude > 0.1 then
                    local now = os.clock()
                    if now - (lastMovementNoise[player] or 0) >= 0.9 then
                        lastMovementNoise[player] = now
                        local sprinting = player:GetAttribute("NightShiftSprinting")
                        emitNoise(root.Position, sprinting and "run" or "walk", sprinting and 25 or 8, player)
                    end
                end
                local tool = character and character:FindFirstChild("NightShiftFlashlight")
                local handle = tool and tool:FindFirstChild("Handle")
                local spot = handle and handle:FindFirstChild("FlashlightBeam")
                if spot and spot.Enabled then
                    profile.battery = math.max(0, (profile.battery or maxB) - (round.phase == "SHIFT" and 0.18 or 0))
                    if profile.battery <= 0 then setFlashlight(player, false); notify(player, TEXT.flashEmpty) end
                elseif round.phase ~= "SHIFT" then
                    profile.battery = math.min(maxB, (profile.battery or maxB) + 0.375)
                end
                if os.clock() - lastVitals > 1 then refreshVitals(player) end
            end
        end
        if os.clock() - lastVitals > 1 then lastVitals = os.clock() end
    end
end)

-- Autosave only profiles whose load succeeded; failed reads are never overwritten with defaults.
task.spawn(function()
    while true do
        task.wait(CONFIG.AUTOSAVE_SECONDS)
        for _, player in ipairs(Players:GetPlayers()) do task.spawn(saveProfile, player) end
    end
end)

local function chooseTasks()
    local pool = {}
    round.activeTasks = {}
    round.tasks = {}
    for _, definition in ipairs(TASK_DEFS) do
        round.tasks[definition.id] = false
        if round.number >= (definition.firstNight or 1) then table.insert(pool, definition.id) end
    end
    for i = #pool, 2, -1 do
        local j = math.random(1, i)
        pool[i], pool[j] = pool[j], pool[i]
    end
    round.tasksPerShift = math.min(#pool, round.number >= 5 and 4 or CONFIG.TASKS_PER_SHIFT)
    for i, id in ipairs(pool) do
        if i <= round.tasksPerShift then round.activeTasks[id] = true end
    end
    if round.number == 1 then
        round.activeTasks = {restock = true, generator = true, cctv = true}
        round.tasksPerShift = 3
    end
    local breaker = world and world:FindFirstChild("BasementBreakerPanel", true)
    if breaker then breaker:SetAttribute("Inspected", false) end
    local breakerLamp = world and world:FindFirstChild("BasementBreakerStatusLamp", true)
    if breakerLamp then
        breakerLamp.Color = Color3.fromRGB(235, 65, 48)
        local statusLight = breakerLamp:FindFirstChildOfClass("PointLight")
        if statusLight then statusLight.Color = breakerLamp.Color end
    end
    setTaskPromptsEnabled()
end

task.spawn(function()
    while true do
        clearMonster()
        if director then director:EndShift() end
        if haunts then haunts:EndShift() end
        if incidents then incidents:EndShift() end
        if recovery then recovery:EndShift() end
        eventToken += 1
        generatorOverheatToken += 1
        generatorOverheatActive, generatorOverheatStage = false, 0
        if world then world:SetAttribute("GeneratorOverheated", false) end
        round.phase = "INTERMISSION"
        round.eventName = ""
        round.timeLeft = CONFIG.INTERMISSION_SECONDS
        round.tasks = {}
        round.activeTasks = {}
        round.participation = {}
        round.resultSuccess = false
        restoreLighting()
        for _, player in ipairs(Players:GetPlayers()) do
            restoreHidden(player)
            if profiles[player] then
                player:SetAttribute("NightShiftSprinting", false)
                profiles[player].stamina = maxStamina(profiles[player])
                profiles[player].battery = maxBattery(profiles[player])
                applyWalkSpeed(player)
                refreshVitals(player)
            end
        end
        -- An empty server must not advance to nightmare difficulty before anyone joins.
        while #Players:GetPlayers() == 0 do
            round.number = 0
            task.wait(1)
        end
        round.number += 1
        round.tasksPerShift = round.number >= 5 and 4 or CONFIG.TASKS_PER_SHIFT
        setTaskPromptsEnabled()
        for remaining = CONFIG.INTERMISSION_SECONDS, 1, -1 do
            round.timeLeft = remaining
            broadcastState()
            task.wait(1)
            if #Players:GetPlayers() == 0 then break end
        end

        if #Players:GetPlayers() > 0 then
            chooseTasks()
            round.phase = "SHIFT"
            round.timeLeft = CONFIG.SHIFT_SECONDS
            round.playerCaught = {}
            round.finishWindow = nil
            batteryUsed = {}
            recovery:BeginShift()
            gameplay:BeginShift(round.number, round.activeTasks)
            campaign:BeginShift(round.number)
            director:BeginShift(round.number)
            haunts:BeginShift(round.number)
            incidents:BeginShift(round.number)
            remote:FireAllClients("Notify", TEXT.shiftStart)
            setTaskPromptsEnabled()
            scheduleGeneratorOverheat()
            local deadline = os.clock() + CONFIG.SHIFT_SECONDS
            local finishApplied = false
            while os.clock() < deadline and #Players:GetPlayers() > 0 do
                if round.finishWindow and not finishApplied and (not campaign or not campaign:HasActiveWork()) then
                    deadline = math.min(deadline, os.clock() + round.finishWindow)
                    finishApplied = true
                end
                round.timeLeft = math.max(0, math.ceil(deadline - os.clock()))
                for _, participant in ipairs(Players:GetPlayers()) do
                    if profiles[participant] and profiles[participant].ready then
                        round.participation[participant] = (round.participation[participant] or 0) + 1
                    end
                end
                director:Tick()
                broadcastState()
                task.wait(1)
            end

            clearMonster()
            director:EndShift()
            haunts:EndShift()
            incidents:EndShift()
            recovery:EndShift()
            eventToken += 1
            round.phase = "RESULTS"
            round.timeLeft = CONFIG.RESULTS_SECONDS
            round.resultSuccess = allTasksComplete()
            restoreLighting()
            setTaskPromptsEnabled()
            local completed = 0
            for id in pairs(round.activeTasks) do if round.tasks[id] then completed += 1 end end
            for _, player in ipairs(Players:GetPlayers()) do
                restoreHidden(player)
                player:SetAttribute("NightShiftSprinting", false)
                applyWalkSpeed(player)
                local profile = profiles[player]
                if profile and profile.ready and (round.participation[player] or 0) >= 30 and gameplay:IsContributor(player) then
                    local reward = completed * 25
                    local xpReward = completed * 18
                    if round.resultSuccess then
                        reward += 195 + math.min(60, round.number * 4)
                        xpReward += 85
                        if not round.playerCaught[player] then reward += 35; xpReward += 15 end
                        profile.nights += 1
                    end
                    award(player, reward, xpReward)
                    local message = round.resultSuccess and TEXT.shiftReward or "Не все задания выполнены. Оплата за сделанную работу: "
                    notify(player, message .. reward .. "!")
                    remote:FireClient(player, "ShiftResults", {success = round.resultSuccess, completed = completed, total = round.tasksPerShift,
                        reward = reward, xp = xpReward, night = round.number, contribution = gameplay:GetContributionSummary(player)})
                elseif profile and profile.ready then
                    local reason = (round.participation[player] or 0) < 30 and "Ты присоединился к концу смены." or "В этой смене пока нет полезного вклада: помогай с задачами, камерами или спасением."
                    notify(player, reason)
                    remote:FireClient(player, "ShiftResults", {success = round.resultSuccess, completed = completed, total = round.tasksPerShift,
                        reward = 0, xp = 0, night = round.number, contribution = gameplay:GetContributionSummary(player), reason = reason})
                end
            end
            campaign:EndShift()
            gameplay:EndShift()
            for _, player in ipairs(Players:GetPlayers()) do task.spawn(saveProfile, player) end
            for remaining = CONFIG.RESULTS_SECONDS, 1, -1 do
                round.timeLeft = remaining
                broadcastState()
                task.wait(1)
                if #Players:GetPlayers() == 0 then break end
            end
        end
    end
end)
