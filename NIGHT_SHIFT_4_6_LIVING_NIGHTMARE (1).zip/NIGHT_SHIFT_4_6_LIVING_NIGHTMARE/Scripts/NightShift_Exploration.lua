-- NIGHT SHIFT 4.5: inspectable equipment, including before a contract is assigned.
-- Campaign owns the 24 prompts. This module only handles their free-inspection path.
-- Inspections never modify objectives, power, inventory, health, money or saved data.
local Exploration = {}
Exploration.__index = Exploration

local V, RGB = Vector3.new, Color3.fromRGB
local COLORS = {
    idle=RGB(94,145,143), active=RGB(231,183,94), good=RGB(121,195,154),
    paper=RGB(219,211,184), ink=RGB(46,55,59), off=RGB(148,119,86),
}
local RANGE, PLAYER_COOLDOWN, STATION_COOLDOWN = 7.5, .65, 3.5
local GUIDE = "Осмотр доступен всегда. Для текущего этапа контракта действие у станции меняется на «Выполнить»."
local ORDER = {
    "security_terminal","loading_manifest","stock_supplies","retail_check","retail_register",
    "generator_panel","cold_sensor","boiler_gauge","basement_breaker","yard_meter",
    "workshop_bench","workshop_parts","pump_console","pump_valve_a","pump_valve_b","pump_valve_c",
    "archive_catalog","archive_records","comms_console","comms_rack","staff_locker","staff_firstaid",
    "dispatch_board","dispatch_scanner",
}
local DEFINITIONS = {
    security_terminal={action="Прочитать журнал",effect="paper",sound="paper",status="ЖУРНАЛ / ПОСЛЕДНЯЯ СМЕНА",
        texts={"В журнале: «После полуночи проверять погрузочную и лестницу B1. Не доверять одному монитору». На полях отмечен запасной выход через технический двор.",
            "Последняя строка обрывается: «В 03:17 кто-то ответил по связи из пустого архива». Под записью стоит твоя должность, но чужая подпись."},
        hint="Камеры открываются на пульте охраны. Контракты и их текущий этап — в меню миссий."},
    loading_manifest={action="Сверить накладную",effect="paper",sound="paper",status="ПРИЁМКА / ПЛОМБЫ НА МЕСТЕ",
        texts={"Накладная отмечает два маршрута: товар идёт на склад наверху, возвраты — в B1. У последнего ящика номер смены зачёркнут дважды.",
            "В накладной повторяется одна и та же доставка в 03:17. У подписи получателя остался мокрый отпечаток, хотя бумага сухая."},
        hint="Спуск в B1 находится у настенного указателя. Станции внизу можно осматривать сразу."},
    stock_supplies={action="Проверить опись",effect="paper",sound="paper",status="ЗАПАСЫ / ОПИСЬ ПРОВЕРЕНА",
        texts={"В описи перечислены пломбы, крепёж и наборы для ремонта. На полке оставлена пометка: комплект для контракта выдаётся только по номеру заявки."},
        hint="Коробки для пополнения полок берутся у отдельного складского ящика. Осмотр описи не расходует запасы."},
    retail_check={action="Проверить маршрут",effect="paper",sound="paper",status="ОБХОД / МАРШРУТ ОТМЕЧЕН",
        texts={"Карточка обхода: кассы → холодильники → погрузочная. Если слышны шаги со стороны служебных комнат, проверь путь к укрытию до следующего задания."},
        hint="Осматривай оборудование между контрактами. Любой шум в коридоре может помочь понять, где находится угроза."},
    retail_register={action="Просмотреть контрольный чек",effect="paper",sound="paper",status="КАССА / КОНТРОЛЬНЫЙ ЧЕК",
        texts={"Контрольный чек пуст, кроме времени 03:17 и строки «ПОКУПАТЕЛЬ: 0». Касса не выполняет списание — это просмотр журнала.",
            "Лента заканчивается фразой «Не обслуживать после закрытия». Следующий чек уже наполовину отпечатан, хотя к кассе никто не подходил."},
        hint="Сверка выручки отмечается отдельно, когда этот этап появится в контракте."},
    generator_panel={action="Проверить питание",effect="meter",sound="switch",status="ГЕНЕРАТОР / ДИАГНОСТИКА",powered=true,
        onText="Индикатор подтверждает питание сети. Контрольная стрелка вернулась к метке; осмотр не меняет состояние двигателя.",
        offText="Питание сети отсутствует. Журнал работает от резервной батареи. Для восстановления питания нужен настоящий пуск у панели генератора.",
        hint="Этот журнал показывает состояние. Запуск двигателя и ремонт выполняются у самого генератора."},
    cold_sensor={action="Считать датчик",effect="meter",sound="scan",status="ХОЛОД / ДАТЧИК ОТВЕЧАЕТ",powered=true,
        onText="Самопроверка датчика T-04 завершена. На корпусе указана контрольная температура −18 °C; уплотнитель закрыт и не обледенел.",
        offText="Датчик не получает сетевое питание. В памяти сохранилась контрольная отметка −18 °C; новых измерений до восстановления сети нет.",
        hint="Контрольная отметка — запись прибора. Задание на холодный склад появится отдельным этапом контракта."},
    boiler_gauge={action="Проверить манометр",effect="meter",sound="valve_release",status="КОТЁЛ / СТРЕЛКА СВОБОДНА",noise=12,
        texts={"Проверочный клапан коротко выпускает воздух. Стрелка возвращается к контрольной риске; основной контур остаётся закрыт.",
            "Корпус манометра тёплый. После короткой проверки слышен второй стук со стороны труб, но стрелка больше не двигается."},
        hint="Проверка прибора доступна всегда. Рабочие настройки контура задаются только текущим контрактом."},
    basement_breaker={action="Проверить индикаторы",effect="relay",sound="switch",status="ЩИТ / ТЕСТ ИНДИКАТОРОВ",powered=true,
        onText="Контрольная кнопка зажигает индикаторы A–B–C. Подписи контуров читаются, рубильники не переключались.",
        offText="Сетевое питание отсутствует. Резервная кнопка проверила только сигнальные лампы; питание в комнатах от этого не восстановится.",
        hint="Схему можно изучить заранее. Последовательность переключения будет указана в активной задаче."},
    yard_meter={action="Осмотреть счётчик",effect="meter",sound="switch",status="ВНЕШНИЙ КОНТУР / ТЕСТ",powered=true,
        onText="Внешний контур под напряжением. Пломба цела, контрольный индикатор отвечает; показания не сбрасывались.",
        offText="Питания на внешнем контуре нет. Пломба цела; причина отключения находится внутри служебной сети.",
        hint="Проверка не запускает генератор. Возвращайся через служебную дверь в торговый зал."},
    workshop_bench={action="Проверить инструмент",effect="tool",sound="repair",status="СТЕНД / ИНСТРУМЕНТ ИСПРАВЕН",
        texts={"Ты проверяешь рукоять и возвращаешь инструмент на место. На стенде отмечено: питание узла отключают до ремонта, а не после.",
            "На инструменте свежая металлическая стружка. В журнале ремонта сегодняшняя строка ещё пуста."},
        hint="Инструменты можно осматривать до задания. Сборка ремонтного комплекта появляется отдельным этапом контракта."},
    workshop_parts={action="Приоткрыть ящик",effect="drawer",target="WorkshopPartsCabinet",sound="item_pickup",status="КОМПЛЕКТ / ЯЧЕЙКИ ПОДПИСАНЫ",
        texts={"Ящик приоткрывается: крепёж разложен по ячейкам, пломбы сухие. Карточка выдачи требует номер ремонтной заявки."},
        hint="Осмотр ничего не забирает. Когда потребуется комплект, действие у этого шкафа изменится."},
    pump_console={action="Проверить датчики",effect="meter",sound="switch",status="НАСОСЫ / КОНТРОЛЬНАЯ ПРОБА",powered=true,
        onText="Контрольный импульс проходит через датчики. На схеме подача отмечена A, обратная линия — B, резерв — C; насосы не переключались.",
        offText="Питания насосов нет. Контрольная стрелка работает от батареи, а схема A–B–C остаётся доступна для изучения.",
        hint="Вентили допускают короткую проверку свободного хода. Рабочий порядок будет указан в контракте."},
    pump_valve_a={action="Проверить ход A",effect="valve",sound="valve",status="КОНТУР A / ХОД ПРОВЕРЕН",noise=14,
        texts={"Маховик подачи A поворачивается на проверочный угол и возвращается обратно. За трубой слышно движение воды; рабочее положение не изменилось."},
        hint="Это проверка свободного хода. Для миссии следуй порядку вентилей в её текущем этапе."},
    pump_valve_b={action="Проверить ход B",effect="valve",sound="valve",status="КОНТУР B / ХОД ПРОВЕРЕН",noise=14,
        texts={"Маховик обратной линии B отзывается глухим щелчком. После проверки он возвращается на исходную риску."},
        hint="Осмотр не считается переключением по контракту. Порядок действий будет показан в задании."},
    pump_valve_c={action="Проверить ход C",effect="valve",sound="valve",status="КОНТУР C / ХОД ПРОВЕРЕН",noise=14,
        texts={"Резервный маховик C движется туже остальных. Проверочный ход завершён; контур остаётся в исходном положении."},
        hint="Проверять маховики можно заранее. Контракт отдельно укажет, когда включать резерв."},
    archive_catalog={action="Открыть каталог",effect="paper",sound="paper",status="КАТАЛОГ / СЛУЖЕБНЫЕ ЗАПИСИ",
        texts={"В каталоге: шкаф 07 — комната персонала; узел R2 — серверная; накладные возвратов — склад B1-06. Между страницами вклеен план служебных проходов.",
            "Между мастерской, архивом и комнатой персонала есть западный проход. Запись о его закрытии перечёркнута: это второй путь при обходе."},
        hint="Изучи маршрут до погони: архив соединён с соседними западными комнатами двумя проходами."},
    archive_records={action="Просмотреть папку",effect="drawer",target="ArchiveFileCabinet2",sound="paper",status="АРХИВ / СМЕНА 03:17",
        texts={"В папке несколько смен с одинаковым временем окончания — 03:17. На последней странице: «Если голос назовёт твоё имя, не отвечай».",
            "На старом плане лестница подписана «вход», а все остальные двери — «ожидание». Кто-то исправил подписи карандашом."},
        hint="Свободное чтение раскрывает записи и маршруты. Получение документа для контракта отмечается отдельным действием."},
    comms_console={action="Проверить связь",effect="radio",sound="radio_test",status="СВЯЗЬ / ТЕСТОВЫЙ КАНАЛ",noise=18,powered=true,
        onText="Тестовый канал отвечает коротким шумом. В конце пакета слышен такой же щелчок, как у двери в коридоре. Основная частота не изменялась.",
        offText="Сетевой узел отключён. На резервном канале слышна только статика; голосовые сообщения недоступны до восстановления питания.",
        hint="Проверка связи доступна сразу. Выбор рабочей частоты появится, когда её потребует контракт."},
    comms_rack={action="Запустить тест индикации",effect="rack",sound="switch",status="УЗЕЛ R2 / ИНДИКАЦИЯ",powered=true,
        onText="Индикаторы R2 проходят тест сверху вниз. Кабели закреплены; питание и конфигурация узла не менялись.",
        offText="Сеть отключена. Резервная цепь кратко проверила лампы R2; это не перезапуск серверов.",
        hint="Краткий тест не сбрасывает узел. Перезапуск связи возможен во время соответствующего этапа контракта."},
    staff_locker={action="Осмотреть шкаф 07",effect="drawer",target="StaffPersonalLocker",sound="item_pickup",status="ШКАФ 07 / ЛИЧНЫЕ ВЕЩИ",
        texts={"Дверца приоткрывается. Внутри висят запасная куртка и записка: «Напарник должен видеть, в какую комнату ты вошёл».",
            "На внутренней стороне дверцы выцарапано семь вертикальных черт. В табеле числятся только шесть предыдущих смен."},
        hint="Личные вещи остаются на месте. Предмет контракта берётся здесь, когда текущий этап укажет шкаф 07."},
    staff_firstaid={action="Проверить аптечку",effect="drawer",target="StaffFirstAid",sound="item_pickup",status="АПТЕЧКА / ПЛОМБА ЦЕЛА",
        texts={"Упаковки сухие, пломба набора цела. На дверце памятка: сначала отведи напарника от угрозы, затем помогай ему."},
        hint="Осмотр не расходует медицинские предметы и не лечит. Выдача набора отмечается отдельным этапом задания."},
    dispatch_board={action="Прочитать порядок возврата",effect="paper",sound="paper",status="ВОЗВРАТЫ / ПОРЯДОК УЧЁТА",
        texts={"Порядок приёмки: прочитать накладную, проверить номер пломбы, затем отметить повреждения. Коробки без номера остаются в карантине.",
            "В списке возвратов есть коробка, которую никто не принимал. Рядом от руки: «Не открывать, если внутри перестали стучать»."},
        hint="Сканер рядом можно проверить на тестовой метке даже без задания."},
    dispatch_scanner={action="Проверить сканер",effect="scan",sound="scan",status="СКАНЕР / TEST-01 СЧИТАНО",noise=10,
        texts={"Луч проходит по тестовой метке TEST-01. Сканер подтверждает чтение; накладные и пломбы настоящих возвратов не изменились."},
        hint="Тестовая метка доступна всегда. Сканирование груза для контракта появится отдельным действием."},
}

local function alivePart(part)
    return part and part.Parent and part:IsA("BasePart")
end

function Exploration.new(ctx)
    assert(ctx and ctx.getProfile,"Exploration needs getProfile")
    return setmetatable({ctx=ctx,players=ctx.Players or game:GetService("Players"),
        workspace=ctx.Workspace or game:GetService("Workspace"),clock=ctx.clock or os.clock,
        stations={},devices={},runtimes={},active={},worldParts={},built=false},Exploration)
end

function Exploration:_part(id,name,size,frame,color,material)
    local part=Instance.new("Part")
    part.Name="Explore_"..id.."_"..name;part.Size=size;part.CFrame=frame
    part.Color=color or COLORS.ink;part.Material=material or Enum.Material.Metal
    part.Anchored=true;part.CanCollide=false;part.CanTouch=false;part.CanQuery=false
    part.TopSurface=Enum.SurfaceType.Smooth;part.BottomSurface=Enum.SurfaceType.Smooth
    part:SetAttribute("ExplorationStation",id);part:SetAttribute("ExplorationEffect",name)
    part.Parent=self.folder
    return part
end

function Exploration:_nearest(name,position,range)
    local best,distance=nil,range or 8
    for _,part in ipairs(self.worldParts) do
        if part.Name==name and alivePart(part) then
            local d=(part.Position-position).Magnitude
            if d<distance then best,distance=part,d end
        end
    end
    return best
end

function Exploration:_bind(device,part,mode)
    if not alivePart(part) then return end
    table.insert(device.movers,{part=part,home=part.CFrame,color=part.Color,mode=mode})
end

function Exploration:_buildDevice(id,station,definition)
    local part=station.part
    local gui=part:FindFirstChildOfClass("SurfaceGui")
    if not gui then
        gui=Instance.new("SurfaceGui");gui.Name="ExplorationSign";gui.Face=Enum.NormalId.Front
        gui.SizingMode=Enum.SurfaceGuiSizingMode.PixelsPerStud;gui.PixelsPerStud=55
        gui.LightInfluence=0;gui.AlwaysOnTop=false;gui.MaxDistance=26;gui.Parent=part
    end
    local title=gui:FindFirstChildOfClass("TextLabel")
    local device={id=id,station=station,definition=definition,movers={},title=title}
    if title then
        device.titleSize=title.Size;device.titlePosition=title.Position
        title.Size=UDim2.fromScale(.68,.56);title.Position=UDim2.fromScale(.05,.07)
    end
    local footer=Instance.new("TextLabel")
    footer.Name="ExplorationStatus";footer.BackgroundTransparency=1
    footer.Size=UDim2.fromScale(.81,.23);footer.Position=UDim2.fromScale(.05,.69)
    footer.Font=Enum.Font.GothamBold;footer.TextColor3=COLORS.idle
    footer.TextScaled=true;footer.TextWrapped=false;footer.Text="";footer.Visible=false;footer.Parent=gui
    device.footer=footer
    device.lamp=self:_part(id,"Indicator",V(.13,.13,.06),part.CFrame*CFrame.new(1.15,-.48,-.1),COLORS.idle,Enum.Material.Neon)
    local kind=definition.effect
    if kind=="meter" then
        local backing=self:_part(id,"Gauge",V(.57,.42,.06),part.CFrame*CFrame.new(.98,.58,-.12),COLORS.ink)
        local needle=self:_part(id,"Needle",V(.035,.28,.035),backing.CFrame*CFrame.new(0,-.02,-.055),COLORS.paper,Enum.Material.Neon)
        self:_bind(device,needle,"needle")
    elseif kind=="relay" then
        local button=self:_part(id,"TestButton",V(.26,.22,.12),part.CFrame*CFrame.new(1.05,.56,-.12),COLORS.paper)
        self:_bind(device,button,"button")
    elseif kind=="radio" then
        for index=1,3 do
            local bar=self:_part(id,"SignalBar"..index,V(.09,.1+index*.07,.04),part.CFrame*CFrame.new(.79+index*.14,.48,-.11),COLORS.idle,Enum.Material.Neon)
            self:_bind(device,bar,"signal")
        end
    elseif kind=="paper" then
        local sheet=self:_part(id,"LedgerPage",V(.42,.53,.025),part.CFrame*CFrame.new(1.05,.48,-.12),COLORS.paper,Enum.Material.SmoothPlastic)
        self:_bind(device,sheet,"page")
        for index=1,3 do
            local line=self:_part(id,"LedgerInk"..index,V(.3,.018,.008),sheet.CFrame*CFrame.new(0,.12-index*.08,-.019),COLORS.ink)
            self:_bind(device,line,"page")
        end
    elseif kind=="drawer" then
        local front=self:_nearest(definition.target.."Front",part.Position,6)
        local handle=self:_nearest(definition.target.."Handle",part.Position,6)
        self:_bind(device,front,"drawer");self:_bind(device,handle,"drawer")
        if front then
            -- The plaque is attached to this door. Keep its text/prompt and tiny
            -- indicator with the door rather than leaving a floating label behind.
            self:_bind(device,part,"drawer");self:_bind(device,device.lamp,"drawer")
        end
    elseif kind=="tool" then
        local handle=self:_nearest("WorkshopToolHandle",part.Position,6)
        self:_bind(device,handle,"tool")
        if handle then self:_bind(device,self:_nearest("WorkshopToolHead",handle.Position,1),"tool") end
    elseif kind=="valve" then
        local valve=self:_nearest("PumpValveWheel",part.Position,3)
        if valve then
            device.pivot=valve.CFrame
            self:_bind(device,valve,"valve")
            for index=1,2 do
                local spoke=self:_part(id,"ValveSpoke"..index,V(.08,1.05,.11),valve.CFrame*CFrame.new(.13,0,0)*CFrame.Angles(math.rad((index-1)*90),0,0),COLORS.ink)
                self:_bind(device,spoke,"valve")
            end
            local grip=self:_part(id,"ValveGrip",V(.18,.23,.13),valve.CFrame*CFrame.new(.18,.43,0),COLORS.paper)
            self:_bind(device,grip,"valve")
        end
    elseif kind=="rack" then
        for _,candidate in ipairs(self.worldParts) do
            if candidate.Name=="ServerRackLED" and math.abs(candidate.Position.X-part.Position.X)<2 and (candidate.Position-part.Position).Magnitude<5 then
                self:_bind(device,candidate,"signal")
            end
        end
    elseif kind=="scan" then
        self:_part(id,"ScannerHousing",V(.52,.25,.7),CFrame.new(24.1,-7.34,-172.2),COLORS.ink)
        self:_part(id,"TestLabel",V(.9,.025,1.05),CFrame.new(27.9,-7.455,-172.2),COLORS.paper,Enum.Material.SmoothPlastic)
        for index=1,5 do
            self:_part(id,"Barcode"..index,V(.06,.014,.72),CFrame.new(27.55+index*.12,-7.435,-172.2),COLORS.ink,Enum.Material.SmoothPlastic)
        end
        local beam=self:_part(id,"ScanBeam",V(.035,.018,.92),CFrame.new(27.5,-7.417,-172.2),COLORS.active,Enum.Material.Neon)
        beam.Transparency=1;device.beam=beam;device.beamHome=beam.CFrame
    end
    part:SetAttribute("ExplorationReady",true);part:SetAttribute("InspectAction",definition.action)
    part:SetAttribute("ExplorationMode",kind)
    return device
end

function Exploration:Build(world,stations)
    assert(not self.built and world and type(stations)=="table","Exploration.Build requires one world and stations")
    self.world=world;self.stations=stations
    for _,descendant in ipairs(world:GetDescendants()) do
        if descendant:IsA("BasePart") then table.insert(self.worldParts,descendant) end
    end
    self.folder=Instance.new("Model");self.folder.Name="NightShiftExploration41";self.folder.Parent=world
    for _,id in ipairs(ORDER) do
        assert(stations[id] and alivePart(stations[id].part),"Missing inspection station: "..id)
        self.devices[id]=self:_buildDevice(id,stations[id],DEFINITIONS[id])
    end
    self.folder:SetAttribute("InspectionStations",#ORDER);self.folder:SetAttribute("FreeInspection",true)
    self.built=true
    return self
end

function Exploration:_near(player,station)
    if not self.built or not player or player.Parent~=self.players then return false end
    local profile=self.ctx.getProfile(player)
    if not profile or not profile.ready then return false end
    if player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") then return false end
    local character=player.Character
    local root=character and character:FindFirstChild("HumanoidRootPart")
    local human=character and character:FindFirstChildOfClass("Humanoid")
    if not root or not human or not (human.Health>0) or not alivePart(station.part) then return false end
    if not ((root.Position-station.part.Position).Magnitude<=RANGE) then return false end
    if self.ctx.hasLineOfSight then return self.ctx.hasLineOfSight(player,station.part)==true end
    local head=character:FindFirstChild("Head") or root
    local params=RaycastParams.new()
    params.FilterType=Enum.RaycastFilterType.Exclude;params.FilterDescendantsInstances={character,self.folder}
    params.IgnoreWater=true;params.RespectCanCollide=true
    local result=self.workspace:Raycast(head.Position,station.part.Position-head.Position,params)
    return result==nil or result.Instance==station.part
end

function Exploration:_restore(device)
    for _,mover in ipairs(device.movers) do
        if alivePart(mover.part) then mover.part.CFrame=mover.home;mover.part.Color=mover.color end
    end
    if device.beam and device.beam.Parent then device.beam.Transparency=1;device.beam.CFrame=device.beamHome end
    if device.lamp and device.lamp.Parent then device.lamp.Color=COLORS.idle end
    if device.footer and device.footer.Parent then device.footer.Text="";device.footer.Visible=false;device.footer.TextColor3=COLORS.idle end
    if device.station.part.Parent then device.station.part:SetAttribute("InspectionActive",false) end
    self.active[device.id]=nil
end

function Exploration:_animate(device,now)
    local active=self.active[device.id]
    if not active then return end
    local t=math.clamp((now-active.started)/active.duration,0,1)
    if t>=1 then self:_restore(device);return end
    local pulse=math.sin(t*math.pi)
    for index,mover in ipairs(device.movers) do
        local part=mover.part
        if alivePart(part) then
            if mover.mode=="needle" then
                part.CFrame=mover.home*CFrame.Angles(0,0,math.rad(48)*math.sin(t*math.pi*2))
            elseif mover.mode=="button" then
                part.CFrame=mover.home*CFrame.new(0,0,.07*math.sin(math.min(t*3,1)*math.pi))
            elseif mover.mode=="page" then
                -- The whole little ledger page lifts together and returns to its bracket.
                part.CFrame=mover.home+device.station.facing*(.16*pulse)+V(0,.07*pulse,0)
            elseif mover.mode=="drawer" then
                part.CFrame=mover.home+device.station.facing*(.32*pulse)
            elseif mover.mode=="tool" then
                part.CFrame=mover.home+V(0,.18*pulse,.2*pulse)
            elseif mover.mode=="valve" then
                part.CFrame=device.pivot*CFrame.Angles(math.rad(32)*pulse,0,0)*device.pivot:ToObjectSpace(mover.home)
            elseif mover.mode=="signal" then
                part.Color=(math.floor(t*12+index)%3==0) and COLORS.active or COLORS.good
            end
        end
    end
    if device.beam and device.beam.Parent then
        device.beam.Transparency=.06
        device.beam.CFrame=device.beamHome+V(.8*t,0,0)
    end
    if device.lamp and device.lamp.Parent then
        device.lamp.Color=math.floor(t*10)%2==0 and COLORS.active or COLORS.good
    end
end

function Exploration:Interact(player,stationId)
    if type(stationId)~="string" or #stationId>64 then return false end
    local station,device=self.stations[stationId],self.devices[stationId]
    if not station or not device or not self:_near(player,station) then return false end
    local now=self.clock()
    local runtime=self.runtimes[player]
    if not runtime then runtime={nextAt=0,stations={},visits={}};self.runtimes[player]=runtime end
    if now<runtime.nextAt or now<(runtime.stations[stationId] or 0) then return false end
    runtime.nextAt=now+PLAYER_COOLDOWN
    if self.active[stationId] then
        if self.ctx.notify then self.ctx.notify(player,"Проверка этого прибора ещё завершается. Подожди пару секунд.") end
        return false
    end
    runtime.stations[stationId]=now+STATION_COOLDOWN
    local definition=device.definition
    local visits=(runtime.visits[stationId] or 0)+1
    runtime.visits[stationId]=visits%12
    local powered=not self.ctx.getPower or self.ctx.getPower()~=false
    local message=definition.powered and (powered and definition.onText or definition.offText)
        or definition.texts[(visits-1)%#definition.texts+1]
    local status=definition.powered and not powered and "СЕТЬ ОТКЛЮЧЕНА / РЕЗЕРВНЫЙ ТЕСТ" or definition.status
    local payload={stationId=stationId,title=station.title,action=definition.action,text=message,status=status,
        hint=definition.hint or GUIDE,room=station.roomLabel or station.room,freeInspection=true,powered=powered}
    self.active[stationId]={started=now,duration=2.4}
    station.part:SetAttribute("InspectionActive",true)
    device.footer.Text=status;device.footer.Visible=true;device.footer.TextColor3=powered and COLORS.good or COLORS.active
    self:_animate(device,now+.08)
    if self.ctx.onInspect then self.ctx.onInspect(player,payload)
    elseif self.ctx.notify then self.ctx.notify(player,message.." "..payload.hint) end
    if self.ctx.onSound then
        local audience=player
        if definition.noise then audience=nil end
        self.ctx.onSound(definition.sound,station.part.Position,definition.action,audience)
    end
    if definition.noise and self.ctx.onNoise then
        self.ctx.onNoise(station.part.Position,"inspection_"..stationId,definition.noise,player)
    end
    return true
end

function Exploration:Tick(_dt)
    if not self.built then return end
    local now=self.clock()
    for id in pairs(self.active) do
        local device=self.devices[id]
        if device then self:_animate(device,now) else self.active[id]=nil end
    end
end

function Exploration:OnPlayerRemoving(player)
    self.runtimes[player]=nil
end

function Exploration:Destroy()
    for _,device in pairs(self.devices) do
        self:_restore(device)
        if device.footer and device.footer.Parent then device.footer:Destroy() end
        if device.title and device.title.Parent then
            device.title.Size=device.titleSize;device.title.Position=device.titlePosition
        end
        if device.station.part.Parent then
            device.station.part:SetAttribute("ExplorationReady",nil)
            device.station.part:SetAttribute("InspectAction",nil)
            device.station.part:SetAttribute("ExplorationMode",nil)
            device.station.part:SetAttribute("InspectionActive",nil)
        end
    end
    if self.folder then self.folder:Destroy() end
    self.folder=nil;self.devices={};self.active={};self.runtimes={};self.worldParts={};self.stations={};self.built=false
end

function Exploration.GetStationIds()
    local result={};for index,id in ipairs(ORDER) do result[index]=id end;return result
end

return Exploration
