-- NIGHT SHIFT 4.5: client experience, spatial sound, team radio and preferences.
-- ModuleScript in ReplicatedStorage. Called by NightShift_Client with its existing HUD.
-- Sound is owned by the independent NightShift_Audio controller, not this UI.

local Experience = {}
local DEFAULTS = {
    masterVolume = 1, ambientVolume = .55, effectsVolume = .7, threatVolume = .85, uiVolume = .55,
    reducedFlashes = true, cameraShake = false, captions = true, highContrast = false,
    quality = "auto", mix = "balanced", fov = 76, textScale = 1, brightness = 0, objectiveMarker = true,
    incidentHints = true, reducedInterference = false,
}
local function text(value, fallback)
    return type(value) == "string" and value or fallback or ""
end
local function number(value, fallback, low, high)
    local n = tonumber(value)
    if not n or n ~= n or n == math.huge or n == -math.huge then n = fallback end
    return math.clamp(n, low, high)
end

function Experience.NormalizePreferences(value)
    value = type(value) == "table" and value or {}
    local result = {}
    for _, key in ipairs({"masterVolume", "ambientVolume", "effectsVolume", "threatVolume", "uiVolume"}) do
        result[key] = number(value[key], DEFAULTS[key], 0, 1)
    end
    result.fov = number(value.fov, DEFAULTS.fov, 68, 90)
    result.textScale = number(value.textScale, DEFAULTS.textScale, 1, 1.2)
    result.brightness = number(value.brightness, DEFAULTS.brightness, 0, .12)
    for _, key in ipairs({"reducedFlashes", "cameraShake", "captions", "highContrast", "objectiveMarker", "incidentHints", "reducedInterference"}) do
        if type(value[key]) == "boolean" then result[key] = value[key] else result[key] = DEFAULTS[key] end
    end
    result.quality = (value.quality == "low" or value.quality == "standard") and value.quality or "auto"
    result.mix = value.mix == "night" and "night" or "balanced"
    if result.effectsVolume == 0 then
        if value.threatVolume == nil then result.threatVolume = 0 end
        if value.uiVolume == nil then result.uiVolume = 0 end
        if result.ambientVolume == 0 and value.masterVolume == nil then result.masterVolume = 0 end
    end
    return result
end

function Experience.PhaseWelcome(phase)
    if phase == "SHIFT" then return "Смена уже идёт. Посмотрите задания и присоединяйтесь к команде." end
    if phase == "RESULTS" then return "Смена завершена. Следующая начнётся после итогов." end
    return "Подготовка к смене. Осмотритесь, проверьте фонарь и выберите задачу."
end

function Experience.FormatTask(item)
    item = type(item) == "table" and item or {}
    local line = (item.done and "✓  " or "○  ") .. text(item.title, "Задание")
    local stage = text(item.stageText)
    if stage == "" then stage = text(item.location) end
    if stage ~= "" then line ..= "\n     " .. stage end
    local claimed = text(item.claimedName)
    if claimed ~= "" and not item.done then line ..= "\n     " .. claimed .. " занимается задачей" end
    return line
end

function Experience.MergeTasks(base, detailed)
    local byId, merged = {}, {}
    for _, item in ipairs(type(detailed) == "table" and detailed or {}) do
        if type(item) == "table" and type(item.id) == "string" then byId[item.id] = item end
    end
    for _, item in ipairs(type(base) == "table" and base or {}) do
        if type(item) == "table" then
            local row = table.clone(item)
            for key, value in pairs(byId[item.id] or {}) do row[key] = value end
            table.insert(merged, row)
        end
    end
    return merged
end

function Experience.ResultsText(value)
    value = type(value) == "table" and value or {}
    local contribution = type(value.contribution) == "table" and value.contribution or {}
    local lines = {
        (value.success == true and "СМЕНА ВЫПОЛНЕНА" or "СМЕНА ЗАВЕРШЕНА") .. " · НОЧЬ " .. tostring(math.floor(number(value.night, 1, 1, 1000000))),
        "Задания команды: " .. tostring(math.floor(number(value.completed, 0, 0, 100))) .. " / " .. tostring(math.floor(number(value.total, 0, 0, 100))),
        "Ваша оплата: " .. tostring(math.floor(number(value.reward, 0, 0, 1000000))) .. "   ·   Опыт: +" .. tostring(math.floor(number(value.xp, 0, 0, 1000000))),
        "Ваш полезный вклад: " .. tostring(math.floor(number(contribution.score, 0, 0, 100000))),
    }
    local areas, seen = {}, {}
    for _, kind in ipairs(type(contribution.kinds) == "table" and contribution.kinds or {}) do
        if type(kind) == "string" then
            local area
            if kind:find("^complete_") then area = "выполнение заданий"
            elseif kind:find("^pickup_") then area = "доставка предметов"
            elseif kind:find("^litter_") then area = "уборка"
            elseif kind:find("^cooler_") then area = "холодильники"
            elseif kind:find("^generator_") or kind:find("^breaker_") or kind == "fuse_install" then area = "электропитание"
            elseif kind == "anomaly_report" then area = "проверка аномалий"
            elseif kind == "camera_warning" then area = "предупреждение команды"
            elseif kind:find("^customer_") then area = "обслуживание покупателей"
            elseif kind:find("^campaign_") then area = "личные контракты"
            elseif kind:find("revive", 1, true) then area = "помощь напарникам" end
            if area and not seen[area] then seen[area] = true; table.insert(areas, area) end
        end
    end
    if #areas > 0 then table.insert(lines, "Участие: " .. table.concat(areas, ", ")) end
    local reason = text(value.reason)
    if reason ~= "" then table.insert(lines, reason)
    elseif contribution.useful == false then table.insert(lines, "Для полной оплаты помогайте с заданиями, камерами и спасением напарников.") end
    return table.concat(lines, "\n")
end

function Experience.LayoutMetrics(width,height,scale,touch)
    width,height=math.max(280,tonumber(width) or 1100),math.max(220,tonumber(height) or 720)
    return {width=math.min(680,width-24),height=math.min(602,height-24),hit=touch and 44 or 40,
        footer=touch and 44 or 40,captionWidth=math.min(440,width-24),reportWidth=math.min(620,width-24),reportHeight=(touch and 44 or 40)+34}
end

function Experience.new(ctx)
    assert(ctx and ctx.remote and ctx.player and ctx.content and ctx.gui, "Experience requires the existing HUD context")
    local Players = game:GetService("Players")
    local UserInputService = game:GetService("UserInputService")
    local Lighting = game:GetService("Lighting")
    local RunService = game:GetService("RunService")
    local GuiService = game:GetService("GuiService")
    local ContextActionService = game:GetService("ContextActionService")
    local ProximityPromptService = game:GetService("ProximityPromptService")
    local Debris = game:GetService("Debris")
    local player, remote = ctx.player, ctx.remote
    local self = setmetatable({
        context = ctx, preferences = Experience.NormalizePreferences(), gameplay = {}, campaign = {}, worldRooms = {},
        condition = {}, phase = "INTERMISSION", connections = {},
        shadowDefaults = setmetatable({}, {__mode = "k"}),
        cctvOnlyParts = setmetatable({}, {__mode = "k"}),
        stationPromptDefaults = setmetatable({}, {__mode = "k"}),
        dead = false, modal = nil, welcomed = false, captionToken = 0, effectUntil = 0,
        shakeUntil = 0, tasks = {}, effects = {}, markerObjects = {},
    }, {__index = Experience})
    local COLORS = {
        panel = Color3.fromRGB(13, 19, 25), secondary = Color3.fromRGB(25, 34, 42),
        text = Color3.fromRGB(236, 239, 234), muted = Color3.fromRGB(139, 153, 161),
        mint = Color3.fromRGB(206, 166, 98), orange = Color3.fromRGB(224, 171, 91),
        red = Color3.fromRGB(211, 83, 75),
    }
    local function box(class, name, parent, size, position)
        local o = Instance.new(class)
        o.Name, o.Size, o.Position = name, size, position or UDim2.new()
        o.BorderSizePixel = 0
        o.BackgroundColor3 = COLORS.panel
        o.ZIndex = 80
        o.Parent = parent
        return o
    end
    local function rounded(o, radius)
        local c = Instance.new("UICorner"); c.CornerRadius = UDim.new(0, radius or 7); c.Parent = o
    end
    local function label(name, parent, value, size, position, fontSize)
        local o = box("TextLabel", name, parent, size, position)
        o.BackgroundTransparency = 1
        o.Text, o.TextColor3 = value, COLORS.text
        o.Font = Enum.Font.GothamMedium
        o.TextSize = fontSize or 15
        o.TextWrapped = true
        o.TextXAlignment = Enum.TextXAlignment.Left
        o.TextYAlignment = Enum.TextYAlignment.Center
        return o
    end
    local function button(name, parent, value, size, position, fn)
        local o = box("TextButton", name, parent, size, position)
        o.Text, o.TextColor3 = value, COLORS.text
        o.Font, o.TextSize = Enum.Font.GothamMedium, 13
        o.TextWrapped, o.AutoButtonColor, o.Selectable = true, true, true
        o.BackgroundColor3 = COLORS.secondary
        rounded(o, 7)
        local stroke=Instance.new("UIStroke");stroke.Color=Color3.fromRGB(102,121,128);stroke.Transparency=.72;stroke.Thickness=1;stroke.Parent=o
        local baseColor = COLORS.secondary
        o.MouseEnter:Connect(function() if not self.dead then o.BackgroundColor3 = baseColor:Lerp(Color3.fromRGB(48,62,70),.48); stroke.Transparency=.34 end end)
        o.MouseLeave:Connect(function() o.BackgroundColor3 = baseColor; stroke.Transparency=.72 end)
        o.Activated:Connect(function()
            if self.dead then return end
            self:PlaySound({kind = "ui_click"})
            fn()
        end)
        return o
    end
    local function row(parent, name, height)
        local o = box("Frame", name, parent, UDim2.new(1, -8, 0, height))
        o.BackgroundTransparency = 1
        return o
    end
    local function scrolling(parent, name)
        local o = box("ScrollingFrame", name, parent, UDim2.new(1, -24, 1, -122), UDim2.fromOffset(12, 110))
        o.BackgroundTransparency, o.ScrollBarThickness = 1, 4
        o.ScrollBarImageColor3 = COLORS.mint
        o.CanvasSize, o.AutomaticCanvasSize = UDim2.new(), Enum.AutomaticSize.Y
        o.ScrollingDirection = Enum.ScrollingDirection.Y
        local layout = Instance.new("UIListLayout")
        layout.Padding, layout.SortOrder, layout.Parent = UDim.new(0, 12), Enum.SortOrder.LayoutOrder, o
        return o
    end
    local function connect(signal, fn)
        table.insert(self.connections, signal:Connect(fn))
    end

    -- The permanent HUD keeps only a contextual drop action. All tools share one terminal.
    self.footer = box("Frame", "ShiftTools", ctx.tasksPanel or ctx.content, UDim2.fromOffset(144,40), UDim2.new(1,-292,1,-20))
    self.footer.AnchorPoint, self.footer.BackgroundTransparency = Vector2.new(0,1), 1
    self.radioButton = button("Radio", self.footer, "РАЦИЯ [V]", UDim2.fromScale(1,1), UDim2.new(), function() self:OpenPanel("team") end)
    self.optionsButton = button("Options", self.footer, "ОПЦИИ [P]", UDim2.fromScale(1,1), UDim2.new(), function() self:OpenPanel("settings") end)
    self.radioButton.Visible, self.optionsButton.Visible = false,false
    self.dropButton = button("DropItem", self.footer, "ПОЛОЖИТЬ [G]", UDim2.fromScale(1,1), UDim2.new(), function() self:SendAction("DropItem") end)
    self.dropButton.Visible, self.footer.Visible = false,false

    self.shield = box("Frame", "ExperienceModalShield", ctx.content, UDim2.fromScale(1,1))
    self.shield.BackgroundColor3=Color3.fromRGB(4,6,7)
    self.shield.BackgroundTransparency, self.shield.Active, self.shield.Visible, self.shield.ZIndex = .22,true,false,110
    self.panel = box("Frame", "ExperiencePanel", self.shield, UDim2.fromOffset(680,580), UDim2.fromScale(.5,.5))
    self.panel.AnchorPoint,self.panel.ZIndex=Vector2.new(.5,.5),111
    rounded(self.panel,10)
    self.panel.BackgroundColor3 = COLORS.panel
    local panelGradient=Instance.new("UIGradient");panelGradient.Color=ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(21,31,39)),ColorSequenceKeypoint.new(1,Color3.fromRGB(10,15,20))});panelGradient.Rotation=90;panelGradient.Parent=self.panel
    local border=Instance.new("UIStroke");border.Color=Color3.fromRGB(111,130,137);border.Transparency=.48;border.Thickness=1.2;border.Parent=self.panel
    self.panelKicker=label("TerminalKicker",self.panel,"NIGHTMART  /  СЛУЖЕБНЫЙ ТЕРМИНАЛ",UDim2.new(1,-100,0,16),UDim2.fromOffset(24,18),10)
    self.panelKicker.TextColor3=COLORS.muted
    self.panelTitle=label("Title",self.panel,"КОМАНДА",UDim2.new(1,-100,0,32),UDim2.fromOffset(24,37),22)
    self.panelTitle.Font=Enum.Font.GothamBold
    self.closeButton=button("Close",self.panel,"×",UDim2.fromOffset(44,44),UDim2.new(1,-64,0,20),function()self:ClosePanel()end)
    self.closeButton.TextSize=24
    self.tabs,self.tabOrder={}, {"missions","map","team","journal","upgrades","settings"}
    for i,data in ipairs({{"missions","МИССИИ"},{"map","ЛОКАЦИИ"},{"team","КОМАНДА"},{"journal","ЖУРНАЛ"},{"upgrades","СНАРЯЖЕНИЕ"},{"settings","НАСТРОЙКИ"}}) do
        self.tabs[data[1]]=button("Tab"..data[1],self.panel,data[2],UDim2.new(.25,-10,0,40),UDim2.new((i-1)/4,20,0,88),function()self:OpenPanel(data[1])end)
        self.tabs[data[1]].TextSize=11
    end
    self.pages={missions=scrolling(self.panel,"Missions"),map=scrolling(self.panel,"Places"),team=scrolling(self.panel,"Team"),settings=scrolling(self.panel,"Preferences"),journal=scrolling(self.panel,"Journal"),upgrades=scrolling(self.panel,"Upgrades")}
    for i,object in ipairs(ctx.upgradeControls or {}) do
        object.Parent=self.pages.upgrades
        object.LayoutOrder=i
        object.Position=UDim2.new()
        object.Size=UDim2.new(1,-8,0,object.Name=="EmployeeProfile" and 132 or (object.Name=="ShopFoot" and 48 or 52))
        if object:IsA("TextButton") then object.BackgroundColor3=COLORS.secondary;object.TextColor3=COLORS.text;object.TextSize=13 end
    end
    self.pingRows, self.teamLabels = {}, {}
    for i, pair in ipairs({{"help", "НУЖНА ПОМОЩЬ"}, {"danger", "ОПАСНОСТЬ ЗДЕСЬ"}, {"working", "ЗАНИМАЮСЬ ЗАДАЧЕЙ"}, {"safe", "ЗДЕСЬ БЕЗОПАСНО"}}) do
        local b = button("Ping" .. pair[1], self.pages.team, pair[2], UDim2.new(1, -8, 0, 44), UDim2.new(), function()
            self:SendAction("Ping", {kind = pair[1]})
            self:ClosePanel()
        end)
        b.LayoutOrder = i
        table.insert(self.pingRows, b)
    end
    local teamHeading = label("TeamHeading", self.pages.team, "СОТРУДНИКИ НА СМЕНЕ", UDim2.new(1, -8, 0, 24), UDim2.new(), 13)
    teamHeading.TextColor3, teamHeading.LayoutOrder = COLORS.orange, 5
    self.teamEmpty = label("TeamEmpty", self.pages.team, "Вы на смене. Сведения о команде обновляются автоматически.", UDim2.new(1, -8, 0, 52), UDim2.new(), 14)
    self.teamEmpty.LayoutOrder = 6
    self.settingsRows = {}
    local function settingRange(key, title, order, step, format)
        local r = row(self.pages.settings, key, 58); r.LayoutOrder = order
        label("Label", r, title, UDim2.new(1, -180, 1, 0), UDim2.new(), 14)
        local minus = button("Minus", r, "−", UDim2.fromOffset(44,44), UDim2.new(1,-152,0,5), function() self:SetPreference(key, self.preferences[key] - step) end)
        local v = label("Value", r, "", UDim2.fromOffset(52,44), UDim2.new(1,-104,0,5), 15); v.TextXAlignment = Enum.TextXAlignment.Center
        local plus = button("Plus", r, "+", UDim2.fromOffset(44,44), UDim2.new(1,-48,0,5), function() self:SetPreference(key, self.preferences[key] + step) end)
        self.settingsRows[key] = {row = r, value = v, minus = minus, plus = plus, format = format}
    end
    local function settingsCopy(name, value, order, heading)
        local l = label(name, self.pages.settings, value, UDim2.new(1,-8,0,heading and 28 or 40), UDim2.new(), heading and 11 or 13)
        l.TextColor3, l.LayoutOrder = heading and COLORS.orange or COLORS.muted, order
        l.AutomaticSize = Enum.AutomaticSize.Y
        return l
    end
    self.soundTestButton = button("SoundTest", self.pages.settings, "ПРОВЕРИТЬ ЗВУК", UDim2.new(1,-8,0,48), UDim2.new(), function()
        local audio = ctx.getAudio and ctx.getAudio()
        if audio then audio:Test() else self:UpdateAudioStatus({state="loading",text="Звук ещё подключается. Попробуйте через несколько секунд."}) end
    end)
    self.soundTestButton.LayoutOrder, self.soundTestButton.TextColor3 = 1, COLORS.orange
    self.soundStatus = settingsCopy("AudioStatus", "Подключаем звук…", 2)
    for i, data in ipairs({{"masterVolume","ОБЩАЯ ГРОМКОСТЬ"},{"ambientVolume","ОКРУЖЕНИЕ"},{"effectsVolume","ДЕЙСТВИЯ"},{"threatVolume","МОНСТР"},{"uiVolume","ИНТЕРФЕЙС"}}) do
        settingRange(data[1], data[2], i+2, .1, "percent")
    end
    self.mixButton = button("Mix", self.pages.settings, "", UDim2.new(1,-8,0,48), UDim2.new(), function()
        self:SetPreference("mix", self.preferences.mix == "night" and "balanced" or "night")
    end)
    self.mixButton.LayoutOrder = 8
    settingsCopy("MixHint", "Мягкий режим снижает резкость угроз и сигналов. Направление звуков сохраняется.", 9)
    settingsCopy("DisplayHeading", "ИЗОБРАЖЕНИЕ", 20, true)
    settingsCopy("DisplayHint", "Настройте обзор и видимость тёмных участков. В камерах охраны обзор фиксирован.", 21)
    settingRange("fov", "УГОЛ ОБЗОРА", 22, 2, "degrees")
    settingRange("brightness", "ОСВЕТЛЕНИЕ ТЕНЕЙ", 23, .02, "percent")
    self.qualityButton = button("Quality", self.pages.settings, "", UDim2.new(1,-8,0,48), UDim2.new(), function()
        self:SetPreference("quality", ({auto="low",low="standard",standard="auto"})[self.preferences.quality])
    end)
    self.qualityButton.LayoutOrder = 24
    settingsCopy("QualityHint", "Авто: облегчённые тени на телефоне. Лёгкий режим уменьшает тени декора; стандартный возвращает их.", 25)
    settingsCopy("AccessibilityHeading", "УДОБСТВО И ЧИТАЕМОСТЬ", 30, true)
    settingsCopy("AccessibilityHint", "Подписи подсказывают сторону звука. Вспышки и тряска отключаются независимо.", 31)
    settingRange("textScale", "РАЗМЕР ТЕКСТА", 32, .1, "percent")
    for i, pair in ipairs({{"highContrast","ВЫСОКИЙ КОНТРАСТ"},{"captions","ПОДПИСИ ЗВУКОВ"},{"reducedFlashes","УМЕНЬШЕННЫЕ ВСПЫШКИ"},{"cameraShake","ТРЯСКА КАМЕРЫ"},{"objectiveMarker","МЕТКА ЦЕЛИ"},{"incidentHints","ПОДСКАЗКИ АВАРИЙ"},{"reducedInterference","УМЕРЕННЫЕ ПОМЕХИ CCTV"}}) do
        local b = button(pair[1], self.pages.settings, "", UDim2.new(1,-8,0,48), UDim2.new(), function() self:SetPreference(pair[1], not self.preferences[pair[1]]) end)
        b.LayoutOrder = 32+i
        self.settingsRows[pair[1]] = {button=b,title=pair[2]}
    end
    self.resetButton = button("ResetPreferences", self.pages.settings, "СБРОСИТЬ НАСТРОЙКИ", UDim2.new(1,-8,0,48), UDim2.new(), function()
        self.preferenceToken = (self.preferenceToken or 0) + 1
        self:ApplyPreferences(DEFAULTS)
        self:SendAction("SetPreferences", {preferences=table.clone(self.preferences)})
    end)
    self.resetButton.LayoutOrder = 98
    settingsCopy("Version", "NIGHT SHIFT 4.5 · LIVING NIGHTMARE", 99)

    self.incidentCard = button("IncidentCard",ctx.content,"",UDim2.fromOffset(272,88),UDim2.fromOffset(24,20),function()self:OpenPanel("journal")end)
    self.incidentCard.AnchorPoint=Vector2.new(1,0)
    self.incidentCard.BackgroundColor3=Color3.fromRGB(54,37,31)
    self.incidentCard.TextColor3=Color3.fromRGB(245,209,178)
    self.incidentCard.TextSize=12;self.incidentCard.Visible=false
    self.incidentJournal=label("IncidentJournal",self.pages.journal,"",UDim2.new(1,-8,0,74),UDim2.new(),14)
    self.incidentJournal.LayoutOrder=-5;self.incidentJournal.AutomaticSize=Enum.AutomaticSize.Y
    self.incidentJournal.TextColor3=COLORS.orange
    self.cctvSync=label("CCTVSyncWarning",ctx.cctvPanel or ctx.content,"SYNC ERROR / ПРОВЕРЬТЕ СИСТЕМУ",UDim2.fromOffset(320,26),UDim2.new(.5,-160,0,44),12)
    self.cctvSync.TextXAlignment=Enum.TextXAlignment.Center
    self.cctvSync.TextColor3=COLORS.red;self.cctvSync.BackgroundTransparency=.22
    self.cctvSync.Visible=false;self.incident={active=false}

    self.campaignCard = button("CampaignCard", ctx.content, "", UDim2.fromOffset(300,84), UDim2.fromOffset(24,260), function() self:OpenPanel("missions") end)
    self.campaignCard.BackgroundColor3 = COLORS.panel
    self.campaignKicker = label("CampaignKicker", self.campaignCard, "ЛИЧНЫЙ КОНТРАКТ", UDim2.new(1,-24,0,16), UDim2.fromOffset(12,8), 10)
    self.campaignKicker.TextColor3 = COLORS.orange
    self.campaignTitle = label("CampaignTitle", self.campaignCard, "Ночной архив", UDim2.new(1,-24,0,22), UDim2.fromOffset(12,27), 13)
    self.campaignObjective = label("CampaignObjective", self.campaignCard, "Откройте миссии", UDim2.new(1,-24,0,30), UDim2.fromOffset(12,49), 11)
    self.campaignObjective.TextColor3 = COLORS.muted
    local function missionCopy(name, value, order, size, color)
        local l = label(name, self.pages.missions, value, UDim2.new(1,-8,0,size == 20 and 40 or 28), UDim2.new(), size or 14)
        l.LayoutOrder, l.TextColor3, l.AutomaticSize = order, color or COLORS.text, Enum.AutomaticSize.Y
        l.TextYAlignment = Enum.TextYAlignment.Top
        return l
    end
    self.missionProgress = missionCopy("MissionProgress", "НОЧНОЙ АРХИВ · 0 / 24", 1, 11, COLORS.orange)
    self.missionTitle = missionCopy("MissionTitle", "Ожидание личного контракта", 2, 20)
    self.missionSummary = missionCopy("MissionSummary", "Контракты открываются по ходу ночных смен.", 3, 14, COLORS.muted)
    self.missionObjective = missionCopy("MissionObjective", "", 4, 16)
    self.missionHint = missionCopy("MissionHint", "", 5, 13, COLORS.muted)
    self.missionTimer = missionCopy("MissionTimer", "", 6, 13, COLORS.orange)
    self.missionStatus = missionCopy("MissionStatus", "", 7, 13, COLORS.muted)
    self.missionRoute = button("MissionRoute", self.pages.missions, "ГДЕ НАХОДИТСЯ ЦЕЛЬ", UDim2.new(1,-8,0,48), UDim2.new(), function() self:OpenPanel("map") end)
    self.missionRoute.LayoutOrder = 8
    self.missionChoices, self.missionAssist, self.missionRecords = {}, {}, {}
    self.placeNow = label("CurrentPlace", self.pages.map, "Выберите помещение ниже", UDim2.new(1,-8,0,40), UDim2.new(), 16)
    self.placeNow.LayoutOrder, self.placeNow.AutomaticSize = 1, Enum.AutomaticSize.Y
    self.placeHint = label("PlaceHint", self.pages.map, "B1 — подвальный этаж. Вход через погрузочную.\nСтанции можно осматривать и без миссии. Действия вашего контракта отмечены отдельно.", UDim2.new(1,-8,0,70), UDim2.new(), 14)
    self.placeHint.LayoutOrder, self.placeHint.AutomaticSize = 2, Enum.AutomaticSize.Y
    self.placeHint.TextColor3 = COLORS.muted
    self.placeButtons = {}

    self.inspectionTitle = label("InspectionTitle", self.pages.journal, "", UDim2.new(1,-8,0,28), UDim2.new(), 16)
    self.inspectionTitle.LayoutOrder, self.inspectionTitle.AutomaticSize, self.inspectionTitle.Visible = -2, Enum.AutomaticSize.Y, false
    self.inspectionTitle.TextColor3 = COLORS.orange
    self.inspectionDetail = label("InspectionDetail", self.pages.journal, "", UDim2.new(1,-8,0,80), UDim2.new(), 14)
    self.inspectionDetail.LayoutOrder, self.inspectionDetail.AutomaticSize, self.inspectionDetail.Visible = -1, Enum.AutomaticSize.Y, false
    self.inspectionDetail.TextYAlignment = Enum.TextYAlignment.Top
    self.storyLabel = label("Story", self.pages.journal, "Здесь появятся записи о ночных происшествиях.", UDim2.new(1, -8, 0, 116), UDim2.new(), 16)
    self.storyLabel.LayoutOrder = 1
    self.resultLabel = label("Results", self.pages.journal, "", UDim2.new(1, -8, 0, 132), UDim2.new(), 15)
    self.resultLabel.LayoutOrder = 2
    self.resultLabel.AutomaticSize = Enum.AutomaticSize.Y
    self.customerReceipt = label("CustomerReceipt", self.pages.journal, "", UDim2.new(1, -8, 0, 132), UDim2.new(), 15)
    self.customerReceipt.LayoutOrder, self.customerReceipt.Visible = 3, false
    self.serveCustomer = button("ServeCustomer", self.pages.journal, "ОБСЛУЖИТЬ ПОКУПАТЕЛЯ", UDim2.new(1, -8, 0, 48), UDim2.new(), function()
        self:SendAction("ServeCustomer", {choice = "serve"}); self:ClosePanel()
    end)
    self.refuseCustomer = button("RefuseCustomer", self.pages.journal, "ОТКАЗАТЬ В ОБСЛУЖИВАНИИ", UDim2.new(1, -8, 0, 48), UDim2.new(), function()
        self:SendAction("ServeCustomer", {choice = "refuse"}); self:ClosePanel()
    end)
    self.serveCustomer.LayoutOrder, self.refuseCustomer.LayoutOrder = 4, 5
    self.serveCustomer.Visible, self.refuseCustomer.Visible = false, false
    local help = label("Help", self.pages.journal, "Фонарь — F. Действие — E. Бег — Shift.\nQ — выйти из укрытия. G — положить предмет.\nV — рация. P — настройки.\nM — миссии. N — локации.\nСтанции доступны для свободного осмотра. Результат — в журнале. Действия личного контракта подписаны «Контракт».\nВыберите задание в списке, чтобы отметить: «беру его».\nКамеры: Q / R — сменить вид; отметьте тип аномалии кнопкой под изображением.", UDim2.new(1, -8, 0, 160), UDim2.new(), 14)
    help.LayoutOrder = 6
    help.AutomaticSize = Enum.AutomaticSize.Y

    self.caption = label("SoundCaption", ctx.content, "", UDim2.fromOffset(420, 42), UDim2.new(.5, 0, 1, -80), 15)
    self.caption.AnchorPoint, self.caption.Visible = Vector2.new(.5, 1), false
    self.caption.BackgroundTransparency, self.caption.BackgroundColor3 = .14, COLORS.panel
    self.caption.TextXAlignment, self.caption.ZIndex = Enum.TextXAlignment.Center, 102
    rounded(self.caption)
    self.reportBar = box("Frame", "CameraReport", ctx.content, UDim2.fromOffset(580, 64), UDim2.new(.5, 0, 1, -126))
    self.reportBar.AnchorPoint, self.reportBar.Visible, self.reportBar.ZIndex = Vector2.new(.5, 1), false, 75
    rounded(self.reportBar)
    self.reportTitle = label("ReportTitle", self.reportBar, "ОТМЕТИТЬ АНОМАЛИЮ НА ЭТОЙ КАМЕРЕ", UDim2.new(1, -12, 0, 22), UDim2.fromOffset(6, 0), 12)
    self.reportTitle.TextXAlignment, self.reportTitle.TextColor3 = Enum.TextXAlignment.Center, COLORS.orange
    self.reportButtons = {}
    for i, pair in ipairs({{"silhouette", "СИЛУЭТ"}, {"light", "НЕОБЫЧНЫЙ СВЕТ"}, {"open_door", "ОТКРЫТЫЙ ЛЮК"}}) do
        local b = button("Report" .. pair[1], self.reportBar, pair[2], UDim2.new(1/3, -8, 0, 36), UDim2.new((i-1)/3, 4, 0, 24), function()
            local active, index = self:GetCCTV()
            local info = self.gameplay.anomalies or self.gameplay.cctv or {}
            if active and info.active == true and number(info.reportCooldown, 0, 0, 30) <= 0 then
                self:SendAction("ReportAnomaly", {camera = index, choice = pair[1]})
            end
        end)
        table.insert(self.reportButtons, b)
    end

    if ctx.tasksScroll then
        self.tutorialCard = box("Frame", "FirstShiftGuide", self.pages.team, UDim2.new(1, -8, 0, 128))
        self.tutorialCard.LayoutOrder, self.tutorialCard.Visible = -10, false
        self.tutorialCard.BackgroundColor3 = COLORS.secondary
        rounded(self.tutorialCard)
        self.tutorialText = label("Instruction", self.tutorialCard, "", UDim2.new(1, -12, 0, 58), UDim2.fromOffset(6, 2), 13)
        self.skipButton = button("Skip", self.tutorialCard, "ПРОПУСТИТЬ ОБУЧЕНИЕ", UDim2.new(1, -12, 0, 30), UDim2.fromOffset(6, 62), function() self:SendAction("SkipTutorial") end)
    end
    self.conditionBar = box("Frame", "DownedStatus", ctx.content, UDim2.fromOffset(440, 160), UDim2.fromScale(.5, .48))
    self.conditionBar.AnchorPoint, self.conditionBar.Visible, self.conditionBar.ZIndex = Vector2.new(.5, .5), false, 105
    rounded(self.conditionBar, 12)
    self.conditionText = label("Condition", self.conditionBar, "", UDim2.new(1, -28, 0, 98), UDim2.fromOffset(14, 10), 19)
    self.conditionText.TextXAlignment, self.conditionText.TextColor3 = Enum.TextXAlignment.Center, COLORS.red
    self.secondChance = button("SecondChance", self.conditionBar, "ПОДНЯТЬСЯ", UDim2.new(1, -32, 0, 40), UDim2.fromOffset(16, 112), function()
        if self.condition.downed and self.condition.secondChanceAvailable and self.condition.recoveryReady then self:SendAction("SecondChance") end
    end)

    self.markerFolder=Instance.new("Folder");self.markerFolder.Name="NightShiftClientMarkers";self.markerFolder.Parent=workspace
    self.colorEffect=Instance.new("ColorCorrectionEffect")
    self.colorEffect.Name,self.colorEffect.Brightness,self.colorEffect.Parent="NightShift37PersonalEffects",0,Lighting

    self.comfortEffect = Instance.new("ColorCorrectionEffect")
    self.comfortEffect.Name, self.comfortEffect.Brightness, self.comfortEffect.Parent = "NightShift40Comfort", 0, Lighting
    self.originalFov = workspace.CurrentCamera and workspace.CurrentCamera.FieldOfView

    function self:SendAction(action, fields)
        if self.dead then return end
        local payload = type(fields) == "table" and table.clone(fields) or {}
        payload.action = action
        remote:FireServer("NS36Action", payload)
    end

    function self:GetCCTV()
        if ctx.getCCTV then return ctx.getCCTV() end
        return false, 1
    end

    function self:GetTasks(base)
        return Experience.MergeTasks(base, self.gameplay.tasks)
    end

    function self:TrackCCTVPart(object)
        if object:IsA("BasePart") and object:GetAttribute("CCTVOnly") == true then
            if self.cctvOnlyParts[object] == nil then self.cctvOnlyParts[object] = object.LocalTransparencyModifier end
            object.LocalTransparencyModifier = self:GetCCTV() and 0 or 1
        end
    end

    function self:UpdateCCTVVisibility()
        local modifier = self:GetCCTV() and 0 or 1
        for object in pairs(self.cctvOnlyParts) do
            if object.Parent then object.LocalTransparencyModifier = modifier else self.cctvOnlyParts[object] = nil end
        end
    end

    function self:Caption(value, position, seconds)
        if not self.preferences.captions or value == "" then return end
        local suffix = ""
        local camera = workspace.CurrentCamera
        if typeof(position) == "Vector3" and camera then
            local delta = camera.CFrame:PointToObjectSpace(position)
            if delta.Magnitude > 90 then return end
            if delta.Magnitude < 7 then suffix = " · рядом"
            elseif math.abs(delta.X) > math.abs(delta.Z) * .55 then suffix = delta.X < 0 and " · слева" or " · справа"
            elseif delta.Z > 0 then suffix = " · позади"
            else suffix = " · впереди" end
        end
        self.captionToken += 1
        local token = self.captionToken
        self.captionUntil = os.clock() + (seconds or 2.8)
        self.caption.Text = text(value) .. suffix
        self.caption.Visible = not (ctx.isToastVisible and ctx.isToastVisible())
        task.delay(seconds or 2.8, function()
            if not self.dead and self.captionToken == token then self.caption.Visible = false end
        end)
    end

    function self:PlaySound(data)
        local audio=ctx.getAudio and ctx.getAudio()
        if audio and not self.dead then return audio:Play(data) end
        return false
    end

    function self:UpdateAudioStatus(state)
        self.audioStatus=type(state)=="table" and state or {}
        if self.soundStatus then
            self.soundStatus.Text=text(self.audioStatus.text,"Подключаем звук…")
            self.soundStatus.TextColor3=self.audioStatus.state=="failed" and COLORS.red or COLORS.muted
        end
    end

    function self:ApplyQuality(object)
        local low = self.preferences.quality == "low" or (self.preferences.quality == "auto" and UserInputService.TouchEnabled)
        if object:IsA("Light") then
            if self.shadowDefaults[object] == nil then self.shadowDefaults[object] = object.Shadows end
            if low then object.Shadows = false else object.Shadows = self.shadowDefaults[object] end
        elseif object:IsA("BasePart") and not object.CanCollide then
            if self.shadowDefaults[object] == nil then self.shadowDefaults[object] = object.CastShadow end
            if low then object.CastShadow = false else object.CastShadow = self.shadowDefaults[object] end
        end
    end

    function self:ScaleText()
        for _, object in ipairs(ctx.content:GetDescendants()) do
            if object:IsA("TextLabel") or object:IsA("TextButton") then
                local base = object:GetAttribute("NS40BaseTextSize")
                if type(base) ~= "number" then base = object.TextSize; object:SetAttribute("NS40BaseTextSize", base) end
                object.TextSize = math.min(25, base * self.preferences.textScale)
            end
        end
    end

    function self:ResponsiveText(object, base)
        object:SetAttribute("NS40BaseTextSize", base)
        object.TextSize = math.min(25, base * self.preferences.textScale)
    end

    function self:ApplyPreferences(value)
        self.preferences = Experience.NormalizePreferences(value)
        local audio = ctx.getAudio and ctx.getAudio(); if audio then audio:SetPreferences(self.preferences) end
        for key, entry in pairs(self.settingsRows) do
            if entry.value then
                entry.value.Text = entry.format == "degrees" and (tostring(math.floor(self.preferences[key]+.5)) .. "°") or (tostring(math.floor(self.preferences[key]*100+.5)) .. "%")
            elseif entry.button then entry.button.Text = entry.title .. ": " .. (self.preferences[key] and "ВКЛ" or "ВЫКЛ") end
        end
        self.qualityButton.Text = "ГРАФИКА: " .. ({auto="АВТО",low="ЛЁГКАЯ",standard="СТАНДАРТ"})[self.preferences.quality]
        self.mixButton.Text = "ЗВУКОВОЙ РЕЖИМ: " .. (self.preferences.mix == "night" and "МЯГКИЙ" or "ОБЫЧНЫЙ")
        if not self.preferences.captions then self.caption.Visible = false end
        if self.preferences.reducedFlashes then self.effectUntil = 0; self.colorEffect.Brightness = 0 end
        if not self.preferences.cameraShake then self.shakeUntil = 0 end
        self.comfortEffect.Brightness = self.preferences.brightness
        if workspace.CurrentCamera and not self:GetCCTV() then workspace.CurrentCamera.FieldOfView = self.preferences.fov end
        self.panel.BackgroundColor3 = self.preferences.highContrast and Color3.fromRGB(7,9,10) or COLORS.panel
        if ctx.tasksPanel then ctx.tasksPanel.BackgroundTransparency = self.preferences.highContrast and 0 or .15 end
        local world = workspace:FindFirstChild("NightShiftWorld")
        if world then for _, object in ipairs(world:GetDescendants()) do self:ApplyQuality(object) end end
        self:UpdateMissionMarker()
        self:ScaleText()
        if ctx.refreshLayout then ctx.refreshLayout() end
    end

    function self:SetPreference(key, value)
        local updated = table.clone(self.preferences); updated[key] = value
        self:ApplyPreferences(updated)
        self.preferenceToken = (self.preferenceToken or 0) + 1
        local token = self.preferenceToken
        task.delay(.35, function()
            if not self.dead and token == self.preferenceToken then self:SendAction("SetPreferences", {preferences = table.clone(self.preferences)}) end
        end)
    end

    function self:IsBlockingInput()
        return self.modal ~= nil or self.condition.downed == true or player:GetAttribute("NightShiftDowned") == true
    end

    function self:SyncInputLock()
        local blocked = self.modal ~= nil or (ctx.shop and ctx.shop.Visible == true)
        player:SetAttribute("NightShiftClientMenu", blocked == true)
        if blocked and not self.inputLocked then
            self.inputLocked = true
            self.promptsWereEnabled = ProximityPromptService.Enabled
            ProximityPromptService.Enabled = false
            local playerScripts = player:FindFirstChild("PlayerScripts")
            local playerModule = playerScripts and playerScripts:FindFirstChild("PlayerModule")
            if playerModule then
                local ok, controls = pcall(function() return require(playerModule):GetControls() end)
                if ok and controls then self.modalControls = controls; pcall(function() controls:Disable() end) end
            end
            ContextActionService:BindActionAtPriority("NightShift36Modal", function() return Enum.ContextActionResult.Sink end, false, 3000,
                Enum.KeyCode.W, Enum.KeyCode.A, Enum.KeyCode.S, Enum.KeyCode.D,
                Enum.KeyCode.E, Enum.KeyCode.F, Enum.KeyCode.Q, Enum.KeyCode.R,
                Enum.KeyCode.LeftShift, Enum.KeyCode.RightShift, Enum.KeyCode.ButtonX, Enum.KeyCode.ButtonY, Enum.KeyCode.ButtonL3)
        elseif not blocked and self.inputLocked then
            self.inputLocked = false
            ContextActionService:UnbindAction("NightShift36Modal")
            ProximityPromptService.Enabled = self.promptsWereEnabled ~= false
            if self.modalControls then
                local cctv = self:GetCCTV()
                if not cctv then pcall(function() self.modalControls:Enable() end) end
                self.modalControls = nil
            end
        end
    end

    function self:OpenPanel(tab)
        if not self.pages[tab] or self.condition.downed or player:GetAttribute("NightShiftDowned") then return end
        if not self.modal then
            if ctx.releaseControls then ctx.releaseControls() end
            if ctx.closeShop then ctx.closeShop() end
        end
        self:PlaySound({kind="menu_open"})
        self.modal, self.shield.Visible = tab, true
        self:SyncInputLock()
        for name, page in pairs(self.pages) do
            page.Visible = name == tab
            self.tabs[name].BackgroundColor3 = name == tab and Color3.fromRGB(66,57,42) or COLORS.secondary
            self.tabs[name].TextColor3 = name == tab and COLORS.orange or COLORS.muted
        end
        self.panelTitle.Text = ({missions="НОЧНОЙ АРХИВ",map="ЛОКАЦИИ",settings="ЗВУК И КОМФОРТ",journal="ЖУРНАЛ СМЕНЫ",upgrades="СНАРЯЖЕНИЕ",team="КОМАНДА"})[tab]
        if ctx.refreshLayout then ctx.refreshLayout() end
        if UserInputService.GamepadEnabled then GuiService.SelectedObject = self.closeButton end
    end

    function self:ClosePanel()
        if self.modal and not self.dead then self:PlaySound({kind="menu_close"}) end
        self.modal, self.shield.Visible = nil, false
        self:SyncInputLock()
        if GuiService.SelectedObject and GuiService.SelectedObject:IsDescendantOf(self.shield) then GuiService.SelectedObject = nil end
        if ctx.refreshLayout and not self.dead then ctx.refreshLayout() end
    end

    function self:Layout()
        local width,height=ctx.content.Size.X.Offset,ctx.content.Size.Y.Offset
        local touch=UserInputService.TouchEnabled
        local compact=width<620
        local hit=touch and 44 or 40
        local panelWidth,panelHeight=math.min(680,width-24),math.min(602,height-24)
        self.panel.Size=UDim2.fromOffset(panelWidth,panelHeight)
        local padding=compact and 16 or 24
        self.panelTitle.Position=UDim2.fromOffset(padding,37)
        self:ResponsiveText(self.panelTitle, compact and 18 or 22)
        self.panelTitle.Text = ({missions="НОЧНОЙ АРХИВ",map="ЛОКАЦИИ",settings=compact and "НАСТРОЙКИ" or "ЗВУК И КОМФОРТ",journal="ЖУРНАЛ СМЕНЫ",upgrades="СНАРЯЖЕНИЕ",team="КОМАНДА"})[self.modal] or self.panelTitle.Text
        self.panelKicker.Position=UDim2.fromOffset(padding,17)
        self:ResponsiveText(self.panelKicker, compact and 9 or 10)
        self.closeButton.Size=UDim2.fromOffset(44,44)
        self.closeButton.Position=UDim2.new(1,-padding-44,0,18)
        self.panelKicker.Text = compact and "NIGHTMART / ТЕРМИНАЛ" or "NIGHTMART  /  СЛУЖЕБНЫЙ ТЕРМИНАЛ"
        local cols=compact and 3 or 6
        local gap=8
        local usable=panelWidth-padding*2
        local tabWidth=(usable-gap*(cols-1))/cols
        for i,name in ipairs(self.tabOrder) do
            local index=i-1
            self.tabs[name].Position=UDim2.fromOffset(padding+(index%cols)*(tabWidth+gap),84+math.floor(index/cols)*(hit+gap))
            self.tabs[name].Size=UDim2.fromOffset(tabWidth,hit)
        end
        local pageTop=84+math.ceil(#self.tabOrder/cols)*(hit+gap)+16
        for _,page in pairs(self.pages) do
            page.Position=UDim2.fromOffset(padding,pageTop)
            page.Size=UDim2.new(1,-padding*2,1,-pageTop-16)
        end
        local small=width<980 or height<620
        self.footer.Size=UDim2.fromOffset(96,touch and 44 or 40)
        self.footer.Position=UDim2.new(1,-12,0,4)
        self.footer.AnchorPoint=Vector2.new(1,0)
        self.dropButton.Size,self.dropButton.Position=UDim2.fromScale(1,1),UDim2.new()
        self.dropButton.Text=touch and "ПОЛОЖИТЬ" or "G · ПОЛОЖИТЬ"
        self:ResponsiveText(self.dropButton, 11)
        local carrying = self:GetCarry() ~= nil
        self.dropButton.Visible, self.dropButton.Active, self.dropButton.AutoButtonColor = carrying, carrying, carrying
        self.dropButton.TextColor3 = carrying and COLORS.orange or COLORS.muted
        self.footer.Visible=carrying and not self.modal and not self:GetCCTV() and not self.condition.downed
        for _,button in ipairs(self.pingRows)do button.Size=UDim2.new(1,-8,0,hit+4)end
        for _,entry in pairs(self.settingsRows) do
            if entry.row then
                local stacked=panelWidth<460
                entry.row.Size=UDim2.new(1,-8,0,stacked and 82 or 58)
                local y=stacked and 30 or 5
                entry.minus.Size,entry.plus.Size=UDim2.fromOffset(44,44),UDim2.fromOffset(44,44)
                entry.minus.Position,entry.plus.Position=UDim2.new(1,-152,0,y),UDim2.new(1,-48,0,y)
                entry.value.Position,entry.value.Size=UDim2.new(1,-104,0,y),UDim2.fromOffset(52,44)
                local heading=entry.row:FindFirstChild("Label")
                heading.Position=UDim2.new()
                heading.Size=stacked and UDim2.new(1,0,0,24) or UDim2.new(1,-168,1,0)
                self:ResponsiveText(heading, 12)
            elseif entry.button then entry.button.Size=UDim2.new(1,-8,0,hit+10);self:ResponsiveText(entry.button, 12) end
        end
        self.qualityButton.Size,self.soundTestButton.Size=UDim2.new(1,-8,0,hit+8),UDim2.new(1,-8,0,hit+8)
        self:ResponsiveText(self.qualityButton, 12)
        self.serveCustomer.Size,self.refuseCustomer.Size=UDim2.new(1,-8,0,hit+8),UDim2.new(1,-8,0,hit+8)
        self.caption.Size=UDim2.fromOffset(math.min(440,width-24),58)
        self:ResponsiveText(self.caption, compact and 11 or 12)
        local reportWidth=math.min(620,width-24)
        self.reportBar.Size=UDim2.fromOffset(reportWidth,hit+34)
        self.reportBar.Position=UDim2.new(.5,0,1,-(touch and 146 or 126))
        for _,b in ipairs(self.reportButtons)do b.Size=UDim2.new(1/3,-10,0,hit);b.Position=UDim2.new(b.Position.X.Scale,5,0,28);self:ResponsiveText(b,compact and 10 or 12) end
        self:ResponsiveText(self.reportTitle, compact and 9 or 11)
        self.conditionBar.Size=UDim2.fromOffset(math.min(440,width-24),122+hit)
        self:ResponsiveText(self.conditionText, compact and 16 or 19)
        self.secondChance.Size,self.secondChance.Position=UDim2.new(1,-32,0,hit),UDim2.fromOffset(16,112)
        if self.tutorialCard then
            self.tutorialCard.Size=UDim2.new(1,-8,0,hit+90)
            self.tutorialText.Size,self.tutorialText.Position=UDim2.new(1,-24,0,72),UDim2.fromOffset(12,6)
            self:ResponsiveText(self.tutorialText, 13)
            self.skipButton.Size,self.skipButton.Position=UDim2.new(1,-24,0,hit),UDim2.fromOffset(12,82)
            self:ResponsiveText(self.skipButton, 11)
        end
        local portrait = width < 620 and height > width
        local expanded = ctx.isTasksExpanded and ctx.isTasksExpanded()
        self.campaignCard.Size = UDim2.fromOffset(portrait and width-108 or 300, portrait and 90 or 84)
        local bottom = ctx.tasksPanel and ctx.tasksPanel.Position.Y.Offset + ctx.tasksPanel.Size.Y.Offset or 260
        self.campaignCard.Position = UDim2.fromOffset(ctx.tasksPanel and ctx.tasksPanel.Position.X.Offset or 24, bottom+10)
        self.campaignCard.Visible = self.campaign.mission ~= nil and not self.modal and not self:GetCCTV() and not self.condition.downed
            and not player:GetAttribute("NightShiftHidden") and not player:GetAttribute("NightShiftDowned")
            and not (ctx.isToastVisible and ctx.isToastVisible()) and not expanded and height > 500
        local incident=self.incident or {}
        local isIncident=incident.active==true and self.phase=="SHIFT"
        self.incidentCard.Visible=isIncident and self.preferences.incidentHints and not self.modal and not self:GetCCTV()
            and not self.condition.downed and height>380 and width>=640
        self.incidentCard.Size=UDim2.fromOffset(math.min(width-24,compact and 224 or 280),compact and 70 or 88)
        self.incidentCard.Position=UDim2.new(1,-12,0,compact and 64 or 18)
        self.incidentCard.Text="АВАРИЯ  ·  "..tostring(incident.remaining or 0).."с\n"..text(incident.title).."\n"..text(incident.action)
        self.incidentCard.TextSize=compact and 10 or 12
        self.campaignKicker.Text = touch and ("ГЛАВА " .. tostring(self.campaign.chapter or 1) .. "/8 · МИССИИ") or ("ГЛАВА " .. tostring(self.campaign.chapter or 1) .. "/8 · МИССИИ [M]")
        self:UpdateCameraUI()
        self:ScaleText()
    end

    function self:UpdateCameraUI()
        local active = self:GetCCTV()
        self.cctvSync.Visible=active==true and self.incident and self.incident.id=="desync" and self.incident.active
            and not self.preferences.reducedInterference and not self.modal
        self:UpdateCCTVVisibility()
        self:UpdateMissionMarker()
        local info = self.gameplay.anomalies or self.gameplay.cctv or {}
        self.reportBar.Visible = active == true and info.active == true and not self.modal and not self.condition.downed
        local cooldown = math.ceil(number(info.reportCooldown, 0, 0, 30))
        self.reportTitle.Text = cooldown > 0 and ("ПРОВЕРЬТЕ НАБЛЮДЕНИЕ · " .. cooldown .. " СЕК") or "ОТМЕТИТЬ АНОМАЛИЮ НА ЭТОЙ КАМЕРЕ"
        for _, b in ipairs(self.reportButtons) do b.Active = cooldown <= 0; b.AutoButtonColor = cooldown <= 0 end
        local width,height=ctx.content.Size.X.Offset,ctx.content.Size.Y.Offset
        local portrait=width<620 and height>width
        local compact=width<980 or height<620
        self.caption.Visible=self.preferences.captions and os.clock()<(self.captionUntil or 0) and not self.modal and not (ctx.isToastVisible and ctx.isToastVisible())
        if active then
            self.caption.AnchorPoint=Vector2.new(.5,1)
            self.caption.Size=UDim2.fromOffset(math.min(440,width-24),58)
            self.caption.Position=UDim2.new(.5,0,1,-(UserInputService.TouchEnabled and 244 or 218))
        elseif portrait then
            self.caption.AnchorPoint=Vector2.new(0,0)
            self.caption.Size=UDim2.fromOffset(width-100,64)
            local bottom=ctx.tasksPanel and (ctx.tasksPanel.Position.Y.Offset+ctx.tasksPanel.Size.Y.Offset) or 266
            if self.campaignCard.Visible then bottom = self.campaignCard.Position.Y.Offset + self.campaignCard.Size.Y.Offset end
            self.caption.Position=UDim2.fromOffset(12,math.min(bottom+8,height-76))
        elseif compact then
            local space=UserInputService.TouchEnabled and 76 or 0
            self.caption.AnchorPoint=Vector2.new(1,1)
            self.caption.Size=UDim2.fromOffset(math.min(360,width-280-space),64)
            self.caption.Position=UDim2.new(1,-12-space,1,-98)
        else
            self.caption.AnchorPoint=Vector2.new(.5,1)
            self.caption.Size=UDim2.fromOffset(440,58)
            self.caption.Position=UDim2.new(.5,0,1,-100)
        end
    end

    function self:ShowThreat(data)
        self:Caption("Опасность: " .. text(type(data) == "table" and data.name, "движение рядом"), type(data) == "table" and data.position or nil, 3)
        if ctx.showToast then ctx.showToast("Прислушайтесь. Существо ищет сотрудников.") end
        self:Visual({kind = "threat", duration = .65})
    end

    function self:ShowCaught()
        if ctx.releaseControls then ctx.releaseControls() end
        self:Caption("Вас настигли. Дождитесь помощи или используйте доступную вторую попытку.", nil, 3)
        self:Visual({kind = "caught", duration = .9})
    end

    function self:Visual(data)
        if type(data) ~= "table" then return end
        local duration = number(data.duration, 1, .1, 15)
        if not self.preferences.reducedFlashes then
            self.effectKind, self.effectStarted, self.effectUntil = data.kind, os.clock(), os.clock() + duration
        end
        if self.preferences.cameraShake and (data.kind == "caught" or data.kind == "threat") then self.shakeUntil = os.clock() + math.min(duration, .8) end
    end

    function self:UpdateTeam(data)
        local members = type(data) == "table" and data or {}
        self.teamEmpty.Visible = #members == 0
        for i, item in ipairs(members) do
            local l = self.teamLabels[i]
            if not l then
                l = label("Employee" .. i, self.pages.team, "", UDim2.new(1, -8, 0, 54), UDim2.new(), 14)
                l.LayoutOrder = 10 + i; self.teamLabels[i] = l
            end
            l.Visible = true
            local carry = text(item.carrying)
            l.Text = text(item.name, "Сотрудник") .. " · " .. text(item.status, "на смене") .. (carry ~= "" and "\nНесёт: " .. carry or "") .. "\nПолезный вклад: " .. tostring(math.floor(number(item.contribution, 0, 0, 100000)))
        end
        for i = #members + 1, #self.teamLabels do self.teamLabels[i].Visible = false end
    end

    function self:UpdateCondition(data)
        self.condition = type(data) == "table" and data or {}
        self.conditionBar.Visible = self.condition.downed == true
        if self.condition.downed then
            if ctx.closeShop then ctx.closeShop() end
            self:ClosePanel()
            if ctx.releaseControls then ctx.releaseControls() end
            local remaining = math.ceil(number(self.condition.reviveRemaining, 0, 0, 120))
            self.conditionText.Text = "НУЖНА ПОМОЩЬ\n" .. (self.condition.soloSecondChance and "Вы сможете использовать вторую попытку." or "Напарник может помочь вам подняться.") .. "\nЭвакуация через " .. remaining .. " сек."
            self.secondChance.Visible = self.condition.secondChanceAvailable == true
            self.secondChance.Text = self.condition.recoveryReady and "ИСПОЛЬЗОВАТЬ ВТОРУЮ ПОПЫТКУ" or "ПЕРЕВЕДИТЕ ДЫХАНИЕ…"
            self.secondChance.Active = self.condition.recoveryReady == true
            self.secondChance.AutoButtonColor = self.condition.recoveryReady == true
        else
            self.secondChance.Visible = false
        end
    end

    function self:ShowPing(data)
        if type(data) ~= "table" then return end
        local position = typeof(data.position) == "Vector3" and data.position or nil
        local names = {help = "Нужна помощь", danger = "Опасность", working = "Занимаюсь задачей", safe = "Здесь безопасно"}
        local value = text(data.name, "Напарник") .. ": " .. (names[data.kind] or text(data.text, "Отметка"))
        self:PlaySound({kind = "ping", caption = value, position = position})
        self:Caption(value, position, 4)
        if not position then return end
        -- Temporary in-world marker, not a permanent silhouette through every wall.
        local p = Instance.new("Part")
        p.Name, p.Size, p.Position = "TeamRadioMarker", Vector3.new(.1,.1,.1), position + Vector3.new(0, 3, 0)
        p.Anchored, p.Transparency, p.CanCollide, p.CanQuery, p.CanTouch = true, 1, false, false, false
        p.Parent = self.markerFolder
        local billboard = Instance.new("BillboardGui")
        billboard.Size, billboard.AlwaysOnTop, billboard.MaxDistance = UDim2.fromOffset(190, 45), false, 80
        billboard.Adornee, billboard.Parent = p, p
        local l = label("MarkerText", billboard, value, UDim2.fromScale(1,1), UDim2.new(), 13)
        l.TextXAlignment, l.BackgroundTransparency = Enum.TextXAlignment.Center, .15
        l.TextColor3 = data.kind == "danger" and COLORS.red or COLORS.mint
        Debris:AddItem(p, 7)
    end

    function self:GetCarry()
        return self.campaign.carry or self.gameplay.carry
    end

    function self:UpdateMissionMarker()
        local mission = self.campaign.mission
        local valid = type(mission) == "table" and typeof(mission.position) == "Vector3"
        local world = workspace:FindFirstChild("NightShiftWorld")
        local stationPart
        if valid and world and type(mission.stationId) == "string" then
            for _, candidate in ipairs(world:GetDescendants()) do
                if candidate:IsA("BasePart") and candidate:GetAttribute("StationId") == mission.stationId then
                    stationPart = candidate
                    break
                end
            end
        end
        local targetPosition = Vector3.zero
        if valid then
            if stationPart then
                targetPosition = stationPart.Position + stationPart.CFrame.LookVector * 1.65 + Vector3.new(0, 1.35, 0)
            else
                targetPosition = mission.position + Vector3.new(0, 1.6, 0)
            end
        end
        local character = player.Character
        local root = character and character:FindFirstChild("HumanoidRootPart")
        local camera = workspace.CurrentCamera
        local distance = root and (root.Position - targetPosition).Magnitude or math.huge
        local visible = false
        if valid and camera and distance <= 34 then
            local params = RaycastParams.new()
            params.FilterType = Enum.RaycastFilterType.Exclude
            local excludes = {self.markerFolder}
            if character then table.insert(excludes, character) end
            local stationModel = stationPart and stationPart:FindFirstAncestorOfClass("Model")
            if stationModel then table.insert(excludes, stationModel)
            elseif stationPart then table.insert(excludes, stationPart) end
            params.FilterDescendantsInstances = excludes
            params.RespectCanCollide = true
            params.IgnoreWater = true
            visible = workspace:Raycast(camera.CFrame.Position, targetPosition - camera.CFrame.Position, params) == nil
        end
        local enabled = valid and visible and distance > 7.5 and self.preferences.objectiveMarker
            and self.campaign.active == true and not self:GetCCTV() and not self.modal and not self.condition.downed
            and not player:GetAttribute("NightShiftHidden") and not player:GetAttribute("NightShiftDowned")
        if valid and not self.missionMarker then
            local part = Instance.new("Part")
            part.Name, part.Size = "MissionMarker", Vector3.new(.1,.1,.1)
            part.Anchored, part.Transparency, part.CanCollide, part.CanQuery, part.CanTouch = true, 1, false, false, false
            part.Parent = self.markerFolder
            local gui = Instance.new("BillboardGui")
            gui.Name, gui.Size, gui.AlwaysOnTop, gui.MaxDistance = "MissionMarkerLabel", UDim2.fromOffset(136,30), false, 34
            gui.LightInfluence, gui.StudsOffsetWorldSpace = 0, Vector3.new(0,0,0)
            gui.Adornee, gui.Parent = part, part
            local caption = label("Objective", gui, "ЦЕЛЬ КОНТРАКТА", UDim2.fromScale(1,1), UDim2.new(), 10)
            caption.Font = Enum.Font.GothamBold
            caption.TextColor3, caption.BackgroundColor3, caption.BackgroundTransparency = COLORS.orange, COLORS.panel, .12
            caption.TextXAlignment = Enum.TextXAlignment.Center
            local corner = Instance.new("UICorner"); corner.CornerRadius = UDim.new(0,5); corner.Parent = caption
            local stroke = Instance.new("UIStroke"); stroke.Color = COLORS.orange; stroke.Transparency = .42; stroke.Thickness = 1; stroke.Parent = caption
            self.missionMarker, self.missionBillboard = part, gui
        end
        if self.missionBillboard then self.missionBillboard.Enabled = enabled == true end
        if valid and self.missionMarker then self.missionMarker.Position = targetPosition end
    end

    function self:UpdateStationPrompts()
        local world = workspace:FindFirstChild("NightShiftWorld")
        if not world then return end
        local mission = type(self.campaign.mission)=="table" and self.campaign.mission or {}
        local verbs = {inspect="осмотреть",pickup="взять предмет",deliver="передать предмет",work="начать проверку",choice="открыть панель",sequence="открыть панель"}
        for _, prompt in ipairs(world:GetDescendants()) do
            if prompt:IsA("ProximityPrompt") and prompt:GetAttribute("NS41Explorable") then
                local id = prompt:GetAttribute("CampaignStation")
                if not self.stationPromptDefaults[prompt] then
                    self.stationPromptDefaults[prompt] = {action=prompt.ActionText,object=prompt.ObjectText}
                end
                local original = self.stationPromptDefaults[prompt]
                local personal = self.campaign.active==true and mission.stationId==id
                if personal then
                    prompt.ActionText = "Контракт · " .. (verbs[mission.type] or "выполнить этап")
                    prompt.ObjectText = original.object
                else
                    local action = prompt.Parent and prompt.Parent:GetAttribute("InspectAction")
                    prompt.ActionText = text(action,"Осмотреть")
                    prompt.ObjectText = original.object
                end
            end
        end
    end

    function self:RecordInspection(data)
        if type(data)~="table" then return end
        self.lastInspection = data
        self.inspectionTitle.Text = "ОСМОТР · " .. text(data.title,"Оборудование")
        local lines = {text(data.status),text(data.text)}
        if text(data.hint)~="" then table.insert(lines,text(data.hint)) end
        if data.contractActive and text(data.nextObjective)~="" then
            table.insert(lines,"ВАШ КОНТРАКТ\n" .. text(data.nextObjective) .. "\nГДЕ: " .. text(data.nextRoom,"См. миссии"))
        else
            table.insert(lines,"Свободный осмотр доступен без задания. Для операций контракта откройте «Миссии».")
        end
        self.inspectionDetail.Text = table.concat(lines,"\n\n")
        self.inspectionTitle.Visible, self.inspectionDetail.Visible = true, true
        self:ScaleText()
        if ctx.showToast then ctx.showToast(text(data.title,"Осмотр") .. "\nРезультат записан в журнал.") end
    end

    function self:UpdateCampaign(data)
        self.campaign = type(data) == "table" and data or {}
        local c = self.campaign
        local mission = type(c.mission) == "table" and c.mission or {}
        local quota = type(c.quota) == "table" and c.quota or {}
        local total, completed = number(c.total,24,1,999), number(c.completed,0,0,999)
        self.missionProgress.Text = "ГЛАВА " .. tostring(c.chapter or 1) .. "/" .. tostring(c.chapters or 8)
            .. " · " .. text(c.chapterTitle,"Ночной архив") .. "\nКОНТРАКТЫ " .. tostring(completed) .. " / " .. tostring(total)
        self.missionTitle.Text = text(mission.title,"Ожидание контракта")
        self.missionSummary.Text = text(mission.summary,"Контракты появляются после загрузки профиля.")
        self.missionObjective.Text = "ЭТАП " .. tostring(mission.step or 1) .. " / " .. tostring(mission.steps or 1)
            .. "\n" .. text(mission.objective,"Дождитесь начала смены")
        local nearHint = c.active and mission.near ~= true and "\nПодойдите к станции, чтобы выполнить действие." or ""
        self.missionHint.Text = "ГДЕ: " .. text(mission.location,"Объект") .. "\n" .. text(mission.hint) .. nearHint
        local timer = type(c.timer) == "table" and c.timer or {}
        local sequence = type(c.sequenceProgress) == "table" and c.sequenceProgress or {}
        if timer.active then
            self.missionTimer.Text = "ПРОВЕРКА: " .. tostring(math.ceil(number(timer.remaining,0,0,120))) .. " СЕК · оставайтесь рядом"
        elseif number(sequence.total,0,0,20) > 0 then
            self.missionTimer.Text = "КОНТУРЫ: " .. tostring(sequence.done or 0) .. " / " .. tostring(sequence.total)
        else self.missionTimer.Text = "" end
        self.missionTimer.Visible = self.missionTimer.Text ~= ""
        self.missionStatus.Text = text(c.status) .. "\nЗа эту смену: " .. tostring(quota.done or 0) .. " / " .. tostring(quota.limit or 2)
        if c.finishedStory then self.missionStatus.Text ..= "\nАрхив раскрыт. Доступны повторные контракты: " .. tostring(c.replayCount or 0) end
        if c.carry then self.missionStatus.Text ..= "\nВ руках: " .. text(c.carry.label) .. " · " .. text(c.carry.destination) end
        if c.active~=true then self.missionStatus.Text ..= "\nСвободный осмотр станций доступен и без контракта." end
        self.campaignTitle.Text = text(mission.title,"Ночной архив")
        self.campaignTitle.TextTruncate = Enum.TextTruncate.AtEnd
        self.campaignObjective.Text = text(mission.objective,"Откройте миссии")
        self.campaignObjective.TextTruncate = Enum.TextTruncate.AtEnd
        local options = type(c.options) == "table" and c.options or {}
        for i, option in ipairs(options) do
            local b = self.missionChoices[i]
            if not b then
                b = button("MissionChoice" .. i, self.pages.missions, "", UDim2.new(1,-8,0,52), UDim2.new(), function()
                    local current = self.campaign
                    local selected = current.options and current.options[i]
                    if selected and current.active and current.mission and current.mission.near == true then
                        self:SendAction("CampaignChoice", {choice=selected.id, token=current.token})
                    end
                end)
                b.LayoutOrder = 10+i
                self.missionChoices[i] = b
            end
            local enabled = c.active == true and mission.near == true
            b.Text, b.Visible, b.Active, b.AutoButtonColor = text(option.label,option.id), true, enabled, enabled
            b.TextColor3 = enabled and COLORS.text or COLORS.muted
        end
        for i=#options+1,#self.missionChoices do self.missionChoices[i].Visible=false; self.missionChoices[i].Active=false end
        local assists = type(c.assistTargets) == "table" and c.assistTargets or {}
        for i, target in ipairs(assists) do
            local b = self.missionAssist[i]
            if not b then
                b = button("MissionAssist" .. i, self.pages.missions, "", UDim2.new(1,-8,0,56), UDim2.new(), function()
                    local targetNow = self.campaign.assistTargets and self.campaign.assistTargets[i]
                    if targetNow then self:SendAction("CampaignAssist", {targetUserId=targetNow.userId,targetToken=targetNow.token}) end
                end)
                b.LayoutOrder = 30+i; self.missionAssist[i] = b
            end
            b.Text, b.Visible = "ПОМОЧЬ: " .. text(target.name,"Напарник") .. "\n" .. text(target.title), true
        end
        for i=#assists+1,#self.missionAssist do self.missionAssist[i].Visible=false end
        local records = type(c.records) == "table" and c.records or {}
        for i, record in ipairs(records) do
            local l = self.missionRecords[i]
            if not l then
                l = label("CampaignRecord" .. i, self.pages.missions, "", UDim2.new(1,-8,0,90), UDim2.new(), 14)
                l.AutomaticSize, l.LayoutOrder, l.TextYAlignment = Enum.AutomaticSize.Y, 50+i, Enum.TextYAlignment.Top
                self.missionRecords[i] = l
            end
            l.Text, l.Visible = "АРХИВ: " .. text(record.title) .. "\n" .. text(record.text), true
        end
        for i=#records+1,#self.missionRecords do self.missionRecords[i].Visible=false end
        self:UpdateStationPrompts()
        self:UpdateMissionMarker()
        if ctx.refreshLayout then ctx.refreshLayout() else self:Layout() end
    end

    function self:UpdateCurrentPlace()
        local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
        local best, volume
        if root then
            local p = root.Position
            for _, room in ipairs(self.worldRooms) do
                local b = room.bounds
                if type(b) == "table" and typeof(b.min) == "Vector3" and typeof(b.max) == "Vector3"
                    and p.X >= b.min.X and p.X <= b.max.X and p.Y >= b.min.Y and p.Y <= b.max.Y and p.Z >= b.min.Z and p.Z <= b.max.Z then
                    local size = b.max-b.min
                    local v = size.X*size.Y*size.Z
                    if not volume or v < volume then best,volume=room,v end
                end
            end
        end
        self.placeNow.Text = best and ("ВЫ ЗДЕСЬ: " .. text(best.label)) or "Выберите помещение ниже"
    end

    function self:UpdatePlaces(data)
        self.worldRooms = type(data) == "table" and type(data.rooms) == "table" and data.rooms or {}
        for i, room in ipairs(self.worldRooms) do
            local b = self.placeButtons[i]
            if not b then
                b = button("Place" .. i, self.pages.map, "", UDim2.new(1,-8,0,52), UDim2.new(), function()
                    local current = self.worldRooms[i]
                    if current then
                        self.placeHint.Text = text(current.label) .. "\n" .. text(current.hint,"Следуйте указателям помещения.")
                        self.pages.map.CanvasPosition = Vector2.new()
                    end
                end)
                b.LayoutOrder = i+10; self.placeButtons[i] = b
            end
            b.Text, b.Visible = ((tonumber(room.floorY) or 0) < -3 and "B1  ·  " or "01  ·  ") .. text(room.label), true
        end
        for i=#self.worldRooms+1,#self.placeButtons do self.placeButtons[i].Visible=false end
        self:UpdateCurrentPlace()
        self:ScaleText()
    end

    function self:HandleEvent(kind, data)
        if self.dead then return end
        if kind == "CampaignState" then self:UpdateCampaign(data)
        elseif kind == "CampaignPrompt" then self:UpdateCampaign(data); self:OpenPanel("missions")
        elseif kind == "WorldGuide" then self:UpdatePlaces(data)
        elseif kind == "ExploreResult" then self:RecordInspection(data)
        elseif kind == "IncidentUpdate" and type(data)=="table" then
            local wasActive=self.incident and self.incident.active==true
            self.incident=data
            self.incidentJournal.Text=data.active and ("ВНЕШНЯЯ АВАРИЯ · "..text(data.title).."\n"..
                text(data.room).." · Этап "..tostring(data.step or 1).."/"..tostring(data.total or 3)..
                " · "..tostring(data.remaining or 0).."с\nСледующее действие: "..text(data.action))
                or "АВАРИЙНЫЕ КОНТУРЫ: НОРМА\nПри появлении сбоя станции доступны и без текущей миссии."
            if data.active and not wasActive then
                self:Caption("Авария: "..text(data.room)..". Откройте журнал.",nil,3)
            end
            self:Layout()
        elseif kind == "ThreatSense" and type(data) == "table" then
            self:Caption(text(data.text), data.position, number(data.duration, 2.5, .3, 8))
            if data.state == "CHASE" then self:Visual({kind="threat", duration=.5}) end
        elseif kind == "Preferences" then self:ApplyPreferences(data)
        elseif kind == "NS36Visual" then self:Visual(data)
        elseif kind == "TeamPing" or kind == "NS36Ping" then self:ShowPing(data)
        elseif kind == "PlayerCondition" then self:UpdateCondition(data)
        elseif kind == "ShiftResults" and type(data) == "table" then
            self.shiftResults = data
            self.resultLabel.Text = Experience.ResultsText(data)
            if ctx.showToast then ctx.showToast("Смена окончена. В журнале — ваша оплата, опыт и вклад в работу команды.") end
            self:OpenPanel("journal")
        elseif kind == "GameplayState" and type(data) == "table" then
            self.gameplay = data
            self:UpdateTeam(data.team)
            local carry = self:GetCarry()
            self.dropButton.Text = carry and "ПОЛОЖИТЬ [G]" or "РУКИ СВОБОДНЫ"
            if UserInputService.TouchEnabled and carry then self.dropButton.Text = "ПОЛОЖИТЬ" end
            self.dropButton.Active, self.dropButton.AutoButtonColor = carry ~= nil, carry ~= nil
            self.dropButton.TextColor3 = carry and COLORS.orange or COLORS.muted
            self.dropButton.Visible = carry ~= nil
            self:Layout()
            if self.tutorialCard then
                local tutorial = type(data.tutorial) == "table" and data.tutorial or {}
                self.tutorialCard.Visible = tutorial.done == false and text(tutorial.text) ~= ""
                self.tutorialText.Text = "ПЕРВАЯ СМЕНА\n" .. text(tutorial.text)
                self.skipButton.Visible = tutorial.canSkip ~= false
                if tutorial.done==false and tutorial.step~=self.lastTutorialStep then
                    self.lastTutorialStep=tutorial.step
                    if ctx.showToast then ctx.showToast(text(tutorial.text) .. "  Подсказки: Меню → Команда.") end
                end
            end
            if type(data.story) == "table" then self.storyLabel.Text = "НОЧЬ " .. tostring(data.story.night or 1) .. "\n\n" .. text(data.story.text) end
            local customer = type(data.customer) == "table" and data.customer or {}
            self.customerReceipt.Visible = customer.active == true
            self.serveCustomer.Visible, self.refuseCustomer.Visible = customer.active == true, customer.active == true
            self.customerReceipt.Text = "ПОКУПАТЕЛЬ У КАССЫ\n" .. text(customer.text) .. "\nЧек: " .. text(customer.receipt) .. "\n" .. text(customer.receiptHint)
            if ctx.refreshTasks then ctx.refreshTasks() end
            self:UpdateCameraUI()
        elseif kind == "State" and type(data) == "table" then
            local previous = self.phase
            self.phase = text(data.phase, "INTERMISSION")
            self.latestState = data
            if previous == "RESULTS" and self.phase ~= "RESULTS" then self.shiftResults = nil end
            if not self.welcomed then
                self.welcomed = true
                if ctx.showToast then ctx.showToast(Experience.PhaseWelcome(self.phase)) end
            end
            if self.phase == "RESULTS" and self.shiftResults then
                self.resultLabel.Text = Experience.ResultsText(self.shiftResults)
            elseif self.phase == "RESULTS" then
                local lines = {data.resultSuccess and "СМЕНА ЗАВЕРШЕНА" or "ОСТАЛИСЬ НЕВЫПОЛНЕННЫЕ ЗАДАЧИ"}
                for _, item in ipairs(type(data.taskList) == "table" and data.taskList or {}) do table.insert(lines, (item.done and "✓ " or "○ ") .. text(item.title)) end
                local ownContribution = 0
                for _, member in ipairs(self.gameplay.team or {}) do if member.userId == player.UserId then ownContribution = member.contribution or 0 end end
                table.insert(lines, "Ваш полезный вклад: " .. tostring(ownContribution))
                self.resultLabel.Text = table.concat(lines, "\n")
                if previous ~= "RESULTS" and ctx.showToast then ctx.showToast("Итоги смены доступны в рации → Журнал.") end
            end
            self:UpdateCameraUI()
        end
    end

    connect(ctx.content:GetPropertyChangedSignal("Size"), function() self:Layout() end)
    if ctx.tasksPanel then connect(ctx.tasksPanel:GetPropertyChangedSignal("Size"), function() self:Layout() end) end
    if ctx.shop then connect(ctx.shop:GetPropertyChangedSignal("Visible"), function() self:SyncInputLock() end) end
    connect(UserInputService.InputBegan, function(input, processed)
        if input.KeyCode == Enum.KeyCode.Escape or input.KeyCode == Enum.KeyCode.ButtonB then
            if self.modal then self:ClosePanel() end
            return
        end
        if processed or UserInputService:GetFocusedTextBox() or self.condition.downed then return end
        if input.KeyCode == Enum.KeyCode.V or input.KeyCode == Enum.KeyCode.DPadUp then
            if self.modal then self:ClosePanel() else self:OpenPanel("team") end
        elseif input.KeyCode == Enum.KeyCode.P or input.KeyCode == Enum.KeyCode.DPadDown then
            if self.modal then self:ClosePanel() else self:OpenPanel("settings") end
        elseif input.KeyCode == Enum.KeyCode.M then
            if self.modal == "missions" then self:ClosePanel() else self:OpenPanel("missions") end
        elseif input.KeyCode == Enum.KeyCode.N then
            if self.modal == "map" then self:ClosePanel() else self:OpenPanel("map") end
        elseif not self.modal and input.KeyCode == Enum.KeyCode.G then self:SendAction("DropItem") end
    end)
    connect(UserInputService.WindowFocusReleased, function() if ctx.closeShop then ctx.closeShop() end; self:ClosePanel(); self.shakeUntil = 0 end)
    connect(GuiService.MenuOpened, function() if ctx.closeShop then ctx.closeShop() end; self:ClosePanel(); self.shakeUntil = 0 end)
    connect(player.CharacterRemoving, function() self:ClosePanel(); self:UpdateCondition({downed = false}) end)
    connect(player:GetAttributeChangedSignal("NightShiftDowned"), function()
        if player:GetAttribute("NightShiftDowned") then
            if ctx.closeShop then ctx.closeShop() end
            self:ClosePanel(); if ctx.releaseControls then ctx.releaseControls() end
        end
    end)
    -- Runtime anomaly props can be created after this controller starts.
    connect(workspace.DescendantAdded, function(object)
        task.defer(function()
            if not self.dead and object.Parent then
                self:TrackCCTVPart(object)
                local world = workspace:FindFirstChild("NightShiftWorld")
                if world and object:IsDescendantOf(world) then self:ApplyQuality(object) end
            end
        end)
    end)
    for _, object in ipairs(workspace:GetDescendants()) do self:TrackCCTVPart(object) end
    connect(RunService.Heartbeat, function(dt)
        if self.dead then return end
        local now = os.clock()
        self.placeElapsed = (self.placeElapsed or 0) + dt
        if self.placeElapsed >= .75 then self.placeElapsed = 0; self:UpdateCurrentPlace(); self:UpdateMissionMarker() end
        if self.effectUntil > now and not self.preferences.reducedFlashes then
            local elapsed = now - self.effectStarted
            local envelope = math.min(1, elapsed * 4, (self.effectUntil-now) * 4)
            -- Deliberately slow and mild: local preference can suppress the entire modulation.
            self.colorEffect.Brightness = -(self.effectKind == "caught" and .1 or .035) * (.5 + .5*math.sin(elapsed*4)) * envelope
        else self.colorEffect.Brightness = 0 end
        self:UpdateCameraUI()
    end)
    RunService:BindToRenderStep("NightShift36GentleShake", Enum.RenderPriority.Camera.Value + 2, function()
        if not self.dead and self.preferences.cameraShake and os.clock() < self.shakeUntil and not self:GetCCTV() then
            local camera = workspace.CurrentCamera
            if camera then
                local t = os.clock()
                camera.CFrame *= CFrame.Angles(math.sin(t*21)*.0018, math.cos(t*17)*.0018, 0)
            end
        end
    end)

    function self:Destroy()
        if self.dead then return end
        if ctx.closeShop then ctx.closeShop() end
        self:ClosePanel(); self.dead = true
        for _, connection in ipairs(self.connections) do connection:Disconnect() end
        RunService:UnbindFromRenderStep("NightShift36GentleShake")
        for object, default in pairs(self.shadowDefaults) do
            if object.Parent then if object:IsA("Light") then object.Shadows = default else object.CastShadow = default end end
        end
        for object, default in pairs(self.cctvOnlyParts) do if object.Parent then object.LocalTransparencyModifier = default end end
        for prompt, default in pairs(self.stationPromptDefaults) do
            if prompt.Parent then prompt.ActionText,prompt.ObjectText=default.action,default.object end
        end
        for _, object in ipairs({self.footer,self.shield,self.caption,self.reportBar,self.conditionBar,self.markerFolder,self.colorEffect,self.comfortEffect,self.campaignCard,self.incidentCard,self.cctvSync}) do object:Destroy() end
        if workspace.CurrentCamera and self.originalFov then workspace.CurrentCamera.FieldOfView = self.originalFov end
        if self.tutorialCard then self.tutorialCard:Destroy() end
    end
    self:ApplyPreferences(ctx.initialPreferences or DEFAULTS)
    self:UpdateAudioStatus(ctx.audioStatus)
    self:Layout()
    task.spawn(function()
        local world = workspace:WaitForChild("NightShiftWorld", 20)
        if world and not self.dead then self:ApplyPreferences(self.preferences) end
    end)
    return self
end

Experience.DefaultPreferences = table.clone(DEFAULTS)
return Experience
