-- NIGHT SHIFT 4.6: optional, read-only map audit for the Studio server Command Bar.
-- Start Play, switch to the server context, then run this file's contents.
-- This script never moves doors, teleports players, awards currency or saves data.
local RunService = game:GetService("RunService")
local PathfindingService = game:GetService("PathfindingService")
local Workspace = game:GetService("Workspace")
assert(RunService:IsStudio() and RunService:IsRunning(), "Start Play in Roblox Studio first.")
local world = Workspace:FindFirstChild("NightShiftWorld")
assert(world and world:GetAttribute("LayoutVersion") == "4.6", "NIGHT SHIFT 4.6 has not finished building.")

local passed, failed = 0, 0
local function record(ok, label, detail)
    if ok then passed += 1; print("[MAP AUDIT] PASS: " .. label)
    else failed += 1; warn("[MAP AUDIT] CHECK: " .. label .. " — " .. tostring(detail or "")) end
end
local segments = {
    {"Вход → подход к складу", Vector3.new(12, 0.8, 25), Vector3.new(31, 0.8, 0)},
    {"Вход → охрана", Vector3.new(12, 0.8, 25), Vector3.new(32, 0.8, 23.5)},
    {"Вход → задний выход", Vector3.new(12, 0.8, 25), Vector3.new(2, 0.8, -27)},
    {"Внутри склада → генератор", Vector3.new(31, 0.8, -7), Vector3.new(32, 0.8, -19)},
    {"Погрузка → B1", Vector3.new(0, 0.8, -43), Vector3.new(7, -10, -83)},
    {"B1 → погрузка", Vector3.new(7, -10, -83), Vector3.new(0, 0.8, -43)},
    {"B1 → холодный склад", Vector3.new(7, -10, -83), Vector3.new(-21.5, -10, -91)},
    {"B1 → котельная", Vector3.new(7, -10, -83), Vector3.new(33.5, -10, -94)},
    {"B1 → резервный щит", Vector3.new(7, -10, -83), Vector3.new(19.5, -10, -101)},
    {"Погрузка → правый двор", Vector3.new(0, 0.8, -43), Vector3.new(21.5, 0.8, -70)},
    {"Открытый задний двор", Vector3.new(0, 0.8, -70), Vector3.new(0, 0.8, -98)},
    {"Щитовая B1 → служебный коридор", Vector3.new(7, -10, -103), Vector3.new(7, -10, -112)},
    {"Начало → конец служебного коридора", Vector3.new(7, -10, -112), Vector3.new(7, -10, -170)},
    {"Коридор → мастерская", Vector3.new(7, -10, -120), Vector3.new(-12, -10, -120)},
    {"Коридор → насосная", Vector3.new(7, -10, -120), Vector3.new(26, -10, -120)},
    {"Коридор → архив", Vector3.new(7, -10, -142), Vector3.new(-12, -10, -142)},
    {"Коридор → серверная", Vector3.new(7, -10, -142), Vector3.new(26, -10, -142)},
    {"Коридор → комната персонала", Vector3.new(7, -10, -164), Vector3.new(-12, -10, -164)},
    {"Коридор → склад возвратов", Vector3.new(7, -10, -164), Vector3.new(26, -10, -164)},
    {"Мастерская → западный проход", Vector3.new(-12, -10, -120), Vector3.new(-22, -10, -131)},
    {"Западный проход → архив", Vector3.new(-22, -10, -131), Vector3.new(-12, -10, -142)},
    {"Архив → западный проход персонала", Vector3.new(-12, -10, -142), Vector3.new(-22, -10, -153)},
    {"Западный проход → персонал", Vector3.new(-22, -10, -153), Vector3.new(-12, -10, -164)},
}
for _, segment in ipairs(segments) do
    local path = PathfindingService:CreatePath({AgentRadius = 1.5, AgentHeight = 5.5, AgentCanJump = false, WaypointSpacing = 2})
    local ok, err = pcall(function() path:ComputeAsync(segment[2], segment[3]) end)
    record(ok and path.Status == Enum.PathStatus.Success, segment[1], err or tostring(path.Status))
    path:Destroy()
end

local params = OverlapParams.new()
params.FilterType = Enum.RaycastFilterType.Include
params.FilterDescendantsInstances = {world}
params.RespectCanCollide = true
local expansion = world:FindFirstChild("Locations_4_0")
record(expansion ~= nil and world:GetAttribute("ExpansionRoomCount") == 6, "Шесть новых помещений B1")
local roomIds = {"workshop", "pump", "archive", "comms", "staff", "dispatch"}
for _, id in ipairs(roomIds) do
    local room = expansion and expansion:FindFirstChild("NS40Room_" .. id)
    local floor = room and room:FindFirstChild(id .. "Floor")
    local ceiling = room and room:FindFirstChild(id .. "Ceiling")
    record(room ~= nil and room:IsA("Model") and room:GetAttribute("RoomId") == id, "Помещение: " .. id)
    record(floor ~= nil and floor:IsA("BasePart") and floor.CanCollide
        and math.abs(floor.Position.Y + floor.Size.Y * 0.5 + 10.5) < 0.01,
        "Физический пол: " .. id)
    record(ceiling ~= nil and ceiling:IsA("BasePart") and ceiling.CanCollide
        and math.abs(ceiling.Position.Y - ceiling.Size.Y * 0.5 + 0.8) < 0.01,
        "Физический потолок: " .. id)
end
local stationIds = {
    "security_terminal", "loading_manifest", "stock_supplies", "retail_check", "retail_register",
    "generator_panel", "cold_sensor", "boiler_gauge", "basement_breaker", "yard_meter",
    "workshop_bench", "workshop_parts", "pump_console", "pump_valve_a", "pump_valve_b", "pump_valve_c",
    "archive_catalog", "archive_records", "comms_console", "comms_rack", "staff_locker", "staff_firstaid",
    "dispatch_board", "dispatch_scanner",
}
local stations, stationCount, duplicateIds = {}, 0, {}
for _, part in ipairs(world:GetDescendants()) do
    if part:IsA("BasePart") and part:GetAttribute("StationId") then
        local id = part:GetAttribute("StationId")
        stationCount += 1
        if stations[id] then table.insert(duplicateIds, tostring(id)) end
        stations[id] = part
    end
end
record(stationCount == 24 and #duplicateIds == 0, "24 уникальные станции контрактов", table.concat(duplicateIds, ", "))
local sightParams = RaycastParams.new()
sightParams.FilterType = Enum.RaycastFilterType.Include
sightParams.FilterDescendantsInstances = {world}
sightParams.RespectCanCollide = true
for _, id in ipairs(stationIds) do
    local station = stations[id]
    local approach = station and station:GetAttribute("Approach")
    local usable = station ~= nil and station.Name == "NS40Station_" .. id and typeof(approach) == "Vector3"
    record(usable, "StationId / Approach: " .. id)
    if usable then
        local blockers = Workspace:GetPartBoundsInBox(CFrame.new(approach - Vector3.new(0, 0.2, 0)), Vector3.new(2.8, 5.4, 2.8), params)
        record(#blockers == 0, "Место перед станцией: " .. id, blockers[1] and blockers[1].Name)
        local horizontal = Vector3.new(approach.X - station.Position.X, 0, approach.Z - station.Position.Z)
        local gui = station:FindFirstChildOfClass("SurfaceGui")
        record(horizontal.Magnitude > 2.5 and station.CFrame.LookVector:Dot(horizontal.Unit) > 0.99
            and gui ~= nil and gui.Face == Enum.NormalId.Front, "Лицевая сторона станции: " .. id)
        local eye = approach + Vector3.new(0, 1.5, 0)
        local hit = Workspace:Raycast(eye, station.Position - eye, sightParams)
        record(hit == nil or hit.Instance == station, "Видимость станции: " .. id, hit and hit.Instance.Name)
        local prompt = station:FindFirstChild("NS40CampaignPrompt_" .. id)
        record(prompt ~= nil and prompt:IsA("ProximityPrompt") and prompt:GetAttribute("CampaignStation") == id,
            "Действующий prompt контракта: " .. id)
        local floorY = approach.Y - 3
        local origin = floorY < -5 and Vector3.new(7, -10, -103) or Vector3.new(12, 0.8, 25)
        local path = PathfindingService:CreatePath({AgentRadius = 1.5, AgentHeight = 5.5, AgentCanJump = false, WaypointSpacing = 2})
        local ok, err = pcall(function() path:ComputeAsync(origin, approach - Vector3.new(0, 2.5, 0)) end)
        record(ok and path.Status == Enum.PathStatus.Success, "Маршрут к станции: " .. id, err or tostring(path.Status))
        path:Destroy()
    end
end
for i = 1, 18 do
    local top = 0.3 - i * 0.6
    local center = Vector3.new(7, top + 2.8, -54 - (i - 0.5) * 1.35)
    local blockers = Workspace:GetPartBoundsInBox(CFrame.new(center), Vector3.new(2.8, 5.4, 0.9), params)
    record(#blockers == 0, "Просвет ступени " .. i, blockers[1] and blockers[1].Name)
end
for _, part in ipairs(world:GetDescendants()) do
    if part:IsA("BasePart") and part:GetAttribute("DoorLeaf") then
        record(typeof(part:GetAttribute("ClosedCFrame")) == "CFrame" and typeof(part:GetAttribute("OpenCFrame")) == "CFrame", "Дверные состояния: " .. part.Name)
        record(part:GetAttribute("DoorBusy") == true or part.CanCollide, "Коллизия двери: " .. part.Name)
    end
end
-- 4.4 physical expansion and emergency-light checks.
local yardFloor = world:FindFirstChild("LoadingOuterYardFloor", true)
record(yardFloor ~= nil and yardFloor:IsA("BasePart") and yardFloor.CanCollide
    and yardFloor.Size.X >= 58 and yardFloor.Size.Z >= 29, "Физический пол заднего двора")
local outerGate = world:FindFirstChild("LoadingYardOuterGate", true)
record(outerGate ~= nil and outerGate:GetAttribute("DoorLeaf") == true
    and outerGate:GetAttribute("IsOpen") == true, "Открытый выезд за погрузочными воротами")
local alarmCount, malformedBeacons = 0, 0
for _, object in ipairs(world:GetChildren()) do
    if object:IsA("Model") and object.Name:find("AlarmBeacon", 1, true) then
        alarmCount += 1
        if not object:FindFirstChild("Dome") and not object:FindFirstChild(object.Name .. "Dome") then malformedBeacons += 1 end
    end
end
record(alarmCount >= 5 and malformedBeacons == 0, "Пять вращающихся красных аварийных маяков", malformedBeacons)
local promptCount, stackedPromptCount = 0, 0
for _, object in ipairs(world:GetDescendants()) do
    if object:IsA("ProximityPrompt") then
        promptCount += 1
        if object.Exclusivity ~= Enum.ProximityPromptExclusivity.OneGlobally then stackedPromptCount += 1 end
    end
end
record(promptCount > 20 and stackedPromptCount == 0, "Один видимый prompt без повторяющихся карточек", stackedPromptCount)
local hvacCount = 0
for _, object in ipairs(world:GetDescendants()) do if object.Name == "AlleyHVACUnit1" or object.Name == "AlleyHVACUnit2" then hvacCount += 1 end end
record(hvacCount == 2 and world:FindFirstChild("AlleyPowerCabinet", true) ~= nil, "Технический двор: вентиляция и силовой шкаф")

local fontCount, wrongFonts = 0, {}
for _, object in ipairs(world:GetDescendants()) do
    if object:IsA("TextLabel") and (object.Parent:IsA("SurfaceGui") or object.Parent:IsA("BillboardGui")) then
        fontCount += 1
        if object.Font ~= Enum.Font.GothamBold then table.insert(wrongFonts, object:GetFullName()) end
    end
end
record(fontCount >= 60 and #wrongFonts == 0, "Единый шрифт всех надписей", table.concat(wrongFonts, ", "))
local corridor = Workspace:GetPartBoundsInBox(CFrame.new(30, 4.1, 4.65), Vector3.new(11.9, 7.1, 11.2), params)
record(#corridor == 0, "Свободный подход к охране", corridor[1] and corridor[1].Name)
for i = 1, 18 do
    local z = -54 - (i - 0.5) * 1.35
    for _, x in ipairs({2.75, 11.25}) do
        local walls = Workspace:GetPartBoundsInBox(CFrame.new(x, 7.0, z), Vector3.new(0.2, 0.2, 0.2), params)
        record(#walls > 0, "Верхняя стенка лестницы " .. i .. " / " .. x)
    end
    local roof = Workspace:GetPartBoundsInBox(CFrame.new(7, 11.35, z), Vector3.new(0.2, 0.2, 0.2), params)
    record(#roof > 0, "Перекрытие лестницы " .. i)
end
local cameras = world:FindFirstChild("CameraPoints")
record(cameras and #cameras:GetChildren() == 6, "Шесть камер CCTV")
print(string.format("[MAP AUDIT 4.4] Complete: %d passed, %d to inspect. Doors remain in their current state; open a required route manually and rerun if needed. Player/controller/network playtests are separate.", passed, failed))
