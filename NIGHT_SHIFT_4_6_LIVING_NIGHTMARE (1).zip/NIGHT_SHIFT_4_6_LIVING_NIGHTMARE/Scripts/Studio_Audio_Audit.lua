-- NIGHT SHIFT 4.5: read-only CLIENT Command Bar audio diagnostic.
-- Start Play, choose Client in Studio, then execute this file's contents.
-- Does not change game settings, start sounds, grant rewards or contact services.
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local Workspace = game:GetService("Workspace")
assert(RunService:IsStudio() and RunService:IsRunning() and RunService:IsClient(),
    "Start Play and select the Client Command Bar context first.")

local records, playing, loaded = {}, 0, 0
local function belongs(sound)
    local group = sound.SoundGroup
    if group and string.find(group.Name, "NightShift", 1, true) then return true end
    local parent = sound
    while parent and parent ~= game do
        if string.find(parent.Name, "NightShift", 1, true) or string.find(parent.Name, "NS37", 1, true) then return true end
        parent = parent.Parent
    end
    return false
end
for _, container in ipairs({SoundService, Workspace}) do
    for _, object in ipairs(container:GetDescendants()) do
        if object:IsA("Sound") and belongs(object) then
            table.insert(records, object)
            if object.IsLoaded then loaded += 1 end
            if object.IsPlaying then playing += 1 end
        end
    end
end
table.sort(records, function(a, b) return a:GetFullName() < b:GetFullName() end)
for _, sound in ipairs(records) do
    local group = sound.SoundGroup
    print(string.format("[AUDIO AUDIT] %s | loaded=%s playing=%s length=%.2fs volume=%.3f group=%.3f loudness=%.2f | %s",
        sound:GetFullName(), tostring(sound.IsLoaded), tostring(sound.IsPlaying), sound.TimeLength,
        sound.Volume, group and group.Volume or 1, sound.PlaybackLoudness, sound.SoundId))
end
print(string.format("[AUDIO AUDIT] %d sounds; %d loaded; %d playing. Open Settings and press Test sound to inspect a local cue.",
    #records, loaded, playing))
if #records == 0 then warn("[AUDIO AUDIT] Audio manager has not created sounds; inspect client Output for its startup error.") end
if #records > 0 and loaded == 0 then warn("[AUDIO AUDIT] No sound is loaded yet; inspect the in-game sound status and client Output.") end
print("[AUDIO AUDIT] Engine flags and loudness are diagnostics. They do not prove that the device/speakers or Roblox master volume are audible.")
