-- NIGHT SHIFT 4.5: layered audio, dynamic incidents and proximity horror.
-- The builtin files were decoded and measured; the quiet source files need gain.
-- Load success is checked per Sound, and expiry begins when playback actually starts.
local Audio = {}
Audio.__index = Audio

local ASSETS = {
    wind = "rbxasset://sounds/action_falling.ogg",
    steps = "rbxasset://sounds/action_footsteps_plastic.mp3",
    thump = "rbxasset://sounds/action_jump_land.mp3",
    mechanism = "rbxasset://sounds/action_get_up.mp3",
    water = "rbxasset://sounds/action_swim.mp3",
    impact = "rbxasset://sounds/impact_explosion_03.mp3",
    tone = "rbxasset://sounds/volume_slider.ogg",
}
local FALLBACK = {wind = "water", water = "wind", steps = "thump", mechanism = "thump", thump = "mechanism", impact = "thump", tone = "thump"}
local SOURCE_RMS = {wind = -42.54, steps = -42.13, thump = -31.67, mechanism = -35.61, water = -41.43, impact = -12.43, tone = -26.04}
-- Optional original audio: import files from Audio_Pack_4_2, 4_3 and 4_4 in Asset Manager,
-- then enter owned audio IDs below. Missing IDs keep Roblox builtin fallback.
local CUSTOM_AUDIO_IDS = {
    -- Optional original assets: enter approved IDs published by the experience owner.
    -- Every value remains 0 until explicitly imported: the audible builtin
    -- fallback is used for all events without any upload.
    room_tone=0, basement_tone=0, generator_start=0, generator_motor=0,
    alarm_start=0, fear_sting=0, monster_roar=0, crawler_scrape=0, mimic_voice=0,
    monster_breath=0, player_death=0, interaction_knock=0, relay_glitch=0,
    incident_surge=0, incident_flood=0, incident_camera=0,
    incident_radio=0, incident_archive=0, incident_step=0,
    incident_wrong=0, incident_done=0,
    -- ambience_store.wav  -> room_tone=0,
    -- ambience_basement.wav -> basement_tone=0,
    -- generator_start.wav -> generator_start=0,
    -- generator_loop_seamless.wav -> generator_motor=0 (Audio_Pack_4_4),
    -- alarm_siren_loop.wav -> alarm_start=0 (Audio_Pack_4_4),
    -- fear_sting.wav      -> fear_sting=0,
    -- monster_roar.wav    -> monster_roar=0 (Audio_Pack_4_4),
    -- crawler_scrape.wav  -> crawler_scrape=0,
    -- mimic_voice.wav     -> mimic_voice=0,
    -- monster_breath.wav  -> monster_breath=0,
    -- player_death.wav    -> player_death=0,
    -- interaction_knock.wav -> interaction_knock=0,
    -- relay_glitch.wav    -> relay_glitch=0,
    -- Audio_Pack_4_3: incident_surge / incident_flood / incident_camera /
    -- incident_radio / incident_archive / incident_done / incident_wrong / incident_step
    -- require creator-owned audio ID to replace bundled sound fallback.
}
local SOUNDS = {
    -- Raw source RMS: wind -42.54, mechanism -35.61, thump -31.67, tone -26.04 dBFS.
    door = {asset = "mechanism", volume = 2.4, speed = .85, range = 44, caption = "Открывается дверь"},
    doorHit = {asset = "thump", volume = 2.1, speed = .55, range = 56, caption = "Удары в дверь"},
    step = {asset = "thump", volume = 1.35, speed = .68, range = 38, caption = "Тяжёлые шаги"},
    footstep = {asset = "thump", volume = .9, speed = 1.65, global = true},
    threat = {asset = "wind", volume = 6.0, speed = .72, range = 64, duration = 2.4, caption = "Что-то движется рядом"},
    caught = {asset = "impact", volume = .16, speed = .72, global = true, duration = 1.3, caption = "Вас настигли"},
    powerDown = {asset = "mechanism", volume = 2.5, speed = .45, global = true, caption = "Питание отключилось"},
    powerOn = {asset = "mechanism", volume = 2.4, speed = 1.1, global = true, caption = "Генератор запущен"},
    flicker = {asset = "tone", volume = .65, speed = .65, global = true, caption = "Треск электропроводки"},
    alarm = {asset = "tone", volume = 1.1, speed = .82, global = true, caption = "Сигнал охраны"},
    task = {asset = "tone", volume = .8, speed = 1.4, global = true, caption = "Этап задания выполнен"},
    interact = {asset = "mechanism", volume = 1.5, speed = 1.4, global = true},
    flashlight = {asset = "mechanism", volume = 1.4, speed = 1.8, global = true},
    ui_click = {asset = "tone", volume = .55, speed = 1.55, global = true},
    ui_hover = {asset = "tone", volume = .2, speed = 1.9, global = true, duration = .12},
    fail = {asset = "tone", volume = .75, speed = .65, global = true, caption = "Проверьте действие"},
    ping = {asset = "tone", volume = .8, speed = 1.18, global = true},
    radio = {asset = "wind", volume = 3.4, speed = 2.2, global = true, duration = .75, caption = "Помехи в рации"},
    radio_test = {asset = "wind", volume = 3.4, speed = 2.2, range = 30, duration = .75, caption = "Проверка радиосвязи"},
    customer = {asset = "tone", volume = .9, speed = 1.75, global = true, caption = "Покупатель у кассы"},
    anomaly = {asset = "wind", volume = 4.8, speed = .82, range = 38, duration = 1.8, caption = "Необычный шум"},
    revive = {asset = "tone", volume = .85, speed = 1.65, global = true, caption = "Напарник снова на ногах"},
    item_pickup = {asset = "mechanism", volume = 1.9, speed = 1.2, range = 26, caption = "Предмет поднят"},
    item_drop = {asset = "thump", volume = 1.2, speed = 1, range = 28, caption = "Предмет положен"},
    cleanup = {asset = "water", volume = 3.2, speed = 1.25, range = 26, duration = .7, caption = "Уборка"},
    switch = {asset = "mechanism", volume = 2.0, speed = 1.6, range = 30, caption = "Щёлкнул переключатель"},
    entry = {asset = "tone", volume = .7, speed = .95, global = true},
    terminal = {asset = "tone", volume = .72, speed = 1.28, range = 28, caption = "Ответ терминала"},
    scan = {asset = "tone", volume = .9, speed = 1.85, range = 24, duration = .36, caption = "Сканирование"},
    paper = {asset = "water", volume = 2, speed = 2.1, range = 20, duration = .42, caption = "Шелест документов"},
    valve = {asset = "mechanism", volume = 2.1, speed = .6, range = 34, caption = "Поворот вентиля"},
    repair = {asset = "mechanism", volume = 2.3, speed = 1.12, range = 32, caption = "Работа инструментом"},
    mission_complete = {asset = "tone", volume = .95, speed = 1.25, global = true, caption = "Контракт выполнен"},
    chapter_unlock = {asset = "tone", volume = 1, speed = .88, global = true, caption = "Открыта новая глава"},
    locker = {asset = "mechanism", volume = 1.8, speed = .65, range = 30, caption = "Дверца укрытия"},
    menu_open = {asset = "tone", volume = .55, speed = 1.2, global = true, duration = .3},
    menu_close = {asset = "tone", volume = .45, speed = .9, global = true, duration = .25},
    purchase = {asset = "tone", volume = .85, speed = 1.65, global = true},
    monster_notice = {asset = "wind", volume = 4.4, speed = .67, range = 66, duration = 1.3, caption = "Существо насторожилось"},
    monster_search = {asset = "mechanism", volume = 1.8, speed = .48, range = 42, caption = "Существо ищет рядом"},
    monster_breath = {asset = "wind", volume = 3.8, speed = .58, range = 34, duration = 1.4, caption = "Тяжёлое дыхание"},
    monster_retreat = {asset = "wind", volume = 2.7, speed = .95, range = 46, duration = 1.1, caption = "Шаги удаляются"},
    footstep_metal = {asset = "thump", volume = .75, speed = 2.2, global = true, duration = .2},
    footstep_wood = {asset = "mechanism", volume = 1.1, speed = 1.5, global = true, duration = .24},
    footstep_water = {asset = "water", volume = 2.2, speed = 2, global = true, duration = .23},
    alarm_start = {asset = "tone", volume = .85, speed = .75, range = 100, caption = "Тревога: аварийная сирена"},
    generator_start = {asset = "mechanism", volume = 2.1, speed = .62, range = 58, caption = "Стартер генератора"},
    generator_warning = {asset = "tone", volume = .8, speed = .88, range = 42, duration = 1.4, caption = "Предупреждение генератора"},
    generator_stop = {asset = "mechanism", volume = 1.5, speed = .55, range = 48, duration = 1.2, caption = "Мотор генератора затихает"},
    monster_attack = {asset = "impact", volume = .12, speed = .68, range = 42, duration = .6, caption = "Существо бросилось вперёд"},
    monster_chase = {asset = "wind", volume = 3.0, speed = .62, range = 45, caption = "Существо преследует вас"},
    player_downed = {asset = "wind", volume = 3.0, speed = .48, global = true, caption = "Вы ранены. Дыхание сбилось"},
    player_death = {asset = "mechanism", volume = 1.8, speed = .42, global = true, duration = 1.5, caption = "Сознание гаснет"},
    player_revived = {asset = "wind", volume = 2.2, speed = 1.2, global = true, duration = .9, caption = "Вы снова можете двигаться"},
    pipe_knock = {asset = "thump", volume = .8, speed = .62, range = 35, duration = .45, caption = "Стук в трубах"},
    metal_creak = {asset = "mechanism", volume = 1.15, speed = .45, range = 34, duration = 1.5, caption = "Металл скрипит"},
    distant_rattle = {asset = "mechanism", volume = .85, speed = 1.35, range = 38, duration = .9, caption = "Где-то дребезжит решётка"},
    radio_whisper = {asset = "water", volume = 1.65, speed = .74, range = 28, duration = 1.8, caption = "Тихие помехи из динамика"},
    water_drip = {asset = "water", volume = 1.5, speed = 1.55, range = 26, duration = .55, caption = "Капли падают на металл"},
    valve_release = {asset = "wind", volume = 2.1, speed = 1.45, range = 30, duration = .75, caption = "Клапан выпускает воздух"},
    inspect = {asset = "mechanism", volume = .8, speed = 1.3, range = 20, duration = .4},
    test = {asset = "tone", volume = 1.15, speed = 1, global = true},
    fear_sting = {asset="impact",volume=.095,speed=.47,range=42,duration=1.8,caption="Внезапный глухой удар",category="ambient"},
    crawler_scrape = {asset="mechanism",volume=1.5,speed=.58,range=42,duration=.35,caption="По полу волочится что-то тяжёлое",category="threat"},
    mimic_voice = {asset="wind",volume=2.7,speed=.78,range=48,duration=1.6,caption="Искажённый голос за стеллажом",category="threat"},
    mimic_step = {asset="thump",volume=.62,speed=1.1,range=34,duration=.27,caption="Слишком ровные шаги",category="threat"},
    tape_echo = {asset="water",volume=1.8,speed=.65,range=22,duration=1.0,caption="Из приёмника доносится голос",category="effects"},
    relay_glitch = {asset="tone",volume=.65,speed=.57,range=26,duration=.3,caption="Реле щёлкает",category="effects"},
    glass_tap = {asset="thump",volume=.6,speed=1.64,range=22,duration=.28,caption="Стук по стеклу",category="effects"},
    interaction_knock = {asset="thump",volume=.9,speed=.72,range=30,duration=.4,caption="Два удара по шкафу",category="effects"},
    incident_surge = {asset="mechanism",volume=2.2,speed=.73,range=60,duration=1.65,caption="Тревога двигателя",category="ambient"},
    incident_flood = {asset="water",volume=3.0,speed=.66,range=54,duration=2.1,caption="В насосной поднимается вода",category="ambient"},
    incident_camera = {asset="tone",volume=.78,speed=.54,range=48,duration=1.5,caption="Камеры потеряли синхронизацию",category="ambient"},
    incident_radio = {asset="wind",volume=2.7,speed=.49,range=53,duration=1.8,caption="Помехи в радиолинии",category="ambient"},
    incident_archive = {asset="thump",volume=1.6,speed=.43,range=55,duration=1.1,caption="Стук из архивной комнаты",category="ambient"},
    incident_step = {asset="mechanism",volume=1.35,speed=1.55,range=24,duration=.35,caption="Переключатель сработал",category="effects"},
    incident_wrong = {asset="tone",volume=1.0,speed=.55,range=34,duration=.55,caption="Неверная настройка",category="effects"},
    incident_done = {asset="tone",volume=1.0,speed=1.35,range=52,duration=1.1,caption="Контур стабилизирован",category="effects"},
    incident_failed = {asset="mechanism",volume=1.55,speed=.49,range=48,duration=1.5,caption="Автоматика сбросила неисправность",category="ambient"},
}
SOUNDS.task_success, SOUNDS.task_error, SOUNDS.door_chime = SOUNDS.task, SOUNDS.fail, SOUNDS.customer
SOUNDS.item_inspect = SOUNDS.inspect
for _, kind in ipairs({"step", "threat", "caught", "doorHit", "monster_notice", "monster_search", "monster_breath", "monster_retreat"}) do SOUNDS[kind].category = "threat" end
for _, kind in ipairs({"monster_attack", "monster_chase", "player_downed", "player_death", "player_revived"}) do SOUNDS[kind].category = "threat" end
for _, kind in ipairs({"pipe_knock", "metal_creak", "distant_rattle", "radio_whisper", "water_drip"}) do SOUNDS[kind].category = "ambient" end
for _, kind in ipairs({"ui_click", "ui_hover", "menu_open", "menu_close", "ping", "entry", "purchase", "mission_complete", "chapter_unlock"}) do SOUNDS[kind].category = "ui" end
local SHIFT_CUES = {alarm=true,alarm_start=true,generator_start=true,generator_warning=true,generator_stop=true,powerDown=true,powerOn=true,monster_chase=true,monster_attack=true,
    fear_sting=true,crawler_scrape=true,mimic_voice=true,mimic_step=true,
    incident_surge=true,incident_flood=true,incident_camera=true,incident_radio=true,incident_archive=true,incident_failed=true,
    monster_notice=true,monster_search=true,monster_breath=true,monster_retreat=true,player_downed=true,threat=true,caught=true}
local DEFAULTS = {masterVolume = 1, ambientVolume = .55, effectsVolume = .7, threatVolume = .85, uiVolume = .55, mix = "balanced"}
local SOURCE_CONFIG = {
    Cooler = {kind = "fridge", volume = 4.2, speed = .72, range = 42, powered = true},
    Generator = {kind = "generator", volume = 5.8, speed = .54, range = 52, powered = true},
    VentilationFan = {kind = "vent", volume = 3.6, speed = .93, range = 38, powered = true},
    VentGrille = {kind = "vent", volume = 3.6, speed = .93, range = 42, powered = true},
    GeneratorWallVent = {kind = "vent", volume = 3.2, speed = .88, range = 30, powered = true},
    BoilerPressureVessel = {kind = "boiler", volume = 3.2, speed = .64, range = 32, powered = false},
    ParkingLampWestPole = {kind = "outside", volume = 3.0, speed = 1.0, range = 58, powered = false},
}
local AMBIENT_TYPES = {
    pump = {kind = "pump", asset = "water", volume = 3.3, speed = .68, range = 34, powered = true},
    server = {kind = "server", volume = 3.2, speed = 1.35, range = 28, powered = true},
    vent = {kind = "vent", volume = 3.3, speed = .92, range = 34, powered = true},
    drip = {kind = "drip", asset = "water", volume = 2.5, speed = .58, range = 26, powered = false},
    transformer = {kind = "transformer", volume = 4, speed = .5, range = 36, powered = true},
    workshop = {kind = "workshop", volume = 2.8, speed = .75, range = 28, powered = true},
    archive = {kind = "archive", volume = 2.4, speed = .65, range = 26, powered = false},
    staff = {kind = "staff", volume = 2.1, speed = 1.08, range = 24, powered = true},
    dispatch = {kind = "dispatch", volume = 2.8, speed = .85, range = 30, powered = true},
    cold = {kind = "cold", volume = 3.5, speed = .7, range = 34, powered = true},
}
local CHARACTER_SOUNDS = {Running = true, Jumping = true, Landing = true, Climbing = true, Swimming = true, FreeFalling = true, Died = true, GettingUp = true}
local function finite(value, fallback, low, high)
    local n = tonumber(value)
    if not n or n ~= n or n == math.huge or n == -math.huge then n = fallback end
    return math.clamp(n, low, high)
end

function Audio.new(ctx)
    ctx = ctx or {}
    local self = setmetatable({ctx = ctx, player = ctx.player or game:GetService("Players").LocalPlayer,
        players = game:GetService("Players"), characterSounds = {},
        workspace = game:GetService("Workspace"), soundService = game:GetService("SoundService"),
        provider = game:GetService("ContentProvider"), runService = game:GetService("RunService"),
        clock = ctx.clock or os.clock, preferences = table.clone(DEFAULTS), assets = {}, voices = {},
        sources = {}, connections = {}, gates = {}, dead = false, testState = "idle", testToken = 0,
        elapsed = 0, discoveryElapsed = 0, footClock = 0, retryAt = 0, sourceCount = 0,
        cues = {}, phase = "INTERMISSION", nextAtmosphereAt = 0, atmosphereIndex = 0,
        conditionDowned = false, senseState = "IDLE", senseUntil = 0,
    }, Audio)
    self.lastCharacter = self.player and self.player.Character
    self.ambientGroup = Instance.new("SoundGroup")
    self.ambientGroup.Name, self.ambientGroup.Volume, self.ambientGroup.Parent = "NightShift42Ambience", DEFAULTS.ambientVolume, self.soundService
    self.effectsGroup = Instance.new("SoundGroup")
    self.effectsGroup.Name, self.effectsGroup.Volume, self.effectsGroup.Parent = "NightShift42Effects", DEFAULTS.effectsVolume, self.soundService
    self.threatGroup = Instance.new("SoundGroup")
    self.threatGroup.Name, self.threatGroup.Volume, self.threatGroup.Parent = "NightShift40Creature", DEFAULTS.threatVolume, self.soundService
    self.uiGroup = Instance.new("SoundGroup")
    self.uiGroup.Name, self.uiGroup.Volume, self.uiGroup.Parent = "NightShift40Interface", DEFAULTS.uiVolume, self.soundService
    -- Layered cues use conservative gain; compression softens coincident peaks.
    -- This is not an estimate of the listener's hardware volume.
    for _, group in ipairs({self.ambientGroup, self.effectsGroup, self.threatGroup, self.uiGroup}) do
        local compressor = Instance.new("CompressorSoundEffect")
        compressor.Name, compressor.Threshold, compressor.Ratio = "NightShiftPeakControl", -10, 6
        compressor.Attack, compressor.Release, compressor.GainMakeup = .01, .18, 0
        compressor.Parent = group
    end
    self.emitters = Instance.new("Folder")
    self.emitters.Name, self.emitters.Parent = "NightShift42AudioEmitters", self.workspace
    self.preloadFolder = Instance.new("Folder")
    self.preloadFolder.Name, self.preloadFolder.Parent = "NightShift42AudioPreload", self.soundService
    for key, asset in pairs(ASSETS) do
        local sound = Instance.new("Sound")
        sound.Name, sound.SoundId, sound.Volume, sound.Parent = "Preload_" .. key, asset, 0, self.preloadFolder
        self.assets[key] = {sound = sound, state = "loading", attempts = 0}
    end
    self:_StatusChanged()
    for key in pairs(self.assets) do self:_Warm(key) end
    self:_StartBed()
    self:_DiscoverWorld()
    table.insert(self.connections, self.workspace.DescendantAdded:Connect(function(object)
        if self.dead then return end
        if object.Name == "NightShiftWorld" then self:_DiscoverWorld() end
        if self.world then self:_AttachSource(object) end
    end))
    table.insert(self.connections, self.runService.Heartbeat:Connect(function(dt) self:_Update(dt) end))
    -- Starts independently from HUD and server State replication.
    task.delay(.7, function() if not self.dead then self:Play({kind = "entry"}) end end)
    return self
end

function Audio:GetStatus()
    local loaded, failed, total = 0, 0, 0
    for _, asset in pairs(self.assets) do
        total += 1
        if asset.state == "ready" then loaded += 1 elseif asset.state == "failed" then failed += 1 end
    end
    local state, message = "loading", "Звуки загружаются…"
    if self.dead then state, message = "destroyed", "Звук остановлен"
    elseif (self.preferences.masterVolume == 0 or (self.preferences.ambientVolume == 0 and self.preferences.effectsVolume == 0 and self.preferences.threatVolume == 0 and self.preferences.uiVolume == 0)) then state, message = "muted", "Звук выключен в настройках"
    elseif loaded == total then state, message = "ready", "Звуки загружены"
    elseif failed == total then state, message = "failed", "Звуки не загрузились. Нажми «Проверить звук» для повторной попытки."
    elseif failed > 0 then state, message = "degraded", "Часть звуков заменена резервными; загрузка повторится."
    end
    if not self.dead and not ((self.preferences.masterVolume == 0 or (self.preferences.ambientVolume == 0 and self.preferences.effectsVolume == 0 and self.preferences.threatVolume == 0 and self.preferences.uiVolume == 0))) then
        if self.testState == "loading" then message = "Загружаем контрольный сигнал…"
        elseif self.testState == "played" then message = "Сигнал запущен. Если тишина, проверь громкость Roblox и устройства."
        elseif self.testState == "muted" then message = "Звуки действий выключены. Подними их громкость и повтори проверку."
        elseif self.testState == "failed" then message = "Контрольный сигнал не загрузился. Попробуй снова."
        end
    end
    return {state = state, text = message, loaded = loaded, failed = failed, total = total, testState = self.testState}
end

function Audio:_StatusChanged()
    if type(self.ctx.status) == "function" then pcall(self.ctx.status, self:GetStatus()) end
end

function Audio:SetPreferences(prefs)
    if self.dead then return end
    prefs = type(prefs) == "table" and prefs or {}
    for _, key in ipairs({"masterVolume", "ambientVolume", "effectsVolume", "threatVolume", "uiVolume"}) do
        self.preferences[key] = finite(prefs[key], DEFAULTS[key], 0, 1)
    end
    if self.preferences.effectsVolume == 0 then
        if prefs.threatVolume == nil then self.preferences.threatVolume = 0 end
        if prefs.uiVolume == nil then self.preferences.uiVolume = 0 end
        if self.preferences.ambientVolume == 0 and prefs.masterVolume == nil then self.preferences.masterVolume = 0 end
    end
    self.preferences.mix = prefs.mix == "night" and "night" or "balanced"
    local master, soft = self.preferences.masterVolume, self.preferences.mix == "night"
    self.ambientGroup.Volume = master * self.preferences.ambientVolume
    self.effectsGroup.Volume = master * self.preferences.effectsVolume * (soft and .85 or 1)
    self.threatGroup.Volume = master * self.preferences.threatVolume * (soft and .62 or 1)
    self.uiGroup.Volume = master * self.preferences.uiVolume * (soft and .85 or 1)
    if master == 0 or self.preferences.effectsVolume == 0 then
        self.testToken += 1
        if self.testVoice then self:_Dispose(self.testVoice); self.testVoice = nil end
        self.testState = "muted"
    elseif self.testState == "muted" then self.testState = "idle" end
    for key, cue in pairs(self.cues) do
        if master == 0 or self.preferences[cue.channel] == 0 then self:_StopCue(key) end
    end
    self:_StatusChanged()
end

-- Connect first, check IsLoaded again, and inspect the fetch callback. A pcall
-- alone cannot detect an individual failed asset in PreloadAsync.
function Audio:_Load(sound, timeout, callback)
    local finished, connection = false, nil
    local function finish(ok)
        if finished then return end
        finished = true
        if connection then connection:Disconnect() end
        if not self.dead and sound.Parent then
            task.defer(function() if not self.dead and sound.Parent then callback(ok) end end)
        end
    end
    if sound.IsLoaded then finish(true); return function() end end
    connection = sound.Loaded:Connect(function() if sound.IsLoaded then finish(true) end end)
    if sound.IsLoaded then finish(true) else
        task.spawn(function()
            local ok = pcall(function()
                self.provider:PreloadAsync({sound}, function(_, status)
                    if status == Enum.AssetFetchStatus.Success then
                        if sound.IsLoaded then finish(true) end
                    elseif status == Enum.AssetFetchStatus.Failure or status == Enum.AssetFetchStatus.TimedOut then finish(false) end
                end)
            end)
            if not ok then finish(false) elseif sound.IsLoaded then finish(true) end
        end)
        task.delay(timeout, function() finish(sound.IsLoaded == true) end)
    end
    return function()
        finished = true
        if connection then connection:Disconnect() end
    end
end

function Audio:_AssetResult(key, ok)
    local asset = self.assets[key]
    if not asset then return end
    if ok then asset.state = "ready" elseif asset.state ~= "ready" then asset.state = "failed" end
    self:_StatusChanged()
end

function Audio:_Warm(key)
    local asset = self.assets[key]
    if self.dead or not asset or asset.state == "ready" then return end
    if asset.cancel then asset.cancel() end
    asset.attempts += 1
    asset.state = "loading"
    asset.cancel = self:_Load(asset.sound, 8, function(ok) self:_AssetResult(key, ok) end)
end

function Audio:_Dispose(voice)
    if not voice or voice.dead then return end
    voice.dead = true
    if voice.cancel then voice.cancel() end
    if voice.ended then voice.ended:Disconnect() end
    if voice.sound then voice.sound:Destroy() end
    if voice.emitter then voice.emitter:Destroy() end
    self.voices[voice] = nil
end

function Audio:_Voice(definition, options)
    if self.dead then return nil end
    options = options or {}
    local count = 0
    for _ in pairs(self.voices) do count += 1 end
    if count >= 64 then return nil end
    local voice = {definition = definition, baseVolume = math.clamp(definition.volume or 1, 0, 10),
        looped = options.looped == true, source = options.source, deadline = self.clock() + (options.maxWait or 4), options = options}
    self.voices[voice] = true
    local keys = {definition.asset, FALLBACK[definition.asset]}
    if options.kind and options.kind:find("^footstep") then
        for _, key in ipairs({"thump", "mechanism"}) do
            if not table.find(keys, key) then table.insert(keys, key) end
        end
    end
    local function attempt(index, forceBuiltin)
        if self.dead or voice.dead then return end
        local key = keys[index]
        if not key or (not voice.looped and self.clock() > voice.deadline) then
            if options.failed then options.failed() end
            self:_Dispose(voice)
            return
        end
        local customKey = options.customKey or options.kind
        local assetId = customKey and CUSTOM_AUDIO_IDS[customKey]
        local useCustom=index==1 and forceBuiltin~=true and type(assetId)=="number" and assetId>0
        if not useCustom and self.assets[key].state == "failed" and keys[index + 1] then attempt(index + 1,true); return end
        if voice.cancel then voice.cancel() end
        if voice.sound then voice.sound:Destroy() end
        local sound = Instance.new("Sound")
        voice.sound, voice.asset = sound, key
        sound.Name = "NS42_" .. (definition.kind or options.kind or key)
        -- If an imported asset fails permission/loading, retry the same cue
        -- with the builtin original asset before falling back to alternate sound.
        sound.SoundId=useCustom and ("rbxassetid://"..tostring(math.floor(assetId))) or ASSETS[key]
        sound.SoundGroup = (definition.category == "ambient" or (not definition.category and options.looped)) and self.ambientGroup
            or (definition.category == "threat" and self.threatGroup or (definition.category == "ui" and self.uiGroup or self.effectsGroup))
        voice.gain = useCustom and 1 or 10 ^ ((SOURCE_RMS[definition.asset] - SOURCE_RMS[key]) / 20)
        sound.Volume = voice.baseVolume * voice.gain * finite(options.volume, 1, 0, 1.5)
        sound.Volume = math.clamp(sound.Volume, 0, 10)
        -- One-shot occlusion: real walls attenuate and muffle a sound rather than
        -- letting a threat scream at full volume through three concrete rooms.
        -- Only one ray per new voice, not per rendered frame.
        if options.position and not definition.global and not voice.looped then
            local ok,blocked=pcall(function()
                local camera=self.workspace.CurrentCamera
                if not camera then return false end
                local delta=options.position-camera.CFrame.Position
                if delta.Magnitude<2 or delta.Magnitude>(definition.range or 44) then return false end
                local params=RaycastParams.new()
                local excludes={self.emitters}
                if self.player and self.player.Character then table.insert(excludes,self.player.Character) end
                params.FilterType=Enum.RaycastFilterType.Exclude
                params.FilterDescendantsInstances=excludes
                params.RespectCanCollide=true
                return self.workspace:Raycast(camera.CFrame.Position,delta,params)~=nil
            end)
            if ok and blocked then
                voice.occluded=true
                sound.Volume*=.48
                local muffler=Instance.new("EqualizerSoundEffect")
                muffler.LowGain,muffler.MidGain,muffler.HighGain=0,-3,-12
                muffler.Parent=sound
            end
        end
        sound.PlaybackSpeed, sound.Looped = finite(options.pitch, definition.speed or 1, .4, 2.5), voice.looped
        sound.RollOffMode = Enum.RollOffMode.Linear
        sound.RollOffMinDistance, sound.RollOffMaxDistance = definition.minDistance or 10, definition.range or 44
        local parent = options.source or self.soundService
        if options.position and not definition.global then
            if not voice.emitter then
                local emitter = Instance.new("Part")
                emitter.Name, emitter.Size, emitter.Position = "AudioEmitter", Vector3.new(.1,.1,.1), options.position
                emitter.Anchored, emitter.Transparency, emitter.CanCollide, emitter.CanTouch, emitter.CanQuery = true, 1, false, false, false
                emitter.Parent = self.emitters
                voice.emitter = emitter
            end
            parent = voice.emitter
        end
        sound.Parent = parent
        if options.eq then
            local eq = Instance.new("EqualizerSoundEffect")
            eq.LowGain, eq.MidGain, eq.HighGain = options.eq[1], options.eq[2], options.eq[3]
            eq.Parent = sound
        end
        if options.position and options.position.Y < -3 then
            local echo = Instance.new("ReverbSoundEffect")
            echo.DecayTime, echo.Density, echo.WetLevel, echo.DryLevel = .65, .45, -16, 0
            echo.Parent = sound
        end
        voice.cancel = self:_Load(sound, voice.looped and 6 or math.max(.1, math.min(4, voice.deadline - self.clock())), function(ok)
            if not useCustom then self:_AssetResult(key, ok) end
            if voice.dead or self.dead then return end
            if not ok then
                if useCustom then attempt(index, true) else attempt(index + 1, true) end
                return
            end
            if not voice.looped and self.clock() > voice.deadline then
                if options.failed then options.failed() end
                self:_Dispose(voice); return
            end
            local played = pcall(function() sound:Play() end)
            if not played then attempt(index + 1); return end
            voice.started = self.clock()
            if options.started then options.started(key ~= definition.asset) end
            if not voice.looped then
                voice.ended = sound.Ended:Connect(function() self:_Dispose(voice) end)
                local duration = definition.duration or (sound.TimeLength > 0 and math.max(.2, sound.TimeLength / sound.PlaybackSpeed) or 4)
                task.delay(math.min(12, duration + .15), function() self:_Dispose(voice) end)
            end
        end)
    end
    attempt(1)
    return voice
end

function Audio:_StopCue(key)
    local cue = self.cues[key]
    if not cue then return end
    self.cues[key] = nil
    for _, voice in ipairs(cue.voices) do self:_Dispose(voice) end
end

function Audio:_CueLayer(cue, layer, index)
    if self.dead or self.cues[cue.key] ~= cue then return end
    local definition = table.clone(layer)
    definition.category = definition.category or cue.category
    local kind = layer.kind or (index == 1 and cue.kind or cue.kind .. "_layer" .. index)
    local voice = self:_Voice(definition, {kind = kind, customKey = layer.customKey, position = cue.position, looped = layer.looped == true,
        volume = layer.looped and 0 or cue.volume, eq = layer.eq})
    if voice then
        voice.cueMode = layer.mode
        table.insert(cue.voices, voice)
        if index == 1 then cue.anchor = voice end
    end
end

function Audio:_BeginCue(key, kind, payload, layers, duration, category, heartbeat)
    local old = self.cues[key]
    if old then
        if typeof(payload.position) == "Vector3" then old.position = payload.position end
        if key == "chase" and old.started then
            old.duration = math.min(8, math.max(old.duration, self.clock() - old.started + duration))
            old.hardDeadline = old.requestedAt + 12
        end
        -- Rapid repeats update a moving emitter; they do not stack or extend an alarm forever.
        return true
    end
    local now = self.clock()
    local cue = {key = key, kind = kind, position = payload.position, volume = finite(payload.volume, 1, 0, 1.5),
        layers = layers, voices = {}, nextLayer = 2, requestedAt = now, duration = duration,
        loadDeadline = now + 4, hardDeadline = now + duration + 4,
        category = category or "effects", channel = (category or "effects") .. "Volume", heartbeat = heartbeat}
    self.cues[key] = cue
    self:_CueLayer(cue, layers[1], 1)
    if not cue.anchor then self.cues[key] = nil end
    return cue.anchor ~= nil
end

function Audio:_Composite(kind, payload)
    local global = payload.position == nil
    -- Use experience-owned WAVs when configured; layered builtin cues are
    -- deliberately kept as fallback for projects without an audio import.
    local keepLayeredCustom = kind == "alarm" or kind == "alarm_start" or kind == "monster_chase"
    if not keepLayeredCustom and type(CUSTOM_AUDIO_IDS[kind]) == "number" and CUSTOM_AUDIO_IDS[kind] > 0 then return nil end
    if kind=="incident_surge" then
        return self:_BeginCue("inc_surge",kind,payload,{
            {asset="mechanism",volume=1.7,speed=.62,range=59,duration=.55,eq={2,-2,-8}},
            {at=.22,asset="tone",volume=.40,speed=.7,range=54,duration=1.1,eq={-3,2,-6}},
            {at=.58,asset="wind",volume=2.3,speed=.52,range=53,duration=1.3,eq={3,-2,-11}},
        },2.15,"ambient")
    elseif kind=="incident_flood" then
        return self:_BeginCue("inc_flood",kind,payload,{
            {asset="water",volume=3.0,speed=.68,range=58,duration=1.45,eq={3,0,-6}},
            {at=.28,asset="mechanism",volume=1.1,speed=.47,range=48,duration=.8,eq={2,-1,-9}},
        },1.85,"ambient")
    elseif kind=="incident_camera" then
        return self:_BeginCue("inc_camera",kind,payload,{
            {asset="tone",volume=.38,speed=.52,range=45,duration=.7},
            {at=.25,asset="water",volume=1.7,speed=.73,range=45,duration=1.0,eq={-3,1,-12}},
        },1.45,"ambient")
    elseif kind=="incident_radio" then
        return self:_BeginCue("inc_radio",kind,payload,{
            {asset="wind",volume=3.2,speed=.54,range=53,duration=1.5,eq={-3,3,-11}},
            {at=.2,asset="tone",volume=.16,speed=.61,range=40,duration=1.0},
        },1.85,"ambient")
    elseif kind=="incident_archive" then
        return self:_BeginCue("inc_archive",kind,payload,{
            {asset="thump",volume=1.3,speed=.48,range=50,duration=.65,eq={2,-3,-11}},
            {at=.38,asset="mechanism",volume=1.1,speed=.5,range=43,duration=.85},
            {at=.64,asset="thump",volume=.7,speed=.6,range=40,duration=.35},
        },1.65,"ambient")
    elseif kind=="fear_sting" then
        return self:_BeginCue("fear_sting",kind,payload,{
            {asset="impact",volume=.07,speed=.43,range=44,duration=.7,eq={3,-3,-11}},
            {at=.12,asset="wind",volume=2.3,speed=.52,range=43,duration=1.4,eq={2,-2,-15}},
            {at=.22,asset="tone",volume=.10,speed=.56,range=40,duration=.7,eq={-3,-4,-9}},
        },1.9,"ambient")
    end
    if kind == "generator_start" then
        return self:_BeginCue("generator_start", kind, payload, {
            {asset="mechanism",volume=1.8,speed=.48,range=58,duration=1.25,eq={5,-3,-13}},
            {at=.16,asset="thump",volume=.62,speed=.58,range=54,duration=.48,eq={5,-5,-14}},
            {at=.55,asset="wind",volume=1.25,speed=.54,range=58,duration=1.55,eq={7,-6,-17}},
        }, 2.4, "ambient")
    elseif kind == "generator_warning" then
        return self:_BeginCue("generator_warning", kind, payload, {
            {asset="tone",customKey="alarm_start",volume=.78,speed=.92,range=42,duration=.58,eq={-4,0,-5}},
            {at=.72,asset="tone",customKey="alarm_start",volume=.78,speed=.92,range=42,duration=.58,eq={-4,0,-5}},
        }, 1.45, "effects")
    elseif kind == "generator_stop" then
        return self:_BeginCue("generator_stop", kind, payload, {
            {asset="wind",customKey="generator_motor",volume=2.0,speed=.68,range=58,duration=1.4,mode="generator_stop",eq={7,-5,-17}},
            {at=.12,asset="mechanism",volume=1.25,speed=.48,range=52,duration=.75,eq={3,-2,-10}},
            {at=.82,asset="thump",volume=.42,speed=.52,range=42,duration=.42,eq={5,-6,-14}},
        }, 1.7, "ambient")
    elseif kind == "powerDown" then
        return self:_BeginCue("power_down", kind, payload, {
            {asset="thump",volume=.72,speed=.48,range=48,duration=.42,eq={5,-5,-13}},
            {at=.14,asset="mechanism",volume=.82,speed=.48,range=48,duration=.62,eq={3,-3,-12}},
        }, .95, "ambient")
    elseif kind == "powerOn" then
        return self:_BeginCue("power_on", kind, payload, {
            {asset="mechanism",volume=.72,speed=.55,range=48,duration=.52,eq={4,-3,-12}},
            {at=.16,asset="thump",volume=.38,speed=.62,range=46,duration=.36,eq={5,-4,-13}},
        }, .82, "ambient")
    elseif kind == "alarm" or kind == "alarm_start" then
        return self:_BeginCue("alarm", kind, payload, {
            {asset="tone",customKey="alarm_start",volume=.92,speed=.75,range=100,global=global,looped=true,mode="siren",eq={-3,0,-3}},
            {asset="wind",volume=1.15,speed=1.2,range=75,global=global,looped=true,mode="siren_body",eq={1,-3,-10}},
        }, finite(payload.duration, 6, 2, 18), "effects")
    elseif kind == "generator_start" then
        return self:_BeginCue("generator_start", kind, payload, {
            {asset="mechanism",volume=1.7,speed=.62,range=58,duration=.28},
            {at=.3,asset="mechanism",volume=1.85,speed=.68,range=58,duration=.3},
            {at=.68,asset="mechanism",volume=2.0,speed=.76,range=58,duration=.28},
            {at=1.02,asset="mechanism",volume=2.05,speed=.86,range=58,duration=.3},
            {at=1.34,asset="impact",volume=.065,speed=.58,range=56,duration=.45,eq={1,-2,-9}},
            {at=1.42,asset="wind",volume=3.6,speed=.5,range=58,duration=1.05,eq={4,-2,-11}},
        }, 2.65, "effects")
    elseif kind == "monster_chase" then
        return self:_BeginCue("chase", kind, payload, {
            {asset="wind",customKey="monster_breath",volume=2.6,speed=.62,range=45,looped=true,mode="breath",eq={4,-3,-13}},
            {at=.16,asset="thump",volume=.42,speed=.52,range=38,looped=true,mode="breath",eq={6,-6,-17}},
        }, finite(payload.duration, 3, .5, 8), "threat", .78)
    elseif kind == "player_downed" then
        return self:_BeginCue("downed", kind, payload, {
            {asset="wind",volume=2.7,speed=.48,global=true,looped=true,mode="breath",eq={2,-4,-15}},
            {at=.1,asset="tone",volume=.13,speed=.48,global=true,duration=1.2,eq={-6,-5,-8}},
        }, finite(payload.duration, 35, 1, 36), "threat", 1.25)
    elseif kind == "player_death" then
        return self:_BeginCue("death", kind, payload, {
            {asset="mechanism",volume=1.8,speed=.42,global=true,duration=1.5,mode="death_fade",eq={1,-3,-10}},
            {at=.12,asset="impact",volume=.055,speed=.52,global=true,duration=.55,eq={2,-6,-13}},
            {at=.2,asset="wind",volume=3.2,speed=.42,global=true,duration=2.5,mode="death_fade",eq={1,-3,-13}},
            {at=.48,asset="tone",volume=.12,speed=.45,global=true,duration=1.7,mode="death_fade",eq={-6,-4,-8}},
        }, 3.1, "threat")
    elseif kind == "monster_attack" then
        return self:_BeginCue("attack", kind, payload, {
            {asset="impact",volume=.12,speed=.68,range=42,duration=.6,eq={1,-2,-7}},
            {at=.04,asset="wind",customKey="monster_roar",volume=3.15,speed=.62,range=42,duration=2.6,eq={5,-3,-14}},
            {at=.22,asset="wind",customKey="fear_sting",volume=1.2,speed=.52,range=38,duration=1.25,eq={4,-2,-13}},
            {at=.25,asset="mechanism",volume=1.05,speed=.44,range=32,duration=.8},
        }, 2.8, "threat")
    end
    return nil
end

function Audio:_UpdateCues(now)
    local stale = {}
    for key, cue in pairs(self.cues) do
        if not cue.started and cue.anchor and cue.anchor.started then cue.started = cue.anchor.started end
        local elapsed = cue.started and now - cue.started or 0
        local generatorOff = key == "generator_start" and now - cue.requestedAt > .8 and self.world and self.world:GetAttribute("PowerState") == "OFF"
        if now >= cue.hardDeadline or (not cue.started and now >= cue.loadDeadline)
            or (cue.started and elapsed >= cue.duration) or generatorOff then
            table.insert(stale, key)
        elseif cue.started then
            while cue.nextLayer <= #cue.layers and elapsed >= (cue.layers[cue.nextLayer].at or 0) do
                self:_CueLayer(cue, cue.layers[cue.nextLayer], cue.nextLayer)
                cue.nextLayer += 1
            end
            if cue.heartbeat and now >= (cue.nextBeat or 0) then
                self:_CueLayer(cue, {asset="thump",volume=.62,speed=.63,global=true,duration=.22,category="threat",kind="heartbeat",eq={3,-4,-15}}, 99)
                cue.secondBeat, cue.nextBeat = now + .17, now + cue.heartbeat
            end
            if cue.secondBeat and now >= cue.secondBeat then
                self:_CueLayer(cue, {asset="thump",volume=.38,speed=.72,global=true,duration=.18,category="threat",kind="heartbeat_echo",eq={2,-4,-15}}, 100)
                cue.secondBeat = nil
            end
            local envelope = math.clamp(math.min(elapsed/.22, (cue.duration-elapsed)/.5), 0, 1)
            for index = #cue.voices, 1, -1 do
                local voice = cue.voices[index]
                if voice.dead then table.remove(cue.voices, index)
                elseif voice.sound then
                    if voice.emitter and typeof(cue.position) == "Vector3" then voice.emitter.Position = cue.position end
                    if voice.looped then
                        local modulation, pitch = 1, voice.definition.speed or 1
                        if voice.cueMode == "siren" then
                            local sweep = .5 + .5*math.sin(elapsed*math.pi*1.6)
                            modulation, pitch = .64 + sweep*.36, .62 + sweep*.78
                        elseif voice.cueMode == "siren_body" then modulation = .55 + .25*math.sin(elapsed*math.pi*1.6)^2
                        elseif voice.cueMode == "breath" then modulation = .45 + .55*(.5+.5*math.sin(elapsed*2.8))^2 end
                        voice.sound.PlaybackSpeed = math.clamp(pitch, .4, 2.5)
                        voice.sound.Volume = math.clamp(voice.baseVolume*(voice.gain or 1)*cue.volume*modulation*envelope, 0, 10)
                    elseif voice.cueMode == "death_fade" and voice.started then
                        local life = now - voice.started
                        local fade = math.clamp(1-life/(voice.definition.duration or 1),0,1)^1.3
                        voice.sound.Volume = math.clamp(voice.baseVolume*(voice.gain or 1)*cue.volume*fade,0,10)
                    elseif voice.cueMode == "generator_stop" and voice.started then
                        local life = now - voice.started
                        local duration = voice.definition.duration or 1.4
                        local fade = math.clamp(1-life/duration,0,1)^1.35
                        voice.sound.PlaybackSpeed = math.clamp((voice.definition.speed or .68)-life*.2,.36,1.5)
                        voice.sound.Volume = math.clamp(voice.baseVolume*(voice.gain or 1)*cue.volume*fade,0,10)
                    end
                end
            end
        end
    end
    for _, key in ipairs(stale) do self:_StopCue(key) end
end

function Audio:HandleEvent(kind, data)
    if self.dead then return end
    if kind == "State" and type(data) == "table" then
        local before = self.phase
        self.phase = type(data.phase) == "string" and data.phase or self.phase
        if type(data.phase) == "string" then self.phaseKnown = true end
        if type(data.monsterActive) == "boolean" then self.monsterActive = data.monsterActive end
        if before ~= "SHIFT" and self.phase == "SHIFT" then self.nextAtmosphereAt = self.clock() + 18 + math.random()*10 end
        if self.phase ~= "SHIFT" then
            self.conditionDowned, self.senseState, self.senseUntil = false, "IDLE", 0
            self.generatorOverride, self.generatorOverrideUntil = nil, nil
            self:_StopCue("alarm"); self:_StopCue("chase"); self:_StopCue("downed"); self:_StopCue("attack"); self:_StopCue("generator_start"); self:_StopCue("fear_sting")
            self:_StopAtmosphere()
        end
    elseif kind == "ThreatSense" and type(data) == "table" then
        local state = type(data.state) == "string" and data.state or "IDLE"
        self.senseState = state
        self.senseUntil = self.clock() + finite(data.duration, 1.8, .2, 8)
        if state == "CHASE" and not self.conditionDowned and self.phase == "SHIFT" then
            self:Play({kind="monster_chase",position=data.position,duration=math.min(8,finite(data.duration,1.8,.2,8)+.4)})
        else self:_StopCue("chase") end
    elseif kind == "PlayerCondition" and type(data) == "table" then
        local was = self.conditionDowned
        self.conditionDowned = data.downed == true and (not self.phaseKnown or self.phase == "SHIFT")
        if self.conditionDowned and not was then
            self:_StopCue("chase")
            self:Play({kind="player_downed",duration=finite(data.reviveRemaining,35,1,36)})
        elseif not self.conditionDowned then
            self:_StopCue("downed")
            -- false also means evacuation / character removal / round cleanup.
            -- Only the explicit successful "revive" event announces recovery.
        end
    elseif kind == "CharacterRemoving" then
        self.removingCharacter, self.lastCharacter = data or (self.player and self.player.Character), nil
        self:_ResetPersonalScene(false)
    elseif kind == "CharacterAdded" then
        self.removingCharacter, self.lastCharacter = nil, data or (self.player and self.player.Character)
        self:_ResetPersonalScene(true)
    end
end

function Audio:_ResetPersonalScene(newCharacter)
    self:_StopCue("chase"); self:_StopCue("downed"); self:_StopCue("attack")
    self.conditionDowned, self.senseState, self.senseUntil = false, "IDLE", 0
    if newCharacter then self:_StopCue("death"); self.lastDeath = nil end
end

function Audio:Play(payload)
    if self.dead or type(payload) ~= "table" then return false end
    local kind = type(payload.kind) == "string" and payload.kind or ""
    if self.phaseKnown and self.phase ~= "SHIFT" and SHIFT_CUES[kind] then return true end
    if kind == "alarm_stop" then self:_StopCue("alarm"); return true end
    if kind == "generator_run" then self.generatorOverride, self.generatorOverrideUntil = "RUNNING", self.clock()+3; self:_StopCue("generator_start"); return true end
    if kind == "generator_start" then self.generatorOverride, self.generatorOverrideUntil = "STARTING", self.clock()+4 end
    if kind == "generator_stop" then
        self.generatorOverride, self.generatorOverrideUntil = "OFF", self.clock()+3
        self:_StopCue("generator_start")
        self:_StopGeneratorMotor()
    elseif kind == "player_death" then
        if self.clock() - (self.lastDeath or -100) < 3 then return true end
        self.lastDeath = self.clock()
        self:_StopCue("downed"); self:_StopCue("chase"); self:_StopCue("attack")
        self:_StopAtmosphere()
    elseif kind == "player_revived" then self:_StopCue("downed") end
    local definition = SOUNDS[kind]
    if not definition then return false end
    local position = typeof(payload.position) == "Vector3" and payload.position or nil
    local camera = self.workspace.CurrentCamera
    if not definition.global and position and camera and (position - camera.CFrame.Position).Magnitude > (definition.range or 44) then return false end
    local now = self.clock()
    local gate = kind
    if now - (self.gates[gate] or -100) < (kind == "step" and .23 or kind == "footstep" and .2 or .12) then return false end
    self.gates[gate] = now
    local caption = type(payload.caption) == "string" and payload.caption or definition.caption
    if self.ctx.caption and caption and caption ~= "" then
        local captionReady = (kind ~= "step" or now - (self.lastStepCaption or -100) > 4)
            and (kind ~= "monster_chase" or now - (self.lastChaseCaption or -100) > 5)
        if captionReady then
            pcall(self.ctx.caption, caption, position, 2.4)
            if kind == "step" then self.lastStepCaption = now end
            if kind == "monster_chase" then self.lastChaseCaption = now end
        end
    end
    local channel = definition.category == "threat" and "threatVolume" or (definition.category == "ui" and "uiVolume" or (definition.category == "ambient" and "ambientVolume" or "effectsVolume"))
    if self.preferences.masterVolume <= 0 or self.preferences[channel] <= 0 then return true end
    local composite = self:_Composite(kind, {position=position,volume=payload.volume,duration=payload.duration})
    if composite ~= nil then return composite end
    local customOneShot = (kind == "monster_notice" or kind == "monster_retreat" or kind == "monster_breath") and "monster_breath"
        or (kind == "monster_search" and "crawler_scrape" or nil)
    local voice = self:_Voice(definition, {kind = kind, customKey = customOneShot, position = position, volume = payload.volume, pitch = payload.pitch})
    if voice and (kind == "monster_notice" or kind == "monster_search" or kind == "monster_breath" or kind == "monster_retreat") then
        self:_Voice({asset=kind=="monster_notice" and "tone" or "water",volume=kind=="monster_notice" and .16 or 1.25,
            speed=kind=="monster_retreat" and .92 or .47,range=definition.range,duration=1.0,category="threat"},
            {kind=kind.."_undertone",position=position,volume=payload.volume,eq={2,-2,-12}})
    elseif voice and kind == "pipe_knock" then
        self:_BeginCue("pipe_echo", "pipe_knock", {position=position,volume=.55}, {
            {asset="thump",volume=.38,speed=.7,range=28,duration=.2},
            {at=.32,asset="thump",volume=.52,speed=.58,range=28,duration=.35},
        }, .9, "ambient")
    end
    return voice ~= nil
end

function Audio:Test()
    if self.dead then return false end
    if self.preferences.masterVolume <= 0 or self.preferences.effectsVolume <= 0 then
        self.testToken += 1
        self.testState = "muted"; self:_StatusChanged(); return false
    end
    local now = self.clock()
    if now - (self.lastTest or -100) < 1 then return false end
    self.lastTest = now
    self.testToken += 1
    local token = self.testToken
    if self.testVoice then self:_Dispose(self.testVoice) end
    for key, asset in pairs(self.assets) do if asset.state == "failed" then self:_Warm(key) end end
    self.testState = "loading"; self:_StatusChanged()
    local voice = self:_Voice(SOUNDS.test, {kind = "test", maxWait = 8,
        started = function()
            if self.testToken == token then self.testState = "played"; self:_StatusChanged() end
        end,
        failed = function()
            if self.testToken == token then self.testState = "failed"; self:_StatusChanged() end
        end,
    })
    self.testVoice = voice
    if not voice then self.testState = "failed"; self:_StatusChanged(); return false end
    return true
end

function Audio:_StartBed()
    if self.dead then return end
    if not self.bed or self.bed.dead then
        self.bed = self:_Voice({asset = "wind", kind = "room_tone", volume = 4.8, speed = .8, global = true},
            {looped = true, kind = "room_tone", eq = {2, 0, -6}})
    end
    -- The extra basement layer is optional.  Without an imported asset it would
    -- duplicate the regular built-in noise, so no second layer is created.
    if type(CUSTOM_AUDIO_IDS.basement_tone)=="number" and CUSTOM_AUDIO_IDS.basement_tone>0
        and (not self.basementBed or self.basementBed.dead) then
        self.basementBed=self:_Voice({asset="wind",kind="basement_tone",volume=2.3,
            speed=.84,global=true,category="ambient"},
            {looped=true,kind="basement_tone",volume=0,eq={2,-2,-8}})
    end
end

function Audio:_DiscoverWorld()
    if self.dead then return end
    local world = self.workspace:FindFirstChild("NightShiftWorld")
    if world ~= self.world then
        for key in pairs(self.cues) do self:_StopCue(key) end
        self:_StopGeneratorMotor()
        self.generatorPart, self.generatorOverride, self.generatorOverrideUntil = nil, nil, nil
        self.motorRetryAt = 0
        for part, entry in pairs(self.sources) do self:_Dispose(entry.voice); self.sources[part] = nil end
        self.sourceCount, self.world = 0, world
        self.nextAtmosphereAt = self.clock() + 18 + math.random()*10
        if world then
            -- Reserve the generator before adding the rest of the equipment.
            local generator = world:FindFirstChild("Generator", true)
            if generator then self:_AttachSource(generator) end
            for _, object in ipairs(world:GetDescendants()) do self:_AttachSource(object) end
        end
    elseif world and self.sourceCount < 32 then
        -- Names and attributes can replicate after Parent; revisit discovered parts.
        for _, object in ipairs(world:GetDescendants()) do self:_AttachSource(object) end
    end
end

function Audio:_AttachSource(part)
    if self.dead or not self.world or not part:IsA("BasePart") or self.sources[part] then return end
    local config = SOURCE_CONFIG[part.Name] or AMBIENT_TYPES[part:GetAttribute("NS40Ambient")]
    if not config or not part:IsDescendantOf(self.world) or self.sourceCount >= 32 then return end
    config = table.clone(config)
    local powered = part:GetAttribute("Powered")
    if type(powered) == "boolean" then config.powered = powered end
    local entry = {part = part, config = config, retryAt = self.clock() + 8}
    self.sources[part] = entry
    self.sourceCount += 1
    if config.kind == "generator" then self.generatorPart = part end
    local active = not (config.powered and self.world:GetAttribute("PowerState") == "OFF")
    if config.kind == "generator" then active = self:_GeneratorState(part) == "RUNNING" end
    entry.voice = self:_Voice({asset = config.asset or "wind", kind = config.kind, volume = config.volume, speed = config.speed, range = config.range},
        {looped = true, source = part, kind = config.kind, volume = active and 1 or 0, eq = {config.kind == "generator" and 5 or 1, -2, -9}})
end

function Audio:_GeneratorState(part)
    if not part or not part.Parent or not self.world or not part:IsDescendantOf(self.world) then return "OFF" end
    if self.world:GetAttribute("PowerState") == "OFF" then return "OFF" end
    local state = part:GetAttribute("NSGeneratorState")
    -- A remote cue can arrive just before the matching replicated attribute.
    if self.generatorOverride and self.clock() < (self.generatorOverrideUntil or 0) then return self.generatorOverride end
    if state == "OFF" or state == "STARTING" or state == "RUNNING" then return state end
    return "RUNNING" -- Older worlds expose only PowerState.
end

function Audio:_StopGeneratorMotor()
    if self.generatorMotor then self:_Dispose(self.generatorMotor); self.generatorMotor = nil end
    for _, voice in ipairs(self.generatorMotorLayers or {}) do self:_Dispose(voice) end
    self.generatorMotorLayers = {}
end

function Audio:_UpdateMotor(now)
    local part = self.generatorPart
    local running = self:_GeneratorState(part) == "RUNNING"
    local hasMotorVoice = self.generatorMotor ~= nil or #(self.generatorMotorLayers or {}) > 0
    local sourceMismatch = self.generatorMotor ~= nil and self.generatorMotor.source ~= part
    for _, voice in ipairs(self.generatorMotorLayers or {}) do
        if voice and voice.source ~= part then sourceMismatch = true end
    end
    if hasMotorVoice and (not running or sourceMismatch) then self:_StopGeneratorMotor() end
    if not running then self.motorRetryAt = 0; return end
    local primaryAlive = self.generatorMotor and not self.generatorMotor.dead and self.generatorMotor.sound ~= nil
    local layerAlive = false
    for _, voice in ipairs(self.generatorMotorLayers or {}) do
        if voice and not voice.dead and voice.sound then layerAlive = true; break end
    end
    if not primaryAlive and not layerAlive then
        self:_StopGeneratorMotor()
        if now < (self.motorRetryAt or 0) then return end
        self.motorRetryAt = now + 8
        self.generatorMotor = self:_Voice({asset="mechanism",volume=1.2,speed=.72,range=50,category="ambient"},
            {looped=true,source=part,kind="generator_motor",volume=0,eq={7,-4,-15}})
        self.generatorMotorLayers = {}
        -- Keep a low mechanical bed under the imported loop; at a higher level it
        -- also becomes the fallback when the creator has not uploaded the WAV yet.
        local importedMotor = type(CUSTOM_AUDIO_IDS.generator_motor)=="number" and CUSTOM_AUDIO_IDS.generator_motor>0
        local rumbleVolume, pulseVolume = importedMotor and .62 or 1.7, importedMotor and .18 or .52
        table.insert(self.generatorMotorLayers,self:_Voice({asset="wind",volume=rumbleVolume,speed=.56,range=50,category="ambient"},
            {looped=true,source=part,kind="generator_motor",volume=0,eq={7,-7,-18}}))
        table.insert(self.generatorMotorLayers,self:_Voice({asset="thump",volume=pulseVolume,speed=.48,range=42,category="ambient"},
            {looped=true,source=part,kind="generator_motor",volume=0,eq={8,-8,-18}}))
    end
    local motorVoices = {}
    if self.generatorMotor then table.insert(motorVoices,self.generatorMotor) end
    for _, voice in ipairs(self.generatorMotorLayers or {}) do table.insert(motorVoices,voice) end
    local primary = self.sources[part]
    for index, motor in ipairs(motorVoices) do
        if motor and motor.sound and motor.started and not motor.dead then
            local t = now - motor.started
            local target = motor.baseVolume*(motor.gain or 1)*(.83+.17*math.sin(t*(index==1 and 8.2 or 5.4)+index)^2)*math.clamp(t/.75,0,1)
            if primary and primary.occluded then target *= .58 end
            motor.sound.PlaybackSpeed = (motor.definition.speed or .7) + .025*math.sin(t*(4.1+index*.7))
            motor.sound.Volume = math.clamp(target,0,10)
        end
    end
end

function Audio:_StopAtmosphere()
    self:_StopCue("pipe_echo")
    local stale = {}
    for voice in pairs(self.voices) do
        if voice.definition.category == "ambient" and not voice.looped then table.insert(stale,voice) end
    end
    for _, voice in ipairs(stale) do self:_Dispose(voice) end
end

function Audio:_UpdateAtmosphere(now, humanoid)
    local blocked = self.phase ~= "SHIFT" or not self.world or not humanoid or humanoid.Health <= 0
        or self.conditionDowned or self.player:GetAttribute("NightShiftDowned")
        or self.cues.death ~= nil
        or self.player:GetAttribute("NightShiftClientMenu") or self.player:GetAttribute("NightShiftCCTV")
        or (self.senseState ~= "IDLE" and now < self.senseUntil)
        or self.preferences.masterVolume == 0 or self.preferences.ambientVolume == 0
    if blocked then
        if not self.atmosphereBlocked then self:_StopAtmosphere() end
        self.atmosphereBlocked = true
        if now >= self.nextAtmosphereAt then self.nextAtmosphereAt = now + 8 end
        return
    end
    self.atmosphereBlocked = false
    if now < self.nextAtmosphereAt then return end
    local camera, candidates = self.workspace.CurrentCamera, {}
    if camera then
        for part, entry in pairs(self.sources) do
            if part.Parent and part:IsDescendantOf(self.world) then
                local delta = part.Position - camera.CFrame.Position
                if delta.Magnitude >= 4 and delta.Magnitude <= 26 and math.abs(delta.Y) <= 7.5 then
                    table.insert(candidates, {part=part,config=entry.config,distance=delta.Magnitude})
                end
            end
        end
    end
    if #candidates == 0 then self.nextAtmosphereAt = now + 10; return end
    table.sort(candidates, function(a,b) return a.distance < b.distance end)
    local candidate = candidates[math.random(1,math.min(3,#candidates))]
    self.atmosphereIndex += 1
    local sourceKind, kind = candidate.config.kind, self.atmosphereIndex%2 == 0 and "metal_creak" or "distant_rattle"
    if sourceKind == "pump" or sourceKind == "boiler" or sourceKind == "drip" then
        kind = self.atmosphereIndex%2 == 0 and "water_drip" or "pipe_knock"
    elseif sourceKind == "server" or sourceKind == "dispatch" or sourceKind == "staff" then
        kind = self.atmosphereIndex%2 == 0 and "radio_whisper" or "distant_rattle"
    end
    self:Play({kind=kind,position=candidate.part.Position,volume=.8})
    self.nextAtmosphereAt = now + (self.monsterActive and 34 or 22) + math.random()*14
end

function Audio:_RouteCharacterSounds()
    local seen = {}
    local players = self.players.GetPlayers and self.players:GetPlayers() or {self.player}
    for _, player in ipairs(players) do
        local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
        if root then
            for _, sound in ipairs(root:GetChildren()) do
                if sound:IsA("Sound") and CHARACTER_SOUNDS[sound.Name] then
                    seen[sound] = true
                    if not self.characterSounds[sound] then self.characterSounds[sound] = {group = sound.SoundGroup} end
                    sound.SoundGroup = self.effectsGroup
                end
            end
        end
    end
    for sound, original in pairs(self.characterSounds) do
        if not seen[sound] then
            if sound.Parent then sound.SoundGroup = original.group end
            self.characterSounds[sound] = nil
        end
    end
end

function Audio:_SyncFootsteps(character)
    local root = character and character:FindFirstChild("HumanoidRootPart")
    local running = root and root:FindFirstChild("Running")
    if running and not running:IsA("Sound") then running = nil end
    if running ~= self.runningSound then
        if self.runningSound and self.runningSound.Parent then self.runningSound.Volume = self.runningVolume end
        self.runningSound, self.runningVolume = running, running and running.Volume or nil
    end
    local available = self.assets.thump.state == "ready" or self.assets.mechanism.state == "ready"
    if running then
        -- The normal character sound otherwise doubles every custom footfall and
        -- bypasses the effects-volume preference. Preserve it for respawn/cleanup.
        if available or self.preferences.masterVolume == 0 or self.preferences.effectsVolume == 0 then running.Volume = 0
        else running.Volume = self.runningVolume end
    end
    return available
end

function Audio:_Update(dt)
    if self.dead then return end
    self.elapsed += dt
    self.discoveryElapsed += dt
    self.footClock += dt
    if self.discoveryElapsed >= 2 then
        self.discoveryElapsed = 0
        self:_DiscoverWorld()
    end
    local now = self.clock()
    if now >= self.retryAt then
        self.retryAt = now + 20
        for key, asset in pairs(self.assets) do
            if asset.state == "failed" and asset.attempts < 3 then self:_Warm(key) end
        end
        self:_StartBed()
    end
    -- Local footsteps remain at the player and are not lost to a remote CCTV camera.
    local character = self.player and self.player.Character
    if character == self.removingCharacter then character = nil elseif character then self.removingCharacter = nil end
    if character ~= self.lastCharacter then
        self.lastCharacter = character
        self:_ResetPersonalScene(character ~= nil)
    end
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if now > self.senseUntil and self.senseState ~= "IDLE" then self.senseState = "IDLE"; self:_StopCue("chase") end
    self:_UpdateCues(now)
    self:_UpdateMotor(now)
    self:_UpdateAtmosphere(now, humanoid)
    self:_RouteCharacterSounds()
    local customFootsteps = self:_SyncFootsteps(character)
    if customFootsteps and humanoid and humanoid.Health > 0 and humanoid.MoveDirection.Magnitude > .15 and humanoid.FloorMaterial ~= Enum.Material.Air
        and not self.player:GetAttribute("NightShiftHidden") and not self.player:GetAttribute("NightShiftDowned") then
        local sprinting = self.player:GetAttribute("NightShiftSprinting") == true
        if self.footClock >= (sprinting and .31 or .48) then
            self.footClock = 0
            local material = humanoid.FloorMaterial
            local kind = "footstep"
            if material == Enum.Material.Metal or material == Enum.Material.DiamondPlate or material == Enum.Material.CorrodedMetal then kind = "footstep_metal"
            elseif material == Enum.Material.Wood or material == Enum.Material.WoodPlanks then kind = "footstep_wood"
            elseif material == Enum.Material.Water then kind = "footstep_water" end
            self:Play({kind = kind, volume = sprinting and 1.35 or 1})
        end
    else self.footClock = 0 end
    if self.elapsed < .3 then return end
    self.elapsed = 0
    local camera = self.workspace.CurrentCamera
    local powered = not self.world or self.world:GetAttribute("PowerState") ~= "OFF"
    if self.bed and self.bed.sound and not self.bed.dead then
        local target = powered and 4.8 or 2.8
        local underground=camera and camera.CFrame.Position.Y<-3
        if underground then target*=self.basementBed and .38 or .82 end
        -- Adaptive silence while being hunted makes actual positional threat sounds intelligible.
        if self.senseState=="CHASE" then target*=.58
        elseif self.senseState=="SUSPICIOUS" or self.senseState=="SEARCH" then target*=.82 end
        target *= self.bed.gain or 1
        self.bed.sound.Volume += (target - self.bed.sound.Volume) * .35
    end
    if self.basementBed and self.basementBed.sound and not self.basementBed.dead then
        local target=camera and camera.CFrame.Position.Y<-3 and self.basementBed.baseVolume or 0
        if not powered then target*=.72 end
        if self.senseState=="CHASE" then target*=.55 end
        target*=self.basementBed.gain or 1
        self.basementBed.sound.Volume+=(target-self.basementBed.sound.Volume)*.32
    end
    for part, entry in pairs(self.sources) do
        if not part.Parent or not self.world or not part:IsDescendantOf(self.world) then
            self:_Dispose(entry.voice); self.sources[part] = nil; self.sourceCount -= 1
        else
            local voice = entry.voice
            if not voice or voice.dead then
                if now >= entry.retryAt then
                    self.sources[part] = nil; self.sourceCount -= 1
                    self:_AttachSource(part)
                end
            elseif voice.sound then
                local target = entry.config.volume
                local requiresPower = entry.config.powered
                local attribute = part:GetAttribute("Powered")
                if type(attribute) == "boolean" then requiresPower = attribute end
                if requiresPower and not powered then target = 0 end
                if entry.config.kind == "generator" then
                    if self:_GeneratorState(part) ~= "RUNNING" then
                        target = 0
                        voice.sound.Volume = 0
                        if voice.sound.IsPlaying then voice.sound:Stop(); voice.paused = true end
                    elseif voice.paused and voice.started and voice.sound.IsLoaded then
                        voice.sound:Play(); voice.paused = nil
                    end
                    voice.sound.PlaybackSpeed = entry.config.speed + .018*math.sin(now*3.1)
                end
                entry.occluded = false
                if camera and target > 0 then
                    local delta = part.Position - camera.CFrame.Position
                    if delta.Magnitude < entry.config.range then
                        local params = RaycastParams.new()
                        local excluded = {self.emitters, part}
                        if character then table.insert(excluded, character) end
                        params.FilterType, params.FilterDescendantsInstances, params.RespectCanCollide = Enum.RaycastFilterType.Exclude, excluded, true
                        if self.workspace:Raycast(camera.CFrame.Position, delta, params) then target *= .6; entry.occluded = true end
                    end
                end
                target *= voice.gain or 1
                voice.sound.Volume += (target - voice.sound.Volume) * .55
            end
        end
    end
end

function Audio:Destroy()
    if self.dead then return end
    self.dead = true
    self.testToken += 1
    for key in pairs(self.cues) do self:_StopCue(key) end
    self:_StopGeneratorMotor()
    self.generatorPart, self.generatorOverride = nil, nil
    for _, connection in ipairs(self.connections) do connection:Disconnect() end
    for _, asset in pairs(self.assets) do if asset.cancel then asset.cancel() end end
    local voices = {}
    for voice in pairs(self.voices) do table.insert(voices, voice) end
    for _, voice in ipairs(voices) do self:_Dispose(voice) end
    if self.runningSound and self.runningSound.Parent then self.runningSound.Volume = self.runningVolume end
    for sound, original in pairs(self.characterSounds) do if sound.Parent then sound.SoundGroup = original.group end end
    table.clear(self.characterSounds)
    self.emitters:Destroy(); self.preloadFolder:Destroy()
    self.ambientGroup:Destroy(); self.effectsGroup:Destroy(); self.threatGroup:Destroy(); self.uiGroup:Destroy()
    self:_StatusChanged()
end

Audio.AssetCatalog = ASSETS
Audio.SoundCatalog = SOUNDS
Audio.DefaultPreferences = table.clone(DEFAULTS)
return Audio
