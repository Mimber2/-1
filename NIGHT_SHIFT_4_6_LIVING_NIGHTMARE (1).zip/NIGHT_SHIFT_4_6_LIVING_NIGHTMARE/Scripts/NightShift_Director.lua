-- NIGHT SHIFT 4.0: warnings, bounded hunt budgets and recovery time.
local Director = {}
Director.__index = Director

function Director.new(ctx)
    return setmetatable({ctx = ctx}, Director)
end

function Director:BeginShift(night)
    local now = self.ctx.clock()
    self.night, self.started = math.max(1, night), now
    self.hunts, self.blackouts = 0, 0
    self.huntBudget = math.min(5, 2 + math.floor(math.max(0, night - 1) / 2))
    self.nextHunt = now + self.ctx.random:NextNumber(night == 1 and 62 or 45, night == 1 and 82 or 64)
    self.nextAtmosphere = now + self.ctx.random:NextNumber(26, 40)
    self.quietUntil = now + 35
    self.wasActive, self.warningAt = false, nil
    self.blackoutAt = nil
    self.active = true
end

function Director:EndShift()
    self.active, self.blackoutAt, self.warningAt = false, nil, nil
end

function Director:RequestThreat()
    local round = self.ctx.getRound()
    if not self.active or round.phase ~= "SHIFT" or round.monsterActive or self.hunts >= self.huntBudget then return end
    self.nextHunt = math.min(self.nextHunt, math.max(self.ctx.clock() + 6, self.quietUntil))
end

function Director:_pressure()
    local round = self.ctx.getRound()
    local complete, total = 0, 0
    for id in pairs(round.activeTasks) do total += 1; if round.tasks[id] then complete += 1 end end
    local separation = self.ctx.teamSeparated and self.ctx.teamSeparated() and .08 or 0
    return math.clamp((total > 0 and complete / total or 0) * .14 + math.min(self.night - 1, 7) * .028 + separation, 0, .38)
end

function Director:_struggling()
    return self.ctx.teamStruggling and self.ctx.teamStruggling() == true
end

function Director:_warn(now)
    if self.warningAt then return end
    self.warningAt = now
    self.nextHunt = math.max(self.nextHunt, now + 6)
    if type(self.ctx.warning) == "function" then
        self.ctx.warning("В коридорах слышны тяжёлые шаги. Проверьте ближайшее укрытие.")
    end
end

function Director:GetState()
    local now = self.ctx.clock()
    local round = self.ctx.getRound()
    local phase = "QUIET"
    if not self.active then phase = "IDLE"
    elseif round.monsterActive then phase = "HUNT"
    elseif self.warningAt then phase = "WARNING"
    elseif now < self.quietUntil then phase = "RECOVERY" end
    return {phase = phase, hunts = self.hunts or 0, budget = self.huntBudget or 0}
end

function Director:Tick()
    local round = self.ctx.getRound()
    if not self.active or round.phase ~= "SHIFT" then return end
    local now = self.ctx.clock()
    if self.wasActive and not round.monsterActive then
        self.quietUntil = now + self.ctx.random:NextNumber(30, 43)
        self.nextHunt = math.max(self.quietUntil + 8, now + self.ctx.random:NextNumber(59, 82) * (1 - self:_pressure()))
        self.blackoutAt, self.warningAt = nil, nil
    end
    self.wasActive = round.monsterActive
    local struggling = self:_struggling()
    if round.monsterActive and self.blackoutAt and now >= self.blackoutAt then
        if not struggling and round.eventName == "" and round.timeLeft > 48 then
            self.ctx.blackout(48 + math.min(16, self.night * 3))
            self.blackouts += 1
        end
        self.blackoutAt = nil
    end
    if not round.monsterActive and struggling then
        self.quietUntil = math.max(self.quietUntil, now + 12)
        self.nextHunt = math.max(self.nextHunt, now + 18)
        self.warningAt = nil
        return
    end
    if not round.monsterActive and self.hunts < self.huntBudget and now >= self.nextHunt - 6
        and now >= self.quietUntil and round.timeLeft > 36 then
        if self.ctx.trainingPending and self.ctx.trainingPending() and now - self.started < 110 then
            self.nextHunt, self.warningAt = now + 8, nil
            return
        end
        self:_warn(now)
        if now >= self.nextHunt then
            local spawned = self.ctx.spawn()
            self.warningAt = nil
            if spawned then
                self.hunts += 1
                self.wasActive = true
                if self.blackouts == 0 and (self.night >= 2 or self.hunts >= 2) and not struggling then
                    self.blackoutAt = now + self.ctx.random:NextNumber(10, 18)
                else self.nextAtmosphere = now + 8 end
                self.nextHunt = now + 85
            else
                -- No safe spawn means postponement, never a fallback on a player.
                self.nextHunt = now + self.ctx.random:NextNumber(13, 20)
            end
        end
    elseif round.timeLeft <= 36 then self.warningAt = nil end
    if now >= self.nextAtmosphere and now >= self.quietUntil and not self.warningAt
        and round.eventName == "" and round.timeLeft > 24 then
        if self.ctx.random:NextInteger(1, 3) == 1 and self.hunts > 0 then self.ctx.alarm(8)
        else self.ctx.flicker(self.ctx.random:NextInteger(5, 9)) end
        self.nextAtmosphere = now + self.ctx.random:NextNumber(58, 85)
    end
end

return Director
