-- NIGHT SHIFT 4.5 | Read-only Play-mode audit, Server Command Bar.
-- Does not trigger events, change saved data, or alter map geometry.
local RunService=game:GetService("RunService")
assert(RunService:IsStudio() and RunService:IsRunning() and RunService:IsServer(),
    "Start Play, then select SERVER in Studio Command Bar")
local world=workspace:FindFirstChild("NightShiftWorld")
assert(world,"NightShiftWorld missing: check Server Output for map build error")
local folder=world:FindFirstChild("NS43EmergencyStations",true)
assert(folder,"NS43EmergencyStations missing: check Incidents module installation")
local ids={surge=true,flood=true,desync=true,radio=true,archive=true}
local expected=0
for id in pairs(ids)do
    expected+=1
    local model=folder:FindFirstChild("NS43_"..id)
    assert(model and model:IsA("Model"),"Missing incident panel: "..id)
    local count=0
    for _,obj in ipairs(model:GetDescendants())do
        if obj:IsA("BasePart") then
            assert(not obj.CanCollide,"Incident panel blocks passage: "..obj:GetFullName())
            assert(obj.Anchored,"Moving incident panel: "..obj:GetFullName())
        elseif obj:IsA("ProximityPrompt") then
            count+=1
            assert(obj:GetAttribute("NS43IncidentControl")==true,"Panel prompt lacks tag: "..obj:GetFullName())
        end
    end
    assert(count==3,"Expected 3 prompts for "..id..", found "..count)
    print("[INCIDENT AUDIT] OK "..id.." | 3 physical controls")
end
local water=folder:FindFirstChild("PumpRoomWater")
assert(water and water:IsA("BasePart") and not water.CanCollide and not water.CanTouch,
    "Non-colliding water visual missing")
local attribute=world:GetAttribute("NS43Incident")
assert(type(attribute)=="string","World incident attribute missing")
print("[INCIDENT AUDIT] PASS "..expected.." incident panels / 15 controls / no collision | active="..attribute)
print("[INCIDENT AUDIT] Next: Play with two clients, fix an incident, leave a station, and verify expiry and night reset.")
