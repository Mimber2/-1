-- NIGHT SHIFT 4.1: ally rescue, a solo second chance, and safe round/character cleanup.
local Recovery = {}
Recovery.__index = Recovery

function Recovery.new(ctx)
    return setmetatable({ctx = ctx, downed = {}, usedSecondChance = {}, lastCatch = {}, rescueRewards = {}}, Recovery)
end

function Recovery:_send(player, state)
    if player.Parent == self.ctx.Players then self.ctx.remote:FireClient(player, "PlayerCondition", state) end
end

function Recovery:_helpersAvailable(except)
    for _, player in ipairs(self.ctx.Players:GetPlayers()) do
        if player ~= except and not self.downed[player] then
            local human = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
            local profile = self.ctx.getProfile(player)
            if human and human.Health > 0 and profile and profile.ready then return true end
        end
    end
    return false
end

function Recovery:CanAct(player)
    return not self.downed[player] and player:GetAttribute("NightShiftDowned") ~= true
end

function Recovery:_restore(player, evacuate)
    local state = self.downed[player]
    self.downed[player] = nil
    player:SetAttribute("NightShiftDowned", false)
    if state then
        if state.prompt and state.prompt.Parent then state.prompt:Destroy() end
        if state.character == player.Character and state.human.Parent then
            state.human.JumpPower = state.jumpPower
            state.human.JumpHeight = state.jumpHeight
            state.human.AutoRotate = state.autoRotate
            if state.hipHeight then state.human.HipHeight = state.hipHeight end
            if evacuate and state.root.Parent then
                state.character:PivotTo(CFrame.new(0, 4.2, 25))
                state.root.AssemblyLinearVelocity = Vector3.zero
                state.root.AssemblyAngularVelocity = Vector3.zero
            end
        end
    end
    self.ctx.applyWalkSpeed(player)
    self:_send(player, {downed = false, evacuated = evacuate == true})
end

function Recovery:Catch(player)
    local now = self.ctx.clock()
    local round = self.ctx.getRound()
    local profile = self.ctx.getProfile(player)
    if round.phase ~= "SHIFT" or not profile or self.downed[player] or now - (self.lastCatch[player] or -100) < 14 then return false end
    local character = player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    local human = character and character:FindFirstChildOfClass("Humanoid")
    if not root or not human or human.Health <= 0 then return false end
    self.ctx.forceExit(player)
    self.ctx.dropCarry(player)
    self.lastCatch[player] = now
    round.playerCaught[player] = true
    profile.deaths += 1
    player:SetAttribute("NightShiftSprinting", false)
    player:SetAttribute("NightShiftDowned", true)
    self.ctx.setFlashlight(player, false)
    local state = {character = character, root = root, human = human, started = now, untilAt = now + 35,
        jumpPower = human.JumpPower, jumpHeight = human.JumpHeight, autoRotate = human.AutoRotate, hipHeight = human.HipHeight}
    self.downed[player] = state
    human.WalkSpeed, human.JumpPower, human.JumpHeight, human.AutoRotate = 0, 0, 0, false
    human.HipHeight = math.max(0, (state.hipHeight or 2) - 0.75)
    state.prompt = self.ctx.addPrompt(root, "Помочь подняться", player.DisplayName or player.Name, 3, function(rescuer)
        if rescuer == player or not self:CanAct(rescuer) or self.downed[player] ~= state then return end
        local rescuerRoot = rescuer.Character and rescuer.Character:FindFirstChild("HumanoidRootPart")
        if not rescuerRoot or (rescuerRoot.Position - root.Position).Magnitude > 7 then return end
        local params = RaycastParams.new()
        params.FilterType = Enum.RaycastFilterType.Exclude
        params.FilterDescendantsInstances = {character, rescuer.Character}
        params.RespectCanCollide = true
        if self.ctx.Workspace:Raycast(rescuerRoot.Position, root.Position - rescuerRoot.Position, params) then return end
        self.lastCatch[player] = self.ctx.clock()
        self:_restore(player, false)
        local rewardKey = tostring(rescuer.UserId) .. ":" .. tostring(player.UserId)
        if not self.rescueRewards[rewardKey] then
            self.rescueRewards[rewardKey] = true
            self.ctx.contribute(rescuer, "revive", 1)
            self.ctx.award(rescuer, 15, 8)
        end
        self.ctx.sound("revive", root.Position, "Сотруднику помогли подняться")
        self.ctx.notify(player, (rescuer.DisplayName or rescuer.Name) .. " помог тебе. Несколько секунд ты защищён.")
    end, {lineOfSight = false, distance = 6})
    state.prompt.RequiresLineOfSight = true
    self.ctx.remote:FireClient(player, "Jumpscare")
    self.ctx.sound("player_downed", root.Position, "Вас настигли. Дыхание сбивается", player)
    self.ctx.notify(player, "Ты ранен. Напарник может помочь удержанием E. При одиночной игре доступен второй шанс.")
    self:Tick()
    return true
end

function Recovery:SecondChance(player)
    if self.ctx.getRound().phase ~= "SHIFT" then return false end
    local state = self.downed[player]
    if not state or self.usedSecondChance[player] or self:_helpersAvailable(player) or self.ctx.clock() - state.started < 8 then return false end
    self.usedSecondChance[player] = true
    self.lastCatch[player] = self.ctx.clock()
    local position = state.root.Position
    self:_restore(player, false)
    self.ctx.sound("revive", position, "Второй шанс использован")
    self.ctx.notify(player, "Ты поднялся. Второй шанс доступен один раз за смену.")
    return true
end

function Recovery:Tick()
    local now = self.ctx.clock()
    for player, state in pairs(self.downed) do
        if player.Parent ~= self.ctx.Players or state.character ~= player.Character or not state.root.Parent or state.human.Health <= 0 then
            self:OnCharacterRemoving(player)
        elseif self.ctx.getRound().phase ~= "SHIFT" then
            self:_restore(player, false)
        elseif now >= state.untilAt then
            local position = state.root.Position
            self:_restore(player, true)
            self.ctx.sound("player_death", position, "Сознание угасает. Эвакуация ко входу", player)
            self.lastCatch[player] = now
            self.ctx.award(player, -25, 0)
            self.ctx.notify(player, "Тебя эвакуировали ко входу. Штраф 25; выполненные задачи сохранены.")
        else
            self:_send(player, {downed = true, reviveRemaining = math.ceil(state.untilAt - now),
                secondChanceAvailable = not self.usedSecondChance[player] and not self:_helpersAvailable(player),
                recoveryReady = now - state.started >= 8, soloSecondChance = not self:_helpersAvailable(player)})
        end
    end
end

function Recovery:OnCharacterRemoving(player)
    self:_restore(player, false)
end

function Recovery:BeginShift()
    self:EndShift()
    self.usedSecondChance, self.lastCatch, self.rescueRewards = {}, {}, {}
end

function Recovery:EndShift()
    local players = {}
    for player in pairs(self.downed) do table.insert(players, player) end
    for _, player in ipairs(players) do self:_restore(player, false) end
end

function Recovery:OnPlayerRemoving(player)
    self:_restore(player, false)
    self.usedSecondChance[player], self.lastCatch[player] = nil, nil
end

return Recovery
