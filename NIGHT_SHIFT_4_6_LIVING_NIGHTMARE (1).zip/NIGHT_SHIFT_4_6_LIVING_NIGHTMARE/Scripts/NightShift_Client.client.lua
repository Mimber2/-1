-- NIGHT SHIFT 4.6 - responsive co-op HUD and controls
-- Keep this LocalScript in StarterPlayer > StarterPlayerScripts.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local MarketplaceService = game:GetService("MarketplaceService")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local GuiService = game:GetService("GuiService")
local player = Players.LocalPlayer
local remote = ReplicatedStorage:WaitForChild("NightShiftRemote")

local TEXT = {
    title = "NIGHT SHIFT 4.6", subtitle = "НОЧНОЙ МАГАЗИН  •  КООП ДО 6 ИГРОКОВ", cash = "НАЛИЧНЫЕ", nights = "СМЕНЫ",
    level = "УРОВЕНЬ", phasePrep = "ПОДГОТОВКА", phaseShift = "НОЧНАЯ СМЕНА",
    phaseResults = "СМЕНА ЗАВЕРШЕНА", objectives = "ЗАДАНИЯ СМЕНЫ", danger = "ОХОТА НАЧАЛАСЬ",
    safe = "Пока что тихо...", speed = "СКОРОСТЬ", stamina = "ВЫНОСЛИВОСТЬ", battery = "БАТАРЕЯ",
    upgrade = "УЛУЧШИТЬ", shop = "МАГАЗИН", close = "ЗАКРЫТЬ", daily = "ЕЖЕДН. БОНУС",
    claim = "ЗАБРАТЬ", vip = "VIP: +15% к наградам", product = "Набор наличных", controls = "WASD — движение  |  SHIFT — бег  |  F — фонарь  |  E — действие",
    flashlight = "ФОНАРЬ", sprint = "БЕГ", xp = "XP", round = "НОЧЬ",
    gotCaught = "ТЕБЯ НАШЛИ", welcome = "Смена началась. Работайте командой, следите за светом и не оставайтесь одни.",
    monsterAwake = "ОН ПРОСНУЛСЯ", hunting = "Охотится за вами",
}

local COLORS = {
    panel = Color3.fromRGB(13, 19, 25), panel2 = Color3.fromRGB(25, 34, 42),
    border = Color3.fromRGB(92, 112, 121), text = Color3.fromRGB(236, 239, 234),
    muted = Color3.fromRGB(139, 153, 161), orange = Color3.fromRGB(224, 171, 91),
    green = Color3.fromRGB(148, 193, 160), red = Color3.fromRGB(211, 83, 75), blue = Color3.fromRGB(137, 174, 193),
}

local gui = Instance.new("ScreenGui")
gui.Name = "NightShiftHUD"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = false
gui.ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.DisplayOrder = 30
local playerGui = player:WaitForChild("PlayerGui")
local previousGui = playerGui:FindFirstChild("NightShiftHUD")
if previousGui then previousGui:Destroy() end
gui.Parent = playerGui

-- One compact interaction card replaces Roblox's stacked default prompt cards.
-- The client chooses only the nearest visible prompt, so basement stations cannot
-- create a long row of repeated "Осмотр" buttons.
local ProximityPromptService = game:GetService("ProximityPromptService")
local promptGui = Instance.new("ScreenGui")
promptGui.Name = "NightShiftSinglePrompt"
promptGui.ResetOnSpawn = false
promptGui.IgnoreGuiInset = true
promptGui.DisplayOrder = 80
promptGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
local oldPromptGui = playerGui:FindFirstChild(promptGui.Name)
if oldPromptGui then oldPromptGui:Destroy() end
promptGui.Parent = playerGui

local promptCard = Instance.new("Frame")
promptCard.Name = "InteractionCard"
promptCard.AnchorPoint = Vector2.new(.5, 1)
promptCard.Position = UDim2.new(.5, 0, 1, -104)
promptCard.Size = UDim2.fromOffset(326, 62)
promptCard.BackgroundColor3 = Color3.fromRGB(12, 18, 23)
promptCard.BackgroundTransparency = .08
promptCard.BorderSizePixel = 0
promptCard.Visible = false
promptCard.Parent = promptGui
local promptCorner = Instance.new("UICorner")
promptCorner.CornerRadius = UDim.new(0, 9)
promptCorner.Parent = promptCard
local promptStroke = Instance.new("UIStroke")
promptStroke.Color = Color3.fromRGB(104, 124, 132)
promptStroke.Transparency = .32
promptStroke.Thickness = 1
promptStroke.Parent = promptCard

local promptTap = Instance.new("TextButton")
promptTap.Name = "TapArea"
promptTap.BackgroundTransparency = 1
promptTap.Text = ""
promptTap.AutoButtonColor = false
promptTap.Size = UDim2.fromScale(1, 1)
promptTap.ZIndex = 5
promptTap.Parent = promptCard

local promptKey = Instance.new("TextLabel")
promptKey.Name = "Key"
promptKey.Position = UDim2.fromOffset(10, 10)
promptKey.Size = UDim2.fromOffset(42, 42)
promptKey.BackgroundColor3 = Color3.fromRGB(37, 49, 57)
promptKey.BorderSizePixel = 0
promptKey.Font = Enum.Font.GothamBold
promptKey.Text = "E"
promptKey.TextSize = 17
promptKey.TextColor3 = Color3.fromRGB(245, 239, 226)
promptKey.ZIndex = 7
promptKey.Parent = promptCard
local keyCorner = Instance.new("UICorner")
keyCorner.CornerRadius = UDim.new(0, 7)
keyCorner.Parent = promptKey

local promptAction = Instance.new("TextLabel")
promptAction.Name = "Action"
promptAction.BackgroundTransparency = 1
promptAction.Position = UDim2.fromOffset(64, 8)
promptAction.Size = UDim2.new(1, -76, 0, 23)
promptAction.Font = Enum.Font.GothamBold
promptAction.Text = "Взаимодействовать"
promptAction.TextSize = 15
promptAction.TextColor3 = Color3.fromRGB(239, 235, 225)
promptAction.TextXAlignment = Enum.TextXAlignment.Left
promptAction.TextTruncate = Enum.TextTruncate.AtEnd
promptAction.ZIndex = 7
promptAction.Parent = promptCard

local promptObject = Instance.new("TextLabel")
promptObject.Name = "Object"
promptObject.BackgroundTransparency = 1
promptObject.Position = UDim2.fromOffset(64, 31)
promptObject.Size = UDim2.new(1, -76, 0, 17)
promptObject.Font = Enum.Font.Gotham
promptObject.Text = ""
promptObject.TextSize = 11
promptObject.TextColor3 = Color3.fromRGB(151, 166, 171)
promptObject.TextXAlignment = Enum.TextXAlignment.Left
promptObject.TextTruncate = Enum.TextTruncate.AtEnd
promptObject.ZIndex = 7
promptObject.Parent = promptCard

local promptTrack = Instance.new("Frame")
promptTrack.Name = "HoldTrack"
promptTrack.Position = UDim2.new(0, 10, 1, -4)
promptTrack.Size = UDim2.new(1, -20, 0, 2)
promptTrack.BackgroundColor3 = Color3.fromRGB(55, 67, 73)
promptTrack.BorderSizePixel = 0
promptTrack.ZIndex = 8
promptTrack.Parent = promptCard
local promptFill = Instance.new("Frame")
promptFill.Name = "HoldProgress"
promptFill.Size = UDim2.new(0, 0, 1, 0)
promptFill.BackgroundColor3 = Color3.fromRGB(224, 171, 91)
promptFill.BorderSizePixel = 0
promptFill.ZIndex = 9
promptFill.Parent = promptTrack

local shownPrompts = {}
local currentPrompt = nil
local holdTween = nil
local tapHeld = false

local function promptPosition(prompt)
    local parent = prompt and prompt.Parent
    if not parent then return nil end
    if parent:IsA("Attachment") then return parent.WorldPosition end
    if parent:IsA("BasePart") then return parent.Position end
    if parent:IsA("Model") then return parent:GetPivot().Position end
    return nil
end

local function cleanPromptText(value)
    local result = tostring(value or ""):gsub("[%c]", " "):gsub("%s+", " ")
    result = result:gsub("^%s+", ""):gsub("%s+$", "")
    -- Lua patterns are byte-oriented: match Russian words as literal UTF-8 strings.
    local lower = result:lower()
    for _, word in ipairs({"осмотр", "осмотреть", "осмотри", "осмотра"}) do
        while true do
            local first, last = lower:find(word .. "%s+" .. word)
            if not first then break end
            local firstWord = result:sub(first, first + #word - 1)
            result = result:sub(1, first - 1) .. firstWord .. result:sub(last + 1)
            lower = result:lower()
        end
    end
    return result
end

local function stripInspectionSuffix(value)
    local lower = value:lower()
    for _, suffix in ipairs({" · осмотр", " • осмотр", " - осмотр", " осмотр"}) do
        if lower:sub(-#suffix) == suffix then
            return value:sub(1, #value - #suffix)
        end
    end
    return value
end

local function resetPromptHold()
    if holdTween then holdTween:Cancel(); holdTween = nil end
    promptFill.Size = UDim2.new(0, 0, 1, 0)
end

local function setPrompt(prompt, inputType)
    currentPrompt = prompt
    resetPromptHold()
    if not prompt then
        promptCard.Visible = false
        return
    end
    local action = cleanPromptText(prompt.ActionText)
    local object = cleanPromptText(prompt.ObjectText)
    object = stripInspectionSuffix(object)
    if object:lower() == action:lower() then object = "" end
    promptAction.Text = action ~= "" and action or "Взаимодействовать"
    promptObject.Text = object
    promptObject.Visible = object ~= ""
    local keyName = prompt.KeyboardKeyCode.Name
    if inputType == Enum.ProximityPromptInputType.Gamepad then
        keyName = prompt.GamepadKeyCode.Name:gsub("Button", "")
    elseif inputType == Enum.ProximityPromptInputType.Touch then
        keyName = "НАЖАТЬ"
    end
    promptKey.Text = keyName
    promptCard.Visible = true
end

ProximityPromptService.PromptShown:Connect(function(prompt, inputType)
    if prompt and prompt.Parent then
        -- Style.Custom is also set on the server; this is a local safety net.
        prompt.Style = Enum.ProximityPromptStyle.Custom
        shownPrompts[prompt] = inputType
    end
end)
ProximityPromptService.PromptHidden:Connect(function(prompt)
    shownPrompts[prompt] = nil
    if currentPrompt == prompt then setPrompt(nil) end
end)
ProximityPromptService.PromptButtonHoldBegan:Connect(function(prompt)
    if prompt ~= currentPrompt then return end
    resetPromptHold()
    local duration = math.max(prompt.HoldDuration, .06)
    holdTween = TweenService:Create(promptFill, TweenInfo.new(duration, Enum.EasingStyle.Linear), {Size = UDim2.new(1, 0, 1, 0)})
    holdTween:Play()
end)
ProximityPromptService.PromptButtonHoldEnded:Connect(function(prompt)
    if prompt == currentPrompt then resetPromptHold() end
end)

promptTap.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
        if currentPrompt and currentPrompt.Parent then
            tapHeld = true
            currentPrompt:InputHoldBegin()
        end
    end
end)
UserInputService.InputEnded:Connect(function(input)
    if tapHeld and (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) then
        tapHeld = false
        if currentPrompt and currentPrompt.Parent then currentPrompt:InputHoldEnd() end
    end
end)

RunService.RenderStepped:Connect(function()
    if not ProximityPromptService.Enabled then
        if promptCard.Visible then setPrompt(nil) end
        return
    end
    local character = player.Character
    local rootPart = character and character:FindFirstChild("HumanoidRootPart")
    if not rootPart then
        if promptCard.Visible then setPrompt(nil) end
        return
    end
    local best, bestDistance, bestInput = nil, math.huge, nil
    for prompt, inputType in pairs(shownPrompts) do
        if not prompt.Parent or not prompt.Enabled then
            shownPrompts[prompt] = nil
        else
            local position = promptPosition(prompt)
            if position then
                local distance = (rootPart.Position - position).Magnitude
                if distance < bestDistance then
                    best, bestDistance, bestInput = prompt, distance, inputType
                end
            end
        end
    end
    if best ~= currentPrompt then
        setPrompt(best, bestInput)
    elseif best and promptCard.Visible then
        local action = cleanPromptText(best.ActionText)
        local object = cleanPromptText(best.ObjectText)
        object = stripInspectionSuffix(object)
        promptAction.Text = action ~= "" and action or "Взаимодействовать"
        promptObject.Text = object
        promptObject.Visible = object ~= ""
    end
end)


-- Scale a GuiObject inside the safe area. UIScale does not resize ScreenGui.
local safeArea = Instance.new("Frame")
safeArea.Name = "SafeArea"
safeArea.BackgroundTransparency = 1
safeArea.BorderSizePixel = 0
safeArea.Size = UDim2.fromScale(1, 1)
safeArea.Parent = gui
local content = Instance.new("Frame")
content.Name = "ResponsiveContent"
content.BackgroundTransparency = 1
content.BorderSizePixel = 0
content.Size = UDim2.fromScale(1, 1)
content.Parent = safeArea
local cctvActive = false
local tasksExpanded = false
local experience
local clientDestroyed = false
local audioController
local audioStatus = {state = "loading", text = "Подключаем звук…"}
local savedPreferences
local pendingSounds = {}
local latestAudioState, latestAudioCondition, latestThreatSense, latestInspection, latestIncident
local latestThreatAt = -math.huge
local lastTaskList = {}
local taskTotal, taskCompleted, focusedTask = 0, 0, nil
local currentThreat, currentEvent, normalPhaseText = false, "", TEXT.phasePrep
local threatCueText, threatCueUntil, threatCueState = "", 0, ""
local updateTasks

local function corner(parent, radius)
    local item = Instance.new("UICorner")
    item.CornerRadius = UDim.new(0, radius or 4)
    item.Parent = parent
end

local function outline(parent, color, transparency)
    local item = Instance.new("UIStroke")
    item.Color = color or COLORS.border
    item.Transparency = transparency or 0.76
    item.Thickness = 1
    item.Parent = parent
end

local function makeFrame(name, parent, size, position, color, transparency)
    local frame = Instance.new("Frame")
    frame.Name = name
    frame.Size = size
    frame.Position = position
    frame.BackgroundColor3 = color or COLORS.panel
    frame.BackgroundTransparency = transparency or 0.06
    frame.Parent = parent
    frame.BorderSizePixel = 0
    corner(frame, 8)
    outline(frame, COLORS.border, .58)
    if name == "TopPanel" or name == "TasksPanel" or name == "VitalsPanel" or name == "ShopPanel"
        or name == "EmployeeProfile" or name == "Toast" or name == "CCTVPanel" then
        local gradient = Instance.new("UIGradient")
        gradient.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(23, 33, 41)), ColorSequenceKeypoint.new(1, COLORS.panel)})
        gradient.Rotation = 90
        gradient.Parent = frame
    elseif name == "DangerBanner" then
        local gradient = Instance.new("UIGradient")
        gradient.Color = ColorSequence.new({ColorSequenceKeypoint.new(0, Color3.fromRGB(142, 47, 48)), ColorSequenceKeypoint.new(1, Color3.fromRGB(73, 24, 31))})
        gradient.Rotation = 90
        gradient.Parent = frame
    end
    return frame
end

local function makeLabel(name, parent, text, size, position, fontSize, color, font)
    local label = Instance.new("TextLabel")
    label.Name = name
    label.BackgroundTransparency = 1
    label.Size = size
    label.Position = position
    label.Text = text or ""
    label.TextColor3 = color or COLORS.text
    label.TextSize = fontSize or 14
    label.Font = font or Enum.Font.Gotham
    label.TextXAlignment = Enum.TextXAlignment.Left
    label.TextYAlignment = Enum.TextYAlignment.Center
    label.TextTruncate = Enum.TextTruncate.AtEnd
    label.Parent = parent
    return label
end

local function makeButton(name, parent, text, size, position, color)
    local button = Instance.new("TextButton")
    button.Name = name
    button.Size = size
    button.Position = position
    button.BackgroundColor3 = color or COLORS.panel2
    button.Text = text
    button.TextColor3 = COLORS.text
    button.TextSize = 13
    button.Font = Enum.Font.GothamMedium
    button.AutoButtonColor = true
    button.BorderSizePixel = 0
    button.Selectable = true
    button.BackgroundTransparency = 0.08
    button.Parent = parent
    corner(button, 7)
    outline(button, COLORS.border, .66)
    button.Activated:Connect(function() if not clientDestroyed and audioController then audioController:Play({kind="ui_click"}) end end)
    return button
end

local function makeBar(parent, name, title, y, color)
    makeLabel(name .. "Title", parent, title, UDim2.new(1, -20, 0, 16), UDim2.new(0, 12, 0, y), 10, COLORS.muted, Enum.Font.GothamBold)
    local back = Instance.new("Frame")
    back.Name = name .. "Back"
    back.Size = UDim2.new(1, -24, 0, 8)
    back.Position = UDim2.new(0, 12, 0, y + 18)
    back.BackgroundColor3 = Color3.fromRGB(39, 48, 61)
    back.Parent = parent
    corner(back, 6)
    local fill = Instance.new("Frame")
    fill.Name = name .. "Fill"
    fill.Size = UDim2.fromScale(1, 1)
    fill.BackgroundColor3 = color
    fill.Parent = back
    corner(fill, 6)
    return fill
end

-- Contextual generator-overheat guide. It opens only when the server confirms
-- the generator has overheated and the player uses its diagnostic prompt.
local generatorGuideGui = Instance.new("ScreenGui")
generatorGuideGui.Name = "NightShiftGeneratorGuide"
generatorGuideGui.ResetOnSpawn = false
generatorGuideGui.IgnoreGuiInset = true
generatorGuideGui.DisplayOrder = 110
generatorGuideGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
generatorGuideGui.Enabled = false
generatorGuideGui.Parent = playerGui

local guideBackdrop = Instance.new("Frame")
guideBackdrop.Name = "Backdrop"
guideBackdrop.Size = UDim2.fromScale(1, 1)
guideBackdrop.BackgroundColor3 = Color3.fromRGB(3, 7, 10)
guideBackdrop.BackgroundTransparency = 0.28
guideBackdrop.BorderSizePixel = 0
guideBackdrop.Parent = generatorGuideGui

local guideCard = Instance.new("Frame")
guideCard.Name = "GuideCard"
guideCard.AnchorPoint = Vector2.new(0.5, 0.5)
guideCard.Position = UDim2.fromScale(0.5, 0.5)
guideCard.Size = UDim2.new(0.9, 0, 0, 390)
guideCard.BackgroundColor3 = Color3.fromRGB(13, 20, 26)
guideCard.BorderSizePixel = 0
guideCard.Parent = guideBackdrop
corner(guideCard, 12)
outline(guideCard, Color3.fromRGB(184, 70, 56), 0.2)
local guideConstraint = Instance.new("UISizeConstraint")
guideConstraint.MinSize = Vector2.new(290, 350)
guideConstraint.MaxSize = Vector2.new(560, 390)
guideConstraint.Parent = guideCard

local guideAccent = Instance.new("Frame")
guideAccent.Name = "WarningAccent"
guideAccent.Size = UDim2.new(1, -28, 0, 3)
guideAccent.Position = UDim2.fromOffset(14, 14)
guideAccent.BackgroundColor3 = Color3.fromRGB(220, 73, 57)
guideAccent.BorderSizePixel = 0
guideAccent.Parent = guideCard
corner(guideAccent, 2)

local guideTitle = makeLabel("GuideTitle", guideCard, "ПЕРЕГРЕВ ГЕНЕРАТОРА",
    UDim2.new(1, -32, 0, 30), UDim2.fromOffset(16, 28), 19, Color3.fromRGB(255, 126, 99), Enum.Font.GothamBold)
guideTitle.TextXAlignment = Enum.TextXAlignment.Center

local guideSummary = makeLabel("GuideSummary", guideCard, "",
    UDim2.new(1, -36, 0, 48), UDim2.fromOffset(18, 68), 13, COLORS.text, Enum.Font.GothamMedium)
guideSummary.TextWrapped = true
guideSummary.TextTruncate = Enum.TextTruncate.None
guideSummary.TextYAlignment = Enum.TextYAlignment.Top

local guideSteps = makeLabel("GuideSteps", guideCard, "",
    UDim2.new(1, -36, 0, 170), UDim2.fromOffset(18, 124), 14, Color3.fromRGB(222, 228, 225), Enum.Font.Gotham)
guideSteps.TextWrapped = true
guideSteps.TextTruncate = Enum.TextTruncate.None
guideSteps.TextYAlignment = Enum.TextYAlignment.Top

local guideFootnote = makeLabel("GuideFootnote", guideCard,
    "После каждого действия подсказка укажет следующую деталь. Не запускай двигатель раньше времени.",
    UDim2.new(1, -36, 0, 28), UDim2.fromOffset(18, 300), 11, COLORS.muted, Enum.Font.Gotham)
guideFootnote.TextWrapped = true
guideFootnote.TextTruncate = Enum.TextTruncate.None
guideFootnote.TextYAlignment = Enum.TextYAlignment.Top

local guideStart = makeButton("GuideStart", guideCard, "НАЧАТЬ УСТРАНЕНИЕ",
    UDim2.new(0.59, -8, 0, 42), UDim2.new(0.04, 0, 1, -54), Color3.fromRGB(117, 48, 42))
guideStart.TextSize = 12
local guideClose = makeButton("GuideClose", guideCard, "ПОЗЖЕ",
    UDim2.new(0.29, -8, 0, 42), UDim2.new(0.67, 0, 1, -54), COLORS.panel2)
guideClose.TextSize = 12

local function closeGeneratorGuide()
    generatorGuideGui.Enabled = false
    if currentPrompt and currentPrompt.Parent then
        setPrompt(currentPrompt, shownPrompts[currentPrompt])
    else
        promptCard.Visible = false
    end
end

local function openGeneratorGuide(data)
    data = type(data) == "table" and data or {}
    guideTitle.Text = tostring(data.title or "ПЕРЕГРЕВ ГЕНЕРАТОРА")
    guideSummary.Text = tostring(data.summary or "Генератору требуется обслуживание системы охлаждения.")
    local rows = {}
    for index, step in ipairs(type(data.steps) == "table" and data.steps or {}) do
        rows[#rows + 1] = string.format("%02d   %s", index, tostring(step))
    end
    guideSteps.Text = table.concat(rows, "\\n\\n")
    generatorGuideGui.Enabled = true
    promptCard.Visible = false
end

guideStart.Activated:Connect(function()
    if not generatorGuideGui.Enabled then return end
    remote:FireServer("GeneratorOverheatStart")
    closeGeneratorGuide()
end)
guideClose.Activated:Connect(closeGeneratorGuide)
UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.Escape and generatorGuideGui.Enabled then
        closeGeneratorGuide()
    end
end)

local top = makeFrame("TopPanel", content, UDim2.fromOffset(236, 58), UDim2.fromOffset(24, 20), COLORS.panel, 0.18)
local topAccent = Instance.new("Frame")
topAccent.Name, topAccent.Size, topAccent.Position = "NightAccent", UDim2.fromOffset(2, 28), UDim2.fromOffset(0, 15)
topAccent.BorderSizePixel, topAccent.BackgroundColor3, topAccent.Parent = 0, COLORS.orange, top
local title = makeLabel("Title", top, "НОЧЬ 01", UDim2.fromOffset(128, 22), UDim2.fromOffset(14, 7), 14, COLORS.text, Enum.Font.GothamBold)
local phaseLabel = makeLabel("Phase", top, TEXT.phasePrep, UDim2.fromOffset(132, 18), UDim2.fromOffset(14, 31), 10, COLORS.muted, Enum.Font.GothamMedium)
local timerLabel = makeLabel("Timer", top, "05:00", UDim2.new(0, 82, 0, 42), UDim2.new(1, -96, 0, 7), 25, COLORS.text, Enum.Font.GothamBold)
timerLabel.TextXAlignment = Enum.TextXAlignment.Right
local subtitle = makeLabel("Subtitle", top, "", UDim2.new(1, -32, 0, 22), UDim2.fromOffset(16, 36), 12, COLORS.muted)
subtitle.Visible = false
local statsLabel = makeLabel("Stats", top, "", UDim2.new(1, -32, 0, 26), UDim2.fromOffset(16, 14), 14, COLORS.text, Enum.Font.GothamMedium)
statsLabel.Visible = false
local xpLabel = makeLabel("XPLabel", top, "XP 0/100", UDim2.new(1, -32, 0, 18), UDim2.fromOffset(16, 64), 11, COLORS.muted)
xpLabel.Visible = false
local xpBack = Instance.new("Frame")
xpBack.Name, xpBack.Size, xpBack.Position = "XPBack", UDim2.new(1, -32, 0, 3), UDim2.fromOffset(16, 90)
xpBack.BorderSizePixel, xpBack.BackgroundColor3, xpBack.Parent = 0, COLORS.panel2, top
xpBack.Visible = false
local xpFill = Instance.new("Frame")
xpFill.Name, xpFill.Size, xpFill.BackgroundColor3, xpFill.BorderSizePixel, xpFill.Parent = "XPFill", UDim2.fromScale(0, 1), COLORS.orange, 0, xpBack

local tasksPanel = makeFrame("TasksPanel", content, UDim2.new(0, 310, 0, 198), UDim2.new(0, 16, 1, -216), COLORS.panel, 0.05)
local taskHeader = makeButton("TasksHeader", tasksPanel, TEXT.objectives .. "  ▾", UDim2.new(1, -16, 0, 28), UDim2.new(0, 8, 0, 5), COLORS.panel)
taskHeader.TextColor3 = COLORS.orange
taskHeader.TextSize = 12
taskHeader.TextXAlignment = Enum.TextXAlignment.Left
local tasksScroll = Instance.new("ScrollingFrame")
tasksScroll.Name = "Objectives"
tasksScroll.Size = UDim2.new(1, -20, 1, -62)
tasksScroll.Position = UDim2.fromOffset(10, 36)
tasksScroll.BackgroundTransparency = 1
tasksScroll.BorderSizePixel = 0
tasksScroll.ScrollBarThickness = 3
tasksScroll.ScrollBarImageColor3 = COLORS.muted
tasksScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
tasksScroll.CanvasSize = UDim2.new()
tasksScroll.ScrollingDirection = Enum.ScrollingDirection.Y
tasksScroll.Parent = tasksPanel
local tasksLayout = Instance.new("UIListLayout")
tasksLayout.Padding = UDim.new(0, 4)
tasksLayout.SortOrder = Enum.SortOrder.LayoutOrder
tasksLayout.Parent = tasksScroll
local taskRows = {}
local taskHint = makeLabel("TaskHint", tasksPanel, "E — взаимодействовать", UDim2.new(1, -24, 0, 16), UDim2.new(0, 14, 1, -22), 10, COLORS.muted, Enum.Font.GothamMedium)
local TASK_LOCATIONS = {restock = "Товарный склад", generator = "Генераторная", door = "Задний выход", trash = "Торговый зал", cctv = "Комната охраны"}

local vitalsPanel = makeFrame("VitalsPanel", content, UDim2.new(0, 220, 0, 108), UDim2.new(1, -16, 1, -80), COLORS.panel, 0.05)
vitalsPanel.AnchorPoint = Vector2.new(1, 1)
local staminaFill = makeBar(vitalsPanel, "Stamina", TEXT.stamina, 8, COLORS.green)
local batteryFill = makeBar(vitalsPanel, "Battery", TEXT.battery, 53, COLORS.blue)

local danger = makeFrame("DangerBanner", content, UDim2.new(0, 310, 0, 38), UDim2.new(0.5, -155, 0, 126), Color3.fromRGB(110, 30, 38), 0.08)
local dangerText = makeLabel("DangerText", danger, TEXT.safe, UDim2.new(1, -20, 1, 0), UDim2.new(0, 10, 0, 0), 12, COLORS.text, Enum.Font.GothamBold)
dangerText.TextXAlignment = Enum.TextXAlignment.Center

danger.Visible = false
local detectionTrack=makeFrame("DetectionTrack",danger,UDim2.new(1,-16,0,3),UDim2.new(0,8,1,-5),COLORS.panel2,.12)
local detectionFill=makeFrame("DetectionFill",detectionTrack,UDim2.fromScale(0,1),UDim2.new(),COLORS.orange,0)
local THREAT_LABELS={SUSPICIOUS="ВАС ЗАМЕЧАЮТ · СКРОЙТЕСЬ",CHASE="ПОГОНЯ · РАЗОРВИТЕ ОБЗОР",
    SEARCH="СУЩЕСТВО ИЩЕТ ВАС",INVESTIGATE="ОНО УСЛЫШАЛО ШУМ",CHECK_LOCKER="ВАШ ШКАФ ЗАМЕЧЕН",
    STAGGER="СУЩЕСТВО ОШЕЛОМЛЕНО",RECOVER="У ВАС ЕСТЬ ПЕРЕДЫШКА"}
local eventLabel = makeLabel("EventLabel", content, "", UDim2.new(0, 420, 0, 24), UDim2.new(0.5, -210, 0, 169), 12, COLORS.orange, Enum.Font.GothamBold)
eventLabel.TextXAlignment = Enum.TextXAlignment.Center

local shopButton = makeButton("ShopButton", content, "МЕНЮ  [B]", UDim2.fromOffset(116, 40), UDim2.new(1, -140, 1, -20), COLORS.panel2)
shopButton.AnchorPoint = Vector2.new(0, 1)
local dailyButton = makeButton("DailyButton", content, TEXT.daily, UDim2.new(0, 190, 0, 42), UDim2.new(1, -206, 0, 128), COLORS.panel2)
local flashlightButton = makeButton("FlashlightButton", content, "F  ФОНАРЬ", UDim2.fromOffset(116, 36), UDim2.new(0, 280, 1, -20), COLORS.panel2)
flashlightButton.AnchorPoint = Vector2.new(0.5, 1)
flashlightButton.Visible = not UserInputService.TouchEnabled
dailyButton.TextSize = 11

local shop = makeFrame("ShopPanel", content, UDim2.new(0, 430, 0, 390), UDim2.new(0.5, -215, 0.5, -195), COLORS.panel, 0.02)
shop.Visible = false
makeLabel("ShopTitle", shop, TEXT.shop, UDim2.new(1, -80, 0, 32), UDim2.new(0, 18, 0, 12), 20, COLORS.orange, Enum.Font.GothamBlack)
local closeButton = makeButton("CloseShop", shop, "X", UDim2.new(0, 36, 0, 34), UDim2.new(1, -50, 0, 12), COLORS.panel2)

local speedButton = makeButton("SpeedUpgrade", shop, "", UDim2.new(1, -36, 0, 48), UDim2.new(0, 18, 0, 62), COLORS.panel2)
local staminaButton = makeButton("StaminaUpgrade", shop, "", UDim2.new(1, -36, 0, 48), UDim2.new(0, 18, 0, 120), COLORS.panel2)
local batteryButtonShop = makeButton("BatteryUpgrade", shop, "", UDim2.new(1, -36, 0, 48), UDim2.new(0, 18, 0, 178), COLORS.panel2)
local vipButton = makeButton("VIPButton", shop, TEXT.vip, UDim2.new(1, -36, 0, 44), UDim2.new(0, 18, 0, 240), COLORS.panel2)
local cashProductButton = makeButton("CashProductButton", shop, TEXT.product, UDim2.new(1, -36, 0, 44), UDim2.new(0, 18, 0, 294), COLORS.panel2)
dailyButton.Parent = shop
dailyButton.Position = UDim2.fromOffset(18, 348)
dailyButton.Size = UDim2.new(1, -36, 0, 44)
dailyButton.TextSize = 12
shop.ZIndex = 50
local shopFoot = makeLabel("ShopFoot", shop, "Покупайте улучшения за заработанные на смене деньги.", UDim2.new(1, -32, 0, 40), UDim2.new(0, 16, 1, -44), 11, COLORS.muted, Enum.Font.GothamMedium)
local profileCard = makeFrame("EmployeeProfile", shop, UDim2.new(1, -36, 0, 104), UDim2.fromOffset(18, 58), COLORS.panel2, 0.25)
for _, object in ipairs({statsLabel, subtitle, xpLabel, xpBack}) do object.Parent = profileCard; object.Visible = true end
statsLabel.TextWrapped = true
statsLabel.Size, statsLabel.Position = UDim2.new(1,-32,0,38), UDim2.fromOffset(16,10)
subtitle.Size, subtitle.Position = UDim2.new(1,-32,0,30), UDim2.fromOffset(16,52)
subtitle.TextWrapped, subtitle.TextTruncate, subtitle.TextSize = true, Enum.TextTruncate.None, 11
xpLabel.Position = UDim2.fromOffset(16,92)
xpBack.Position = UDim2.fromOffset(16,115)
subtitle.Visible = true
local controlsHint = makeLabel("ControlsHint", content, "E  ДЕЙСТВИЕ     SHIFT  БЕГ     V  РАЦИЯ     P  ОПЦИИ", UDim2.fromOffset(400, 16), UDim2.new(0, 24, 1, -22), 10, COLORS.muted)
shopFoot.TextWrapped = true

local toast = makeFrame("Toast", content, UDim2.new(0, 430, 0, 48), UDim2.new(0.5, -215, 0, 211), COLORS.panel2, 0.04)
toast.Visible = false
local toastText = makeLabel("ToastText", toast, "", UDim2.new(1, -24, 1, -8), UDim2.new(0, 12, 0, 4), 12, COLORS.text, Enum.Font.GothamBold)
toast.ZIndex = 70
toastText.TextWrapped = true
toastText.TextTruncate = Enum.TextTruncate.None
toastText.TextXAlignment = Enum.TextXAlignment.Center

local scare = Instance.new("Frame")
scare.Name = "ScareOverlay"
scare.Size = UDim2.fromScale(1, 1)
scare.BackgroundColor3 = Color3.fromRGB(135, 12, 22)
scare.BackgroundTransparency = 1
scare.Visible = false
scare.ZIndex = 100
scare.Parent = content
local scareText = Instance.new("TextLabel")
scareText.Size = UDim2.fromScale(1, 0.2)
scareText.Position = UDim2.fromScale(0, 0.4)
scareText.BackgroundTransparency = 1
scareText.Text = TEXT.gotCaught
scareText.TextColor3 = Color3.fromRGB(255, 235, 230)
scareText.TextSize = 34
scareText.Font = Enum.Font.GothamBlack
scareText.ZIndex = 101
scareText.Parent = scare

local sprintTouch = makeButton("SprintTouch", content, TEXT.sprint, UDim2.new(0, 100, 0, 44), UDim2.new(1, -118, 0.56, 0), COLORS.panel2)
local flashTouch = makeButton("FlashTouch", content, TEXT.flashlight, UDim2.new(0, 100, 0, 44), UDim2.new(1, -118, 0.56, 52), COLORS.panel2)
sprintTouch.Visible = UserInputService.TouchEnabled
flashTouch.Visible = UserInputService.TouchEnabled

local exitHideButton = makeButton("ExitHide", content, "ВЫЙТИ ИЗ УКРЫТИЯ  [Q]", UDim2.fromOffset(270, 48), UDim2.new(0.5, 0, 1, -30), COLORS.green)
exitHideButton.AnchorPoint = Vector2.new(0.5, 1)
exitHideButton.Visible = false
local cctvPanel = makeFrame("CCTVPanel", content, UDim2.fromOffset(600, 90), UDim2.new(0.5, 0, 1, -20), COLORS.panel, 0.02)
cctvPanel.AnchorPoint = Vector2.new(0.5, 1)
cctvPanel.ZIndex = 60
cctvPanel.Visible = false
local cctvLabel = makeLabel("CameraLabel", cctvPanel, "КАМЕРА", UDim2.new(1, -160, 0, 28), UDim2.fromOffset(80, 8), 15, COLORS.green, Enum.Font.GothamBold)
cctvLabel.TextXAlignment = Enum.TextXAlignment.Center
cctvLabel.TextScaled = true
local cctvLabelSize = Instance.new("UITextSizeConstraint")
cctvLabelSize.MinTextSize = 10
cctvLabelSize.MaxTextSize = 15
cctvLabelSize.Parent = cctvLabel
local cctvHint = makeLabel("CameraHint", cctvPanel, "Q / R — переключить   •   E / Esc — выйти", UDim2.new(1, -20, 0, 18), UDim2.fromOffset(10, 42), 11, COLORS.muted)
cctvHint.TextXAlignment = Enum.TextXAlignment.Center
local prevCamera = makeButton("PreviousCamera", cctvPanel, "‹", UDim2.fromOffset(52, 44), UDim2.fromOffset(12, 10), COLORS.blue)
local nextCamera = makeButton("NextCamera", cctvPanel, "›", UDim2.fromOffset(52, 44), UDim2.new(1, -64, 0, 10), COLORS.blue)
local exitCamera = makeButton("ExitCamera", cctvPanel, "ВЫЙТИ", UDim2.fromOffset(110, 28), UDim2.new(0.5, -55, 1, -33), COLORS.orange)
local guiScale = Instance.new("UIScale")
guiScale.Name = "ResponsiveScale"
guiScale.Parent = content
local compact = false

local function layoutVitals()
    for index, name in ipairs({"Stamina", "Battery"}) do
        local heading = vitalsPanel:FindFirstChild(name .. "Title")
        local bar = vitalsPanel:FindFirstChild(name .. "Back")
        heading.Position = UDim2.new((index - 1) * .5, index == 1 and 0 or 10, 0, 0)
        heading.Size = UDim2.new(.5, -10, 0, 18)
        heading:SetAttribute("NS40BaseTextSize", 10)
        heading.TextSize = 10 * (experience and experience.preferences.textScale or 1)
        bar.Position = UDim2.new((index - 1) * .5, index == 1 and 0 or 10, 0, 24)
        bar.Size = UDim2.new(.5, -10, 0, 3)
        bar.BorderSizePixel = 0
    end
end

local function updateLayout()
    if clientDestroyed then return end
    local viewport = safeArea.AbsoluteSize
    if viewport.X <= 0 or viewport.Y <= 0 then return end
    -- Physical-pixel sizing keeps touch targets readable even on 320px displays.
    local width, height = viewport.X, viewport.Y
    local portrait = width < 620 and height > width
    compact = width < 980 or height < 620
    guiScale.Scale = 1
    content.Size = UDim2.fromOffset(width, height)
    local margin = compact and 12 or 24
    local touch = UserInputService.TouchEnabled
    top.Size = UDim2.fromOffset(portrait and math.min(194, width - 112) or 236, 58)
    top.Position = UDim2.fromOffset(margin, compact and 12 or 20)
    title.Size = UDim2.new(1, -110, 0, 22)
    title:SetAttribute("NS40BaseTextSize", 13)
    title.TextSize = 13
    phaseLabel.Size = UDim2.new(1, -94, 0, 18)
    phaseLabel:SetAttribute("NS40BaseTextSize", 9)
    phaseLabel.TextSize = 9
    timerLabel.Size = UDim2.fromOffset(84, 42)
    timerLabel.Position = UDim2.new(1, -94, 0, 7)
    timerLabel:SetAttribute("NS40BaseTextSize", portrait and 23 or 25)
    timerLabel.TextSize = portrait and 23 or 25
    local carrying = experience and experience:GetCarry() ~= nil
    local textScale = experience and experience.preferences.textScale or 1
    local headerHeight = (touch or carrying) and 44 or 30
    local taskWidth = portrait and (height < 620 and width-108 or width-margin*2) or (compact and 250 or 300)
    local taskHeight = tasksExpanded and math.min(portrait and 270 or 348, math.max(156, height - 184)) or ((touch or carrying) and 144 or 138)
    if portrait and tasksExpanded then taskHeight = math.min(230,math.max(160,height-390)) end
    taskHeight += math.floor((textScale-1)*80)
    tasksPanel.Size = UDim2.fromOffset(taskWidth, taskHeight)
    tasksPanel.Position = UDim2.fromOffset(margin, portrait and 122 or (compact and 84 or 102))
    tasksPanel.BackgroundTransparency = experience and experience.preferences.highContrast and 0 or .15
    taskHeader.Size = UDim2.new(1, -(carrying and 128 or 24), 0, headerHeight)
    taskHeader.Position = UDim2.fromOffset(12, 4)
    taskHeader.TextSize = 10 * textScale
    taskHeader.Text = taskWidth < 270 and ("ЗАДАЧИ " .. taskCompleted .. "/" .. taskTotal)
        or ("ЗАДАЧИ  " .. taskCompleted .. " / " .. taskTotal .. (tasksExpanded and "   ▴" or "   ▾"))
    tasksScroll.Position = UDim2.fromOffset(12, headerHeight + 8)
    tasksScroll.Size = UDim2.new(1, -24, 1, -(headerHeight + 34))
    tasksScroll.Visible = true
    taskHint.Visible = true
    taskHint.Position = UDim2.new(0, 12, 1, -20)
    taskHint.Size = UDim2.new(1, -24, 0, 14)
    taskHint.TextSize = 9 * textScale
    taskHint.Text = taskWidth < 270 and (tasksExpanded and "Выберите задачу" or "Нажми: все задачи")
        or (tasksExpanded and "Выберите задачу, чтобы взять её на себя" or "Нажмите заголовок — все задачи")
    vitalsPanel.BackgroundTransparency = 1
    local stroke = vitalsPanel:FindFirstChildOfClass("UIStroke"); if stroke then stroke.Enabled = false end
    vitalsPanel.AnchorPoint = Vector2.new(0, 1)
    vitalsPanel.Size = UDim2.fromOffset(portrait and width - 24 or 236, 32)
    vitalsPanel.Position = portrait and UDim2.fromOffset(12, 111) or UDim2.new(0, margin, 1, touch and -16 or -48)
    layoutVitals()
    controlsHint.Position = UDim2.new(0, margin, 1, -22)
    controlsHint.Visible = not touch and not compact and not cctvActive
    shopButton.AnchorPoint = Vector2.new(1, compact and 0 or 1)
    shopButton.Size = UDim2.fromOffset(compact and 88 or 116, touch and 44 or 40)
    shopButton.Position = UDim2.new(1, -margin, compact and 0 or 1, compact and 16 or -20)
    shopButton.Text = touch and "МЕНЮ" or "МЕНЮ  [B]"
    flashlightButton.AnchorPoint = Vector2.new(0, 1)
    flashlightButton.Size = UDim2.fromOffset(112, 34)
    flashlightButton.Position = UDim2.new(0, compact and 264 or 286, 1, touch and -16 or -46)
    local side = touch and 52 or 44
    sprintTouch.Size, flashTouch.Size = UDim2.fromOffset(60, side), UDim2.fromOffset(60, side)
    sprintTouch.Position = UDim2.new(1, -76, 1, portrait and -178 or -178)
    flashTouch.Position = UDim2.new(1, -76, 1, portrait and -240 or -238)
    sprintTouch.TextSize, flashTouch.TextSize = 11, 11
    local alertWidth = portrait and width - 24 or (compact and math.min(260, width - 280 - (touch and 76 or 0)) or 360)
    danger.Size = UDim2.fromOffset(alertWidth, 34)
    danger.Position = portrait and UDim2.new(.5, -alertWidth/2, 0, 270) or (compact and UDim2.new(1, -margin-alertWidth-(touch and 76 or 0), 0, 78) or UDim2.new(.5, -alertWidth/2, 0, 20))
    danger.BackgroundColor3, danger.BackgroundTransparency = COLORS.panel, .14
    dangerText.TextColor3, dangerText.TextSize = COLORS.red, 11
    eventLabel.Size = UDim2.fromOffset(alertWidth, 40)
    eventLabel.Position = danger.Position + UDim2.fromOffset(0, 40)
    eventLabel.TextWrapped, eventLabel.TextTruncate, eventLabel.TextSize = true, Enum.TextTruncate.None, 11
    local toastWidth = portrait and width-108 or (compact and math.min(360,width-280-(touch and 76 or 0)) or math.min(420,width-24))
    toast.Size = UDim2.fromOffset(toastWidth, portrait and 76 or 64)
    toast.Position = portrait and UDim2.new(0,12,1,-208) or (compact and UDim2.new(1,-margin-toastWidth-(touch and 76 or 0),1,-96) or UDim2.new(.5,-toastWidth/2,0,94))
    toastText.TextSize = 12
    local shopWidth = math.min(500,width-24)
    shop.Size = UDim2.fromOffset(shopWidth,math.min(650,height-24))
    shop.AnchorPoint,shop.Position = Vector2.new(.5,.5),UDim2.fromScale(.5,.5)
    -- The fallback shop is replaced by the terminal's scrollable upgrades page when loaded.
    if not experience then
        profileCard.Position,profileCard.Size = UDim2.fromOffset(16,54),UDim2.new(1,-32,0,104)
        for i, button in ipairs({speedButton,staminaButton,batteryButtonShop,vipButton,cashProductButton,dailyButton}) do
            button.Position,button.Size = UDim2.fromOffset(16,168+(i-1)*56),UDim2.new(1,-32,0,48)
        end
    end
    cctvPanel.Size = UDim2.fromOffset(math.min(620,width-24),touch and 120 or 100)
    cctvPanel.Position = UDim2.new(.5,0,1,-12)
    prevCamera.Size,nextCamera.Size = UDim2.fromOffset(48,44),UDim2.fromOffset(48,44)
    exitCamera.Size,exitCamera.Position = UDim2.fromOffset(120,44),UDim2.new(.5,-60,1,-48)
    cctvHint.Visible = not portrait
    cctvHint.Text = touch and "Кнопки — сменить камеру" or "Q / R — сменить камеру"
    cctvLabel.TextSize = 13
    cctvLabel.Size = UDim2.new(1,-140,0,36)
    cctvLabel.Position = UDim2.fromOffset(70,6)
    exitHideButton.Size = UDim2.fromOffset(math.min(270,width-24),48)
    exitHideButton.Position = UDim2.new(.5,0,1,touch and -112 or -30)
    local hidden = player:GetAttribute("NightShiftHidden") == true
    local downed = player:GetAttribute("NightShiftDowned") == true
    local modal = experience and experience:IsBlockingInput() or shop.Visible
    danger.Visible = currentThreat and os.clock()<threatCueUntil and threatCueState~="IDLE"
        and not portrait and not modal and not cctvActive
    eventLabel.Visible = not portrait and not modal and not cctvActive
    top.Visible = not cctvActive
    phaseLabel.Text = normalPhaseText
    if portrait and os.clock() < threatCueUntil then phaseLabel.Text = threatCueState == "CHASE" and "ЗА ВАМИ ГОНИТСЯ" or "СЛУШАЙТЕ ВНИМАТЕЛЬНО"; phaseLabel.TextColor3=COLORS.red
    elseif portrait and currentThreat then phaseLabel.Text = "ОПАСНОСТЬ РЯДОМ";phaseLabel.TextColor3=COLORS.red
    elseif portrait and currentEvent ~= "" then phaseLabel.Text = currentEvent:find("АВАРИЯ") and "НЕТ ПИТАНИЯ" or "СИГНАЛ ВНИМАНИЯ";phaseLabel.TextColor3=COLORS.orange end
    tasksPanel.Visible, vitalsPanel.Visible = not cctvActive and not downed, not cctvActive and not downed
    shopButton.Visible = not cctvActive and not downed
    flashlightButton.Visible = not touch and not cctvActive and not hidden and not downed and not modal and not portrait
    sprintTouch.Visible = touch and not cctvActive and not hidden and not downed and not modal
    flashTouch.Visible = touch and not cctvActive and not hidden and not downed and not modal
    exitHideButton.Visible = hidden and not cctvActive and not downed
    if cctvActive then
        local widthAvailable=math.min(420,width-24)
        toast.Size,toast.Position=UDim2.fromOffset(widthAvailable,64),UDim2.new(.5,-widthAvailable/2,0,10)
    end
    if experience then experience:Layout() end
end
safeArea:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateLayout)
taskHeader.Activated:Connect(function() tasksExpanded = not tasksExpanded; if updateTasks then updateTasks(lastTaskList) end; updateLayout() end)
updateLayout()

local profile = {cash = 0, nights = 0, level = 1, xp = 0, xpNext = 100, speedLevel = 0, staminaLevel = 0, batteryLevel = 0, vip = false, dailyReady = false, dailySeconds = 0}
local toastToken = 0
local sprinting = false
local flashlightOn = false
local function formatTime(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    return string.format("%02d:%02d", math.floor(seconds / 60), seconds % 60)
end
local function formatDaily(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    return string.format("%02d:%02d", math.floor(seconds / 3600), math.floor((seconds % 3600) / 60))
end

local function showToast(message)
    toastToken += 1
    local token = toastToken
    toastText.Text = tostring(message)
    toast.Visible = true
    updateLayout()
    task.delay(3.4, function() if toastToken == token then toast.Visible = false; updateLayout() end end)
end

local function setBar(fill, value, maximum)
    local ratio = math.clamp((tonumber(value) or 0) / math.max(1, tonumber(maximum) or 1), 0, 1)
    TweenService:Create(fill, TweenInfo.new(0.18), {Size = UDim2.fromScale(ratio, 1)}):Play()
end

local function updateDailyButton()
    dailyButton.Text = profile.dailyReady and (TEXT.daily .. "  +$" .. tostring(250 + profile.level * 15)) or (TEXT.daily .. "  " .. formatDaily(profile.dailySeconds))
    if profile.dailyReady then dailyButton.BackgroundColor3 = COLORS.panel2 else dailyButton.BackgroundColor3 = COLORS.panel2 end
end

local function updateProfile()
    statsLabel.Text = "НА СЧЁТЕ  $" .. tostring(profile.cash) .. "   ·   УР. " .. tostring(profile.level) .. "\nСМЕН ЗАВЕРШЕНО: " .. tostring(profile.nights)
    xpLabel.Text = TEXT.xp .. " " .. tostring(profile.xp) .. "/" .. tostring(profile.xpNext)
    xpFill.Size = UDim2.fromScale(math.clamp((profile.xp or 0) / math.max(1, profile.xpNext or 100), 0, 1), 1)
    speedButton.Text = TEXT.speed .. "  Lv." .. profile.speedLevel .. "  |  " .. (profile.speedLevel >= 3 and "МАКС" or "$" .. ({250, 550, 1050})[profile.speedLevel + 1])
    staminaButton.Text = TEXT.stamina .. "  Lv." .. profile.staminaLevel .. "  |  " .. (profile.staminaLevel >= 3 and "МАКС" or "$" .. ({220, 500, 950})[profile.staminaLevel + 1])
    batteryButtonShop.Text = TEXT.battery .. "  Lv." .. profile.batteryLevel .. "  |  " .. (profile.batteryLevel >= 3 and "МАКС" or "$" .. ({180, 420, 800})[profile.batteryLevel + 1])
    vipButton.Visible = profile.vip == true or profile.vipReady == true
    cashProductButton.Visible = profile.cashProductReady == true
    if profile.vip then
        vipButton.Text = "VIP АКТИВЕН"
        vipButton.BackgroundColor3 = COLORS.panel2
    elseif not profile.vipReady then
        vipButton.Text = "VIP ПОКА НЕДОСТУПЕН"
        vipButton.BackgroundColor3 = COLORS.panel2
    else
        vipButton.Text = TEXT.vip .. "  |  КУПИТЬ"
        vipButton.BackgroundColor3 = COLORS.panel2
    end
    if profile.cashProductReady then
        cashProductButton.Text = TEXT.product .. "  |  КУПИТЬ"
        cashProductButton.BackgroundColor3 = COLORS.panel2
    else
        cashProductButton.Text = "ПОКУПКИ ПОКА НЕДОСТУПНЫ"
        cashProductButton.BackgroundColor3 = COLORS.panel2
    end
    updateDailyButton()
end

updateTasks = function(taskList)
    taskList = type(taskList) == "table" and taskList or {}
    lastTaskList = taskList
    if experience then taskList = experience:GetTasks(taskList) end
    taskTotal, taskCompleted = #taskList, 0
    local current = nil
    for i, item in ipairs(taskList) do
        if item.done then taskCompleted += 1 elseif not current then current = i end
    end
    current = current or 1
    if focusedTask ~= current then tasksScroll.CanvasPosition = Vector2.new(0,0); focusedTask = current end
    local count = math.max(1,#taskList)
    for i=1,count do
        local row = taskRows[i]
        if not row then
            row = makeButton("Task" .. i,tasksScroll,"",UDim2.new(1,-4,0,66),UDim2.new(),COLORS.panel)
            row.BackgroundTransparency, row.AutomaticSize = .12, Enum.AutomaticSize.Y
            row.BackgroundColor3 = COLORS.panel2
            row.LayoutOrder = i
            local accent = Instance.new("Frame")
            accent.Name, accent.Size, accent.Position = "TaskAccent", UDim2.fromOffset(3, 36), UDim2.fromOffset(0, 6)
            accent.BorderSizePixel, accent.BackgroundColor3, accent.Parent = 0, COLORS.orange, row
            corner(accent, 2)
            local titleLabel = makeLabel("TaskTitle",row,"",UDim2.new(1,-16,0,20),UDim2.fromOffset(10,1),14,COLORS.text,Enum.Font.GothamBold)
            local detailLabel = makeLabel("TaskStage",row,"",UDim2.new(1,-16,0,40),UDim2.fromOffset(10,25),12,COLORS.muted)
            detailLabel.TextWrapped, detailLabel.TextTruncate, detailLabel.AutomaticSize = true, Enum.TextTruncate.None, Enum.AutomaticSize.Y
            detailLabel.TextYAlignment = Enum.TextYAlignment.Top
            row.Activated:Connect(function()
                local id = row:GetAttribute("TaskId")
                if type(id)=="string" and row:GetAttribute("TaskDone")~=true then remote:FireServer("NS36Action",{action="ClaimTask",taskId=id}) end
            end)
            taskRows[i]=row
        end
        local item=taskList[i]
        local textScale = experience and experience.preferences.textScale or 1
        row:FindFirstChild("TaskTitle").TextSize = 14 * textScale
        row:FindFirstChild("TaskStage").TextSize = 12 * textScale
        row.Visible=tasksExpanded or i==current
        local titleLabel, detailLabel = row:FindFirstChild("TaskTitle"), row:FindFirstChild("TaskStage")
        local accent = row:FindFirstChild("TaskAccent")
        if accent then accent.BackgroundColor3 = item and item.done and COLORS.green or COLORS.orange end
        if item then
            titleLabel.Text=(item.done and "✓  " or "") .. tostring(item.title)
            titleLabel.TextColor3=item.done and COLORS.green or COLORS.text
            local stage=tostring(item.stageText or item.location or TASK_LOCATIONS[item.id] or "")
            if type(item.claimedName)=="string" and item.claimedName~="" and not item.done then stage ..= "\n" .. item.claimedName .. " занимается задачей" end
            detailLabel.Text=stage
            row:SetAttribute("TaskId",item.id); row:SetAttribute("TaskDone",item.done==true)
        else
            titleLabel.Text="Подготовка к смене"
            detailLabel.Text="Осмотритесь. Задания появятся после начала смены."
            row:SetAttribute("TaskId",nil);row:SetAttribute("TaskDone",false)
        end
    end
    for i=count+1,#taskRows do taskRows[i].Visible=false end
    updateLayout()
end

local function updateVitals(data)
    if type(data) ~= "table" then return end
    setBar(staminaFill, data.stamina, data.maxStamina)
    setBar(batteryFill, data.battery, data.maxBattery)
    local staminaTitle = vitalsPanel:FindFirstChild("StaminaTitle")
    local batteryTitle = vitalsPanel:FindFirstChild("BatteryTitle")
    local staminaName = "ВЫНОСЛ."
    staminaTitle.Text = staminaName .. "  " .. tostring(math.ceil(tonumber(data.stamina) or 0))
    batteryTitle.Text = TEXT.battery .. "  " .. tostring(math.ceil(tonumber(data.battery) or 0))
    batteryFill.BackgroundColor3 = (tonumber(data.battery) or 0) <= 20 and COLORS.orange or COLORS.blue
end

local scareToken = 0
local function flashScare()
    scareToken += 1
    local token = scareToken
    scare.Visible = true
    scare.BackgroundTransparency = 0.45
    TweenService:Create(scare, TweenInfo.new(0.55), {BackgroundTransparency = 1}):Play()
    task.delay(0.6, function() if scareToken == token then scare.Visible = false end end)
end

local function setSprint(enabled)
    if clientDestroyed then return end
    enabled = enabled == true and not cctvActive and not shop.Visible and not player:GetAttribute("NightShiftHidden") and not player:GetAttribute("NightShiftDowned") and not (experience and experience:IsBlockingInput())
    if sprinting == enabled and enabled then return end
    sprinting = enabled
    sprintTouch.BackgroundColor3 = enabled and Color3.fromRGB(78, 68, 45) or COLORS.panel2
    sprintTouch.Text = enabled and "БЕГ: ВКЛ" or TEXT.sprint
    remote:FireServer("Sprint", enabled)
end

local function updateFlashlight(enabled)
    flashlightOn = enabled == true
    local color = flashlightOn and Color3.fromRGB(78, 68, 45) or COLORS.panel2
    flashlightButton.BackgroundColor3 = color
    flashTouch.BackgroundColor3 = color
    flashTouch.Text = flashlightOn and "СВЕТ: ВКЛ" or TEXT.flashlight
end

local cameraPoints = {}
local cameraIndex = 1
local cameraFov = 70
local cameraControls
local controlsDisabled = false
local cameraConnection
local function closeCCTV()
    if not cctvActive then return end
    cctvActive = false
    remote:FireServer("NS36Action", {action = "CCTVView", active = false})
    if cameraConnection then cameraConnection:Disconnect(); cameraConnection = nil end
    local camera = workspace.CurrentCamera
    local character = player.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if camera then
        camera.CameraType = Enum.CameraType.Custom
        camera.FieldOfView = experience and experience.preferences.fov or cameraFov
        if humanoid then camera.CameraSubject = humanoid end
    end
    if controlsDisabled and cameraControls then pcall(function() cameraControls:Enable() end) end
    controlsDisabled = false
    cameraControls = nil
    cctvPanel.Visible = false
    updateLayout()
end

local function selectCamera(delta)
    if #cameraPoints == 0 then closeCCTV(); return end
    cameraIndex = (cameraIndex - 1 + delta) % #cameraPoints + 1
    local point = cameraPoints[cameraIndex]
    cctvLabel.Text = string.format("CAM %02d / %02d  •  %s", cameraIndex, #cameraPoints, tostring(point:GetAttribute("Label") or point.Name))
    remote:FireServer("NS36Action", {action = "CCTVView", active = true, camera = cameraIndex})
    if experience then experience:UpdateCameraUI() end
end

local function openCCTV()
    if cctvActive or player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") or (experience and experience:IsBlockingInput()) then return end
    local world = workspace:FindFirstChild("NightShiftWorld")
    local points = world and world:FindFirstChild("CameraPoints")
    local monitor = world and (world:FindFirstChild("CCTVMonitor", true) or world:FindFirstChild("CCTV", true))
    local character = player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    local camera = workspace.CurrentCamera
    if not points or not monitor or not monitor:IsA("BasePart") or not root or not humanoid or humanoid.Health <= 0 or not camera or (root.Position - monitor.Position).Magnitude > 12 then
        showToast("Подойдите к монитору в комнате охраны.")
        return
    end
    table.clear(cameraPoints)
    for _, point in ipairs(points:GetChildren()) do
        if point:IsA("BasePart") then table.insert(cameraPoints, point) end
    end
    table.sort(cameraPoints, function(a, b)
        local aOrder, bOrder = a:GetAttribute("Order") or 0, b:GetAttribute("Order") or 0
        return aOrder == bOrder and a.Name < b.Name or aOrder < bOrder
    end)
    if #cameraPoints == 0 then showToast("Камеры ещё подключаются. Попробуйте снова."); return end
    setSprint(false)
    shop.Visible = false
    cctvActive = true
    cameraIndex = 1
    cameraFov = camera.FieldOfView
    local playerScripts = player:FindFirstChild("PlayerScripts")
    local playerModule = playerScripts and playerScripts:FindFirstChild("PlayerModule")
    if playerModule and playerModule:IsA("ModuleScript") then
        local ok, controls = pcall(function() return require(playerModule):GetControls() end)
        if ok and controls then
            cameraControls = controls
            controlsDisabled = pcall(function() controls:Disable() end)
        end
    end
    camera.CameraType = Enum.CameraType.Scriptable
    camera.FieldOfView = 76
    cctvPanel.Visible = true
    selectCamera(0)
    updateLayout()
    cameraConnection = RunService.RenderStepped:Connect(function()
        local activeCamera = workspace.CurrentCamera
        local currentCharacter = player.Character
        local currentRoot = currentCharacter and currentCharacter:FindFirstChild("HumanoidRootPart")
        local currentHumanoid = currentCharacter and currentCharacter:FindFirstChildOfClass("Humanoid")
        local point = cameraPoints[cameraIndex]
        if not activeCamera or not currentRoot or not currentHumanoid or currentHumanoid.Health <= 0 or not monitor.Parent or not point or not point.Parent or player:GetAttribute("NightShiftHidden") or player:GetAttribute("NightShiftDowned") or (currentRoot.Position - monitor.Position).Magnitude > 12 then
            closeCCTV()
            return
        end
        if not controlsDisabled and currentHumanoid.MoveDirection.Magnitude > 0.05 then closeCCTV(); return end
        activeCamera.CameraType = Enum.CameraType.Scriptable
        activeCamera.CFrame = point.CFrame
        activeCamera.Focus = point.CFrame * CFrame.new(0, 0, -24)
    end)
end
prevCamera.Activated:Connect(function() selectCamera(-1) end)
nextCamera.Activated:Connect(function() selectCamera(1) end)
exitCamera.Activated:Connect(closeCCTV)
exitHideButton.Activated:Connect(function() remote:FireServer("ExitHide") end)

remote.OnClientEvent:Connect(function(kind, data)
    if clientDestroyed then return end
    -- Audio is independent of the menu controller: a UI failure cannot silence the game.
    if kind == "Preferences" then
        savedPreferences = data
        if audioController then audioController:SetPreferences(data) end
    elseif kind == "NS36Sound" then
        if audioController then audioController:Play(data)
        elseif #pendingSounds < 12 then table.insert(pendingSounds, {payload=data, at=os.clock()}) end
    elseif kind == "State" or kind == "PlayerCondition" or kind == "ThreatSense" then
        if kind == "State" then latestAudioState = data
        elseif kind == "PlayerCondition" then latestAudioCondition = data
        else latestThreatSense, latestThreatAt = data, os.clock() end
        if audioController then audioController:HandleEvent(kind, data) end
    elseif kind == "IncidentUpdate" then
        latestIncident = data
    elseif kind == "GeneratorOverheatGuide" then
        openGeneratorGuide(data)
    elseif kind == "ExploreResult" then
        latestInspection = data
        if not experience and type(data) == "table" then
            showToast(tostring(data.title or "Осмотр") .. "\n" .. tostring(data.text or data.status or "Проверка завершена"))
        end
    end
    if experience then experience:HandleEvent(kind, data) end
    if kind == "Profile" and type(data) == "table" then
        for key, value in pairs(data) do profile[key] = value end
        updateProfile()
    elseif kind == "Vitals" then
        updateVitals(data)
    elseif kind == "State" and type(data) == "table" then
        local phases = {INTERMISSION = TEXT.phasePrep, SHIFT = TEXT.phaseShift, RESULTS = TEXT.phaseResults}
        phaseLabel.Text = data.phase == "RESULTS" and tostring(data.resultLabel or TEXT.phaseResults) or phases[data.phase] or tostring(data.phase)
        normalPhaseText = phaseLabel.Text
        currentThreat, currentEvent = data.monsterActive == true, tostring(data.eventName or "")
        timerLabel.Text = formatTime(data.timeLeft)
        if data.phase == "RESULTS" then
            phaseLabel.TextColor3 = data.resultSuccess == true and COLORS.green or COLORS.red
        elseif data.phase == "SHIFT" then phaseLabel.TextColor3 = COLORS.orange else phaseLabel.TextColor3 = COLORS.blue end
        title.Text = string.format("НОЧЬ %02d", tonumber(data.number) or 1)
        subtitle.Text = "СОТРУДНИКИ  " .. tostring(data.playerCount or 1) .. "/" .. tostring(data.maxPlayers or 6) .. "   ·   УГРОЗА: " .. tostring(data.difficultyLabel or "СПОКОЙНО")
        if (data.difficultyTier or 1) >= 4 then subtitle.TextColor3 = COLORS.orange else subtitle.TextColor3 = COLORS.muted end
        updateTasks(data.taskList or {})
        danger.Visible = data.monsterActive == true and os.clock()<threatCueUntil and threatCueState~="IDLE"
            and not cctvActive and not (safeArea.AbsoluteSize.X < 620 and safeArea.AbsoluteSize.Y > safeArea.AbsoluteSize.X)
        dangerText.Text=os.clock()<threatCueUntil and (THREAT_LABELS[threatCueState] or threatCueText) or TEXT.safe
        eventLabel.Text = tostring(data.eventName or "")
        danger.BackgroundColor3 = COLORS.panel
    elseif kind == "ThreatSense" and type(data) == "table" then
        threatCueText = type(data.text) == "string" and data.text or "Существо рядом"
        threatCueState = data.state or ""
        threatCueUntil = os.clock() + math.clamp(tonumber(data.duration) or 3, .3, 8)
        dangerText.Text=THREAT_LABELS[threatCueState] or threatCueText
        detectionFill.Size=UDim2.fromScale(math.clamp(tonumber(data.intensity) or 0,0,1),1)
        detectionFill.BackgroundColor3=threatCueState=="CHASE" and COLORS.red or COLORS.orange
        updateLayout()
    elseif kind == "Notify" then
        showToast(data)
    elseif kind == "Scare" then
        if experience then experience:ShowThreat(data)
        else showToast(tostring(data and data.name or "") .. " — " .. TEXT.hunting) end
    elseif kind == "Jumpscare" then
        closeCCTV()
        if experience then experience:ShowCaught()
        else showToast("Вас настигли. Дождитесь помощи или используйте доступную вторую попытку.") end
    elseif kind == "PromptPass" then
        local id = tonumber(data)
        if id and id > 0 then MarketplaceService:PromptGamePassPurchase(player, id) end
    elseif kind == "PromptProduct" then
        local id = tonumber(data)
        if id and id > 0 then MarketplaceService:PromptProductPurchase(player, id) end
    elseif kind == "FlashlightState" then
        if flashlightOn ~= (data == true) and audioController then audioController:Play({kind="flashlight"}) end
        updateFlashlight(data)
    elseif kind == "OpenCCTV" then
        openCCTV()
    elseif kind == "CloseCCTV" then
        closeCCTV()
    end
end)

local function toggleShop()
    if player:GetAttribute("NightShiftDowned") then return end
    if experience then
        if experience.modal then experience:ClosePanel() else experience:OpenPanel("missions") end
        updateLayout()
        return
    end
    closeCCTV()
    setSprint(false)
    shop.Visible = not shop.Visible
    if shop.Visible and UserInputService.GamepadEnabled then GuiService.SelectedObject = closeButton end
end
shopButton.Activated:Connect(toggleShop)
closeButton.Activated:Connect(function() shop.Visible = false end)
speedButton.Activated:Connect(function() remote:FireServer("BuyUpgrade", "Speed") end)
staminaButton.Activated:Connect(function() remote:FireServer("BuyUpgrade", "Stamina") end)
batteryButtonShop.Activated:Connect(function() remote:FireServer("BuyUpgrade", "Battery") end)
vipButton.Activated:Connect(function() if not profile.vip and profile.vipReady then remote:FireServer("PromptPass", "VIP") end end)
cashProductButton.Activated:Connect(function() if profile.cashProductReady then remote:FireServer("PromptProduct", "Cash") end end)
dailyButton.Activated:Connect(function() if profile.dailyReady then remote:FireServer("ClaimDaily") else showToast("Вернись, когда таймер награды обнулится.") end end)
local function requestFlashlight()
    if shop.Visible or player:GetAttribute("NightShiftDowned") or (experience and experience:IsBlockingInput()) then return end
    remote:FireServer("Flashlight")
end
flashlightButton.Activated:Connect(requestFlashlight)
flashTouch.Activated:Connect(requestFlashlight)

-- A mobile tap toggles sprint, so sliding a finger off the button cannot strand it on.
sprintTouch.Activated:Connect(function() setSprint(not sprinting) end)
local heldSprintKeys = {}
UserInputService.InputBegan:Connect(function(input, processed)
    if clientDestroyed then return end
    if input.KeyCode == Enum.KeyCode.Escape or input.KeyCode == Enum.KeyCode.ButtonB then
        closeCCTV()
        shop.Visible = false
        setSprint(false)
        if input.KeyCode == Enum.KeyCode.ButtonB and player:GetAttribute("NightShiftHidden") then remote:FireServer("ExitHide") end
        return
    end
    if UserInputService:GetFocusedTextBox() then return end
    if experience and experience:IsBlockingInput() then
        if input.KeyCode == Enum.KeyCode.B or input.KeyCode == Enum.KeyCode.ButtonSelect then experience:ClosePanel() end
        return
    end
    if player:GetAttribute("NightShiftDowned") then return end
    if cctvActive then
        if input.KeyCode == Enum.KeyCode.Q or input.KeyCode == Enum.KeyCode.ButtonL1 then selectCamera(-1)
        elseif input.KeyCode == Enum.KeyCode.R or input.KeyCode == Enum.KeyCode.ButtonR1 then selectCamera(1)
        elseif input.KeyCode == Enum.KeyCode.E or input.KeyCode == Enum.KeyCode.B or input.KeyCode == Enum.KeyCode.ButtonX then closeCCTV() end
        return
    end
    if player:GetAttribute("NightShiftHidden") and input.KeyCode == Enum.KeyCode.Q then
        remote:FireServer("ExitHide")
        return
    end
    if processed then return end
    if shop.Visible then
        if input.KeyCode == Enum.KeyCode.B or input.KeyCode == Enum.KeyCode.ButtonSelect then toggleShop() end
        return
    end
    if input.KeyCode == Enum.KeyCode.LeftShift or input.KeyCode == Enum.KeyCode.RightShift then
        heldSprintKeys[input.KeyCode] = true
        setSprint(true)
    elseif input.KeyCode == Enum.KeyCode.ButtonL3 then
        setSprint(not sprinting)
    elseif input.KeyCode == Enum.KeyCode.B or input.KeyCode == Enum.KeyCode.ButtonSelect then
        toggleShop()
    elseif input.KeyCode == Enum.KeyCode.F or input.KeyCode == Enum.KeyCode.ButtonY then
        remote:FireServer("Flashlight")
    end
end)
UserInputService.InputEnded:Connect(function(input)
    if clientDestroyed then return end
    if input.KeyCode == Enum.KeyCode.LeftShift or input.KeyCode == Enum.KeyCode.RightShift then
        heldSprintKeys[input.KeyCode] = nil
        setSprint(next(heldSprintKeys) ~= nil)
    end
end)
local function releaseControls()
    if clientDestroyed then return end
    table.clear(heldSprintKeys)
    setSprint(false)
    closeCCTV()
    if experience then experience:ClosePanel() end
end
UserInputService.WindowFocusReleased:Connect(releaseControls)
UserInputService.TextBoxFocused:Connect(function() table.clear(heldSprintKeys); setSprint(false) end)
GuiService.MenuOpened:Connect(releaseControls)
player:GetAttributeChangedSignal("NightShiftHidden"):Connect(function()
    if player:GetAttribute("NightShiftHidden") then releaseControls() end
    updateLayout()
end)
player:GetAttributeChangedSignal("NightShiftDowned"):Connect(function()
    if player:GetAttribute("NightShiftDowned") then releaseControls() end
end)
player:GetAttributeChangedSignal("NightShiftSprinting"):Connect(function()
    if not player:GetAttribute("NightShiftSprinting") then
        sprinting = false
        sprintTouch.BackgroundColor3 = COLORS.panel2
        sprintTouch.Text = TEXT.sprint
    end
end)
local function characterDied()
    releaseControls()
    if clientDestroyed then return end
    if audioController then audioController:Play({kind="player_death",caption="Сознание угасает"}) end
end
player.CharacterRemoving:Connect(function(character)
    releaseControls()
    latestAudioCondition, latestThreatSense, latestThreatAt = nil, nil, -math.huge
    if audioController then audioController:HandleEvent("CharacterRemoving", character) end
end)
player.CharacterAdded:Connect(function(character)
    if clientDestroyed then return end
    releaseControls()
    latestAudioCondition, latestThreatSense, latestThreatAt = nil, nil, -math.huge
    if audioController then audioController:HandleEvent("CharacterAdded", character) end
    updateFlashlight(false)
    shop.Visible = false
    generatorGuideGui.Enabled = false
    updateLayout()
    local humanoid = character:WaitForChild("Humanoid", 10)
    if clientDestroyed then return end
    if humanoid then humanoid.Died:Connect(characterDied) end
    remote:FireServer("RequestState")
end)
if player.Character then
    local humanoid = player.Character:FindFirstChildOfClass("Humanoid")
    if humanoid then humanoid.Died:Connect(characterDied) end
end
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
    -- The old camera may be destroyed during respawn; never leave a new one Scriptable.
    closeCCTV()
    if experience and not clientDestroyed then experience:ApplyPreferences(experience.preferences) end
    updateLayout()
end)

updateProfile()
task.spawn(function()
    while not clientDestroyed do
        task.wait(1)
        if not clientDestroyed and not profile.dailyReady and profile.dailySeconds > 0 then
            profile.dailySeconds -= 1
            if profile.dailySeconds <= 0 then profile.dailyReady = true end
            updateDailyButton()
        end
    end
end)
local function startAudio(module)
    if clientDestroyed or audioController or not module then return end
    local ok, result = pcall(function()
        return require(module).new({
            player = player,
            caption = function(value, position, seconds) if not clientDestroyed and experience then experience:Caption(value, position, seconds) end end,
            status = function(state) if clientDestroyed then return end; audioStatus = state; if experience then experience:UpdateAudioStatus(state) end end,
        })
    end)
    if ok then
        audioController = result
        if savedPreferences then audioController:SetPreferences(savedPreferences) end
        if latestAudioState then audioController:HandleEvent("State", latestAudioState) end
        if latestAudioCondition then audioController:HandleEvent("PlayerCondition", latestAudioCondition) end
        local threatAge = os.clock() - latestThreatAt
        local threatDuration = type(latestThreatSense)=="table" and math.clamp(tonumber(latestThreatSense.duration) or 3, .3, 8) or 0
        if threatAge < threatDuration then
            local current = table.clone(latestThreatSense)
            current.duration = threatDuration - threatAge
            audioController:HandleEvent("ThreatSense", current)
        end
        for _, entry in ipairs(pendingSounds) do
            if os.clock() - entry.at <= 3 then audioController:Play(entry.payload) end
        end
        table.clear(pendingSounds)
    else
        audioStatus = {state="failed",text="Звук не подключился. Перезайдите в игру."}
        if experience then experience:UpdateAudioStatus(audioStatus) end
        warn("[NIGHT SHIFT 4.6] Audio controller failed: " .. tostring(result))
    end
end
local audioModule = ReplicatedStorage:FindFirstChild("NightShift_Audio")
if audioModule then startAudio(audioModule)
else task.spawn(function()
    local module = ReplicatedStorage:WaitForChild("NightShift_Audio", 20)
    if clientDestroyed then return end
    if module then startAudio(module)
    else audioStatus={state="failed",text="Звук не подключился. Перезайдите в игру."}; if experience then experience:UpdateAudioStatus(audioStatus) end end
end) end

local function startExperience(module)
    if clientDestroyed or experience or not module then return end
    local ok, result = pcall(function()
        return require(module).new({
            remote = remote, player = player, gui = gui, content = content, hudScale = guiScale,
            tasksPanel = tasksPanel, tasksScroll = tasksScroll, taskHint = taskHint, shop = shop,
            showToast = showToast, releaseControls = releaseControls, closeCCTV = closeCCTV,
            closeShop = function() shop.Visible = false end,
            getCCTV = function() return cctvActive, cameraIndex, cameraPoints[cameraIndex] end,
            refreshTasks = function() updateTasks(lastTaskList) end,
            refreshLayout = updateLayout,
            getAudio = function() return audioController end,
            audioStatus = audioStatus, initialPreferences = savedPreferences,
            upgradeControls = {profileCard, speedButton, staminaButton, batteryButtonShop, vipButton, cashProductButton, dailyButton, shopFoot},
            cctvPanel = cctvPanel,
            isToastVisible = function() return toast.Visible end,
            isTasksExpanded = function() return tasksExpanded end,
        })
    end)
    if ok then
        experience = result
        experience:UpdateAudioStatus(audioStatus)
        if latestInspection then experience:HandleEvent("ExploreResult", latestInspection) end
        if latestIncident then experience:HandleEvent("IncidentUpdate",latestIncident) end
        updateLayout(); remote:FireServer("RequestState")
    else warn("[NIGHT SHIFT 4.6] Client experience failed to start: " .. tostring(result)) end
end
local experienceModule = ReplicatedStorage:FindFirstChild("NightShift_Experience")
if experienceModule then startExperience(experienceModule)
else task.spawn(function() startExperience(ReplicatedStorage:WaitForChild("NightShift_Experience", 15)) end) end
remote:FireServer("RequestState")

gui.Destroying:Connect(function()
    if clientDestroyed then return end
    closeCCTV()
    releaseControls()
    clientDestroyed = true
    if generatorGuideGui then generatorGuideGui:Destroy() end
    if experience then experience:Destroy() end
    if audioController then audioController:Destroy() end
end)
