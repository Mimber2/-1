-- Standalone logic-only test. This is NOT Roblox Studio simulation.
local now=0
math.clamp=function(x,a,b)return math.max(a,math.min(b,x))end
local function vec(x,y,z)
    return setmetatable({X=x,Y=y,Z=z,Magnitude=math.sqrt(x*x+y*y+z*z)},
      {__sub=function(a,b)return vec(a.X-b.X,a.Y-b.Y,a.Z-b.Z)end})
end
Vector3={new=vec};Color3={fromRGB=function(r,g,b)return tostring(r)..":"..tostring(g)..":"..tostring(b)end}
local frameMeta={__mul=function(a,b)return setmetatable({},frameMeta)end}
CFrame={new=function(...)return setmetatable({},frameMeta)end}
local queue={}
task={delay=function(seconds,cb)table.insert(queue,cb)end}
local plays={}
local remote={FireAllClients=function(self,kind,data)table.insert(plays,{kind=kind,data=data})end,
    FireClient=function(self,player,kind,data)table.insert(plays,{kind=kind,data=data})end}
local player={Attributes={},Character={}}
function player:GetAttribute(n)return self.Attributes[n]end
function player.Character:FindFirstChild(name)if name=='HumanoidRootPart' then return {Position=vec(0,0,0)} end end
function player.Character:FindFirstChildOfClass(name)if name=='Humanoid' then return {Health=100} end end
local players={GetPlayers=function()return {player}end}; player.Parent=players
local hits={notices={},noises={},sounds={},repairs={},pressure=0}
local definitions=assert(loadfile(arg[1]))()
local ctx={clock=function()return now end,random={NextInteger=function(self,a,b)return a end,
    NextNumber=function(self,a,b)return a+1 end},Players=players,remote=remote,getProfile=function()return {ready=true}end,
    sound=function(id) table.insert(hits.sounds,id)end, noise=function(_,kind,radius)table.insert(hits.noises,kind)end,
    notify=function(_,s)table.insert(hits.notices,s)end, notifyAll=function(s)table.insert(hits.notices,s)end,
    pressure=function()hits.pressure=hits.pressure+1 end,
    onFix=function(_,kind)table.insert(hits.repairs,kind)end}
local mod=definitions.new(ctx)
local world={SetAttribute=function(self,name,value)self[name]=value end}
mod.world=world
local definitionTable=definitions.GetDefinitions()
for _,def in ipairs(definitionTable)do
  local controls={}
  for i=1,3 do
    controls[i]={knob={Position=vec(0,0,0),CFrame=CFrame.new(),Parent=true,Color='gray'},
     original=CFrame.new(),home='gray',dot={},prompt={}}
  end
  mod.devices[def.id]={definition=def,base={Position=vec(0,0,0)},buttons=controls,
      light={},display={}}
end
mod.water={Transparency=1,Size=vec(20,.08,15),Position=vec(26,-10.34,-120)}
local function eq(a,b,label)if a~=b then error(label..': expected '..tostring(b)..', got '..tostring(a))end end
local function step(id,i)
 now=now+1
 eq(mod:Interact(player,id,i),true,'stage '..i)
 for _,callback in ipairs(queue)do callback()end;queue={}
end
mod:BeginShift(1)
eq(mod:_snapshot().active,false,'no initial incident')
now=39;mod:Tick();eq(mod:_snapshot().active,false,'not early')
now=44;mod:Tick();eq(mod:_snapshot().id,'surge','first night surge only')
eq(world.NS43Incident,'surge','world replicated attribute')
now=now+1;eq(mod:Interact(player,'surge',1),false,'wrong stage rejected')
eq(mod.active.step,1,'wrong stage not advanced')
step('surge',2);step('surge',1);step('surge',3)
eq(mod.active,nil,'fixed incident cleared')
eq(#hits.repairs,3,'three stage contributions')
eq(hits.pressure,0,'no threat on correct sequence')
eq(world.NS43Incident,'','world cleared')
mod:EndShift();eq(mod.phase,'INTERMISSION','phase reset')
now=300;mod:Tick();eq(mod.active,nil,'no incident in intermission')
mod:BeginShift(2);now=now+43;mod:Tick()
eq(mod:_snapshot().id,'flood','second night flood')
eq(world.NS43WaterLeak,true,'water flagged')
now=now+22;mod:Tick()
assert(mod.water.Size.Y>.08,'water rises visually')
now=now+81;mod:Tick();eq(mod.active,nil,'timeout clears event')
eq(hits.pressure,1,'timeout may raise pressure once')
eq(world.NS43WaterLeak,false,'flood cleared')
mod:EndShift();eq(mod.water.Transparency,1,'water invisible after shift')
print('INCIDENT MOCK PASS: gated start, ordering, rewards, flood, timeout, phase, attributes')
