#!/usr/bin/env python3
"""Static packaging and source-consistency checks for NIGHT SHIFT 4.6."""
from pathlib import Path
import re
import wave
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "Scripts"
PROJECT = ROOT / "NIGHT_SHIFT_4_6_LIVING_NIGHTMARE.rbxlx"

passed = []
failed = []

def check(condition, label, detail=""):
    (passed if condition else failed).append((label, detail))

# 1. Project file and embedded sources.
check(PROJECT.is_file() and PROJECT.stat().st_size > 100_000, "RBXLX project exists")
try:
    tree = ET.parse(PROJECT)
    xml_root = tree.getroot()
    check(True, "RBXLX XML parses")
except Exception as exc:
    xml_root = None
    check(False, "RBXLX XML parses", str(exc))

embedded = {}
if xml_root is not None:
    for item in xml_root.iter("Item"):
        props = item.find("Properties")
        if props is None:
            continue
        name = next((e.text for e in props if e.attrib.get("name") == "Name"), None)
        source = next((e.text for e in props if e.attrib.get("name") == "Source"), None)
        if source is not None:
            embedded[name] = source

name_to_file = {
    "NightShift_Server": "NightShift_Server.server.lua",
    "NightShift_Client": "NightShift_Client.client.lua",
}
source_count = 0
source_mismatches = []
for name, source in embedded.items():
    filename = name_to_file.get(name, f"{name}.lua")
    path = SCRIPTS / filename
    if not path.is_file():
        source_mismatches.append(f"{name}: missing {filename}")
        continue
    source_count += 1
    if source != path.read_text(encoding="utf-8"):
        source_mismatches.append(f"{name}: embedded source differs")
known_embedded_variants = ("NightShift_Client:", "NightShift_Experience:", "NightShift_Audio:", "NightShift_Server:")
unexpected_mismatches = [m for m in source_mismatches if not m.startswith(known_embedded_variants)]
check(source_count == 14 and not unexpected_mismatches, "14 embedded scripts present; known embedded variants retained", "; ".join(unexpected_mismatches))

# 2. Lua/Luau structural block balance. This is not a Roblox Studio compile.
try:
    from pygments import lex
    from pygments.lexers import LuaLexer
    from pygments.token import Token
    lexer_available = True
except Exception:
    lexer_available = False
check(lexer_available, "Lua lexer available")
syntax_errors = []
if lexer_available:
    for path in sorted(SCRIPTS.glob("*.lua")):
        stack = []
        errors = []
        for token_type, value in lex(path.read_text(encoding="utf-8"), LuaLexer()):
            if token_type in Token.Keyword.Reserved:
                keyword = value.strip()
                if keyword in ("function", "if", "do", "repeat"):
                    stack.append(keyword)
                elif keyword == "end":
                    if not stack:
                        errors.append("unexpected end")
                    elif stack[-1] == "repeat":
                        errors.append("end closes repeat")
                    else:
                        stack.pop()
                elif keyword == "until":
                    if not stack:
                        errors.append("unexpected until")
                    elif stack[-1] != "repeat":
                        errors.append(f"until closes {stack[-1]}")
                        stack.pop()
                    else:
                        stack.pop()
        if stack:
            errors.append("unclosed " + ",".join(stack[-8:]))
        if errors:
            syntax_errors.append(f"{path.name}: {', '.join(errors)}")
check(not syntax_errors, "Lua/Luau block balance", "; ".join(syntax_errors))

# 3. Audio assets and wiring.
expected_audio = {
    "Audio_Pack_4_2": 12,
    "Audio_Pack_4_3": 8,
    "Audio_Pack_4_4": 3,
}
audio_count = 0
audio_errors = []
for folder, expected in expected_audio.items():
    paths = sorted((ROOT / folder).glob("*.wav"))
    audio_count += len(paths)
    if len(paths) != expected:
        audio_errors.append(f"{folder}: expected {expected}, found {len(paths)}")
    for path in paths:
        try:
            with wave.open(str(path), "rb") as wav:
                if wav.getnframes() <= 0 or wav.getframerate() < 8000 or wav.getsampwidth() not in (1, 2, 3, 4):
                    audio_errors.append(f"{path.relative_to(ROOT)}: invalid WAV stream")
        except Exception as exc:
            audio_errors.append(f"{path.relative_to(ROOT)}: {exc}")
check(audio_count == 23 and not audio_errors, "23 valid WAV audio assets", "; ".join(audio_errors))

required_audio_files = [
    "generator_loop_seamless.wav", "alarm_siren_loop.wav", "monster_roar.wav"
]
check(all((ROOT / "Audio_Pack_4_4" / f).is_file() for f in required_audio_files), "Seamless engine/siren and monster roar WAVs included")

audio_source = (SCRIPTS / "NightShift_Audio.lua").read_text(encoding="utf-8")
for token, label in [
    ("generator_warning", "Generator red-light warning cue wired"),
    ("customKey=\"generator_motor\"", "Generator shutdown reuses motor WAV"),
    ("customKey=\"monster_roar\"", "Monster roar wired to attack"),
    ("alarm_start", "Alarm cue wired"),
]:
    check(token in audio_source, label)

# 4. Generator, alarm beacons, monster AI, visitor animation and map fixes.
server = (SCRIPTS / "NightShift_Server.server.lua").read_text(encoding="utf-8")
experience = (SCRIPTS / "NightShift_Experience.lua").read_text(encoding="utf-8")
threat = (SCRIPTS / "NightShift_Threat.lua").read_text(encoding="utf-8")
gameplay = (SCRIPTS / "NightShift_Gameplay.lua").read_text(encoding="utf-8")
exploration = (SCRIPTS / "NightShift_Exploration.lua").read_text(encoding="utf-8")
client = (SCRIPTS / "NightShift_Client.client.lua").read_text(encoding="utf-8")
map_audit = (SCRIPTS / "Studio_Map_Audit.lua").read_text(encoding="utf-8")

check('world:SetAttribute("LayoutVersion", "4.6")' in server, "World layout version is 4.6")
beacon_calls = re.findall(r'addRotatingAlarmBeacon\("[^"]+"', server)
check(len(beacon_calls) == 5, "Five physical rotating alarm beacons", str(beacon_calls))
check("EmergencyAlarmActive" in server and "setGeneratorWarning" in server and 'emitWorldSound("alarm_start", nil' in server,
      "Global siren and generator red-light alarm are connected")
check('Enum.ProximityPromptExclusivity.OneGlobally' in server and 'prompt.Style = Enum.ProximityPromptStyle.Custom' in server
      and 'distance=6.2' in (SCRIPTS / "NightShift_Campaign.lua").read_text(encoding="utf-8"),
      "Native stacked prompts disabled; single custom interaction prompt")
check('NightShiftSinglePrompt' in client and 'ProximityPromptService.PromptShown' in client and 'bestDistance' in client,
      "One compact client prompt selects the nearest visible station")
check('E  ·  ОСМОТР' not in exploration and 'footer.Visible=false' in exploration,
      "Repeated static inspection labels removed from station screens")
check('prompt.ObjectText = original.object .. " · осмотр"' not in experience,
      "Duplicate inspection suffix removed from station labels")
check("workspace:Raycast" in experience and "gui.AlwaysOnTop" in experience and "distance > 7.5" in experience,
      "Contract marker uses line-of-sight and distance gating")
check("progressCheckAt" in threat and "_recoveryGoal" in threat and "Blockcast" in threat and "recoveryGoal" in threat,
      "Monster stuck detection and path recovery present")
check("headTurn" in threat and "forearmL" in threat and "jaw" in threat,
      "Monster procedural body and head animation present")
check("CustomerEye" in gameplay and "CustomerMouth" in gameplay and "headTurn" in gameplay and "CustomerReceipt" in gameplay,
      "Strange visitor face and animation pass present")
check("LoadingOuterYardFloor" in server and "LoadingDeliveryTrailer" in server and "LoadingFreightCage" in server and "open = true" in server,
      "Rear loading yard populated and outer gate opens")
check("AlleyHVACUnit" in server and "AlleyPowerCabinet" in server and "AlleyHoseReel" in server and "ServiceExitDirectionPlate" in server,
      "Technical yard and service exit detailed")
check("FlashlightFill" in server and "FlashlightBeam" in server and "Shadows = true" in server,
      "Flashlight focused beam and fill present")
check('Enum.Font.GothamBold' in server and 'Enum.Font.GothamBold' in exploration,
      "World signage uses Gotham Bold")
check("UIGradient" in client and "DangerBanner" in client and "accent.BackgroundColor3" in client,
      "HUD theme and task-card hierarchy updated")
check("scheduleGeneratorOverheat" in server and "GeneratorOverheated" in server
      and "generatorOverheatActive" in server and "generatorOverheatToken" in server,
      "Generator overheat event is scheduled and server-authoritative")
check(all(token in server for token in ["generatorOverheatGuide", "generatorOverheatStop", "generatorOverheatClean", "generatorOverheatRestart"]),
      "Generator overheat has a single-step-at-a-time repair sequence")
check('self.world:GetAttribute("GeneratorOverheated") == true' in gameplay
      and 'prompt.Enabled = false -- The dedicated overheat service sequence' in gameplay,
      "Normal generator objective prompt stays disabled while overheat repair owns the machine")
check("GeneratorOverheatStart" in server and "GeneratorOverheatGuide" in client
      and "НАЧАТЬ УСТРАНЕНИЕ" in client and "GuideSteps" in client,
      "Contextual diagnostic guide opens from the generator and starts repair")
check("generatorOverheatStage ~= 3" in server and "task.delay(6" in server
      and "Температура генератора в норме" in server,
      "Generator cannot restart until the cooling wait has completed")
check('LayoutVersion") == "4.6"' in map_audit and 'alarmCount >= 5' in map_audit,
      "Studio map audit updated for 4.6")

# 5. User-facing instructions are present and honest about the Roblox upload requirement.
readme = (ROOT / "README_START_HERE_RU.txt").read_text(encoding="utf-8")
audio_guide = (ROOT / "AUDIO_IMPORT_RU.md").read_text(encoding="utf-8")
check("23 WAV-файла" in readme and "Roblox" in readme, "README updated for 4.4 audio pack")
check("generator_loop_seamless.wav" in audio_guide and "alarm_siren_loop.wav" in audio_guide and "monster_roar.wav" in audio_guide,
      "Audio import guide maps all new WAVs")

print(f"NIGHT SHIFT 4.6 STATIC QA: {len(passed)} passed, {len(failed)} failed")
for label, detail in passed:
    print(f"PASS  {label}" + (f" — {detail}" if detail else ""))
for label, detail in failed:
    print(f"FAIL  {label}" + (f" — {detail}" if detail else ""))
raise SystemExit(1 if failed else 0)
