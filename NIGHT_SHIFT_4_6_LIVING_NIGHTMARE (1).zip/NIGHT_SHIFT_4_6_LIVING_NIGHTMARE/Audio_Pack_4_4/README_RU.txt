NIGHT SHIFT 4.4 — AUDIO PACK

monster_roar.wav — оригинальный синтезированный низкий рёв для атаки монстра.
generator_loop_seamless.wav — бесшовная версия звука работающего двигателя, подготовленная для циклического воспроизведения.
alarm_siren_loop.wav — бесшовная версия сирены, подготовленная для циклического воспроизведения во время красной тревоги.

Формат всех WAV: PCM, mono, 32/44.1 kHz, 16 bit.
Импортируйте файлы через Roblox Studio Asset Manager и внесите выданные ID в CUSTOM_AUDIO_IDS модуля ReplicatedStorage/NightShift_Audio.
