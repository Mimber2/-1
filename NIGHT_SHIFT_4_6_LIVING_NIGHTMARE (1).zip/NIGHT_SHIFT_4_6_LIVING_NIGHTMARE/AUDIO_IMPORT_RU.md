# Как подключить оригинальные звуки к NIGHT SHIFT 4.4

**Важно:** WAV-файлы внутри ZIP — это исходные аудиофайлы, а не Roblox SoundId. Roblox не воспроизводит локальные WAV из архива напрямую. Чтобы генератор, сирена и монстры звучали подготовленными аудиофайлами, WAV нужно импортировать в Roblox от имени владельца опыта или группы.

## Импорт

1. Откройте проект `NIGHT_SHIFT_4_4_LIVING_NIGHTMARE.rbxlx` в Roblox Studio.
2. Войдите под аккаунтом/группой, которая владеет опытом и имеет право загружать аудио.
3. Откройте **Asset Manager** и импортируйте WAV из `Audio_Pack_4_2`, `Audio_Pack_4_3` и `Audio_Pack_4_4`.
4. Скопируйте числовые ID каждого загруженного Audio Asset.
5. Откройте `ReplicatedStorage > NightShift_Audio` и найдите таблицу `CUSTOM_AUDIO_IDS` в начале модуля.
6. Замените `0` напротив нужного имени на числовой ID без кавычек и без `rbxassetid://`.
7. Опубликуйте изменения и проверьте звуки в Play. Если звук не загружается, проверьте Output и права доступа к ассету.

Пример заполнения (числа ниже условные, используйте свои ID):

```lua
local CUSTOM_AUDIO_IDS = {
    generator_start = 1234567890,
    generator_motor = 1234567891,
    alarm_start = 1234567892,
    fear_sting = 1234567893,
    monster_roar = 1234567898,
    crawler_scrape = 1234567894,
    mimic_voice = 1234567895,
    monster_breath = 1234567896,
    player_death = 1234567897,
}
```

## Основные соответствия

Для двигателя и сирены используйте именно бесшовные файлы из `Audio_Pack_4_4`. Исходные `generator_loop.wav` и `alarm_siren.wav` из `Audio_Pack_4_2` оставлены в архиве как исходные версии, но в проекте на них заменены бесшовные варианты.

| WAV | Поле `CUSTOM_AUDIO_IDS` | Где используется |
|---|---|---|
| `Audio_Pack_4_2/generator_start.wav` | `generator_start` | Стартер; также автоматическое восстановление питания |
| `Audio_Pack_4_4/generator_loop_seamless.wav` | `generator_motor` | Бесшовная непрерывная работа двигателя |
| `Audio_Pack_4_4/alarm_siren_loop.wav` | `alarm_start` | Бесшовная зацикленная сирена во время красной тревоги |
| `Audio_Pack_4_2/crawler_scrape.wav` | `crawler_scrape` | Ползущий монстр, скрежет и поиск |
| `Audio_Pack_4_2/mimic_voice.wav` | `mimic_voice` | Искажённый голос Имитатора |
| `Audio_Pack_4_2/monster_breath.wav` | `monster_breath` | Дыхание и фоновый звук преследования |
| `Audio_Pack_4_2/fear_sting.wav` | `fear_sting` | Резкий страшный акцент под рёв |
| `Audio_Pack_4_4/monster_roar.wav` | `monster_roar` | Новый оригинальный низкий рёв монстра при атаке |
| `Audio_Pack_4_2/player_death.wav` | `player_death` | Смерть игрока |
| `Audio_Pack_4_2/ambience_store.wav` | `room_tone` | Атмосфера магазина |
| `Audio_Pack_4_2/ambience_basement.wav` | `basement_tone` | Атмосфера подвала |
| `Audio_Pack_4_2/interaction_knock.wav` | `interaction_knock` | Удары по шкафу/оборудованию |
| `Audio_Pack_4_2/relay_glitch.wav` | `relay_glitch` | Электрические помехи |
| `Audio_Pack_4_3/incident_surge.wav` | `incident_surge` | Перегрев генератора |
| `Audio_Pack_4_3/incident_flood.wav` | `incident_flood` | Протечка/насосная |
| `Audio_Pack_4_3/incident_camera.wav` | `incident_camera` | Сбой камер |
| `Audio_Pack_4_3/incident_radio.wav` | `incident_radio` | Радиосигнал |
| `Audio_Pack_4_3/incident_archive.wav` | `incident_archive` | Сигнал архива |
| `Audio_Pack_4_3/incident_step.wav` | `incident_step` | Шаги/события |
| `Audio_Pack_4_3/incident_wrong.wav` | `incident_wrong` | Ошибочное действие на панели |
| `Audio_Pack_4_3/incident_done.wav` | `incident_done` | Успешное завершение происшествия |

## Что работает до импорта

- Запуск и остановка генератора используют многослойные механические звуки, низкий гул и затухание. При заполненном `generator_start` и `generator_motor` включаются оригинальные записи стартера и двигателя.
- Красная тревога зацикливает `alarm_siren_loop.wav` и одновременно запускает вращающиеся физические маяки. Красный индикатор генератора отдельно даёт короткое двухимпульсное предупреждение (использует два коротких фрагмента `alarm_siren_loop.wav`) и медленно пульсирует маяком генераторной. Если ID не заполнен, используется резервный сигнал.
- Преследование использует дыхание как повторяющийся слой; атака соединяет новый `monster_roar.wav` с `fear_sting`, а отдельные виды монстров — скрежет и искажённый голос.
- `generator_stop` повторно использует `generator_loop_seamless.wav` с понижением высоты тона и затуханием; отдельного WAV остановки в паке нет. `powerDown` добавляет короткий звук реле.

**Ни один ID не был придуман или подставлен за владельца.** Пока поля равны нулю, используется резервный звук. Чтобы услышать именно подготовленные звуки из WAV, нужно завершить импорт в своём Roblox Creator Dashboard.
