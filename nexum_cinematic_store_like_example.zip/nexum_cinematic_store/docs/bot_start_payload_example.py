# Пример обработки перехода с сайта:
# https://t.me/ТВОЙ_БОТ?start=shop_player_pack
#
# Это НЕ обязательный файл для сайта. Это подсказка, что добавить в бота.

from aiogram.filters import CommandStart
from aiogram.types import Message, LabeledPrice

SHOP_PRODUCTS = {
    "starter_pack": {
        "title": "🔥 Стартовый набор",
        "description": "100 гемов, 300 энергии, 1 редкий кейс, бейдж «Первый донатер»",
        "stars": 49,
    },
    "player_pack": {
        "title": "⚡ Набор игрока",
        "description": "400 гемов, 700 энергии, 2 редких кейса",
        "stars": 299,
    },
    "legend_pack": {
        "title": "👑 Набор легенды",
        "description": "1200 гемов, 2000 энергии, 5 редких кейсов, рамка профиля",
        "stars": 799,
    },
    "premium_30": {
        "title": "👑 Premium 30 дней",
        "description": "30 дней Premium, ежедневный бонус, рамка и статус",
        "stars": 399,
    },
    "battle_pass": {
        "title": "🎟 Premium Battle Pass",
        "description": "Премиум-линия сезонных наград",
        "stars": 499,
    },
}

@router.message(CommandStart())
async def start_handler(message: Message):
    # Для aiogram 3 можно получить аргумент так:
    parts = (message.text or "").split(maxsplit=1)
    start_arg = parts[1] if len(parts) > 1 else ""

    if start_arg.startswith("shop_"):
        product_id = start_arg.replace("shop_", "", 1)
        product = SHOP_PRODUCTS.get(product_id)

        if not product:
            await message.answer("Товар не найден. Открой каталог заново.")
            return

        await message.answer_invoice(
            title=product["title"],
            description=product["description"],
            payload=f"shop_pay_{product_id}_{message.from_user.id}",
            provider_token="",  # для Telegram Stars оставить пустым
            currency="XTR",
            prices=[LabeledPrice(label=product["title"], amount=product["stars"])],
        )
        return

    await message.answer("Добро пожаловать в Nexum Game!")
