Nexum Cinematic Store

Сделано по примеру загруженного index(8).html:
- preloader
- progress bar
- fixed glass navigation
- dark/light theme toggle
- aura following cursor
- cinematic hero
- WebGL/Three.js 3D scenes
- animated cards
- catalog, filters, search
- product modal
- cart in localStorage
- interactive recommendation builder
- FAQ accordion
- Telegram deep-links for buying

Как подключить своего бота:
1. Открой index.html
2. Внизу найди:
   const BOT_USERNAME = "your_bot_username";
3. Замени your_bot_username на username своего бота без @.

Пример:
const BOT_USERNAME = "NexumGameBot";

Как работает покупка:
Кнопки формируют ссылку:
https://t.me/ТВОЙ_БОТ?start=shop_ID

Примеры:
https://t.me/NexumGameBot?start=shop_player_pack
https://t.me/NexumGameBot?start=shop_premium_30
https://t.me/NexumGameBot?start=shop_battle_pass

В боте нужно обработать start-параметр shop_ID и показать invoice Telegram Stars.

Товары:
- assets/products.json.js

Картинки товаров:
- assets/products/*.svg

Важно:
Оплата Telegram Stars не может проходить прямо на обычном сайте. Она должна проходить внутри Telegram-бота. Сайт является красивой витриной и отправляет пользователя в бота с выбранным товаром.
