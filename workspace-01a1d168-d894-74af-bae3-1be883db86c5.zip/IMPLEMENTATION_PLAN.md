# Orchestrator Implementation & QA Plan — Екатерина Пименова (3D Gastronomic & Clinical Nutrition WebGL Experience)

## 1. Visual & Spatial Direction (5-Chapter Culinary & Porcelain 3D Engine)
Every chapter features photorealistic + sculptural 3D gastronomic compositions (`LatheGeometry` clearcoated stoneware/porcelain plates with brushed-gold rims, domed gourmet salad shader with smooth rotation & crossfade, 3D-curved RGBA botanical cutouts, and luminous extra-virgin olive-oil droplets):
- **Chapter 01 (`0.00–0.205`) — Тарелка (Morning Sunlit Linen)**: Tilted 3D porcelain Mediterranean wild-salmon, avocado & soft-egg salad plate over warm sunlit linen (`#FAF7F0 -> #EDE5D5`) with deep-espresso `#161814` typography, brushed-brass orbit ring, levitating avocado/basil/cherry-tomato/broccoli/blueberry cutouts, and golden olive-oil droplets.
- **Culinary Bridge (`0.145–0.275`)**: Floating stream of fresh basil leaves, Hass avocado, cherry tomato, and blueberries alongside kinetic typography (`«Еда как биохимия — вкусно и сытно, без голода и запретов»`).
- **Chapter 02 (`0.25–0.455`) — Физиологические оптимумы**: Interactive 3D Clinical Plate Turntable over warm chef's-table charcoal (`#0B0E0A`) with Harvard `50% / 25% / 25%` proportion ring and 5 orbiting ingredients. Clicking any biomarker tab (`Ферритин`, `ТТГ`, `Витамин D`, `Инсулин`) spins the 3D porcelain plate and crossfades across 4 targeted gourmet meals (`plate-mediterranean.jpg`, `plate-vitality-greens.jpg`, `plate-avocado-bowl.jpg`, `plate-berry-family.jpg`).
- **Chapter 03 (`0.445–0.715`) — Программы и цены**: Curved 3D gastronomic ribbon of all 6 clinical offerings with warm champagne frames, swipe/drag inertia, soft scroll snap, and floating herb accents.
- **Chapter 04 (`0.70–0.91`) — Рационы и кейсы**: 4-plate 3D Chef's Tasting Carousel synced to the 4 clinical routes (`01 Энергия`, `02 Стройность`, `03 Дети`, `04 Беременность`) paired with verified `Точка А → Результат` biomarker deltas.
- **Chapter 05 (`0.895–1.00`) — Диагностика в Zoom (0 ₽)**: Signature 3D porcelain Mediterranean plate positioned cleanly on the right (desktop) or upper-center hero niche (mobile) with zero text overlap, paired with instant Zoom/Telegram/WhatsApp/MAX booking.

## 2. Preserved Functional & Mobile Requirements
- Specialist identity: **Екатерина Пименова** (`ИП Пименова Екатерина`).
- Sound button: **Completely absent** (`0` audio controls).
- Full mobile support (`360×800`, `375×667`, `390×844`): `100dvh` stage, safe-area insets, compact header (`Екатерина Пименова` + `Меню` + `Запись 0 ₽`), `>=16px` drawer inputs, direction-locked Chapter 3 touch swipe, and standalone single-file `/home/user/nutriciolog-site.html` with all 13 `.jpg` + `.webp` assets embedded.
