import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Sparkles,
  Layers,
  Award,
  Send,
  PhoneCall,
  Settings,
  Sliders,
  Menu,
} from 'lucide-react';
import {
  BrandProfile,
  DEFAULT_BRAND,
  SERVICES,
  QUICK_BOOKING,
  BIOMARKERS,
  CASE_REVIEWS,
  SPECIALIST_PHOTOS,
  resolveAssetUrl,
} from './data/siteConfig';
import { CinemaWebGLEngine, RibbonCardSpec } from './components/CinemaWebGLEngine';
import { ConciergeDrawers, DrawerType } from './components/ConciergeDrawers';

const BRAND_STORAGE_KEY = 'nutri_cinema_brand_v4';

function bandOpacity(p: number, inStart: number, inEnd: number, outStart: number, outEnd: number) {
  const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
  const fadeIn = inStart === inEnd ? 1 : clamp01((p - inStart) / (inEnd - inStart));
  const fadeOut = outStart === outEnd ? 1 : 1 - clamp01((p - outStart) / (outEnd - outStart));
  return fadeIn * fadeOut;
}

const GLYPHS = 'АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЭЮЯ0123456789';
function useKineticScramble(text: string): string {
  const [display, setDisplay] = useState(text);
  useEffect(() => {
    let frame = 0;
    const total = 12;
    const id = window.setInterval(() => {
      frame++;
      if (frame >= total) {
        setDisplay(text);
        window.clearInterval(id);
        return;
      }
      const revealCount = Math.floor((frame / total) * text.length);
      let next = '';
      for (let i = 0; i < text.length; i++) {
        if (text[i] === ' ' || i < revealCount) {
          next += text[i];
        } else {
          next += GLYPHS[(i * 7 + frame * 3) % GLYPHS.length];
        }
      }
      setDisplay(next);
    }, 24);
    return () => window.clearInterval(id);
  }, [text]);
  return display;
}

const PLATE_NUTRITION_NOTES = [
  'На тарелке: дикий лосось, шпинат, яйцо и семена тыквы (гемовое железо + кофакторы)',
  'На тарелке: грецкий орех, зелень, свёкла и ягоды (селен, антиоксиданты и поддержка ЩЖ)',
  'На тарелке: яйцо пашот, авокадо, зелень и семена (усвоение жирорастворимых витаминов)',
  'На тарелке: индейка, брокколи, киноа и ягоды (ровный инсулиновый и гликемический отклик)',
];

export function App() {
  const [brand, setBrand] = useState<BrandProfile>(() => {
    try {
      const saved = localStorage.getItem(BRAND_STORAGE_KEY);
      return saved ? { ...DEFAULT_BRAND, ...JSON.parse(saved) } : DEFAULT_BRAND;
    } catch {
      return DEFAULT_BRAND;
    }
  });

  const handleSaveBrand = (next: BrandProfile) => {
    setBrand(next);
    try {
      localStorage.setItem(BRAND_STORAGE_KEY, JSON.stringify(next));
    } catch {
      // ignore storage errors in restricted webviews
    }
  };

  const handleResetBrand = () => {
    setBrand(DEFAULT_BRAND);
    try {
      localStorage.removeItem(BRAND_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const scrollProgressRef = useRef(0);
  const scrollVelocityRef = useRef(0);
  const ribbonDragVelRef = useRef(0);
  const [progress, setProgress] = useState(0);
  const [velocity, setVelocity] = useState(0);

  const [activeBioIdx, setActiveBioIdx] = useState(0);
  const [drawer, setDrawer] = useState<DrawerType>(null);
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(SERVICES[0].id);
  const [bookingPrefill, setBookingPrefill] = useState<{ title: string; message: string }>({
    title: SERVICES[0].title,
    message: SERVICES[0].prefillMessage,
  });

  const dragStateRef = useRef<{
    active: boolean;
    intent: 'undecided' | 'horizontal' | 'vertical';
    pointerId: number;
    startX: number;
    startY: number;
    lastX: number;
    moved: number;
    momentumPx: number;
  }>({
    active: false,
    intent: 'undecided',
    pointerId: -1,
    startX: 0,
    startY: 0,
    lastX: 0,
    moved: 0,
    momentumPx: 0,
  });

  const ribbonCards: RibbonCardSpec[] = useMemo(
    () => [
      {
        id: SERVICES[0].id,
        num: '01',
        tag: 'Консультация · Взрослый или ребёнок',
        price: SERVICES[0].price,
        titleLines: ['Персональная консультация', '(взрослый или ребёнок)'],
        subtitle:
          'Разбор анализов, онлайн-встреча 1,5–2 часа, вкусный рацион, схема и 7 дней связи в чате',
        imageSrc: SPECIALIST_PHOTOS.consult,
        portraitMode: true,
        specialistBadge: 'Флагманский формат',
      },
      {
        id: SERVICES[1].id,
        num: '02',
        tag: 'Семейный формат',
        price: SERVICES[1].price,
        titleLines: ['Консультация', '«Мама + ребёнок»'],
        subtitle:
          'Две персональные программы, единый вкусный семейный стол и крепкий иммунитет ребёнка',
        imageSrc: '/images/family-nutrition.jpg',
      },
      {
        id: SERVICES[2].id,
        num: '03',
        tag: 'Личная работа за руку · 1 месяц',
        price: SERVICES[2].price,
        titleLines: ['Индивидуальное', 'ведение'],
        subtitle:
          'Ежедневная обратная связь в чате, 4 личные встречи, настройка рациона (вкл. беременность)',
        imageSrc: SPECIALIST_PHOTOS.mentoring,
        portraitMode: true,
        specialistBadge: 'Ежедневное ведение',
      },
      {
        id: SERVICES[3].id,
        num: '04',
        tag: 'Практическое пособие + чат',
        price: SERVICES[3].price,
        titleLines: ['Гайд', 'для детей и взрослых'],
        subtitle:
          'Готовые возрастные схемы поддержки иммунитета, первые часы при ОРВИ и ответы в чате',
        imageSrc: '/images/plate-vitality-greens.jpg',
      },
    ],
    []
  );

  // Main 60fps scroll & drag-inertia loop
  useEffect(() => {
    let lastScrollY = window.scrollY;
    let lastTime = performance.now();
    let raf = 0;

    const update = () => {
      const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);

      const ds = dragStateRef.current;
      if (!ds.active && Math.abs(ds.momentumPx) > 0.25) {
        const minBandY = 0.458 * maxScroll;
        const maxBandY = 0.682 * maxScroll;
        const nextY = Math.max(minBandY, Math.min(maxBandY, window.scrollY + ds.momentumPx));
        window.scrollTo(0, nextY);
        ds.momentumPx *= 0.91;
      } else if (!ds.active) {
        ds.momentumPx = 0;
      }

      ribbonDragVelRef.current *= 0.88;

      const rawP = Math.max(0, Math.min(1, window.scrollY / maxScroll));
      const now = performance.now();
      const dt = Math.max(16, now - lastTime);
      const dy = window.scrollY - lastScrollY;
      const instVel = (dy / dt) * 0.45;

      const alpha = Math.min(1, 1 - Math.exp(-dt * 0.015));
      scrollProgressRef.current += (rawP - scrollProgressRef.current) * alpha;
      scrollVelocityRef.current += (instVel - scrollVelocityRef.current) * 0.16;
      scrollVelocityRef.current *= 0.9;

      lastScrollY = window.scrollY;
      lastTime = now;

      setProgress(scrollProgressRef.current);
      setVelocity(scrollVelocityRef.current);

      raf = requestAnimationFrame(update);
    };

    raf = requestAnimationFrame(update);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Soft Magnetic Scene Snap (rescues crossfade gaps between chapters)
  useEffect(() => {
    if (drawer) return;
    let timerId: number | null = null;

    const onScroll = () => {
      if (timerId !== null) window.clearTimeout(timerId);
      timerId = window.setTimeout(() => {
        if (dragStateRef.current.active) return;
        const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
        const p = window.scrollY / maxScroll;

        const snapZones: [number, number, number][] = [
          [0.132, 0.168, 0.208],
          [0.246, 0.272, 0.335],
          [0.432, 0.458, 0.475],
          [0.692, 0.718, 0.750],
          [0.888, 0.918, 0.965],
        ];

        for (const [zStart, zEnd, anchor] of snapZones) {
          if (p >= zStart && p <= zEnd) {
            window.scrollTo({ top: anchor * maxScroll, behavior: 'smooth' });
            break;
          }
        }
      }, 750);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (timerId !== null) window.clearTimeout(timerId);
    };
  }, [drawer]);

  const scrollToProgress = (targetP: number) => {
    const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    window.scrollTo({
      top: targetP * maxScroll,
      behavior: 'smooth',
    });
  };

  const openBooking = (title: string, message: string) => {
    setBookingPrefill({ title, message });
    setDrawer('booking');
  };

  const handleServiceDetail = (serviceId: string) => {
    if (serviceId === '__back_catalog__') {
      setDrawer('catalog');
      return;
    }
    setSelectedServiceId(serviceId);
    setDrawer('service-detail');
  };

  // Direction-locked Drag / Swipe handlers
  const onRibbonPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    dragStateRef.current = {
      active: true,
      intent: e.pointerType === 'mouse' ? 'horizontal' : 'undecided',
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      lastX: e.clientX,
      moved: 0,
      momentumPx: 0,
    };
    if (e.pointerType === 'mouse') {
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    }
  };

  const onRibbonPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const ds = dragStateRef.current;
    if (!ds.active || ds.intent === 'vertical') return;

    const totalDx = e.clientX - ds.startX;
    const totalDy = e.clientY - ds.startY;

    if (ds.intent === 'undecided') {
      if (Math.hypot(totalDx, totalDy) < 9) return;
      if (Math.abs(totalDy) >= Math.abs(totalDx)) {
        ds.intent = 'vertical';
        ds.active = false;
        return;
      }
      ds.intent = 'horizontal';
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    }

    const dx = e.clientX - ds.lastX;
    ds.lastX = e.clientX;
    ds.moved += Math.abs(dx);

    const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    const ribbonBandPx = 0.22 * maxScroll;
    const scrollDelta = (-dx / Math.max(280, window.innerWidth * 0.55)) * (ribbonBandPx * 0.36);

    const minBandY = 0.458 * maxScroll;
    const maxBandY = 0.682 * maxScroll;
    const nextY = Math.max(minBandY, Math.min(maxBandY, window.scrollY + scrollDelta));

    window.scrollTo(0, nextY);
    ds.momentumPx = scrollDelta * 0.85;
    ribbonDragVelRef.current = -dx / 24;
  };

  const onRibbonPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const ds = dragStateRef.current;
    if (!ds.active) return;
    ds.active = false;
    try {
      if (e.currentTarget.hasPointerCapture?.(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {
      // ignore
    }
    const totalDist = Math.hypot(e.clientX - ds.startX, e.clientY - ds.startY);
    if (totalDist < 8 && ds.moved < 10) {
      handleServiceDetail(activeRibbonCard.id);
    }
  };

  const ch1Opacity = bandOpacity(progress, 0.0, 0.0, 0.12, 0.165);
  const echoOpacity = bandOpacity(progress, 0.17, 0.195, 0.228, 0.252);
  const ch2Opacity = bandOpacity(progress, 0.262, 0.298, 0.398, 0.432);
  const ch3Opacity = bandOpacity(progress, 0.435, 0.456, 0.682, 0.706);
  const ch4Opacity = bandOpacity(progress, 0.71, 0.745, 0.865, 0.898);
  const ch5Opacity = bandOpacity(progress, 0.908, 0.945, 1.0, 1.0);

  const ribbonLocal = Math.max(0, Math.min(1, (progress - 0.46) / 0.22));
  const activeRibbonIdx = Math.min(
    ribbonCards.length - 1,
    Math.max(0, Math.round(ribbonLocal * (ribbonCards.length - 1)))
  );
  const activeRibbonCard = ribbonCards[activeRibbonIdx];

  const terrainLocal = Math.max(0, Math.min(0.999, (progress - 0.72) / 0.16));
  const terrainPresetIdx = Math.floor(terrainLocal * 4);
  const terrainPresets = [
    {
      code: 'РАЦИОН 01  //  ЭНЕРГИЯ И ЖЕЛЕЗОДЕФИЦИТ',
      headline: 'Возврат утренней бодрости и ресурса',
      caseItem: CASE_REVIEWS[0],
    },
    {
      code: 'РАЦИОН 02  //  МЕТАБОЛИЗМ И ЛЁГКИЙ ЖКТ',
      headline: 'Стройность и сытость без диет',
      caseItem: CASE_REVIEWS[5],
    },
    {
      code: 'РАЦИОН 03  //  ОБЩИЙ СТОЛ МАМЫ И РЕБЁНКА',
      headline: 'Сезон сада без вечных больничных',
      caseItem: CASE_REVIEWS[2],
    },
    {
      code: 'РАЦИОН 04  //  БЕРЕМЕННОСТЬ И ОПОРА',
      headline: 'Спокойное ведение все 3 триместра',
      caseItem: CASE_REVIEWS[3],
    },
  ];
  const currentPreset = terrainPresets[terrainPresetIdx] || terrainPresets[0];
  const scrambledHeadline = useKineticScramble(currentPreset.headline);
  const primaryDelta = currentPreset.caseItem.labDelta[0];

  const activeBio = BIOMARKERS[activeBioIdx] || BIOMARKERS[0];
  const plateNote = PLATE_NUTRITION_NOTES[activeBioIdx] || PLATE_NUTRITION_NOTES[0];

  const encodedQuickTg = encodeURIComponent(QUICK_BOOKING.prefillMessage);
  const tgDirect = `https://t.me/${brand.telegramUsername.replace('@', '')}?text=${encodedQuickTg}`;
  const waDirect = `https://wa.me/${brand.whatsappPhone.replace(/\D/g, '')}?text=${encodedQuickTg}`;

  return (
    <div className="relative min-h-[640vh] select-none bg-[#F0E7D5] text-[#1C2833]">
      {/* 2px TOP PRECISION PROGRESS HAIRLINE */}
      <div className="fixed top-0 inset-x-0 h-[2px] z-40 pointer-events-none bg-[#1C2833]/8">
        <div
          className="h-full bg-[#0F5A4A] transition-all duration-150"
          style={{ width: `${Math.max(2, progress * 100)}%` }}
        />
      </div>

      {/* FULL-VIEWPORT REAL-TIME 3D CULINARY & PORCELAIN WORLD */}
      <CinemaWebGLEngine
        scrollProgressRef={scrollProgressRef}
        scrollVelocityRef={scrollVelocityRef}
        ribbonDragVelRef={ribbonDragVelRef}
        activeBiomarkerIdx={activeBioIdx}
        ribbonCards={ribbonCards}
      />

      {/* TOP FLOATING NAVIGATION CAPSULE */}
      <header className="fixed top-0 sm:top-3 inset-x-0 z-30 px-3 sm:px-8 safe-top pointer-events-none">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-1.5 sm:gap-3">
          <button
            onClick={() => scrollToProgress(0)}
            className="pointer-events-auto shrink-0 pl-1.5 pr-3 sm:pl-2 sm:pr-4 py-1.5 sm:py-2 rounded-full whitespace-nowrap studio-glass-light text-[#1C2833] hover:bg-white/95 transition flex items-center gap-1.5 sm:gap-2.5"
          >
            <span className="relative shrink-0">
              <img
                src={resolveAssetUrl(SPECIALIST_PHOTOS.hero)}
                alt={brand.name}
                className="w-5 h-5 sm:w-6 sm:h-6 rounded-full object-cover object-[50%_18%] ring-1 ring-[#0F5A4A]/25"
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full ring-1 ring-[#F9F6F0] bg-[#0F5A4A]" />
            </span>
            <span className="text-[11px] sm:text-sm font-semibold tracking-tight">{brand.name}</span>
          </button>

          <nav className="hidden xl:flex pointer-events-auto items-center gap-0.5 px-2 py-1.5 rounded-full whitespace-nowrap studio-glass-light text-[#1C2833]">
            {[
              { label: 'Главная', p: 0.0 },
              { label: 'Оптимумы', p: 0.335 },
              { label: 'Консультации', p: 0.46 },
              { label: 'Рационы и кейсы', p: 0.78 },
              { label: 'Запись', p: 0.965 },
            ].map((item) => (
              <button
                key={item.label}
                onClick={() => scrollToProgress(item.p)}
                className="px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap shrink-0 hover:bg-[#0F5A4A]/10 hover:text-[#0F5A4A] transition"
              >
                {item.label}
              </button>
            ))}
            <span className="w-px h-3.5 mx-1 shrink-0 bg-[#1C2833]/15" />
            <button
              onClick={() => setDrawer('catalog')}
              className="px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap shrink-0 hover:bg-[#0F5A4A]/10 hover:text-[#0F5A4A] transition"
            >
              Все тарифы
            </button>
            <button
              onClick={() => setDrawer('cases')}
              className="px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap shrink-0 hover:bg-[#0F5A4A]/10 hover:text-[#0F5A4A] transition"
            >
              Дипломы и FAQ
            </button>
          </nav>

          <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              onClick={() => setDrawer('mobile-menu')}
              aria-label="Открыть меню навигации"
              className="xl:hidden inline-flex items-center gap-1.5 px-2.5 py-2 rounded-full whitespace-nowrap text-[11px] font-medium studio-glass-light text-[#1C2833]"
            >
              <Menu className="w-3.5 h-3.5 text-[#0F5A4A]" />
              Меню
            </button>

            <button
              onClick={() => setDrawer('quiz')}
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full whitespace-nowrap text-xs font-medium studio-glass-light text-[#1C2833] hover:bg-white transition"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#0F5A4A]" />
              Подбор за{'\u00A0'}30{'\u00A0'}сек
            </button>

            <button
              onClick={() => openBooking(QUICK_BOOKING.title, QUICK_BOOKING.prefillMessage)}
              className="px-3.5 sm:px-5 py-2 sm:py-2.5 rounded-full whitespace-nowrap text-[11px] sm:text-xs font-semibold num-tabular btn-brand-gold"
            >
              Записаться
            </button>
          </div>
        </div>
      </header>

      {/* RIGHT-EDGE VERTICAL PRECISION CHAPTER SCRUBBER */}
      <aside className="hidden md:flex fixed right-6 top-1/2 -translate-y-1/2 z-30 flex-col items-end gap-3 pointer-events-auto">
        {[
          { num: '01', name: 'Главная', p: 0.0 },
          { num: '02', name: 'Оптимумы', p: 0.335 },
          { num: '03', name: 'Консультации', p: 0.46 },
          { num: '04', name: 'Рационы', p: 0.78 },
          { num: '05', name: 'Записаться', p: 0.96 },
        ].map((ch, idx, arr) => {
          const nextP = arr[idx + 1]?.p ?? 1.01;
          const isCurrent = progress >= ch.p - 0.06 && progress < nextP - 0.06;
          return (
            <button
              key={ch.num}
              onClick={() => scrollToProgress(ch.p)}
              className="group flex items-center gap-2.5 text-right"
              title={ch.name}
            >
              <span
                className={`text-[10px] uppercase tracking-[0.18em] transition-all px-2.5 py-0.5 rounded-full ${
                  isCurrent
                    ? 'opacity-0 2xl:opacity-100 group-hover:opacity-100 text-[#F9F6F0] font-semibold bg-[#0F5A4A] shadow-sm'
                    : 'opacity-0 group-hover:opacity-95 text-[#1C2833] bg-white/90 border border-[#1C2833]/10'
                }`}
              >
                {ch.name}
              </span>
              <span
                className={`block rounded-full transition-all duration-300 ${
                  isCurrent
                    ? 'w-7 h-[2px] bg-[#0F5A4A]'
                    : 'w-2.5 h-[2px] bg-[#1C2833]/25 group-hover:bg-[#0F5A4A]/70'
                }`}
              />
            </button>
          );
        })}
      </aside>

      {/* =====================================================================
          CHOREOGRAPHED FULL-VIEWPORT ARCHITECTURAL HUD STAGES (100dvh)
         ===================================================================== */}
      <main className="fixed inset-0 viewport-stage z-20 pointer-events-none">
        {/* CHAPTER 1 (0.00 - 0.165): EKATERINA PIMENOVA MAIN HERO SHOWCASE + SMALLER 3D PORCELAIN EMBLEM */}
        {ch1Opacity > 0.01 && (
          <section
            style={{
              opacity: ch1Opacity,
              transform: `translate3d(0, ${(1 - ch1Opacity) * -24}px, 0)`,
            }}
            className="absolute inset-0 flex flex-col justify-between lg:justify-center pt-16 sm:pt-20 lg:pt-16 px-5 sm:px-12 lg:px-16 safe-bottom sm:pb-10 lg:pb-6"
          >
            {/* Mobile Main Hero Portrait Showcase (Photo 1 — Ekaterina is visibly LARGER than the 3D plate beside her) */}
            <div className="lg:hidden pointer-events-auto">
              <button
                type="button"
                onClick={() => setDrawer('cases')}
                aria-label="О специалисте и дипломах Екатерины Пименовой"
                className="w-[196px] sm:w-[236px] p-2 rounded-[22px] studio-accent-block text-left shadow-xl"
              >
                <img
                  src={resolveAssetUrl(SPECIALIST_PHOTOS.hero)}
                  alt="Екатерина Пименова — клинический нутрициолог"
                  className="w-full aspect-[4/4.3] object-cover object-top rounded-[16px]"
                />
                <div className="pt-2 pb-0.5 px-1 flex items-center justify-between gap-1.5">
                  <div className="min-w-0">
                    <div className="text-[11.5px] font-semibold text-[#F9F6F0] leading-tight truncate">
                      {brand.name}
                    </div>
                    <div className="text-[9.5px] text-[#C49B47] font-medium num-tabular truncate">
                      {brand.clientsCount} семей · {brand.experienceYears}
                    </div>
                  </div>
                  <ArrowUpRight className="w-3.5 h-3.5 text-[#C49B47] shrink-0" />
                </div>
              </button>
            </div>

            <div className="max-w-[1380px] w-full mx-auto flex flex-col lg:flex-row lg:items-center justify-between gap-6 sm:gap-8">
              <div className="max-w-[500px] pointer-events-auto border-l-2 border-[#0F5A4A]/35 pl-4 sm:pl-7">
                <div className="inline-flex items-center gap-2 px-3 py-1 sm:px-3.5 sm:py-1.5 rounded-full bg-[#0F5A4A] text-[#F9F6F0] text-[10px] sm:text-[10.5px] font-semibold tracking-[0.11em] uppercase whitespace-nowrap mb-2 sm:mb-4 shadow-sm">
                  <span className="sm:hidden">Клинический нутрициолог</span>
                  <span className="hidden sm:inline">{brand.role}</span>
                  <span className="text-[#C49B47]">·</span>
                  <span className="num-tabular">{brand.experienceYears}</span>
                </div>
                <h1 className="text-[28px] sm:text-5xl lg:text-[56px] xl:text-[60px] font-semibold text-[#1C2833] display-tight">
                  Системное здоровье
                  <br />
                  начинается с{'\u00A0'}тарелки.
                </h1>
                <p className="text-xs sm:text-[15px] text-[#1C2833]/80 mt-2 sm:mt-4 max-w-md leading-relaxed">
                  Восстановление энергии, ЖКТ, гормонального баланса и{'\u00A0'}детского иммунитета
                  через клинический разбор анализов и{'\u00A0'}вкусный семейный рацион без{'\u00A0'}диет.
                </p>
                <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 mt-3.5 sm:mt-6">
                  <button
                    onClick={() => openBooking(QUICK_BOOKING.title, QUICK_BOOKING.prefillMessage)}
                    className="px-5 sm:px-7 py-3 sm:py-3.5 rounded-full btn-brand-gold text-xs sm:text-sm font-semibold inline-flex items-center gap-2"
                  >
                    Записаться
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => scrollToProgress(0.46)}
                    className="px-4 sm:px-5 py-3 sm:py-3.5 rounded-full bg-[#FAF6EE]/90 hover:bg-[#FAF6EE] text-[#1C2833] backdrop-blur-xl border border-[#1C2833]/15 text-xs sm:text-sm font-medium transition inline-flex items-center gap-2 shadow-sm"
                  >
                    <Layers className="w-4 h-4 text-[#0F5A4A]" />
                    Консультации и{'\u00A0'}цены
                  </button>
                </div>

                <button
                  onClick={() => scrollToProgress(0.335)}
                  className="hidden sm:inline-flex mt-4 text-[11px] font-medium text-[#1C2833]/65 hover:text-[#0F5A4A] items-center gap-2 transition"
                >
                  <span>Листайте вниз — разбор тарелки в{'\u00A0'}3D</span>
                  <ArrowDown className="w-3.5 h-3.5 animate-bounce text-[#0F5A4A]" />
                </button>
              </div>

              {/* Desktop Grand Editorial Hero Showcase (Photo 1 — Ekaterina Pimenova is >2x larger than the 3D plate) */}
              <div className="hidden lg:block pointer-events-auto w-[375px] xl:w-[420px] mr-0 xl:mr-2 shrink-0">
                <div className="p-3.5 rounded-[32px] studio-accent-block">
                  <div className="relative overflow-hidden rounded-[24px]">
                    <img
                      src={resolveAssetUrl(SPECIALIST_PHOTOS.hero)}
                      alt="Екатерина Пименова — клинический и интегративный нутрициолог"
                      className="w-full aspect-[4/4.85] object-cover object-top"
                    />
                    <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#0F5A4A]/90 backdrop-blur-md border border-[#C49B47]/45 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#F9F6F0]">
                      Личная практика · {brand.clientsCount} семей
                    </div>
                  </div>
                  <div className="pt-3.5 pb-1.5 px-2 flex items-center justify-between gap-3">
                    <div>
                      <div className="text-base xl:text-lg font-semibold text-[#F9F6F0] leading-tight">
                        {brand.name}
                      </div>
                      <div className="text-xs text-[#F9F6F0]/80 num-tabular mt-0.5">
                        {brand.role} · {brand.experienceYears}
                      </div>
                    </div>
                    <button
                      onClick={() => setDrawer('cases')}
                      className="px-3.5 py-2 rounded-full btn-brand-gold text-xs font-semibold inline-flex items-center gap-1.5 shrink-0"
                    >
                      Дипломы
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* TRANSITION BRIDGE (0.17 - 0.252): KINETIC TYPOGRAPHY + FLOATING FRESH INGREDIENTS */}
        {echoOpacity > 0.01 && (
          <section
            style={{ opacity: echoOpacity }}
            className="absolute inset-0 flex items-center px-5 sm:px-14 lg:px-24"
          >
            <div className="relative max-w-4xl border-l-2 border-[#0F5A4A]/35 pl-5 sm:pl-9">
              {[3, 2, 1].map((layer) => {
                const spread = (14 + Math.abs(velocity) * 26) * layer;
                return (
                  <div
                    key={layer}
                    aria-hidden="true"
                    style={{
                      transform: `translate3d(0, ${spread}px, 0)`,
                      opacity: 0.16 / layer,
                      filter: `blur(${layer * 1.1}px)`,
                    }}
                    className="absolute inset-y-0 left-5 sm:left-9 right-0 text-3xl sm:text-6xl lg:text-[70px] font-semibold text-[#0F5A4A] display-tight select-none"
                  >
                    Еда как биохимия —
                    <br />
                    вкусно и{'\u00A0'}сытно,
                    <br />
                    <span className="text-[#1C2833]/40">без голода и{'\u00A0'}запретов</span>
                  </div>
                );
              })}

              <h2 className="relative text-3xl sm:text-6xl lg:text-[70px] font-semibold text-[#1C2833] display-tight">
                Еда как биохимия —
                <br />
                вкусно и{'\u00A0'}сытно,
                <br />
                <span className="text-[#0F5A4A]">без голода и{'\u00A0'}запретов</span>
              </h2>
            </div>
          </section>
        )}

        {/* CHAPTER 2 (0.262 - 0.432): INTERACTIVE 3D CLINICAL PLATE TURNTABLE + LAB CALCULATOR */}
        {ch2Opacity > 0.01 && (
          <section
            style={{ opacity: ch2Opacity }}
            className="absolute inset-0 flex flex-col justify-between pt-16 sm:pt-24 safe-bottom sm:pb-8 px-4 sm:px-12"
          >
            <div className="text-center max-w-4xl mx-auto pt-1">
              <p className="text-[9px] sm:text-[11px] font-semibold uppercase tracking-[0.22em] sm:tracking-[0.26em] text-[#0F5A4A] mb-1.5 sm:mb-2">
                ФИЗИОЛОГИЧЕСКИЕ ОПТИМУМЫ И КОНСТРУКТОР РАЦИОНА
              </p>
              <h2 className="text-[28px] sm:text-5xl lg:text-[56px] font-semibold text-[#1C2833] display-tight">
                Точность на вашей тарелке
              </h2>
              <div className="hairline-gradient w-36 sm:w-48 mx-auto mt-3 sm:mt-4" />
            </div>

            <div className="hidden xl:flex max-w-[86rem] w-full mx-auto pr-28 items-center justify-between text-[10px] font-mono uppercase tracking-[0.18em] text-[#1C2833]/55 leading-relaxed">
              <span>
                50% ЗЕЛЕНЬ · 25% БЕЛОК
                <br />
                25% СЛОЖНЫЕ УГЛЕВОДЫ
              </span>
              <span className="text-right">
                НАЖМИТЕ МАРКЕР ВНИЗУ —
                <br />
                СМЕНИТСЯ 3D-ТАРЕЛКА
              </span>
            </div>

            <div className="max-w-4xl w-full mx-auto pointer-events-auto space-y-2">
              <div className="studio-accent-block rounded-2xl px-4 py-3 sm:px-5 sm:py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-2.5">
                <div className="space-y-0.5">
                  <div className="text-[11px] sm:text-xs text-[#F9F6F0]/90 num-tabular leading-snug">
                    <span className="text-[#F9F6F0] font-semibold">{activeBio.name}:</span> бланк{' '}
                    {activeBio.labRefMin}–{activeBio.labRefMax}, оптимум{' '}
                    <span className="text-[#C49B47] font-semibold underline underline-offset-4">
                      {activeBio.optimumMin}–{activeBio.optimumMax} {activeBio.unit}
                    </span>
                  </div>
                  <div className="hidden sm:block text-[11px] text-[#F9F6F0]/75">{plateNote}</div>
                </div>
                <button
                  onClick={() => setDrawer('biomarkers')}
                  className="shrink-0 inline-flex items-center gap-1.5 px-4 py-2 rounded-full btn-brand-gold text-xs font-semibold num-tabular self-start md:self-auto"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  Проверить свой показатель
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2">
                {BIOMARKERS.map((bio, idx) => (
                  <button
                    key={bio.id}
                    onClick={() => setActiveBioIdx(idx)}
                    className={`px-3 py-1.5 rounded-full text-[11px] sm:text-xs font-medium num-tabular transition ${
                      activeBioIdx === idx
                        ? 'bg-[#0F5A4A] text-[#F9F6F0] shadow-md'
                        : 'bg-[#FAF6EE]/90 text-[#1C2833]/80 hover:bg-[#FAF6EE] hover:text-[#1C2833] border border-[#1C2833]/12'
                    }`}
                  >
                    {bio.name} · {bio.optimumMin}–{bio.optimumMax}
                  </button>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CHAPTER 3 (0.435 - 0.706): DRAGGABLE & SWIPEABLE CURVED 3D CULINARY GALLERY */}
        {ch3Opacity > 0.01 && (
          <section
            style={{ opacity: ch3Opacity }}
            className="absolute inset-0 flex flex-col justify-between pt-16 sm:pt-24 safe-bottom sm:pb-9 px-4 sm:px-12"
          >
            <div className="max-w-7xl w-full mx-auto pt-1 flex items-center justify-between gap-2 text-[10px] sm:text-[11px] font-medium uppercase tracking-[0.16em] sm:tracking-[0.22em] text-[#1C2833]/75 num-tabular">
              <span className="truncate">
                КОНСУЛЬТАЦИИ<span className="hidden sm:inline"> И ФОРМАТЫ</span> // 0
                {activeRibbonIdx + 1} ИЗ 0{ribbonCards.length}
                <span className="hidden md:inline text-[#1C2833]/45"> · ТЯНИТЕ МЫШЬЮ ИЛИ СВАЙПОМ</span>
              </span>
              <button
                onClick={() => setDrawer('catalog')}
                className="pointer-events-auto shrink-0 whitespace-nowrap text-[#0F5A4A] font-semibold hover:opacity-80 transition underline underline-offset-4"
              >
                ВСЕ 4 ФОРМАТА →
              </button>
            </div>

            <div className="flex-1 flex items-center justify-center my-1 sm:my-2">
              <div
                role="button"
                tabIndex={0}
                aria-label={`Свайпните влево-вправо или нажмите, чтобы открыть ${activeRibbonCard.titleLines.join(' ')}`}
                onPointerDown={onRibbonPointerDown}
                onPointerMove={onRibbonPointerMove}
                onPointerUp={onRibbonPointerUp}
                onPointerCancel={onRibbonPointerUp}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') handleServiceDetail(activeRibbonCard.id);
                }}
                style={{ touchAction: 'pan-y' }}
                className="pointer-events-auto w-full max-w-5xl h-[34vh] sm:h-[46vh] rounded-3xl cursor-grab active:cursor-grabbing focus:outline-none"
              />
            </div>

            <div className="max-w-4xl w-full mx-auto pointer-events-auto">
              <div className="studio-accent-block rounded-2xl p-3.5 sm:px-5 sm:py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
                <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                  <img
                    src={resolveAssetUrl(SPECIALIST_PHOTOS.consult)}
                    alt="Екатерина Пименова — консультация"
                    className="w-11 h-14 sm:w-12 sm:h-16 rounded-xl object-cover object-[50%_20%] ring-1 ring-[#C49B47]/55 shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs text-[#F9F6F0]/75 num-tabular">
                      <span className="font-mono">({activeRibbonCard.num})</span>
                      <span>·</span>
                      <span className="text-[#C49B47] font-semibold">{activeRibbonCard.price}</span>
                    </div>
                    <h3 className="text-[15px] sm:text-xl font-semibold text-[#F9F6F0] mt-0.5 leading-snug">
                      {activeRibbonCard.titleLines.join(' ')}
                    </h3>
                    <p className="text-[11px] sm:text-xs text-[#F9F6F0]/78 mt-0.5 line-clamp-1">
                      {activeRibbonCard.subtitle}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        const prevIdx = Math.max(0, activeRibbonIdx - 1);
                        scrollToProgress(0.46 + (prevIdx / (ribbonCards.length - 1)) * 0.22);
                      }}
                      aria-label="Предыдущий формат"
                      className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#F9F6F0]/12 hover:bg-[#F9F6F0]/22 border border-[#F9F6F0]/20 text-[#F9F6F0] flex items-center justify-center transition"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        const nextIdx = Math.min(ribbonCards.length - 1, activeRibbonIdx + 1);
                        scrollToProgress(0.46 + (nextIdx / (ribbonCards.length - 1)) * 0.22);
                      }}
                      aria-label="Следующий формат"
                      className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#F9F6F0]/12 hover:bg-[#F9F6F0]/22 border border-[#F9F6F0]/20 text-[#F9F6F0] flex items-center justify-center transition"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                  <button
                    onClick={() => handleServiceDetail(activeRibbonCard.id)}
                    className="px-4 sm:px-5 py-2.5 rounded-full btn-brand-gold text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    Подробнее
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* CHAPTER 4 (0.71 - 0.898): 4-PLATE 3D CHEF'S TASTING CAROUSEL + CASE RESULTS */}
        {ch4Opacity > 0.01 && (
          <section
            style={{ opacity: ch4Opacity }}
            className="absolute inset-0 flex flex-col justify-between pt-16 sm:pt-24 safe-bottom sm:pb-10 px-4 sm:px-12"
          >
            <div className="max-w-7xl w-full mx-auto pt-1">
              <div className="max-w-xl border-l-2 border-[#0F5A4A]/35 pl-4 sm:pl-6">
                <p className="text-[10px] sm:text-[11px] font-mono font-semibold uppercase tracking-[0.20em] text-[#0F5A4A] mb-1.5 sm:mb-2">
                  {currentPreset.code}
                </p>
                <h2 className="text-[26px] sm:text-5xl font-semibold text-[#1C2833] display-tight">
                  {scrambledHeadline}
                </h2>
              </div>
            </div>

            <div className="max-w-7xl w-full mx-auto flex flex-col lg:flex-row lg:items-end justify-between gap-3 sm:gap-4 pointer-events-auto">
              <div className="studio-accent-block rounded-2xl p-4 sm:p-5 max-w-xl space-y-2.5 sm:space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#F9F6F0]/75 pb-2 border-b border-[#F9F6F0]/15">
                  <span>
                    <strong className="text-[#F9F6F0] font-semibold">{currentPreset.caseItem.clientName}</strong> ·{' '}
                    {currentPreset.caseItem.clientMeta}
                  </span>
                  {primaryDelta && (
                    <span className="px-2.5 py-0.5 rounded-full bg-[#C49B47] text-[#1C2833] text-[11px] font-semibold num-tabular">
                      {primaryDelta.marker}: {primaryDelta.before} → {primaryDelta.after}
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-[#F9F6F0]/95 leading-relaxed">
                  {currentPreset.caseItem.resultB}
                </p>
                <div className="pt-0.5 flex flex-wrap gap-2">
                  <button
                    onClick={() => setDrawer('cases')}
                    className="px-3.5 sm:px-4 py-2 rounded-full btn-brand-gold text-xs font-semibold inline-flex items-center gap-1.5 num-tabular"
                  >
                    <Award className="w-3.5 h-3.5" />
                    Динамика 6 кейсов и дипломы
                  </button>
                  <button
                    onClick={() => setDrawer('biomarkers')}
                    className="px-3.5 sm:px-4 py-2 rounded-full bg-[#F9F6F0]/12 hover:bg-[#F9F6F0]/20 border border-[#F9F6F0]/22 text-xs text-[#F9F6F0] transition"
                  >
                    Проверить свой анализ
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-1.5 sm:gap-2 num-tabular w-full sm:w-auto">
                {['01 Энергия', '02 Стройность', '03 Дети', '04 Беременность'].map((lbl, idx) => (
                  <button
                    key={lbl}
                    onClick={() => scrollToProgress(0.73 + idx * 0.04)}
                    className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-xs font-semibold transition text-center ${
                      terrainPresetIdx === idx
                        ? 'bg-[#0F5A4A] text-[#F9F6F0] shadow-md'
                        : 'bg-[#FAF6EE]/90 text-[#1C2833]/80 hover:bg-[#FAF6EE] hover:text-[#1C2833] border border-[#1C2833]/12'
                    }`}
                  >
                    {lbl}
                  </button>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CHAPTER 5 (0.908 - 1.00): BOOKING STAGE + PHOTO 2 (EKATERINA SPECIALIST PORTRAIT) */}
        {ch5Opacity > 0.01 && (
          <section
            style={{ opacity: ch5Opacity }}
            className="absolute inset-0 flex flex-col justify-between pt-16 sm:pt-20 safe-bottom sm:pb-6 px-5 sm:px-12 lg:px-16"
          >
            {/* Mobile Booking Portrait Card (Photo 2 — Акцентный блок #0F5A4A) */}
            <button
              type="button"
              onClick={() => openBooking(QUICK_BOOKING.title, QUICK_BOOKING.prefillMessage)}
              aria-label="Записаться на консультацию"
              className="lg:hidden pointer-events-auto absolute top-[62px] right-2.5 w-[134px] p-1.5 rounded-2xl studio-accent-block text-left"
            >
              <img
                src={resolveAssetUrl(SPECIALIST_PHOTOS.booking)}
                alt="Екатерина Пименова — запись на консультацию"
                className="w-full aspect-[4/4.8] object-cover object-top rounded-xl"
              />
              <div className="pt-1.5 px-1 flex items-center justify-between gap-1">
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#F9F6F0]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#C49B47]" />
                  Записаться
                </span>
                <ArrowUpRight className="w-3 h-3 text-[#C49B47] shrink-0" />
              </div>
            </button>

            <div className="max-w-[1380px] w-full mx-auto flex-1 flex items-end pb-2 lg:items-center lg:pb-0 justify-between gap-8">
              <div className="max-w-[505px] pointer-events-auto border-l-2 border-[#0F5A4A]/35 pl-4 sm:pl-8">
                <p className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-[0.22em] text-[#0F5A4A] mb-1 sm:mb-2.5">
                  ОНЛАЙН ПО ВСЕМУ МИРУ · БЕРЕЖНАЯ СИСТЕМА
                </p>
                <h2 className="text-[26px] sm:text-5xl xl:text-[52px] font-semibold text-[#1C2833] display-tight">
                  Записаться
                  <br />
                  на{'\u00A0'}консультацию
                </h2>
                <p className="hidden sm:block text-[14px] text-[#1C2833]/80 mt-3 max-w-lg leading-relaxed num-tabular">
                  Персональная консультация (взрослый или{'\u00A0'}ребёнок), «Мама{'\u00A0'}+{'\u00A0'}ребёнок»,
                  индивидуальное ведение или{'\u00A0'}практический гайд.
                </p>

                {/* MANDATORY PUBLIC OFFER NOTICE + BUTTON (Exact structure requested) */}
                <div className="mt-3 sm:mt-4 p-3 sm:p-4 rounded-2xl bg-[#FAF6EE]/90 backdrop-blur-md border border-[#1C2833]/12 shadow-sm max-w-[465px]">
                  <div className="flex items-start gap-3">
                    <svg
                      viewBox="0 0 28 42"
                      fill="none"
                      aria-hidden="true"
                      className="w-5 h-7 sm:w-6 sm:h-8 text-[#1C2833] shrink-0 mt-0.5"
                    >
                      <path
                        d="M14 2V26M14 26L6.5 18.5M14 26L21.5 18.5"
                        stroke="currentColor"
                        strokeWidth="2.3"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <circle cx="14" cy="35" r="2.8" stroke="currentColor" strokeWidth="2.2" />
                    </svg>
                    <p className="text-[11.5px] sm:text-[13px] font-medium text-[#1C2833] leading-snug">
                      Перед записью необходимо ознакомиться с{'\u00A0'}договором оферты и{'\u00A0'}согласовать
                      дату и{'\u00A0'}время встречи.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setDrawer('legal')}
                    className="mt-2.5 sm:mt-3 w-full py-2.5 sm:py-3 px-4 rounded-xl studio-accent-block hover:brightness-110 transition flex flex-col items-center justify-center text-center"
                  >
                    <span className="text-xs sm:text-[13px] font-semibold tracking-[0.08em] uppercase text-[#F9F6F0]">
                      ДОГОВОР ОФЕРТЫ
                    </span>
                    <span className="text-[10.5px] sm:text-xs text-[#C49B47] font-medium mt-0.5">
                      Обязательно к прочтению!
                    </span>
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-2 sm:gap-2.5 mt-3 sm:mt-4">
                  <button
                    onClick={() => openBooking(QUICK_BOOKING.title, QUICK_BOOKING.prefillMessage)}
                    className="px-5 sm:px-7 py-2.5 sm:py-3 rounded-full btn-brand-gold text-xs sm:text-sm font-semibold inline-flex items-center gap-2 num-tabular"
                  >
                    Записаться
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                  <a
                    href={tgDirect}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-full bg-[#FAF6EE]/90 hover:bg-[#FAF6EE] border border-[#1C2833]/15 text-[#1C2833] text-xs sm:text-sm font-medium inline-flex items-center gap-1.5 transition shadow-sm"
                  >
                    <Send className="w-3.5 h-3.5 text-[#0F5A4A]" />
                    Telegram
                  </a>
                  <a
                    href={waDirect}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-full bg-[#FAF6EE]/90 hover:bg-[#FAF6EE] border border-[#1C2833]/15 text-[#1C2833] text-xs sm:text-sm font-medium inline-flex items-center gap-1.5 transition shadow-sm"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-[#0F5A4A]" />
                    WhatsApp
                  </a>
                </div>
              </div>

              {/* Desktop Editorial Booking Portrait Showcase (Photo 2 — Ekaterina larger than 3D plate) */}
              <div className="hidden lg:block pointer-events-auto w-[345px] xl:w-[385px] mr-0 xl:mr-2 shrink-0">
                <div className="p-3 rounded-[30px] studio-accent-block">
                  <div className="relative overflow-hidden rounded-[22px]">
                    <img
                      src={resolveAssetUrl(SPECIALIST_PHOTOS.booking)}
                      alt="Екатерина Пименова — запись на консультацию"
                      className="w-full aspect-[4/4.85] object-cover object-top"
                    />
                  </div>
                  <div className="pt-3 pb-1 px-2 flex items-center justify-between gap-3">
                    <div>
                      <div className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#F9F6F0]">
                        <span className="w-2 h-2 rounded-full bg-[#C49B47] animate-pulse" />
                        Онлайн-консультации
                      </div>
                      <div className="text-xs text-[#F9F6F0]/75 num-tabular mt-0.5">
                        {brand.city}
                      </div>
                    </div>
                    <button
                      onClick={() => openBooking(QUICK_BOOKING.title, QUICK_BOOKING.prefillMessage)}
                      className="px-3.5 py-1.5 rounded-full btn-brand-gold text-xs font-semibold inline-flex items-center gap-1 shrink-0"
                    >
                      Записаться
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <footer className="max-w-7xl w-full mx-auto pt-3 sm:pt-4 border-t border-[#1C2833]/12 flex flex-wrap items-center justify-between gap-2.5 text-[10px] sm:text-[11px] text-[#1C2833]/65 pointer-events-auto num-tabular">
              <div>
                {brand.legalEntity} · ИНН {brand.inn}
              </div>
              <div className="flex flex-wrap items-center gap-3 sm:gap-4">
                <button onClick={() => setDrawer('catalog')} className="hover:text-[#0F5A4A] transition">
                  Тарифы
                </button>
                <button onClick={() => setDrawer('cases')} className="hover:text-[#0F5A4A] transition">
                  Дипломы и FAQ
                </button>
                <button onClick={() => setDrawer('legal')} className="hover:text-[#0F5A4A] transition">
                  Оферта
                </button>
                <button
                  onClick={() => setDrawer('brand')}
                  className="hover:text-[#0F5A4A] transition inline-flex items-center gap-1"
                >
                  <Settings className="w-3 h-3" />
                  Контакты
                </button>
              </div>
            </footer>
          </section>
        )}
      </main>

      {/* SLIDE-OVER CONCIERGE DRAWERS */}
      <ConciergeDrawers
        activeDrawer={drawer}
        selectedServiceId={selectedServiceId}
        initialBioIdx={activeBioIdx}
        bookingPrefill={bookingPrefill}
        brand={brand}
        onSaveBrand={handleSaveBrand}
        onResetBrand={handleResetBrand}
        onClose={() => setDrawer(null)}
        onOpenDrawer={(next) => setDrawer(next)}
        onNavigateChapter={scrollToProgress}
        onOpenBooking={openBooking}
        onSelectServiceDetail={handleServiceDetail}
      />
    </div>
  );
}

export default App;
