import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export interface RibbonCardSpec {
  id: string;
  num: string;
  tag: string;
  price: string;
  titleLines: [string, string];
  subtitle: string;
  imageSrc: string;
  portraitMode?: boolean;
  specialistBadge?: string;
}

interface CinemaWebGLEngineProps {
  scrollProgressRef: React.MutableRefObject<number>;
  scrollVelocityRef: React.MutableRefObject<number>;
  ribbonDragVelRef: React.MutableRefObject<number>;
  activeBiomarkerIdx: number;
  ribbonCards: RibbonCardSpec[];
}

declare global {
  interface Window {
    __EMBEDDED_IMAGES__?: Record<string, string>;
  }
}

function resolveAssetSrc(src: string): string {
  if (typeof window !== 'undefined' && window.__EMBEDDED_IMAGES__?.[src]) {
    return window.__EMBEDDED_IMAGES__[src];
  }
  return src;
}

function loadManagedTexture(src: string, maxAniso: number): THREE.Texture {
  const resolved = resolveAssetSrc(src);
  const loader = new THREE.TextureLoader();
  if (
    !resolved.startsWith('data:') &&
    typeof window !== 'undefined' &&
    window.location.protocol !== 'file:'
  ) {
    loader.setCrossOrigin('anonymous');
  }
  const tex = loader.load(resolved);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createCulinaryStudioEnvironment(renderer: THREE.WebGLRenderer): THREE.Texture {
  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();

  const envScene = new THREE.Scene();
  envScene.background = new THREE.Color('#121410');

  // Warm overhead sunlit softbox (makes porcelain glaze & olive oil gleam!)
  const topSoftbox = new THREE.Mesh(
    new THREE.PlaneGeometry(16, 16),
    new THREE.MeshBasicMaterial({ color: new THREE.Color(4.8, 4.6, 4.1), side: THREE.DoubleSide })
  );
  topSoftbox.position.set(2.5, 8.5, 5.0);
  topSoftbox.lookAt(0, 0, 0);
  envScene.add(topSoftbox);

  // Fresh botanical morning fill from left
  const leftFill = new THREE.Mesh(
    new THREE.PlaneGeometry(12, 14),
    new THREE.MeshBasicMaterial({ color: new THREE.Color(2.4, 2.7, 2.2), side: THREE.DoubleSide })
  );
  leftFill.position.set(-8.5, 2.5, 3.5);
  leftFill.lookAt(0, 0, 0);
  envScene.add(leftFill);

  // Warm golden-amber linen rim from right
  const rightRim = new THREE.Mesh(
    new THREE.PlaneGeometry(12, 12),
    new THREE.MeshBasicMaterial({ color: new THREE.Color(3.9, 3.2, 2.2), side: THREE.DoubleSide })
  );
  rightRim.position.set(8.5, -0.5, 4.8);
  rightRim.lookAt(0, 0, 0);
  envScene.add(rightRim);

  // Warm travertine table bounce underneath
  const bottomBounce = new THREE.Mesh(
    new THREE.PlaneGeometry(18, 18),
    new THREE.MeshBasicMaterial({ color: new THREE.Color(1.4, 1.3, 1.1), side: THREE.DoubleSide })
  );
  bottomBounce.position.set(0, -8.0, 0);
  bottomBounce.lookAt(0, 0, 0);
  envScene.add(bottomBounce);

  const envRT = pmrem.fromScene(envScene, 0.035);
  pmrem.dispose();
  return envRT.texture;
}

// Sculpted 3D Artisanal Porcelain Plate Geometry (revolved profile facing +Z)
function createPorcelainPlateGeometry(radialSegments = 84): THREE.BufferGeometry {
  const profile = [
    new THREE.Vector2(0.0, -0.13),
    new THREE.Vector2(0.86, -0.13),
    new THREE.Vector2(0.92, -0.165), // Ceramic foot ring resting edge
    new THREE.Vector2(0.98, -0.12),
    new THREE.Vector2(1.24, -0.06),
    new THREE.Vector2(1.45, 0.02),
    new THREE.Vector2(1.53, 0.095),  // Outer rounded stoneware lip
    new THREE.Vector2(1.50, 0.145),  // Top rim crest
    new THREE.Vector2(1.39, 0.115),  // Inner rim slope
    new THREE.Vector2(1.31, 0.03),   // Dish well perimeter
    new THREE.Vector2(0.0, 0.015),   // Dish well center
  ];
  const geo = new THREE.LatheGeometry(profile, radialSegments);
  geo.rotateX(Math.PI / 2); // Orient plate face toward +Z
  geo.computeVertexNormals();
  return geo;
}

// Domed Gourmet Salad Interior Shader (vivid natural color, 3D mound relief, crossfade & olive-oil sheen)
function createSaladBedMaterial(texA: THREE.Texture, texB?: THREE.Texture): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTexA: { value: texA },
      uTexB: { value: texB || texA },
      uMix: { value: 0 },
      uOpacity: { value: 1 },
      uSpinAngle: { value: 0 },
    },
    transparent: true,
    depthWrite: true,
    vertexShader: `
      varying vec2 vUv;
      varying float vRadial;
      varying vec3 vWorldNormal;

      void main() {
        vUv = uv;
        vec2 centered = (uv - 0.5) * 2.0;
        float r = length(centered);
        vRadial = r;

        vec3 pos = position;
        float inside = clamp(1.0 - r * r, 0.0, 1.0);
        // Gentle 3D culinary mound + organic leaf/ingredient micro-relief
        float relief = inside * 0.125 + sin(pos.x * 5.2) * cos(pos.y * 4.8) * 0.022 * inside;
        pos.z += relief;

        vWorldNormal = normalize(normalMatrix * normalize(vec3(-centered.x * 0.18, -centered.y * 0.18, 1.0)));
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D uTexA;
      uniform sampler2D uTexB;
      uniform float uMix;
      uniform float uOpacity;
      uniform float uSpinAngle;
      varying vec2 vUv;
      varying float vRadial;
      varying vec3 vWorldNormal;

      void main() {
        if (vRadial > 1.0) discard;

        // Rotate UVs smoothly around plate center
        vec2 d = vUv - 0.5;
        float c = cos(uSpinAngle);
        float s = sin(uSpinAngle);
        vec2 rotD = vec2(d.x * c - d.y * s, d.x * s + d.y * c);

        // Map inner 88% of centered 800x800 plate photo (zero corner background!)
        vec2 sampleUv = vec2(0.5) + rotD * 0.89;

        vec3 colA = texture2D(uTexA, sampleUv).rgb;
        vec3 colB = texture2D(uTexB, sampleUv).rgb;
        vec3 foodCol = mix(colA, colB, uMix);

        // Subtle studio key light + glossy olive-oil micro-highlight when plate tilts
        vec3 lightDir = normalize(vec3(0.38, 0.52, 0.76));
        float ndl = clamp(dot(normalize(vWorldNormal), lightDir), 0.0, 1.0);
        float spec = pow(ndl, 18.0) * 0.08;

        // Warm porcelain rim blend at outer 6% of well
        vec3 porcelainTone = vec3(0.94, 0.92, 0.88);
        float edgeBlend = smoothstep(0.91, 0.995, vRadial);
        vec3 finalCol = mix(foodCol * (0.94 + 0.11 * ndl) + vec3(1.0, 0.98, 0.92) * spec, porcelainTone, edgeBlend);

        float alpha = (1.0 - smoothstep(0.975, 1.0, vRadial)) * uOpacity;
        gl_FragColor = vec4(finalCol, alpha);
      }
    `,
  });
}

// Floating 3D Curved Botanical / Ingredient Cutout Shader
function createIngredientMaterial(tex: THREE.Texture, curveStrength = 0.16): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTex: { value: tex },
      uTime: { value: 0 },
      uOpacity: { value: 1 },
      uCurve: { value: curveStrength },
      uSeed: { value: Math.random() * 6.28 },
    },
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    vertexShader: `
      uniform float uTime;
      uniform float uCurve;
      uniform float uSeed;
      varying vec2 vUv;
      varying float vShade;

      void main() {
        vUv = uv;
        vec3 pos = position;
        vec2 c = uv - 0.5;
        float arch = -(c.x * c.x + c.y * c.y * 0.6) * uCurve;
        float flutter = sin(pos.x * 3.4 + uTime * 1.7 + uSeed) * 0.018;
        pos.z += arch + flutter;
        vShade = 0.96 + 0.08 * sin(c.x * 2.5 - c.y * 2.0);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D uTex;
      uniform float uOpacity;
      varying vec2 vUv;
      varying float vShade;

      void main() {
        vec4 texel = texture2D(uTex, vUv);
        float a = texel.a * uOpacity;
        if (a < 0.015) discard;
        gl_FragColor = vec4(texel.rgb * vShade, a);
      }
    `,
  });
}

// High-DPI Culinary Editorial Card Texture Generator for Chapter 03 Ribbon
function createCardCanvasTexture(
  spec: RibbonCardSpec,
  maxAnisotropy: number,
  compactMobile: boolean,
  loadedImage?: HTMLImageElement
): THREE.CanvasTexture {
  const scaleFactor = compactMobile ? 2 / 3 : 1;
  const W = Math.round(1536 * scaleFactor);
  const H = Math.round(960 * scaleFactor);
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d')!;

  ctx.save();
  ctx.scale(scaleFactor, scaleFactor);

  const baseW = 1536;
  const baseH = 960;

  const isPortraitCard =
    Boolean(spec.portraitMode) ||
    Boolean(
      loadedImage &&
        loadedImage.complete &&
        loadedImage.naturalWidth > 0 &&
        loadedImage.naturalHeight > loadedImage.naturalWidth * 1.12
    );

  if (isPortraitCard) {
    // LUXURY EDITORIAL SPLIT-PORTRAIT 3D CARD (Акцентный блок #0F5A4A + Кнопки/акценты #C49B47 + Фон/светлый текст #F9F6F0)
    const bgGrad = ctx.createLinearGradient(0, 0, baseW, baseH);
    bgGrad.addColorStop(0, '#126554');
    bgGrad.addColorStop(0.55, '#0F5A4A');
    bgGrad.addColorStop(1, '#093B30');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, baseW, baseH);

    // Warm #C49B47 champagne-gold studio glow behind portrait
    const halo = ctx.createRadialGradient(1160, 460, 40, 1160, 460, 520);
    halo.addColorStop(0, 'rgba(196, 155, 71, 0.30)');
    halo.addColorStop(0.55, 'rgba(15, 90, 74, 0.22)');
    halo.addColorStop(1, 'rgba(9, 59, 48, 0)');
    ctx.fillStyle = halo;
    ctx.fillRect(0, 0, baseW, baseH);

    // Right-side full-height 2:3 editorial portrait frame (zero head or hand cropping!)
    const pxFrame = 910;
    const pyFrame = 70;
    const pwFrame = 552;
    const phFrame = 820;

    if (loadedImage && loadedImage.complete && loadedImage.naturalWidth > 0) {
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(pxFrame, pyFrame, pwFrame, phFrame, 28);
      ctx.clip();

      const iw = loadedImage.naturalWidth;
      const ih = loadedImage.naturalHeight;
      const scale = Math.max(pwFrame / iw, phFrame / ih);
      const dw = iw * scale;
      const dh = ih * scale;
      const dx = pxFrame + (pwFrame - dw) / 2;
      const dy = pyFrame + (phFrame - dh) * 0.32;
      ctx.drawImage(loadedImage, dx, dy, dw, dh);

      const pVig = ctx.createLinearGradient(pxFrame, pyFrame, pxFrame, pyFrame + phFrame);
      pVig.addColorStop(0, 'rgba(9, 59, 48, 0.04)');
      pVig.addColorStop(0.78, 'rgba(9, 59, 48, 0.02)');
      pVig.addColorStop(1, 'rgba(9, 59, 48, 0.38)');
      ctx.fillStyle = pVig;
      ctx.fillRect(pxFrame, pyFrame, pwFrame, phFrame);
      ctx.restore();
    }

    ctx.strokeStyle = 'rgba(196, 155, 71, 0.62)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(pxFrame, pyFrame, pwFrame, phFrame, 28);
    ctx.stroke();

    // Outer 1.5px warm ivory/gold registration frame
    const pad = 34;
    ctx.strokeStyle = 'rgba(249, 246, 240, 0.24)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(pad, pad, baseW - pad * 2, baseH - pad * 2);

    const tick = 22;
    ctx.strokeStyle = '#C49B47';
    ctx.lineWidth = 2.6;
    const corners = [
      [pad, pad + tick, pad, pad, pad + tick, pad],
      [baseW - pad - tick, pad, baseW - pad, pad, baseW - pad, pad + tick],
      [pad, baseH - pad - tick, pad, baseH - pad, pad + tick, baseH - pad],
      [baseW - pad - tick, baseH - pad, baseW - pad, baseH - pad, baseW - pad, baseH - pad - tick],
    ];
    corners.forEach(([x1, y1, x2, y2, x3, y3]) => {
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.lineTo(x3, y3);
      ctx.stroke();
    });

    // Left column tag + #C49B47 gold price badge + specialist badge
    ctx.font = '600 25px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif';
    ctx.fillStyle = 'rgba(249, 246, 240, 0.85)';
    ctx.fillText(`${spec.num}  //  ${spec.tag.toUpperCase()}`, 78, 112);

    const priceText = spec.price;
    ctx.font = '700 30px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif';
    const pw = ctx.measureText(priceText).width + 60;
    ctx.fillStyle = '#C49B47';
    ctx.beginPath();
    ctx.roundRect(78, 146, pw, 60, 30);
    ctx.fill();
    ctx.fillStyle = '#1C2833';
    ctx.fillText(priceText, 78 + 30, 187);

    if (spec.specialistBadge) {
      ctx.font = '500 23px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif';
      const bw = ctx.measureText(spec.specialistBadge).width + 48;
      ctx.fillStyle = 'rgba(249, 246, 240, 0.14)';
      ctx.beginPath();
      ctx.roundRect(78 + pw + 16, 149, bw, 54, 27);
      ctx.fill();
      ctx.strokeStyle = 'rgba(196, 155, 71, 0.48)';
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.fillStyle = '#F9F6F0';
      ctx.fillText(spec.specialistBadge, 78 + pw + 40, 184);
    }

    ctx.strokeStyle = 'rgba(249, 246, 240, 0.22)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(78, 560);
    ctx.lineTo(852, 560);
    ctx.stroke();

    ctx.fillStyle = '#F9F6F0';
    let titleFontSize = 56;
    ctx.font = `600 ${titleFontSize}px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif`;
    while (
      titleFontSize > 42 &&
      (ctx.measureText(spec.titleLines[0]).width > 765 ||
        ctx.measureText(spec.titleLines[1]).width > 765)
    ) {
      titleFontSize -= 2;
      ctx.font = `600 ${titleFontSize}px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif`;
    }
    ctx.fillText(spec.titleLines[0], 78, 642);
    ctx.fillText(spec.titleLines[1], 78, 642 + Math.round(titleFontSize * 1.25));

    // Word-wrap subtitle cleanly inside left column (maxWidth = 770px)
    ctx.fillStyle = 'rgba(249, 246, 240, 0.88)';
    ctx.font = '400 28px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif';
    const words = spec.subtitle.split(' ');
    let line = '';
    let ySub = 786;
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > 760 && line) {
        ctx.fillText(line, 78, ySub);
        line = word;
        ySub += 38;
      } else {
        line = test;
      }
    }
    if (line) ctx.fillText(line, 78, ySub);
  } else {
    ctx.fillStyle = '#0F5A4A';
    ctx.fillRect(0, 0, baseW, baseH);

    if (loadedImage && loadedImage.complete && loadedImage.naturalWidth > 0) {
      const iw = loadedImage.naturalWidth;
      const ih = loadedImage.naturalHeight;
      const scale = Math.max(baseW / iw, baseH / ih);
      const dw = iw * scale;
      const dh = ih * scale;
      ctx.save();
      ctx.globalAlpha = 0.88;
      ctx.drawImage(loadedImage, (baseW - dw) / 2, (baseH - dh) / 2, dw, dh);
      ctx.restore();
    }

    // Deep Emerald (#0F5A4A) editorial vignette for 100% brand cohesion & legibility
    const grad = ctx.createLinearGradient(0, 0, 0, baseH);
    grad.addColorStop(0, 'rgba(11, 69, 57, 0.42)');
    grad.addColorStop(0.38, 'rgba(15, 90, 74, 0.24)');
    grad.addColorStop(0.66, 'rgba(11, 69, 57, 0.80)');
    grad.addColorStop(1, 'rgba(8, 52, 43, 0.97)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, baseW, baseH);

    // Warm ivory 1.5px frame + #C49B47 gold corner ticks
    const pad = 34;
    ctx.strokeStyle = 'rgba(249, 246, 240, 0.28)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(pad, pad, baseW - pad * 2, baseH - pad * 2);

    const tick = 22;
    ctx.strokeStyle = '#C49B47';
    ctx.lineWidth = 2.6;
    const corners = [
      [pad, pad + tick, pad, pad, pad + tick, pad],
      [baseW - pad - tick, pad, baseW - pad, pad, baseW - pad, pad + tick],
      [pad, baseH - pad - tick, pad, baseH - pad, pad + tick, baseH - pad],
      [baseW - pad - tick, baseH - pad, baseW - pad, baseH - pad, baseW - pad, baseH - pad - tick],
    ];
    corners.forEach(([x1, y1, x2, y2, x3, y3]) => {
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.lineTo(x3, y3);
      ctx.stroke();
    });

    ctx.font = '600 26px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif';
    ctx.fillStyle = 'rgba(249, 246, 240, 0.90)';
    ctx.fillText(`${spec.num}  //  ${spec.tag.toUpperCase()}`, 78, 106);

    const priceText = spec.price;
    ctx.font = '700 30px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif';
    const pw = ctx.measureText(priceText).width + 64;
    const px = baseW - 78 - pw;
    ctx.fillStyle = '#C49B47';
    ctx.beginPath();
    ctx.roundRect(px, 64, pw, 62, 31);
    ctx.fill();
    ctx.fillStyle = '#1C2833';
    ctx.fillText(priceText, px + 32, 106);

    ctx.strokeStyle = 'rgba(249, 246, 240, 0.22)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(78, 650);
    ctx.lineTo(baseW - 78, 650);
    ctx.stroke();

    ctx.fillStyle = '#F9F6F0';
    ctx.font = '600 66px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif';
    ctx.fillText(spec.titleLines[0], 78, 736);
    ctx.fillText(spec.titleLines[1], 78, 812);

    ctx.fillStyle = 'rgba(249, 246, 240, 0.88)';
    ctx.font = '400 30px -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", sans-serif';
    ctx.fillText(spec.subtitle, 78, 876);
  }

  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.needsUpdate = true;
  return tex;
}

export const CinemaWebGLEngine: React.FC<CinemaWebGLEngineProps> = ({
  scrollProgressRef,
  scrollVelocityRef,
  ribbonDragVelRef,
  activeBiomarkerIdx,
  ribbonCards,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const bioIdxRef = useRef(activeBiomarkerIdx);
  bioIdxRef.current = activeBiomarkerIdx;
  const [webglFallback, setWebglFallback] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const w = window.innerWidth;
    const h = window.innerHeight;
    let isMobileViewport = w < 768;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: !isMobileViewport || (window.devicePixelRatio || 1) < 2,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglFallback(true);
      return;
    }

    const getOptimalDpr = (vw: number) =>
      Math.min(window.devicePixelRatio || 1, vw < 768 ? 1.75 : 2);

    const initialDpr = getOptimalDpr(w);
    renderer.setSize(w, h);
    renderer.setPixelRatio(initialDpr);
    renderer.setClearColor(0x000000, 0);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.06;
    (renderer as unknown as { transmissionResolutionScale?: number }).transmissionResolutionScale =
      isMobileViewport ? 0.55 : 0.75;
    container.appendChild(renderer.domElement);

    const maxAniso = Math.min(isMobileViewport ? 4 : 8, renderer.capabilities.getMaxAnisotropy() || 1);

    const scene = new THREE.Scene();
    scene.background = null;
    const envTex = createCulinaryStudioEnvironment(renderer);
    scene.environment = envTex;

    const camera = new THREE.PerspectiveCamera(40, w / h, 0.1, 120);
    camera.position.set(0, 0.08, 7.4);

    // Warm Michelin Studio Lighting
    const sunKeyLight = new THREE.DirectionalLight('#fffaf0', 2.6);
    sunKeyLight.position.set(4.2, 6.8, 5.8);
    scene.add(sunKeyLight);

    const botanicalRimLight = new THREE.PointLight('#d9f99d', 1.8, 22);
    botanicalRimLight.position.set(-5.2, 3.0, 3.8);
    scene.add(botanicalRimLight);

    const goldenOliveLight = new THREE.PointLight('#fde68a', 2.4, 22);
    goldenOliveLight.position.set(5.2, -1.6, 4.4);
    scene.add(goldenOliveLight);

    // Load Culinary Plate & Cutout Ingredient Textures
    const plateTexMed = loadManagedTexture('/images/plate-mediterranean.jpg', maxAniso);
    const plateTexVitality = loadManagedTexture('/images/plate-vitality-greens.jpg', maxAniso);
    const plateTexAvocado = loadManagedTexture('/images/plate-avocado-bowl.jpg', maxAniso);
    const plateTexFamily = loadManagedTexture('/images/plate-berry-family.jpg', maxAniso);
    const allPlateTextures = [plateTexMed, plateTexVitality, plateTexAvocado, plateTexFamily];

    const ingTexAvocado = loadManagedTexture('/images/ing-avocado.webp', maxAniso);
    const ingTexBasil = loadManagedTexture('/images/ing-basil.webp', maxAniso);
    const ingTexTomato = loadManagedTexture('/images/ing-tomato.webp', maxAniso);
    const ingTexBroccoli = loadManagedTexture('/images/ing-broccoli.webp', maxAniso);
    const ingTexBerries = loadManagedTexture('/images/ing-berries.webp', maxAniso);

    // Shared 3D Ceramic Plate Geometry & Materials
    const sharedPlateGeo = createPorcelainPlateGeometry(isMobileViewport ? 64 : 88);
    const sharedRimFilletGeo = new THREE.TorusGeometry(1.545, 0.010, 12, isMobileViewport ? 64 : 96);
    const sharedSaladBedGeo = new THREE.PlaneGeometry(2.74, 2.74, 42, 42);

    const createPorcelainMaterial = () =>
      new THREE.MeshPhysicalMaterial({
        color: new THREE.Color('#efeae0'),
        roughness: 0.24,
        metalness: 0.03,
        clearcoat: 0.92,
        clearcoatRoughness: 0.08,
        envMapIntensity: 1.15,
        transparent: true,
        opacity: 1,
      });

    const createRimGoldMaterial = () =>
      new THREE.MeshStandardMaterial({
        color: new THREE.Color('#C49B47'),
        metalness: 0.72,
        roughness: 0.26,
        transparent: true,
        opacity: 0.90,
      });

    // Soft local contact shadow texture right beneath each 3D porcelain plate (leaves page background 100% pure #F9F6F0)
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 256;
    shadowCanvas.height = 256;
    const shCtx = shadowCanvas.getContext('2d')!;
    const shGrad = shCtx.createRadialGradient(128, 128, 16, 128, 128, 124);
    shGrad.addColorStop(0, 'rgba(28, 40, 51, 0.34)');
    shGrad.addColorStop(0.55, 'rgba(28, 40, 51, 0.14)');
    shGrad.addColorStop(1, 'rgba(28, 40, 51, 0.0)');
    shCtx.fillStyle = shGrad;
    shCtx.fillRect(0, 0, 256, 256);
    const contactShadowTex = new THREE.CanvasTexture(shadowCanvas);
    const sharedShadowGeo = new THREE.PlaneGeometry(3.85, 3.85);

    // Helper: Build a complete 3D Sculpted Porcelain Plate + Brushed-Gold Rim + Domed Gourmet Salad + Soft Contact Shadow
    const build3DPlateUnit = (initialTex: THREE.Texture) => {
      const group = new THREE.Group();

      const shadowMat = new THREE.MeshBasicMaterial({
        map: contactShadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.55,
      });
      const shadowMesh = new THREE.Mesh(sharedShadowGeo, shadowMat);
      shadowMesh.position.set(0.06, -0.14, -0.22);
      group.add(shadowMesh);

      const ceramicMat = createPorcelainMaterial();
      const ceramicMesh = new THREE.Mesh(sharedPlateGeo, ceramicMat);
      group.add(ceramicMesh);

      const rimMat = createRimGoldMaterial();
      const rimMesh = new THREE.Mesh(sharedRimFilletGeo, rimMat);
      rimMesh.position.z = 0.222;
      group.add(rimMesh);

      const saladMat = createSaladBedMaterial(initialTex, initialTex);
      const saladMesh = new THREE.Mesh(sharedSaladBedGeo, saladMat);
      saladMesh.position.z = 0.024;
      group.add(saladMesh);

      return { group, ceramicMat, rimMat, saladMat, shadowMat };
    };

    // Luminous Mediterranean Extra-Virgin Olive Oil Droplet Material (single-pass high FPS!)
    const oliveOilMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#eab308'),
      emissive: new THREE.Color('#a16207'),
      emissiveIntensity: 0.30,
      metalness: 0.14,
      roughness: 0.05,
      clearcoat: 1.0,
      clearcoatRoughness: 0.03,
      envMapIntensity: 2.8,
      transparent: true,
      opacity: 0.94,
    });

    // =========================================================================
    // SCENE 1 (0.00 - 0.21): HERO 3D PORCELAIN MEDITERRANEAN SALAD PLATE + LEVITATING INGREDIENTS
    // =========================================================================
    const scene1Group = new THREE.Group();
    scene.add(scene1Group);

    const heroPlate = build3DPlateUnit(plateTexMed);
    scene1Group.add(heroPlate.group);

    // Delicate brushed-gold (#C49B47) culinary orbit ring framing the hero plate
    const brassRingMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#C49B47'),
      metalness: 0.68,
      roughness: 0.30,
      transparent: true,
      opacity: 0.62,
    });
    const heroOrbitRing = new THREE.Mesh(
      new THREE.TorusGeometry(1.82, 0.007, 18, 160),
      brassRingMat
    );
    scene1Group.add(heroOrbitRing);

    interface FloatingIngItem {
      mesh: THREE.Mesh;
      mat: THREE.ShaderMaterial;
      baseOffset: THREE.Vector3;
      rotBase: THREE.Vector3;
      bobSpeed: number;
      bobAmp: number;
      phase: number;
      mobileScale: number;
    }

    const ingPlaneGeo = new THREE.PlaneGeometry(1, 1, 18, 18);
    const scene1Ings: FloatingIngItem[] = [];

    const s1IngDefs = [
      { tex: ingTexAvocado, size: 0.86, pos: [-1.38, 1.02, 0.65], rot: [0.12, 0.18, -0.22], curve: 0.10, mScale: 0.60 },
      { tex: ingTexBasil,   size: 0.66, pos: [1.28, 1.16, 0.72],  rot: [-0.18, -0.22, 0.35], curve: 0.24, mScale: 0.60 },
      { tex: ingTexTomato,  size: 0.60, pos: [-1.42, -0.88, 0.72], rot: [0.10, 0.15, 0.18],  curve: 0.08, mScale: 0.58 },
      { tex: ingTexBerries, size: 0.70, pos: [1.30, -0.98, 0.60], rot: [0.08, -0.15, -0.14], curve: 0.12, mScale: 0.58 },
      { tex: ingTexBasil,   size: 0.52, pos: [-0.22, 1.60, 0.42], rot: [0.22, 0.12, 1.25],   curve: 0.26, mScale: 0.54 },
      { tex: ingTexBroccoli,size: 0.64, pos: [1.46, 0.14, 0.35],  rot: [0.05, -0.20, -0.30], curve: 0.10, mScale: 0.0 },
    ];

    s1IngDefs.forEach((def, idx) => {
      const mat = createIngredientMaterial(def.tex, def.curve);
      const mesh = new THREE.Mesh(ingPlaneGeo, mat);
      mesh.scale.setScalar(def.size);
      scene1Group.add(mesh);
      scene1Ings.push({
        mesh,
        mat,
        baseOffset: new THREE.Vector3(def.pos[0], def.pos[1], def.pos[2]),
        rotBase: new THREE.Vector3(def.rot[0], def.rot[1], def.rot[2]),
        bobSpeed: 0.85 + idx * 0.14,
        bobAmp: 0.06 + (idx % 3) * 0.018,
        phase: idx * 1.15,
        mobileScale: def.mScale * def.size,
      });
    });

    // Golden Extra-Virgin Olive Oil Droplets orbiting Hero Plate
    const s1OilDrops: { mesh: THREE.Mesh; offset: THREE.Vector3; phase: number }[] = [];
    const oilGeo = new THREE.SphereGeometry(1, 24, 24);
    [
      [-1.08, 0.18, 0.92, 0.062],
      [1.15, 0.42, 0.88, 0.050],
      [0.45, -1.42, 0.75, 0.068],
      [-0.65, 1.38, 0.60, 0.044],
      [1.68, -0.28, 0.52, 0.054],
    ].forEach(([ox, oy, oz, r], idx) => {
      const drop = new THREE.Mesh(oilGeo, oliveOilMat);
      drop.scale.setScalar(r);
      scene1Group.add(drop);
      s1OilDrops.push({ mesh: drop, offset: new THREE.Vector3(ox, oy, oz), phase: idx * 1.3 });
    });

    // =========================================================================
    // TRANSITION STREAM (0.15 - 0.27): FLOATING FRESH HERBS & BERRIES STREAM
    // =========================================================================
    const bridgeGroup = new THREE.Group();
    scene.add(bridgeGroup);
    const bridgeItems: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial; basePos: THREE.Vector3; speed: number; rotZ: number }[] = [];
    [
      { tex: ingTexBasil,    x: 1.9,  y: -0.6, z: 1.1, sz: 0.75, rz: 0.4 },
      { tex: ingTexAvocado,  x: 2.8,  y: 0.7,  z: 0.4, sz: 0.92, rz: -0.3 },
      { tex: ingTexTomato,   x: 1.1,  y: 1.1,  z: 0.9, sz: 0.58, rz: 0.2 },
      { tex: ingTexBerries,  x: 2.5,  y: -1.2, z: 0.6, sz: 0.70, rz: -0.2 },
      { tex: ingTexBasil,    x: -2.2, y: 1.25, z: 0.5, sz: 0.56, rz: 1.8 },
    ].forEach((b, i) => {
      const mat = createIngredientMaterial(b.tex, 0.20);
      const mesh = new THREE.Mesh(ingPlaneGeo, mat);
      mesh.scale.setScalar(b.sz);
      bridgeGroup.add(mesh);
      bridgeItems.push({
        mesh,
        mat,
        basePos: new THREE.Vector3(b.x, b.y, b.z),
        speed: 0.6 + i * 0.15,
        rotZ: b.rz,
      });
    });

    // =========================================================================
    // SCENE 2 (0.25 - 0.455) & SCENE 5 (0.895 - 1.00):
    // INTERACTIVE CLINICAL OPTIMUMS 3D PLATE TURNTABLE + PROPORTION COMPASS
    // =========================================================================
    const scene2Group = new THREE.Group();
    scene.add(scene2Group);

    const optimumPlate = build3DPlateUnit(plateTexMed);
    scene2Group.add(optimumPlate.group);

    // Delicate 1px #C49B47 Gold Harvard Nutritional Proportion Ring + 3 Sector Ticks (50% / 25% / 25%)
    const proportionRingMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#C49B47'),
      metalness: 0.68,
      roughness: 0.28,
      transparent: true,
      opacity: 0.72,
    });
    const proportionGroup = new THREE.Group();
    const outerCompassRing = new THREE.Mesh(
      new THREE.TorusGeometry(1.74, 0.0075, 18, 180),
      proportionRingMat
    );
    proportionGroup.add(outerCompassRing);

    // 3 subtle radial proportion ticks (0 deg, 180 deg = 50% greens; 270 deg = 25% protein / 25% complex carbs)
    [0, Math.PI, Math.PI * 1.5].forEach((ang) => {
      const tickGeo = new THREE.CylinderGeometry(0.006, 0.006, 0.18, 8);
      const tickMesh = new THREE.Mesh(tickGeo, proportionRingMat);
      tickMesh.position.set(Math.cos(ang) * 1.74, Math.sin(ang) * 1.74, 0.02);
      tickMesh.rotation.z = ang - Math.PI / 2;
      proportionGroup.add(tickMesh);
    });
    scene2Group.add(proportionGroup);

    // 5 Orbiting Fresh Ingredients around the Clinical Optimum Plate
    const s2Ings: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial; angle: number; radius: number; zOff: number; baseSize: number }[] = [];
    [
      { tex: ingTexBasil,    ang: 0.55,  rad: 2.02, z: 0.45, sz: 0.62, curve: 0.24 },
      { tex: ingTexAvocado,  ang: 2.35,  rad: 2.12, z: 0.40, sz: 0.78, curve: 0.10 },
      { tex: ingTexTomato,   ang: 3.70,  rad: 2.00, z: 0.48, sz: 0.56, curve: 0.08 },
      { tex: ingTexBerries,  ang: 5.15,  rad: 2.08, z: 0.38, sz: 0.64, curve: 0.12 },
      { tex: ingTexBroccoli, ang: 1.45,  rad: 2.15, z: -0.15, sz: 0.62, curve: 0.10 },
    ].forEach((d) => {
      const mat = createIngredientMaterial(d.tex, d.curve);
      const mesh = new THREE.Mesh(ingPlaneGeo, mat);
      scene2Group.add(mesh);
      s2Ings.push({ mesh, mat, angle: d.ang, radius: d.rad, zOff: d.z, baseSize: d.sz });
    });

    // Track biomarker plate switching with silky crossfade & turntable spin
    let currentBioPlateIdx = bioIdxRef.current;
    let targetPlateSpin = 0;
    let currentPlateSpin = 0;
    let crossfadeProgress = 1;

    // =========================================================================
    // SCENE 3 (0.44 - 0.715): CURVED 3D GASTRONOMIC RIBBON + FLOATING HERBS
    // =========================================================================
    const scene3Group = new THREE.Group();
    scene.add(scene3Group);

    const ribbonMeshes: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial; baseAngle: number }[] = [];
    const cardPlaneGeo = new THREE.PlaneGeometry(3.52, 2.20, 40, 22);

    ribbonCards.forEach((spec, i) => {
      const initialTex = createCardCanvasTexture(spec, maxAniso, isMobileViewport);

      const mat = new THREE.ShaderMaterial({
        uniforms: {
          uTex: { value: initialTex },
          uTime: { value: 0 },
          uVelocity: { value: 0 },
          uOpacity: { value: 0 },
        },
        transparent: true,
        side: THREE.DoubleSide,
        vertexShader: `
          uniform float uTime;
          uniform float uVelocity;
          varying vec2 vUv;

          void main() {
            vUv = uv;
            vec3 pos = position;
            float bend = -pow(pos.x, 2.0) * 0.11;
            float wave = sin(pos.x * 2.0 + uTime * 2.0) * (0.014 + abs(uVelocity) * 0.11);
            pos.z += bend + wave;
            pos.y += sin(pos.x * 1.4 + uTime * 1.4) * abs(uVelocity) * 0.05;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
          }
        `,
        fragmentShader: `
          uniform sampler2D uTex;
          uniform float uVelocity;
          uniform float uOpacity;
          varying vec2 vUv;

          void main() {
            float shift = clamp(uVelocity * 0.003, -0.004, 0.004);
            float r = texture2D(uTex, vUv + vec2(shift, 0.0)).r;
            float g = texture2D(uTex, vUv).g;
            float b = texture2D(uTex, vUv - vec2(shift, 0.0)).b;
            gl_FragColor = vec4(r, g, b, uOpacity);
          }
        `,
      });

      const resolvedSrc = resolveAssetSrc(spec.imageSrc);
      const img = new Image();
      if (
        !resolvedSrc.startsWith('data:') &&
        typeof window !== 'undefined' &&
        window.location.protocol !== 'file:'
      ) {
        img.crossOrigin = 'anonymous';
      }
      img.onload = () => {
        const old = mat.uniforms.uTex.value as THREE.Texture;
        mat.uniforms.uTex.value = createCardCanvasTexture(spec, maxAniso, isMobileViewport, img);
        old.dispose();
      };
      img.src = resolvedSrc;

      const mesh = new THREE.Mesh(cardPlaneGeo, mat);
      scene3Group.add(mesh);
      ribbonMeshes.push({ mesh, mat, baseAngle: i * 0.64 });
    });

    // Subtle floating botanical accents around the 3D Ribbon
    const s3Botanicals: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial; basePos: THREE.Vector3; phase: number }[] = [];
    [
      { tex: ingTexBasil,  pos: [-2.85, 1.35, 0.8], sz: 0.56 },
      { tex: ingTexTomato, pos: [2.90, -1.15, 0.7], sz: 0.50 },
      { tex: ingTexBasil,  pos: [2.65, 1.38, -0.4], sz: 0.48 },
    ].forEach((b, idx) => {
      const mat = createIngredientMaterial(b.tex, 0.22);
      const mesh = new THREE.Mesh(ingPlaneGeo, mat);
      mesh.scale.setScalar(b.sz);
      scene3Group.add(mesh);
      s3Botanicals.push({ mesh, mat, basePos: new THREE.Vector3(b.pos[0], b.pos[1], b.pos[2]), phase: idx * 1.7 });
    });

    // =========================================================================
    // SCENE 4 (0.70 - 0.91): 4-PLATE 3D CHEF'S TASTING CAROUSEL (4 CASE ROUTES)
    // =========================================================================
    const scene4Group = new THREE.Group();
    scene.add(scene4Group);

    // Subtle #C49B47 golden orbital trajectory arc connecting the 4 tasting plates
    const tastingArcMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#C49B47'),
      metalness: 0.65,
      roughness: 0.30,
      transparent: true,
      opacity: 0,
    });
    const tastingArcRing = new THREE.Mesh(
      new THREE.TorusGeometry(3.6, 0.006, 14, 180),
      tastingArcMat
    );
    tastingArcRing.rotation.x = 1.18;
    tastingArcRing.position.set(1.25, -0.15, -2.2);
    scene4Group.add(tastingArcRing);

    const routePlates = [
      build3DPlateUnit(plateTexMed),      // 01: Энергия и железодефицит (лосось, шпинат, яйцо)
      build3DPlateUnit(plateTexAvocado),  // 02: Стройность и ЖКТ (зелёный боул с авокадо и пашот)
      build3DPlateUnit(plateTexFamily),   // 03: Мама и ребёнок (индейка, брокколи, киноа, ягоды)
      build3DPlateUnit(plateTexVitality), // 04: Беременность и опора (зелень, орехи, буратта, гранат)
    ];
    routePlates.forEach((rp) => scene4Group.add(rp.group));

    // Companion floating garnish over the active Scene 4 Tasting Plate
    const s4Garnish: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial; offset: THREE.Vector3; phase: number }[] = [];
    [
      { tex: ingTexBasil,   off: [-1.25, 0.95, 0.65], sz: 0.54 },
      { tex: ingTexBerries, off: [1.32, 0.88, 0.55],  sz: 0.58 },
      { tex: ingTexAvocado, off: [1.28, -0.86, 0.58], sz: 0.64 },
    ].forEach((g, idx) => {
      const mat = createIngredientMaterial(g.tex, 0.18);
      const mesh = new THREE.Mesh(ingPlaneGeo, mat);
      mesh.scale.setScalar(g.sz);
      scene4Group.add(mesh);
      s4Garnish.push({ mesh, mat, offset: new THREE.Vector3(g.off[0], g.off[1], g.off[2]), phase: idx * 2.1 });
    });

    // Pointer / Touch Parallax
    let mouseX = 0;
    let mouseY = 0;
    let smoothMX = 0;
    let smoothMY = 0;

    const onMouseMove = (e: MouseEvent) => {
      mouseX = (e.clientX / window.innerWidth) * 2 - 1;
      mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    const onResize = () => {
      const nw = window.innerWidth;
      const nh = window.innerHeight;
      const dpr = getOptimalDpr(nw);
      isMobileViewport = nw < 768;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(dpr);
      renderer.setSize(nw, nh);
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('resize', onResize);

    const smoothBand = (p: number, enter0: number, enter1: number, exit0: number, exit1: number) => {
      const fadeIn = enter0 === enter1 ? 1 : THREE.MathUtils.smoothstep(p, enter0, enter1);
      const fadeOut = exit0 === exit1 ? 1 : 1 - THREE.MathUtils.smoothstep(p, exit0, exit1);
      return fadeIn * fadeOut;
    };

    const clock = new THREE.Clock();
    let rafId = 0;
    let smoothRouteIdx = 0;

    const animate = () => {
      rafId = requestAnimationFrame(animate);
      const dt = Math.min(0.05, clock.getDelta());
      const t = clock.elapsedTime;
      const p = scrollProgressRef.current;
      const vel = scrollVelocityRef.current;

      smoothMX += (mouseX - smoothMX) * 0.06;
      smoothMY += (mouseY - smoothMY) * 0.06;

      const w1 = smoothBand(p, 0.0, 0.0, 0.14, 0.205);
      const wBridge = smoothBand(p, 0.145, 0.185, 0.235, 0.275);
      const w2Plate = smoothBand(p, 0.25, 0.29, 0.398, 0.434);
      const w5Finale = smoothBand(p, 0.895, 0.935, 1.0, 1.0);
      const w2Total = Math.min(1, w2Plate + w5Finale);
      const w3 = smoothBand(p, 0.432, 0.455, 0.684, 0.715);
      const w4 = smoothBand(p, 0.70, 0.745, 0.87, 0.91);

      // ---- SCENE 1: MORNING SUNLIT HERO SALAD PLATE & LEVITATING INGREDIENTS (COMPANION EMBLEM SMALLER THAN EKATERINA'S HERO PORTRAIT) ----
      scene1Group.visible = w1 > 0.01;
      if (scene1Group.visible) {
        const heroX = isMobileViewport ? 0.66 : 0.01;
        const heroY = isMobileViewport ? 0.80 : -0.04;
        const heroScale = isMobileViewport ? 0.23 : 0.43;

        const liftOut = (1 - w1) * 2.4;
        heroPlate.group.position.set(
          heroX + smoothMX * 0.14,
          heroY + Math.sin(t * 0.95) * 0.045 + smoothMY * 0.10 + liftOut,
          0
        );
        heroPlate.group.scale.setScalar(heroScale);
        // Sculptural 3/4 gallery tilt toward the viewer so both vibrant salad & ceramic lip gleam
        heroPlate.group.rotation.set(
          -0.44 + smoothMY * 0.12 + Math.sin(t * 0.6) * 0.04,
          (isMobileViewport ? -0.10 : -0.18) + smoothMX * 0.16 + Math.cos(t * 0.5) * 0.05,
          0.08
        );
        heroPlate.saladMat.uniforms.uSpinAngle.value = t * 0.14 + p * 2.2;
        heroPlate.saladMat.uniforms.uOpacity.value = w1;
        heroPlate.ceramicMat.opacity = w1;
        heroPlate.rimMat.opacity = 0.85 * w1;
        heroPlate.shadowMat.opacity = 0.55 * w1;

        heroOrbitRing.position.copy(heroPlate.group.position);
        heroOrbitRing.scale.setScalar(heroScale);
        heroOrbitRing.rotation.set(
          heroPlate.group.rotation.x + 0.18,
          heroPlate.group.rotation.y - 0.12,
          t * 0.18
        );
        brassRingMat.opacity = 0.48 * w1;

        scene1Ings.forEach((ing, idx) => {
          if (isMobileViewport && (ing.mobileScale <= 0.001 || idx >= 3)) {
            ing.mesh.visible = false;
            return;
          }
          ing.mesh.visible = true;
          const spreadFactor = isMobileViewport ? 0.27 : 0.47;
          const bob = Math.sin(t * ing.bobSpeed + ing.phase) * (ing.bobAmp * 0.72);
          const sway = Math.cos(t * ing.bobSpeed * 0.8 + ing.phase) * (ing.bobAmp * 0.45);

          ing.mesh.position.set(
            heroX + ing.baseOffset.x * spreadFactor + sway + smoothMX * (0.14 + ing.baseOffset.z * 0.10),
            heroY + ing.baseOffset.y * spreadFactor + bob + smoothMY * 0.12 + liftOut * 1.25,
            ing.baseOffset.z
          );
          ing.mesh.scale.setScalar(
            isMobileViewport ? ing.mobileScale * 0.48 : s1IngDefs[idx].size * 0.54
          );
          ing.mesh.rotation.set(
            ing.rotBase.x + Math.sin(t * 0.7 + ing.phase) * 0.08,
            ing.rotBase.y + Math.cos(t * 0.6 + ing.phase) * 0.08,
            ing.rotBase.z + Math.sin(t * 0.5 + ing.phase) * 0.06
          );
          ing.mat.uniforms.uTime.value = t;
          ing.mat.uniforms.uOpacity.value = w1;
        });

        oliveOilMat.opacity = 0.94 * w1;
        s1OilDrops.forEach((d, idx) => {
          const sf = isMobileViewport ? 0.26 : 0.46;
          d.mesh.visible = !isMobileViewport || idx < 2;
          d.mesh.position.set(
            heroX + d.offset.x * sf + Math.cos(t * 0.9 + d.phase) * 0.04 + smoothMX * 0.16,
            heroY + d.offset.y * sf + Math.sin(t * 1.1 + d.phase) * 0.05 + liftOut * 1.15,
            d.offset.z
          );
        });
      }

      // ---- TRANSITION BRIDGE: FLOATING CULINARY STREAM ----
      bridgeGroup.visible = wBridge > 0.01;
      if (bridgeGroup.visible) {
        const localB = (p - 0.145) / 0.13;
        bridgeItems.forEach((b, idx) => {
          b.mesh.visible = !isMobileViewport || idx < 3;
          const mx = isMobileViewport ? b.basePos.x * 0.42 : b.basePos.x;
          b.mesh.position.set(
            mx + smoothMX * 0.25,
            b.basePos.y + (localB - 0.5) * 2.2 * b.speed + Math.sin(t + idx) * 0.08,
            b.basePos.z
          );
          b.mesh.rotation.z = b.rotZ + localB * 0.6 + Math.sin(t * 0.8 + idx) * 0.08;
          b.mat.uniforms.uTime.value = t;
          b.mat.uniforms.uOpacity.value = wBridge * 0.92;
        });
      }

      // ---- SCENE 2 (CLINICAL OPTIMUM PLATE TURNTABLE) & SCENE 5 (FINALE SIGNATURE BOWL) ----
      scene2Group.visible = w2Total > 0.01;
      if (scene2Group.visible) {
        // Check if user clicked a different Biomarker tab -> spin plate & crossfade food!
        const desiredIdx = bioIdxRef.current % allPlateTextures.length;
        if (desiredIdx !== currentBioPlateIdx) {
          optimumPlate.saladMat.uniforms.uTexA.value = allPlateTextures[currentBioPlateIdx];
          optimumPlate.saladMat.uniforms.uTexB.value = allPlateTextures[desiredIdx];
          crossfadeProgress = 0;
          targetPlateSpin += Math.PI * 1.25;
          currentBioPlateIdx = desiredIdx;
        }
        crossfadeProgress = Math.min(1, crossfadeProgress + dt * 2.6);
        const smoothMix = crossfadeProgress * crossfadeProgress * (3 - 2 * crossfadeProgress);
        optimumPlate.saladMat.uniforms.uMix.value = smoothMix;

        currentPlateSpin += (targetPlateSpin - currentPlateSpin) * Math.min(1, dt * 6.5);
        const spinBurst = Math.abs(targetPlateSpin - currentPlateSpin);

        if (w5Finale > 0.01) {
          // SCENE 5 FINALE: Signature Porcelain Plate Balanced Smaller Beside Ekaterina's Portrait (Photo 2)
          optimumPlate.saladMat.uniforms.uTexA.value = plateTexMed;
          optimumPlate.saladMat.uniforms.uTexB.value = plateTexMed;

          const fx = isMobileViewport ? -0.46 : 0.06;
          const fy = isMobileViewport ? 1.28 : -0.02;
          const fScale = isMobileViewport ? 0.25 : 0.43;

          scene2Group.position.set(fx + smoothMX * 0.14, fy + Math.sin(t * 0.9) * 0.04 + smoothMY * 0.08, 0);
          scene2Group.scale.setScalar(THREE.MathUtils.lerp(0.38, fScale, w5Finale));

          optimumPlate.group.rotation.set(
            -0.40 + smoothMY * 0.10,
            (isMobileViewport ? 0.12 : -0.18) + smoothMX * 0.14,
            0.06
          );
          optimumPlate.saladMat.uniforms.uSpinAngle.value = t * 0.14;
          optimumPlate.saladMat.uniforms.uOpacity.value = w5Finale;
          optimumPlate.ceramicMat.opacity = w5Finale;
          optimumPlate.rimMat.opacity = 0.85 * w5Finale;
          optimumPlate.shadowMat.opacity = 0.55 * w5Finale;

          proportionGroup.rotation.copy(optimumPlate.group.rotation);
          proportionGroup.rotation.z = t * 0.15;
          proportionRingMat.opacity = 0.55 * w5Finale;

          s2Ings.forEach((ing, idx) => {
            ing.mesh.visible = !isMobileViewport || idx < 2;
            const orbitAng = ing.angle + t * 0.18;
            ing.mesh.position.set(
              Math.cos(orbitAng) * 1.82,
              Math.sin(orbitAng) * 1.48,
              ing.zOff
            );
            ing.mesh.scale.setScalar(ing.baseSize * 0.82);
            ing.mesh.rotation.z = orbitAng * 0.4;
            ing.mat.uniforms.uTime.value = t;
            ing.mat.uniforms.uOpacity.value = w5Finale * 0.90;
          });
        } else {
          // SCENE 2: Centered Clinical Optimums Plate Turntable
          const cScale = isMobileViewport ? 0.56 : 0.82;
          const cY = isMobileViewport ? 0.10 : -0.02;

          scene2Group.position.set(
            smoothMX * 0.16,
            cY + Math.sin(t * 0.95) * 0.04 + smoothMY * 0.10,
            (1 - w2Plate) * -1.4
          );
          scene2Group.scale.setScalar(THREE.MathUtils.lerp(0.64, cScale, w2Plate));

          optimumPlate.group.rotation.set(
            -0.36 + smoothMY * 0.16 + Math.sin(t * 0.55) * 0.04,
            smoothMX * 0.22 + Math.cos(t * 0.45) * 0.06,
            0
          );
          optimumPlate.saladMat.uniforms.uSpinAngle.value = currentPlateSpin + t * 0.12 + p * 1.8;
          optimumPlate.saladMat.uniforms.uOpacity.value = w2Plate;
          optimumPlate.ceramicMat.opacity = w2Plate;
          optimumPlate.rimMat.opacity = 0.85 * w2Plate;
          optimumPlate.shadowMat.opacity = 0.55 * w2Plate;

          proportionGroup.rotation.copy(optimumPlate.group.rotation);
          proportionGroup.rotation.z = -currentPlateSpin * 0.35 + t * 0.08;
          proportionRingMat.opacity = 0.65 * w2Plate;

          // Ingredients gently expand on spin impulse & assemble cleanly on scroll
          const assembleExpand = 1.0 + (1.0 - w2Plate) * 0.45 + Math.min(0.28, spinBurst * 0.12);
          s2Ings.forEach((ing, idx) => {
            ing.mesh.visible = !isMobileViewport || idx < 4;
            const ang = ing.angle + currentPlateSpin * 0.22 + Math.sin(t * 0.4 + idx) * 0.06;
            const radX = ing.radius * assembleExpand * (isMobileViewport ? 0.88 : 0.92);
            const radY = ing.radius * assembleExpand * 0.78;
            ing.mesh.position.set(
              Math.cos(ang) * radX,
              Math.sin(ang) * radY,
              ing.zOff + Math.sin(t * 0.9 + idx) * 0.08
            );
            ing.mesh.scale.setScalar(ing.baseSize);
            ing.mesh.rotation.set(
              0.12 * Math.sin(t + idx),
              0.12 * Math.cos(t + idx),
              ang * 0.35
            );
            ing.mat.uniforms.uTime.value = t;
            ing.mat.uniforms.uOpacity.value = w2Plate * 0.95;
          });
        }
      }

      // ---- SCENE 3: CURVED 3D GASTRONOMIC RIBBON + FLOATING HERBS ----
      scene3Group.visible = w3 > 0.01;
      if (scene3Group.visible) {
        const localT = THREE.MathUtils.clamp((p - 0.46) / 0.22, 0, 1);
        const totalArc = (ribbonMeshes.length - 1) * 0.64;
        const currentArc = localT * totalArc;

        const radius = isMobileViewport ? 4.4 : 5.6;
        const cardScale = isMobileViewport ? Math.min(0.60, camera.aspect * 1.22) : 1.0;
        const combinedVel = vel + ribbonDragVelRef.current;

        ribbonMeshes.forEach((item) => {
          const angle = item.baseAngle - currentArc + smoothMX * 0.06;
          item.mesh.scale.setScalar(cardScale);
          item.mesh.position.x = Math.sin(angle) * radius;
          item.mesh.position.z = Math.cos(angle) * radius - radius + 0.55;
          item.mesh.position.y =
            Math.sin(angle * 1.4) * 0.06 + smoothMY * 0.10 + (isMobileViewport ? 0.12 : 0.06);
          item.mesh.rotation.y = angle * 0.88;

          item.mat.uniforms.uTime.value = t;
          item.mat.uniforms.uVelocity.value = combinedVel;
          const distFade = THREE.MathUtils.clamp(1.15 - Math.abs(angle) * 0.48, 0.2, 1.0);
          item.mat.uniforms.uOpacity.value = w3 * distFade;
        });

        s3Botanicals.forEach((b, idx) => {
          b.mesh.visible = !isMobileViewport || idx === 0;
          const bx = isMobileViewport ? b.basePos.x * 0.45 : b.basePos.x;
          b.mesh.position.set(
            bx - combinedVel * 0.18 + smoothMX * 0.22,
            b.basePos.y + Math.sin(t * 0.9 + b.phase) * 0.08,
            b.basePos.z
          );
          b.mesh.rotation.z = b.phase + t * 0.12 + combinedVel * 0.08;
          b.mat.uniforms.uTime.value = t;
          b.mat.uniforms.uOpacity.value = w3 * 0.78;
        });
      }

      // ---- SCENE 4: 4-PLATE 3D CHEF'S TASTING CAROUSEL (CASE ROUTES 01..04) ----
      scene4Group.visible = w4 > 0.01;
      if (scene4Group.visible) {
        const local4 = THREE.MathUtils.clamp((p - 0.72) / 0.16, 0, 0.999);
        const targetRoute = Math.floor(local4 * 4);
        smoothRouteIdx += (targetRoute - smoothRouteIdx) * Math.min(1, dt * 6.0);

        tastingArcMat.opacity = 0.36 * w4;
        tastingArcRing.rotation.z = -smoothRouteIdx * 0.65 + t * 0.05;

        const heroSpotX = isMobileViewport ? 0.0 : 1.18;
        const heroSpotY = isMobileViewport ? 0.48 : 0.16;
        const activeScale = isMobileViewport ? 0.48 : 0.86;

        routePlates.forEach((rp, idx) => {
          const rel = idx - smoothRouteIdx;
          const dist = Math.abs(rel);

          if (isMobileViewport && dist > 1.15) {
            rp.group.visible = false;
            return;
          }
          rp.group.visible = true;

          const arcX = heroSpotX + rel * (isMobileViewport ? 2.1 : 2.35);
          const arcY = heroSpotY - dist * 0.34 + Math.sin(t * 0.9 + idx) * 0.04;
          const arcZ = -dist * 1.75;

          rp.group.position.set(
            arcX + smoothMX * 0.15,
            arcY + smoothMY * 0.10,
            arcZ
          );
          const sc = activeScale * THREE.MathUtils.clamp(1.0 - dist * 0.30, 0.40, 1.0);
          rp.group.scale.setScalar(sc);

          rp.group.rotation.set(
            -0.44 + smoothMY * 0.12,
            (isMobileViewport ? 0 : -0.24) - rel * 0.35 + smoothMX * 0.15,
            0.05
          );

          const fade = THREE.MathUtils.clamp(1.08 - dist * 0.68, 0.0, 1.0) * w4;
          rp.saladMat.uniforms.uSpinAngle.value = t * 0.13 + idx * 0.8;
          rp.saladMat.uniforms.uOpacity.value = fade;
          rp.ceramicMat.opacity = fade;
          rp.rimMat.opacity = 0.85 * fade;
          rp.shadowMat.opacity = 0.55 * fade;
        });

        s4Garnish.forEach((g, idx) => {
          g.mesh.visible = !isMobileViewport || idx < 2;
          const sf = isMobileViewport ? 0.60 : 1.0;
          g.mesh.position.set(
            heroSpotX + g.offset.x * sf + Math.cos(t * 0.85 + g.phase) * 0.06 + smoothMX * 0.22,
            heroSpotY + g.offset.y * sf + Math.sin(t * 1.05 + g.phase) * 0.07 + smoothMY * 0.14,
            g.offset.z
          );
          g.mesh.rotation.z = Math.sin(t * 0.6 + g.phase) * 0.25 + idx;
          g.mat.uniforms.uTime.value = t;
          g.mat.uniforms.uOpacity.value = w4 * 0.88;
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
      if (renderer.domElement && renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [ribbonCards, scrollProgressRef, scrollVelocityRef, ribbonDragVelRef]);

  if (webglFallback) {
    return (
      <div className="fixed inset-0 viewport-stage z-0 pointer-events-none brand-cream-stage" />
    );
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 viewport-stage z-0 pointer-events-none brand-cream-stage"
    />
  );
};
