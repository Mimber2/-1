import React, { useEffect, useState } from 'react';
import {
  X,
  Check,
  ArrowUpRight,
  Sparkles,
  FileText,
  Award,
  MessageCircle,
  Send,
  PhoneCall,
  ChevronDown,
  ShieldCheck,
  Settings,
  Sliders,
  Gift,
  Layers,
} from 'lucide-react';
import {
  BrandProfile,
  DEFAULT_BRAND,
  SERVICES,
  QUICK_BOOKING,
  BIOMARKERS,
  CASE_REVIEWS,
  CREDENTIALS,
  FAQ_ITEMS,
  SYMPTOM_ITEMS,
  ServiceOffering,
  SPECIALIST_PHOTOS,
  resolveAssetUrl,
} from '../data/siteConfig';

export type DrawerType =
  | null
  | 'mobile-menu'
  | 'catalog'
  | 'service-detail'
  | 'quiz'
  | 'biomarkers'
  | 'cases'
  | 'booking'
  | 'legal'
  | 'brand';

interface ConciergeDrawersProps {
  activeDrawer: DrawerType;
  selectedServiceId: string | null;
  initialBioIdx: number;
  bookingPrefill: { title: string; message: string };
  brand: BrandProfile;
  onSaveBrand: (next: BrandProfile) => void;
  onResetBrand: () => void;
  onClose: () => void;
  onOpenDrawer: (next: DrawerType) => void;
  onNavigateChapter: (targetP: number) => void;
  onOpenBooking: (title: string, message: string) => void;
  onSelectServiceDetail: (serviceId: string) => void;
}

export const ConciergeDrawers: React.FC<ConciergeDrawersProps> = ({
  activeDrawer,
  selectedServiceId,
  initialBioIdx,
  bookingPrefill,
  brand,
  onSaveBrand,
  onResetBrand,
  onClose,
  onOpenDrawer,
  onNavigateChapter,
  onOpenBooking,
  onSelectServiceDetail,
}) => {
  const [quizStep, setQuizStep] = useState(0);
  const [quizGoal, setQuizGoal] = useState<'personal' | 'family' | 'vip' | 'guide'>('personal');
  const [quizDone, setQuizDone] = useState(false);

  const [bioIdx, setBioIdx] = useState(initialBioIdx);
  const activeBio = BIOMARKERS[bioIdx] || BIOMARKERS[0];
  const [userLabValue, setUserLabValue] = useState<number>(activeBio.exampleClientValue);

  useEffect(() => {
    setBioIdx(initialBioIdx);
    const target = BIOMARKERS[initialBioIdx] || BIOMARKERS[0];
    setUserLabValue(target.exampleClientValue);
  }, [initialBioIdx, activeDrawer]);

  const handleSelectBioTab = (idx: number) => {
    setBioIdx(idx);
    setUserLabValue(BIOMARKERS[idx].exampleClientValue);
  };

  const [expandedDiploma, setExpandedDiploma] = useState<number | null>(0);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [replyWindow, setReplyWindow] = useState<'any' | 'day' | 'evening'>('day');
  const [clientNote, setClientNote] = useState('');
  const [bookingSent, setBookingSent] = useState(false);

  const [draftBrand, setDraftBrand] = useState<BrandProfile>(brand);

  if (!activeDrawer) return null;

  const selectedService: ServiceOffering =
    SERVICES.find((s) => s.id === selectedServiceId) || SERVICES[0];

  const replyWindowLabel =
    replyWindow === 'day'
      ? 'Удобно получить ответ днём (10:00–18:00)'
      : replyWindow === 'evening'
      ? 'Удобно получить ответ вечером (после 18:00)'
      : 'В любое удобное время';

  const buildMessengerMessage = () => {
    const base = clientNote.trim() || bookingPrefill.message;
    const parts = [base];
    if (clientName.trim()) parts.push(`Имя: ${clientName.trim()}`);
    if (clientPhone.trim()) parts.push(`Контакт: ${clientPhone.trim()}`);
    parts.push(`Пожелание по связи: ${replyWindowLabel}`);
    return parts.join('\n');
  };

  const encodedMsg = encodeURIComponent(buildMessengerMessage());
  const tgUrl = `https://t.me/${brand.telegramUsername.replace('@', '')}?text=${encodedMsg}`;
  const waUrl = `https://wa.me/${brand.whatsappPhone.replace(/\D/g, '')}?text=${encodedMsg}`;

  const quizRecommendation = (() => {
    if (quizGoal === 'family') return SERVICES[1];
    if (quizGoal === 'vip') return SERVICES[2];
    if (quizGoal === 'guide') return SERVICES[3];
    return SERVICES[0];
  })();

  const clampedUserVal = Math.max(activeBio.scaleMin, Math.min(activeBio.scaleMax, userLabValue || 0));
  const pinPercent = Math.max(2, Math.min(98, (clampedUserVal / activeBio.scaleMax) * 100));

  const bioZone = (() => {
    if (userLabValue >= activeBio.optimumMin && userLabValue <= activeBio.optimumMax) {
      return {
        badge: 'Физиологический оптимум',
        badgeStyle: 'bg-[#F9F6F0] text-[#0F5A4A]',
        summary: `Отличный ориентир (${userLabValue} ${activeBio.unit}): показатель находится внутри целевого коридора ${activeBio.optimumMin}–${activeBio.optimumMax} ${activeBio.unit}. Важно оценивать его в связке с кофакторами, чтобы убедиться, что это истинный клеточный ресурс.`,
      };
    }
    if (userLabValue >= activeBio.labRefMin && userLabValue <= activeBio.labRefMax) {
      return {
        badge: '«Серая зона» бланка · Скрытый сдвиг',
        badgeStyle: 'bg-[#C49B47] text-[#1C2833]',
        summary: `Показатель ${userLabValue} ${activeBio.unit} укладывается в широкую норму поликлиники (${activeBio.labRefMin}–${activeBio.labRefMax}), поэтому врач не поставит отметку. Однако до физиологического оптимума (${activeBio.optimumMin}–${activeBio.optimumMax} ${activeBio.unit}) ресурса уже не хватает — отсюда усталость и симптомы.`,
      };
    }
    return {
      badge: 'Выход за референс лаборатории',
      badgeStyle: 'bg-[#F9F6F0] text-[#1C2833]',
      summary: `Значение ${userLabValue} ${activeBio.unit} выходит даже за широкие границы лаборатории (${activeBio.labRefMin}–${activeBio.labRefMax} ${activeBio.unit}). Рекомендуется приоритетный разбор причин в связке с сопутствующими маркерами и при необходимости очная консультация профильного врача.`,
    };
  })();

  const renderOfferMandatoryBanner = () => (
    <div className="p-4 sm:p-5 rounded-2xl bg-[#FAF6EE] border border-[#1C2833]/12 shadow-sm space-y-3.5">
      <div className="flex items-start gap-3.5">
        <svg
          viewBox="0 0 28 42"
          fill="none"
          aria-hidden="true"
          className="w-6 h-9 text-[#1C2833] shrink-0 mt-0.5"
        >
          <path
            d="M14 2V26M14 26L6.5 18.5M14 26L21.5 18.5"
            stroke="currentColor"
            strokeWidth="2.3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="14" cy="35" r="2.8" stroke="currentColor" strokeWidth="2.2" />
        </svg>
        <p className="text-xs sm:text-sm font-medium text-[#1C2833] leading-relaxed">
          Перед записью необходимо ознакомиться с{'\u00A0'}договором оферты и{'\u00A0'}согласовать дату
          и{'\u00A0'}время встречи.
        </p>
      </div>
      <button
        type="button"
        onClick={() => onOpenDrawer('legal')}
        className="w-full py-3.5 px-5 rounded-xl studio-accent-block hover:brightness-110 transition flex flex-col items-center justify-center text-center"
      >
        <span className="text-sm sm:text-[15px] font-semibold tracking-[0.08em] uppercase text-[#F9F6F0]">
          ДОГОВОР ОФЕРТЫ
        </span>
        <span className="text-xs sm:text-[13px] text-[#C49B47] font-medium mt-0.5">
          Обязательно к прочтению!
        </span>
      </button>
    </div>
  );

  return (
    <div className="fixed inset-0 viewport-stage z-50 flex justify-end bg-[#1C2833]/45 backdrop-blur-md">
      <div className="flex-1 cursor-pointer" onClick={onClose} />

      <div className="relative w-full max-w-2xl h-full overflow-y-auto overscroll-contain bg-[#F0E7D5] border-l border-[#1C2833]/12 text-[#1C2833] shadow-2xl px-5 sm:px-10 safe-top safe-bottom">
        {/* Top bar */}
        <div className="flex items-center justify-between pt-2 pb-5 mb-6 border-b border-[#1C2833]/12">
          <div className="pr-3">
            <p className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-[0.20em] text-[#0F5A4A]">
              {brand.name} · Клиническая нутрициология
            </p>
            <h2 className="text-xl sm:text-3xl font-semibold tracking-tight text-[#1C2833] mt-1">
              {activeDrawer === 'mobile-menu' && 'Навигация и быстрые действия'}
              {activeDrawer === 'catalog' && 'Все форматы работы и тарифы'}
              {activeDrawer === 'service-detail' && selectedService.title}
              {activeDrawer === 'quiz' && 'Подбор формата за 30 секунд'}
              {activeDrawer === 'biomarkers' && 'Проверка вашего анализа по оптимумам'}
              {activeDrawer === 'cases' && 'Динамика анализов, дипломы и FAQ'}
              {activeDrawer === 'booking' && bookingPrefill.title}
              {activeDrawer === 'legal' && 'Договор публичной оферты'}
              {activeDrawer === 'brand' && 'Настройка контактов и реквизитов'}
            </h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Закрыть"
            className="w-10 h-10 rounded-full bg-[#FAF6EE] hover:bg-[#0F5A4A] text-[#1C2833] hover:text-[#F9F6F0] border border-[#1C2833]/12 flex items-center justify-center transition shrink-0 shadow-sm"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 0. MOBILE QUICK MENU SHEET */}
        {activeDrawer === 'mobile-menu' && (
          <div className="space-y-6 pb-4">
            {/* Specialist Identity Banner (Photo 1 — Акцентный блок #0F5A4A) */}
            <div className="p-3.5 rounded-2xl studio-accent-block flex items-center gap-3.5">
              <img
                src={resolveAssetUrl(SPECIALIST_PHOTOS.hero)}
                alt={brand.name}
                className="w-16 h-24 rounded-xl object-cover shrink-0 ring-1 ring-[#C49B47]/50"
              />
              <div className="min-w-0">
                <div className="text-[10px] uppercase tracking-[0.16em] text-[#C49B47] font-semibold">
                  {brand.role}
                </div>
                <div className="text-base font-semibold text-[#F9F6F0] mt-0.5">{brand.name}</div>
                <div className="text-xs text-[#F9F6F0]/80 mt-1 num-tabular">
                  {brand.experienceYears} практики · {brand.clientsCount} семей · {brand.city}
                </div>
              </div>
            </div>

            {/* Primary Interactive Tools */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                onClick={() => onOpenDrawer('biomarkers')}
                className="p-4 rounded-2xl bg-[#FAF6EE] border border-[#0F5A4A]/25 text-left flex items-center justify-between gap-3 active:scale-[0.99] transition shadow-sm"
              >
                <div>
                  <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#0F5A4A]">
                    Онлайн-калькулятор
                  </div>
                  <div className="text-sm font-semibold text-[#1C2833] mt-0.5">
                    Проверить свой показатель
                  </div>
                </div>
                <Sliders className="w-4 h-4 text-[#0F5A4A] shrink-0" />
              </button>

              <button
                onClick={() => onOpenDrawer('quiz')}
                className="p-4 rounded-2xl bg-[#FAF6EE] border border-[#1C2833]/12 text-left flex items-center justify-between gap-3 active:scale-[0.99] transition shadow-sm"
              >
                <div>
                  <div className="text-[10px] uppercase tracking-[0.16em] text-[#1C2833]/55">
                    Интерактивный тест
                  </div>
                  <div className="text-sm font-semibold text-[#1C2833] mt-0.5">
                    Подбор формата за 30 сек
                  </div>
                </div>
                <Sparkles className="w-4 h-4 text-[#0F5A4A] shrink-0" />
              </button>

              <button
                onClick={() => onOpenDrawer('catalog')}
                className="p-4 rounded-2xl bg-[#FAF6EE] border border-[#1C2833]/12 text-left flex items-center justify-between gap-3 active:scale-[0.99] transition shadow-sm"
              >
                <div>
                  <div className="text-[10px] uppercase tracking-[0.16em] text-[#1C2833]/55">
                    Программы и цены
                  </div>
                  <div className="text-sm font-semibold text-[#1C2833] mt-0.5">
                    Все 4 формата списком
                  </div>
                </div>
                <Layers className="w-4 h-4 text-[#0F5A4A] shrink-0" />
              </button>

              <button
                onClick={() => onOpenDrawer('cases')}
                className="p-4 rounded-2xl bg-[#FAF6EE] border border-[#1C2833]/12 text-left flex items-center justify-between gap-3 active:scale-[0.99] transition shadow-sm"
              >
                <div>
                  <div className="text-[10px] uppercase tracking-[0.16em] text-[#1C2833]/55">
                    Кейсы · 1 784 ак. часа
                  </div>
                  <div className="text-sm font-semibold text-[#1C2833] mt-0.5">
                    Динамика анализов и дипломы
                  </div>
                </div>
                <Award className="w-4 h-4 text-[#0F5A4A] shrink-0" />
              </button>
            </div>

            {/* 5 Chapters Quick Jump */}
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#1C2833]/55 mb-2.5">
                Быстрый переход по 3D-главам
              </div>
              <div className="space-y-2">
                {[
                  { num: '01', label: 'Главная · Системное здоровье', p: 0.0 },
                  { num: '02', label: 'Физиологические оптимумы анализов', p: 0.335 },
                  { num: '03', label: 'Консультации, ведение и гайд', p: 0.46 },
                  { num: '04', label: 'Рационы и кейсы клиентов', p: 0.78 },
                  { num: '05', label: 'Записаться на консультацию', p: 0.965 },
                ].map((ch) => (
                  <button
                    key={ch.num}
                    onClick={() => {
                      onClose();
                      onNavigateChapter(ch.p);
                    }}
                    className="w-full px-4 py-3 rounded-xl bg-[#FAF6EE] hover:bg-[#0F5A4A]/6 border border-[#1C2833]/10 flex items-center justify-between text-left transition"
                  >
                    <span className="text-sm text-[#1C2833] font-medium">
                      <span className="font-mono text-xs text-[#0F5A4A] font-semibold mr-2.5">
                        {ch.num}
                      </span>
                      {ch.label}
                    </span>
                    <ArrowUpRight className="w-4 h-4 text-[#0F5A4A] shrink-0" />
                  </button>
                ))}
              </div>
            </div>

            {/* Mandatory Offer Notice + Direct Messengers CTA */}
            <div className="space-y-3 pt-2 border-t border-[#1C2833]/12">
              {renderOfferMandatoryBanner()}
              <button
                onClick={() => onOpenBooking(QUICK_BOOKING.title, QUICK_BOOKING.prefillMessage)}
                className="w-full py-3.5 px-5 rounded-full btn-brand-gold text-sm font-semibold flex items-center justify-center gap-2"
              >
                Записаться
                <ArrowUpRight className="w-4 h-4" />
              </button>
              <div className="grid grid-cols-2 gap-2.5">
                <a
                  href={`https://t.me/${brand.telegramUsername.replace('@', '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-3 rounded-xl bg-[#FAF6EE] border border-[#1C2833]/12 text-[#1C2833] text-xs font-semibold flex items-center justify-center gap-2 shadow-sm"
                >
                  <Send className="w-3.5 h-3.5 text-[#0F5A4A]" />
                  Telegram
                </a>
                <a
                  href={`https://wa.me/${brand.whatsappPhone.replace(/\D/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-3 rounded-xl bg-[#FAF6EE] border border-[#1C2833]/12 text-[#1C2833] text-xs font-semibold flex items-center justify-center gap-2 shadow-sm"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-[#0F5A4A]" />
                  WhatsApp
                </a>
              </div>
            </div>
          </div>
        )}

        {/* 1. FULL CATALOG DRAWER (STRICTLY 4 FORMATS) */}
        {activeDrawer === 'catalog' && (
          <div className="space-y-5 pb-4">
            {/* Editorial Consultation Spotlight (Photo 3 — Акцентный блок #0F5A4A) */}
            <div className="rounded-2xl p-4 sm:p-5 studio-accent-block flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <img
                src={resolveAssetUrl(SPECIALIST_PHOTOS.consult)}
                alt="Екатерина Пименова — личная консультация"
                className="w-24 h-36 sm:w-28 sm:h-40 rounded-xl object-cover shrink-0 ring-1 ring-[#C49B47]/55"
              />
              <div className="space-y-2 flex-1">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#C49B47] text-[#1C2833] text-[10px] font-semibold uppercase tracking-[0.15em]">
                  Личный разбор с Екатериной
                </span>
                <h3 className="text-base sm:text-lg font-semibold text-[#F9F6F0] leading-snug">
                  Бережные консультации по анализам и питанию без голодных диет
                </h3>
                <p className="text-xs text-[#F9F6F0]/80 leading-relaxed">
                  Каждая консультация — это глубокая подготовка по вашим бланкам, 1,5–2 часа живого
                  диалога и понятный пошаговый план для вас или всей семьи.
                </p>
              </div>
            </div>

            {SERVICES.map((s, i) => (
              <div
                key={s.id}
                className={`rounded-2xl p-5 sm:p-6 transition ${
                  s.highlight
                    ? 'studio-accent-block'
                    : 'bg-[#FAF6EE] border border-[#1C2833]/12 hover:border-[#0F5A4A]/40 shadow-sm text-[#1C2833]'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                  <div className="flex items-start gap-3.5 min-w-0 flex-1">
                    {s.image && (
                      <img
                        src={resolveAssetUrl(s.image)}
                        alt={s.title}
                        className="w-16 h-20 sm:w-20 sm:h-24 rounded-xl object-cover object-top shrink-0 ring-1 ring-[#C49B47]/45"
                      />
                    )}
                    <div className="min-w-0">
                      <span
                        className={`text-[11px] font-semibold uppercase tracking-[0.18em] num-tabular ${
                          s.highlight ? 'text-[#C49B47]' : 'text-[#0F5A4A]'
                        }`}
                      >
                        0{i + 1} · {s.badge}
                      </span>
                      <h3
                        className={`text-lg sm:text-xl font-semibold mt-1 ${
                          s.highlight ? 'text-[#F9F6F0]' : 'text-[#1C2833]'
                        }`}
                      >
                        {s.title}
                      </h3>
                      <p
                        className={`text-xs mt-0.5 ${
                          s.highlight ? 'text-[#F9F6F0]/75' : 'text-[#1C2833]/60'
                        }`}
                      >
                        {s.duration}
                      </p>
                    </div>
                  </div>
                  <div className="text-right num-tabular">
                    <div
                      className={`text-xl sm:text-2xl font-semibold ${
                        s.highlight ? 'text-[#C49B47]' : 'text-[#1C2833]'
                      }`}
                    >
                      {s.price}
                    </div>
                    {s.oldPrice && (
                      <div
                        className={`text-xs line-through ${
                          s.highlight ? 'text-[#F9F6F0]/45' : 'text-[#1C2833]/40'
                        }`}
                      >
                        {s.oldPrice}
                      </div>
                    )}
                  </div>
                </div>
                <p
                  className={`text-sm leading-relaxed mb-4 ${
                    s.highlight ? 'text-[#F9F6F0]/90' : 'text-[#1C2833]/80'
                  }`}
                >
                  {s.subtitle}
                </p>
                <ul className="space-y-1.5 mb-5">
                  {s.deliverables.map((d, idx) => (
                    <li
                      key={idx}
                      className={`text-xs flex items-start gap-2 ${
                        s.highlight ? 'text-[#F9F6F0]/85' : 'text-[#1C2833]/75'
                      }`}
                    >
                      <Check
                        className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${
                          s.highlight ? 'text-[#C49B47]' : 'text-[#0F5A4A]'
                        }`}
                      />
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
                <div className="flex flex-wrap gap-2.5">
                  <button
                    onClick={() => onOpenBooking(s.title, s.prefillMessage)}
                    className="px-5 py-2.5 rounded-full btn-brand-gold text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    {s.ctaLabel}
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onSelectServiceDetail(s.id)}
                    className={`px-4 py-2.5 rounded-full text-xs font-medium transition ${
                      s.highlight
                        ? 'bg-[#F9F6F0]/14 hover:bg-[#F9F6F0]/22 text-[#F9F6F0]'
                        : 'bg-[#F9F6F0] hover:bg-[#0F5A4A]/10 text-[#1C2833] border border-[#1C2833]/12'
                    }`}
                  >
                    Подробнее об этапах
                  </button>
                </div>
              </div>
            ))}

            {renderOfferMandatoryBanner()}
          </div>
        )}

        {/* 2. SINGLE SERVICE DETAIL DRAWER */}
        {activeDrawer === 'service-detail' && (
          <div className="space-y-6 pb-4">
            <div className="rounded-2xl p-5 sm:p-6 studio-accent-block flex flex-col sm:flex-row gap-5 items-start">
              <img
                src={resolveAssetUrl(selectedService.image || SPECIALIST_PHOTOS.consult)}
                alt={selectedService.title}
                className="w-28 h-40 sm:w-32 sm:h-48 rounded-2xl object-cover object-top shrink-0 ring-1 ring-[#C49B47]/55"
              />
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-baseline justify-between gap-3">
                  <span className="text-xs font-semibold uppercase tracking-[0.18em] text-[#C49B47]">
                    {selectedService.badge}
                  </span>
                  <span className="text-2xl sm:text-3xl font-semibold text-[#C49B47] num-tabular">
                    {selectedService.price}
                  </span>
                </div>
                <p className="text-sm text-[#F9F6F0]/90 mt-3 leading-relaxed">
                  {selectedService.subtitle}
                </p>
                <p className="text-xs text-[#F9F6F0]/70 mt-2.5">Формат: {selectedService.duration}</p>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-[#0F5A4A] mb-3">
                Как выстроена работа
              </h4>
              <div className="space-y-3">
                {selectedService.howItWorks.map((step, i) => (
                  <div
                    key={i}
                    className="p-4 rounded-xl bg-[#FAF6EE] border border-[#1C2833]/10 flex gap-3.5 shadow-sm"
                  >
                    <span className="text-xs font-mono font-semibold text-[#0F5A4A] mt-0.5">
                      0{i + 1}
                    </span>
                    <p className="text-sm text-[#1C2833]/90 leading-relaxed">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-[#0F5A4A] mb-3">
                Ваш результат на руках
              </h4>
              <div className="space-y-2.5">
                {selectedService.deliverables.map((item, i) => (
                  <div key={i} className="flex items-start gap-2.5 text-sm text-[#1C2833]/90">
                    <Check className="w-4 h-4 text-[#0F5A4A] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {renderOfferMandatoryBanner()}

            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => onOpenBooking(selectedService.title, selectedService.prefillMessage)}
                className="px-6 py-3.5 rounded-full btn-brand-gold text-sm font-semibold inline-flex items-center gap-2"
              >
                {selectedService.ctaLabel}
                <ArrowUpRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onSelectServiceDetail('__back_catalog__')}
                className="px-5 py-3.5 rounded-full bg-[#FAF6EE] hover:bg-[#0F5A4A]/8 border border-[#1C2833]/12 text-sm font-medium text-[#1C2833] transition"
              >
                Все 4 формата
              </button>
            </div>
          </div>
        )}

        {/* 3. INTERACTIVE QUIZ / SYMPTOM NAVIGATOR */}
        {activeDrawer === 'quiz' && (
          <div className="space-y-6 pb-4">
            {!quizDone ? (
              <>
                <div className="flex items-center gap-2 text-xs text-[#1C2833]/65">
                  <span>Шаг {quizStep + 1} из 2</span>
                  <div className="flex-1 h-1.5 bg-[#1C2833]/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#0F5A4A] transition-all duration-300"
                      style={{ width: quizStep === 0 ? '50%' : '100%' }}
                    />
                  </div>
                </div>

                {quizStep === 0 ? (
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-[#1C2833]">
                      Какая задача сейчас на первом месте?
                    </h3>
                    {[
                      {
                        key: 'personal' as const,
                        label: 'Персональная консультация для себя или ребёнка (энергия, ЖКТ, анализы)',
                      },
                      {
                        key: 'family' as const,
                        label: 'Консультация «Мама + ребёнок» — единая система и общий семейный стол',
                      },
                      {
                        key: 'vip' as const,
                        label: 'Индивидуальное ведение за руку на месяц (или ведение беременности)',
                      },
                      {
                        key: 'guide' as const,
                        label: 'Практический гайд с готовыми возрастными схемами и ответами в чате',
                      },
                    ].map((opt) => (
                      <button
                        key={opt.key}
                        onClick={() => {
                          setQuizGoal(opt.key);
                          setQuizStep(1);
                        }}
                        className="w-full text-left p-4 rounded-xl bg-[#FAF6EE] hover:bg-[#0F5A4A]/6 border border-[#1C2833]/12 hover:border-[#0F5A4A]/45 transition text-sm font-medium text-[#1C2833] shadow-sm"
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-[#1C2833]">
                      Отметьте ваш предпочтительный темп работы:
                    </h3>
                    {[
                      'Пошаговая стратегия с чёткой системой без жёстких диет',
                      'Быстрый старт на ближайшей неделе',
                      'Удобное онлайн-время для консультации в будни или выходные',
                    ].map((pace, i) => (
                      <button
                        key={i}
                        onClick={() => setQuizDone(true)}
                        className="w-full text-left p-4 rounded-xl bg-[#FAF6EE] hover:bg-[#0F5A4A]/6 border border-[#1C2833]/12 hover:border-[#0F5A4A]/45 transition text-sm font-medium text-[#1C2833] shadow-sm"
                      >
                        {pace}
                      </button>
                    ))}
                  </div>
                )}

                <div className="pt-4 border-t border-[#1C2833]/12">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#0F5A4A] mb-3">
                    Частые симптомы, с которыми приходят клиенты
                  </p>
                  <div className="grid sm:grid-cols-2 gap-2.5">
                    {SYMPTOM_ITEMS.slice(0, 6).map((sym) => (
                      <div
                        key={sym.id}
                        className="p-3 rounded-xl bg-[#FAF6EE] border border-[#1C2833]/10 shadow-sm"
                      >
                        <div className="text-xs font-semibold text-[#1C2833]">{sym.title}</div>
                        <div className="text-[11px] text-[#1C2833]/55 mt-1">
                          Маркеры: {sym.markers.join(' · ')}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="rounded-2xl p-6 studio-accent-block space-y-4">
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-[#C49B47]">
                  <Sparkles className="w-3.5 h-3.5" /> Рекомендованный формат
                </span>
                <h3 className="text-2xl font-semibold text-[#F9F6F0]">{quizRecommendation.title}</h3>
                <p className="text-sm text-[#F9F6F0]/85 leading-relaxed">
                  {quizRecommendation.subtitle}
                </p>
                <div className="text-2xl font-semibold text-[#C49B47] num-tabular">
                  {quizRecommendation.price}
                </div>
                <div className="flex flex-wrap gap-3 pt-2">
                  <button
                    onClick={() =>
                      onOpenBooking(quizRecommendation.title, quizRecommendation.prefillMessage)
                    }
                    className="px-6 py-3 rounded-full btn-brand-gold text-xs font-semibold"
                  >
                    {quizRecommendation.ctaLabel}
                  </button>
                  <button
                    onClick={() => {
                      setQuizDone(false);
                      setQuizStep(0);
                    }}
                    className="px-4 py-3 rounded-full bg-[#F9F6F0]/14 text-xs text-[#F9F6F0] hover:bg-[#F9F6F0]/22 transition"
                  >
                    Пройти заново
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 4. LIVE INTERACTIVE BIOMARKER CHECKER */}
        {activeDrawer === 'biomarkers' && (
          <div className="space-y-6 pb-4">
            <div className="flex flex-wrap gap-2">
              {BIOMARKERS.map((b, i) => (
                <button
                  key={b.id}
                  onClick={() => handleSelectBioTab(i)}
                  className={`px-3.5 py-2 rounded-full text-xs font-semibold transition ${
                    bioIdx === i
                      ? 'bg-[#0F5A4A] text-[#F9F6F0] shadow-sm'
                      : 'bg-[#FAF6EE] text-[#1C2833]/80 hover:bg-[#0F5A4A]/8 border border-[#1C2833]/12'
                  }`}
                >
                  {b.name}
                </button>
              ))}
            </div>

            <div className="rounded-2xl p-5 sm:p-6 bg-[#FAF6EE] border border-[#1C2833]/12 shadow-sm space-y-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-[#0F5A4A]">
                    <Sliders className="w-3.5 h-3.5" /> Калькулятор вашего бланка
                  </span>
                  <h3 className="text-xl font-semibold text-[#1C2833] mt-1">{activeBio.name}</h3>
                  <p className="text-xs text-[#1C2833]/60">{activeBio.subtitle}</p>
                </div>

                {/* 16px (text-base) prevents iOS Safari auto-zoom on tap */}
                <div className="flex items-center gap-2 bg-[#F9F6F0] border border-[#0F5A4A]/30 rounded-xl px-3.5 py-2">
                  <label className="text-[11px] text-[#1C2833]/65">Ваш результат:</label>
                  <input
                    type="number"
                    inputMode="decimal"
                    step={activeBio.step}
                    min={activeBio.scaleMin}
                    max={activeBio.scaleMax}
                    value={userLabValue}
                    onChange={(e) => setUserLabValue(parseFloat(e.target.value) || 0)}
                    className="w-16 bg-transparent text-right text-base font-semibold text-[#1C2833] num-tabular focus:outline-none"
                  />
                  <span className="text-xs text-[#1C2833]/60">{activeBio.unit}</span>
                </div>
              </div>

              <div className="space-y-1">
                <input
                  type="range"
                  min={activeBio.scaleMin}
                  max={activeBio.scaleMax}
                  step={activeBio.step}
                  value={clampedUserVal}
                  onChange={(e) => setUserLabValue(parseFloat(e.target.value))}
                  className="w-full accent-[#0F5A4A] cursor-pointer h-2 bg-[#1C2833]/10 rounded-lg"
                />
                <div className="flex justify-between text-[10px] text-[#1C2833]/50 num-tabular">
                  <span>{activeBio.scaleMin}</span>
                  <span>Потяните ползунок или введите цифру</span>
                  <span>
                    {activeBio.scaleMax} {activeBio.unit}
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <div className="flex flex-wrap justify-between gap-1 text-[11px] text-[#1C2833]/65 num-tabular">
                  <span>
                    Бланк: {activeBio.labRefMin}–{activeBio.labRefMax} {activeBio.unit}
                  </span>
                  <span className="text-[#0F5A4A] font-semibold">
                    Оптимум: {activeBio.optimumMin}–{activeBio.optimumMax} {activeBio.unit}
                  </span>
                </div>

                <div className="relative h-4 rounded-full bg-[#F9F6F0] border border-[#1C2833]/12">
                  <div
                    className="absolute top-0 bottom-0 bg-[#1C2833]/12 rounded-full"
                    style={{
                      left: `${(activeBio.labRefMin / activeBio.scaleMax) * 100}%`,
                      width: `${
                        ((activeBio.labRefMax - activeBio.labRefMin) / activeBio.scaleMax) * 100
                      }%`,
                    }}
                  />
                  <div
                    className="absolute top-0 bottom-0 bg-[#0F5A4A] rounded-full"
                    style={{
                      left: `${(activeBio.optimumMin / activeBio.scaleMax) * 100}%`,
                      width: `${
                        ((activeBio.optimumMax - activeBio.optimumMin) / activeBio.scaleMax) * 100
                      }%`,
                    }}
                  />
                  <div
                    className="absolute -top-1.5 -bottom-1.5 w-1.5 bg-[#C49B47] rounded-full shadow-md transition-all duration-150"
                    style={{ left: `${pinPercent}%` }}
                  />
                </div>
              </div>

              {/* Diagnostic Result Callout (Акцентный блок #0F5A4A) */}
              <div className="rounded-xl p-4 studio-accent-block space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className={`text-[11px] font-semibold px-3 py-1 rounded-full ${bioZone.badgeStyle}`}>
                    {bioZone.badge}
                  </span>
                  <span className="text-xs text-[#F9F6F0]/80 num-tabular">
                    Ваш маркер:{' '}
                    <strong className="text-[#C49B47]">
                      {userLabValue} {activeBio.unit}
                    </strong>
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-[#F9F6F0]/90 leading-relaxed">{bioZone.summary}</p>
                <div className="pt-2 border-t border-[#F9F6F0]/15">
                  <div className="text-[11px] text-[#F9F6F0]/70 mb-1.5">
                    Что Екатерина обязательно смотрит в связке с этим показателем:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {activeBio.coMarkers.map((cm, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] px-2.5 py-1 rounded-full bg-[#F9F6F0]/12 border border-[#F9F6F0]/20 text-[#F9F6F0]"
                      >
                        {cm}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={() =>
                  onOpenBooking(
                    SERVICES[0].title,
                    `Здравствуйте, Екатерина! Проверила на сайте свой показатель (${activeBio.name}: ${userLabValue} ${activeBio.unit}). Хочу записаться на персональную консультацию.`
                  )
                }
                className="w-full sm:w-auto px-5 py-3 rounded-full btn-brand-gold text-xs font-semibold inline-flex items-center justify-center gap-2 num-tabular"
              >
                Разобрать на консультации ({userLabValue} {activeBio.unit})
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="rounded-2xl p-5 sm:p-6 bg-[#FAF6EE] border border-[#1C2833]/12 shadow-sm space-y-4">
              <div className="flex items-center gap-2.5">
                <FileText className="w-5 h-5 text-[#0F5A4A] shrink-0" />
                <div>
                  <h4 className="text-sm sm:text-base font-semibold text-[#1C2833]">
                    Как сопоставляются показатели на Персональной консультации
                  </h4>
                  <p className="text-xs text-[#1C2833]/60">
                    Екатерина оценивает не отдельные цифры, а целостную биохимическую связку взрослого или ребёнка
                  </p>
                </div>
              </div>
              <div className="grid sm:grid-cols-3 gap-3 text-xs num-tabular">
                <div className="p-3.5 rounded-xl bg-[#F9F6F0] border border-[#1C2833]/10">
                  <div className="text-[#1C2833]/55">Общий белок</div>
                  <div className="text-base font-semibold text-[#1C2833] mt-0.5">67 г/л</div>
                  <div className="text-[#0F5A4A] font-medium mt-1">Оптимум 73–78 · дефицит субстрата</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#F9F6F0] border border-[#1C2833]/10">
                  <div className="text-[#1C2833]/55">Ферритин</div>
                  <div className="text-base font-semibold text-[#1C2833] mt-0.5">16 мкг/л</div>
                  <div className="text-[#0F5A4A] font-medium mt-1">Оптимум 55–85 · тканевая гипоксия</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#F9F6F0] border border-[#1C2833]/10">
                  <div className="text-[#1C2833]/55">Гомоцистеин</div>
                  <div className="text-base font-semibold text-[#1C2833] mt-0.5">10.4 мкмоль/л</div>
                  <div className="text-[#0F5A4A] font-medium mt-1">Оптимум 5–7 · кофакторы B9 / B12</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 5. CASES WITH VISUAL LAB DELTAS, INTERACTIVE DIPLOMA VERIFICATION & FAQ */}
        {activeDrawer === 'cases' && (
          <div className="space-y-8 pb-4">
            <div className="space-y-4">
              <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-[#0F5A4A]">
                Динамика показателей «Точка А → Результат»
              </h3>
              {CASE_REVIEWS.map((c) => (
                <div
                  key={c.id}
                  className="p-5 rounded-2xl bg-[#FAF6EE] border border-[#1C2833]/12 shadow-sm space-y-3.5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#1C2833]/65">
                    <span>
                      <strong className="text-[#1C2833] font-semibold">{c.clientName}</strong> ·{' '}
                      {c.clientMeta}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-[#0F5A4A] text-[#F9F6F0] font-medium">
                      {c.categoryLabel}
                    </span>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-2.5 pt-1">
                    {c.labDelta.map((m, mIdx) => (
                      <div
                        key={mIdx}
                        className="p-3 rounded-xl bg-[#F9F6F0] border border-[#1C2833]/10 space-y-2 num-tabular"
                      >
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-[#1C2833]/75 font-medium">{m.marker}</span>
                          <span className="text-[#0F5A4A] font-medium">{m.target}</span>
                        </div>
                        <div className="flex items-baseline justify-between gap-2">
                          <span className="text-xs text-[#1C2833]/45 line-through">{m.before}</span>
                          <span className="text-xs text-[#C49B47] font-bold">→</span>
                          <span className="text-sm font-semibold text-[#0F5A4A]">{m.after}</span>
                        </div>
                        <div className="space-y-1">
                          <div className="h-1 w-full bg-[#1C2833]/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#1C2833]/30 rounded-full"
                              style={{ width: `${m.beforePct}%` }}
                            />
                          </div>
                          <div className="h-1.5 w-full bg-[#1C2833]/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#0F5A4A] rounded-full"
                              style={{ width: `${m.afterPct}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="text-xs text-[#1C2833]/90 leading-relaxed">
                    <strong className="text-[#1C2833]">Итог работы:</strong> {c.resultB}
                  </div>
                  <p className="text-xs italic text-[#1C2833]/70 pt-2 border-t border-[#1C2833]/10 leading-relaxed">
                    «{c.quote}»
                  </p>
                </div>
              ))}
            </div>

            <div className="space-y-3">
              <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-[#0F5A4A] flex items-center gap-2">
                <Award className="w-4 h-4 shrink-0" /> Профильное образование (1 784 ак. часа · нажмите для проверки)
              </h3>
              {CREDENTIALS.map((cr, idx) => {
                const isExp = expandedDiploma === idx;
                return (
                  <div
                    key={idx}
                    className="rounded-2xl bg-[#FAF6EE] border border-[#1C2833]/12 overflow-hidden transition shadow-sm"
                  >
                    <button
                      onClick={() => setExpandedDiploma(isExp ? null : idx)}
                      className="w-full p-4 text-left flex items-start justify-between gap-3 hover:bg-[#F9F6F0]/60"
                    >
                      <div className="space-y-1">
                        <div className="text-[11px] text-[#0F5A4A] font-semibold num-tabular">
                          {cr.year} · {cr.hours}
                        </div>
                        <div className="text-sm font-semibold text-[#1C2833]">{cr.program}</div>
                        <div className="text-xs text-[#1C2833]/65">{cr.institution}</div>
                      </div>
                      <ChevronDown
                        className={`w-4 h-4 shrink-0 mt-1 text-[#0F5A4A] transition-transform ${
                          isExp ? 'rotate-180' : ''
                        }`}
                      />
                    </button>

                    {isExp && (
                      <div className="px-4 pb-4 pt-3 studio-accent-block rounded-b-2xl space-y-2.5">
                        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-[#F9F6F0] bg-[#F9F6F0]/10 px-3 py-1.5 rounded-lg border border-[#C49B47]/35">
                          <span>Специалист: {brand.name}</span>
                          <span className="text-[#C49B47]">{cr.docCode}</span>
                        </div>
                        <div className="text-[11px] text-[#F9F6F0]/75">Ключевые модули программы:</div>
                        <ul className="space-y-1">
                          {cr.modules.map((mod, mIdx) => (
                            <li key={mIdx} className="text-xs text-[#F9F6F0]/90 flex items-start gap-2">
                              <Check className="w-3.5 h-3.5 text-[#C49B47] shrink-0 mt-0.5" />
                              <span>{mod}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="space-y-2.5">
              <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-[#0F5A4A]">
                Частые вопросы
              </h3>
              {FAQ_ITEMS.map((f, idx) => (
                <div
                  key={idx}
                  className="rounded-xl bg-[#FAF6EE] border border-[#1C2833]/12 overflow-hidden shadow-sm"
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                    className="w-full p-4 text-left text-sm font-semibold text-[#1C2833] flex items-center justify-between gap-3"
                  >
                    <span>{f.question}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-[#0F5A4A] shrink-0 transition-transform ${
                        openFaq === idx ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {openFaq === idx && (
                    <div className="px-4 pb-4 text-xs text-[#1C2833]/80 leading-relaxed">
                      {f.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 6. BOOKING CONCIERGE DRAWER */}
        {activeDrawer === 'booking' && (
          <div className="space-y-6 pb-4">
            {/* Editorial Booking Welcome Card (Photo 2 — Акцентный блок #0F5A4A) */}
            <div className="p-4 rounded-2xl studio-accent-block flex items-center gap-4">
              <img
                src={resolveAssetUrl(SPECIALIST_PHOTOS.booking)}
                alt="Екатерина Пименова — запись на консультацию"
                className="w-20 h-28 sm:w-24 sm:h-36 rounded-xl object-cover shrink-0 ring-1 ring-[#C49B47]/55"
              />
              <div className="space-y-1.5 min-w-0">
                <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#C49B47]">
                  <span className="w-2 h-2 rounded-full bg-[#C49B47] animate-pulse" />
                  Записаться на консультацию
                </div>
                <div className="text-sm sm:text-base font-semibold text-[#F9F6F0] leading-snug">
                  {brand.name}
                </div>
                <p className="text-xs text-[#F9F6F0]/80 leading-relaxed">
                  Выберите удобный мессенджер с готовым текстом обращения или оставьте контакт —
                  согласуем дату и удобное время встречи.
                </p>
              </div>
            </div>

            {renderOfferMandatoryBanner()}

            <div className="space-y-3">
              <input
                type="text"
                placeholder="Ваше имя"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-[#FAF6EE] border border-[#1C2833]/15 text-base sm:text-sm text-[#1C2833] placeholder:text-[#1C2833]/40 focus:outline-none focus:border-[#0F5A4A]"
              />
              <input
                type="tel"
                placeholder="Телефон или @username в Telegram"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-[#FAF6EE] border border-[#1C2833]/15 text-base sm:text-sm text-[#1C2833] placeholder:text-[#1C2833]/40 focus:outline-none focus:border-[#0F5A4A]"
              />

              <div className="space-y-1.5">
                <label className="block text-[11px] font-medium text-[#1C2833]/65">
                  Когда вам комфортно получить ответ от Екатерины?
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'day' as const, label: 'Завтра днём' },
                    { id: 'evening' as const, label: 'Вечером' },
                    { id: 'any' as const, label: 'В любое время' },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setReplyWindow(opt.id)}
                      className={`py-2.5 px-2 rounded-xl text-xs font-semibold border transition ${
                        replyWindow === opt.id
                          ? 'bg-[#0F5A4A] text-[#F9F6F0] border-[#0F5A4A]'
                          : 'bg-[#FAF6EE] text-[#1C2833]/75 border-[#1C2833]/12 hover:border-[#0F5A4A]/40'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <textarea
                rows={3}
                value={clientNote || bookingPrefill.message}
                onChange={(e) => setClientNote(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-[#FAF6EE] border border-[#1C2833]/15 text-base sm:text-sm text-[#1C2833] placeholder:text-[#1C2833]/40 focus:outline-none focus:border-[#0F5A4A]"
              />
            </div>

            <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
              <a
                href={tgUrl}
                target="_blank"
                rel="noreferrer"
                className="py-3.5 px-3 rounded-xl btn-brand-gold font-semibold text-xs flex items-center justify-center gap-1.5"
              >
                <Send className="w-4 h-4 shrink-0" />
                Telegram
              </a>
              <a
                href={waUrl}
                target="_blank"
                rel="noreferrer"
                className="py-3.5 px-3 rounded-xl bg-[#FAF6EE] hover:bg-[#0F5A4A]/8 border border-[#1C2833]/15 text-[#1C2833] font-semibold text-xs flex items-center justify-center gap-1.5 transition shadow-sm"
              >
                <PhoneCall className="w-4 h-4 text-[#0F5A4A] shrink-0" />
                WhatsApp
              </a>
              <a
                href={brand.maxLink}
                target="_blank"
                rel="noreferrer"
                className="py-3.5 px-3 rounded-xl bg-[#FAF6EE] hover:bg-[#0F5A4A]/8 border border-[#1C2833]/15 text-[#1C2833] font-semibold text-xs flex items-center justify-center gap-1.5 transition shadow-sm"
              >
                <MessageCircle className="w-4 h-4 text-[#0F5A4A] shrink-0" />
                MAX
              </a>
            </div>

            {!bookingSent ? (
              <button
                onClick={() => setBookingSent(true)}
                className="w-full py-3.5 px-4 rounded-full border border-[#0F5A4A]/35 bg-[#FAF6EE] hover:bg-[#0F5A4A]/6 text-[#0F5A4A] text-xs font-semibold transition"
              >
                Оставить тихую заявку + открыть подарок «Базовый чекап»
              </button>
            ) : (
              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-[#FAF6EE] border border-[#0F5A4A]/30 text-xs text-[#1C2833] flex items-center gap-2.5 shadow-sm">
                  <ShieldCheck className="w-4 h-4 text-[#0F5A4A] shrink-0" />
                  Заявка сохранена ({replyWindowLabel}). Для мгновенной связи также можно нажать кнопку Telegram или WhatsApp выше.
                </div>
                <div className="p-5 rounded-2xl studio-accent-block space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#C49B47]">
                    <Gift className="w-4 h-4 shrink-0" />
                    Ваш бонус: Базовый ежегодный чекап без лишних трат
                  </div>
                  <p className="text-xs text-[#F9F6F0]/85 leading-relaxed">
                    ОАК с лейкоцитарной формулой и СОЭ · Общий белок и альбумин · Ферритин + сыв. железо + трансферрин · Витамин D (25-OH) · ТТГ, Т3 св., Т4 св. · Инсулин и глюкоза натощак · Гомоцистеин · АЛТ, АСТ, билирубин фракционно · Копрограмма.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 7. PUBLIC OFFER AGREEMENT (ДОГОВОР ПУБЛИЧНОЙ ОФЕРТЫ) */}
        {activeDrawer === 'legal' && (
          <div className="space-y-5 pb-6 text-xs sm:text-[13px] text-[#1C2833]/85 leading-relaxed">
            <div className="p-4 sm:p-5 rounded-2xl studio-accent-block space-y-2">
              <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#C49B47]">
                Обязательно к ознакомлению перед записью
              </div>
              <div className="text-base sm:text-lg font-semibold text-[#F9F6F0]">
                Договор публичной оферты на оказание информационно-консультационных услуг
              </div>
              <p className="text-xs text-[#F9F6F0]/80">
                Исполнитель: {brand.legalEntity} (ИНН {brand.inn}, ОГРНИП {brand.ogrnip}). Настоящий
                документ является официальным публичным предложением (офертой) в соответствии со
                ст.{'\u00A0'}435 и ч.{'\u00A0'}2 ст.{'\u00A0'}437 Гражданского кодекса РФ.
              </p>
            </div>

            <div className="space-y-4 p-4 sm:p-6 rounded-2xl bg-[#FAF6EE] border border-[#1C2833]/12 shadow-sm">
              <div className="space-y-1.5">
                <h4 className="text-sm font-semibold text-[#0F5A4A]">
                  1. Предмет договора и характер услуг
                </h4>
                <p>
                  1.1. Исполнитель ({brand.name}) оказывает Заказчику информационно-консультационные
                  услуги в области рационального питания, коррекции пищевых привычек, модификации
                  образа жизни и превентивной нутритивной поддержки по выбранному формату:
                  «Персональная консультация (взрослый или ребёнок)», «Консультация „Мама + ребёнок“»,
                  «Индивидуальное ведение» либо предоставление электронного пособия «Гайд».
                </p>
                <p>
                  1.2. Услуги носят исключительно информационно-просветительский и рекомендательный
                  характер, не являются медицинской деятельностью, постановкой диагноза или
                  назначением медикаментозного лечения и не заменяют очного обращения к врачу.
                </p>
              </div>

              <div className="space-y-1.5">
                <h4 className="text-sm font-semibold text-[#0F5A4A]">
                  2. Порядок записи, согласования даты и времени и акцепт оферты
                </h4>
                <p>
                  2.1. Перед оплатой и записью Заказчик обязан полностью ознакомиться с текстом
                  настоящей Оферты и предварительно согласовать с Исполнителем в мессенджере
                  (Telegram, WhatsApp или MAX) свободную дату и время онлайн-встречи.
                </p>
                <p>
                  2.2. Полным и безоговорочным акцептом настоящей Оферты (ст.{'\u00A0'}438 ГК РФ)
                  признаётся внесение Заказчиком 100% предоплаты выбранного формата услуг после
                  согласования даты и времени консультации (либо оплата электронного «Гайда»).
                </p>
                <p>
                  2.3. Анкета и имеющиеся результаты лабораторных исследований направляются Заказчиком
                  не позднее чем за 48 часов до согласованного времени онлайн-встречи для качественной
                  предварительной подготовки Исполнителя.
                </p>
              </div>

              <div className="space-y-1.5">
                <h4 className="text-sm font-semibold text-[#0F5A4A]">
                  3. Правила переноса встречи и сроки сопровождения
                </h4>
                <p>
                  3.1. Перенос согласованной онлайн-консультации по инициативе Заказчика
                  возможен без потери оплаты при уведомлении Исполнителю не позднее чем за 24 часа до
                  начала встречи. При неявке Заказчика без предупреждения менее чем за 24 часа услуга
                  в части проведения созвона считается оказанной.
                </p>
                <p>
                  3.2. Обратная связь в чате (7 дней после консультации либо ежедневное ведение в
                  рамках «Индивидуального ведения» сроком 1 месяц) осуществляется в рабочие дни в
                  согласованные дневные часы.
                </p>
              </div>

              <div className="space-y-1.5">
                <h4 className="text-sm font-semibold text-[#0F5A4A]">
                  4. Ответственность сторон и авторские права
                </h4>
                <p>
                  4.1. Заказчик обязуется предоставить достоверные сведения о состоянии здоровья,
                  известных аллергических реакциях, непереносимостях, хронических заболеваниях,
                  беременности/лактации и принимаемых препаратах. При наличии острых состояний или
                  необходимости применения рецептурных средств Заказчик обязуется проконсультироваться
                  с лечащим врачом (педиатром — в отношении ребёнка).
                </p>
                <p>
                  4.2. Все авторские материалы Исполнителя (индивидуальные программы, рационы, схемы,
                  «Гайд») предназначены исключительно для личного (семейного) использования Заказчиком.
                  Копирование, перепродажа, публикация в открытом доступе и передача третьим лицам
                  запрещены (ст.{'\u00A0'}1229, 1301 ГК РФ).
                </p>
              </div>

              <div className="space-y-1.5">
                <h4 className="text-sm font-semibold text-[#0F5A4A]">
                  5. Порядок возврата и конфиденциальность (ФЗ-152)
                </h4>
                <p>
                  5.1. Возврат денежных средств при отказе Заказчика от услуги до начала её оказания
                  производится в соответствии со ст.{'\u00A0'}32 Закона РФ «О защите прав потребителей»
                  за вычетом фактически понесённых расходов и стоимости уже выполненных этапов работы.
                  Услуга по предоставлению цифрового «Гайда» считается оказанной в полном объёме в
                  момент направления ссылки/доступа к материалам и чату.
                </p>
                <p>
                  5.2. Персональные данные и результаты анализов Заказчика обрабатываются строго
                  конфиденциально в соответствии с Федеральным законом №{'\u00A0'}152-ФЗ «О персональных
                  данных» исключительно для оказания выбранной услуги и не передаются третьим лицам.
                </p>
              </div>

              <div className="pt-3 border-t border-[#1C2833]/12 text-[11.5px] text-[#1C2833]/70 num-tabular">
                <strong className="text-[#1C2833]">Реквизиты Исполнителя:</strong> {brand.legalEntity} ·
                ИНН {brand.inn} · ОГРНИП {brand.ogrnip} · Email: {brand.email} · Тел./WhatsApp:{' '}
                {brand.whatsappDisplay}
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-1">
              <button
                type="button"
                onClick={() => onOpenDrawer('booking')}
                className="px-6 py-3.5 rounded-full btn-brand-gold text-xs sm:text-sm font-semibold inline-flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                Ознакомлен(а) — согласовать дату и время
                <ArrowUpRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onOpenDrawer('catalog')}
                className="px-4 py-3.5 rounded-full bg-[#FAF6EE] hover:bg-[#0F5A4A]/8 border border-[#1C2833]/12 text-xs sm:text-sm font-medium text-[#1C2833] transition"
              >
                К тарифам
              </button>
            </div>
          </div>
        )}

        {/* 8. BRAND CUSTOMIZER */}
        {activeDrawer === 'brand' && (
          <div className="space-y-4 pb-4">
            <p className="text-xs text-[#1C2833]/70">
              Подставьте своё имя, Telegram, WhatsApp и реквизиты — они мгновенно обновятся на всём
              3D-сайте и сохранятся в браузере.
            </p>
            {(
              [
                ['name', 'Имя и фамилия специалиста'],
                ['role', 'Специализация'],
                ['telegramUsername', 'Telegram username (без @)'],
                ['whatsappPhone', 'WhatsApp номер (только цифры, например 79991234567)'],
                ['whatsappDisplay', 'Отображаемый телефон'],
                ['legalEntity', 'ИП / Самозанятый'],
                ['inn', 'ИНН'],
              ] as const
            ).map(([key, label]) => (
              <div key={key}>
                <label className="block text-[11px] font-medium text-[#1C2833]/65 mb-1">
                  {label}
                </label>
                <input
                  type="text"
                  value={draftBrand[key]}
                  onChange={(e) => setDraftBrand({ ...draftBrand, [key]: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FAF6EE] border border-[#1C2833]/15 text-base sm:text-xs text-[#1C2833]"
                />
              </div>
            ))}
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => {
                  onSaveBrand(draftBrand);
                  onClose();
                }}
                className="px-5 py-2.5 rounded-full btn-brand-gold text-xs font-semibold"
              >
                Сохранить реквизиты
              </button>
              <button
                onClick={() => {
                  setDraftBrand(DEFAULT_BRAND);
                  onResetBrand();
                }}
                className="px-4 py-2.5 rounded-full bg-[#FAF6EE] border border-[#1C2833]/15 text-xs font-medium text-[#1C2833]/80 flex items-center gap-1.5"
              >
                <Settings className="w-3.5 h-3.5 text-[#0F5A4A]" /> Сбросить
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
