/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: [
          'Inter',
          '-apple-system',
          'BlinkMacSystemFont',
          '"Segoe UI"',
          'Roboto',
          'sans-serif',
        ],
        serif: [
          'Georgia',
          '"Times New Roman"',
          'serif',
        ],
      },
      colors: {
        obsidian: {
          950: '#040508',
          900: '#080A0F',
          850: '#0D1017',
          800: '#131822',
        },
      },
    },
  },
  plugins: [],
};
